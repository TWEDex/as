#!/usr/bin/env python3
# patch12: adaptive pathfinding (find another route instead of breaking / standing still)
#          + water safety (stop sitting in water until we drown while "hiding")
import sys

F = 'bot.js'
s = open(F, encoding='utf8').read()
done = []

def sub(name, old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        print('!! %-22s found %d (expected %d)' % (name, n, count)); sys.exit(1)
    s = s.replace(old, new, count); done.append(name)

# =============================================== A. WATER: don't drown in our own hideout
sub('hide-wet', """  if (botWet(b) && !b.__wallBury && !inCollapseZone(b)) { log('HIDE wet -> wallBury at', pos(b)); await wallBury(b, Math.min(ms || 90000, 120000)); return }""",
    """  // BUG (owner: "\u0438\u0434\u0451\u0448\u044c \u043a \u0432\u043e\u0434\u0435, \u0441\u0438\u0434\u0438\u0448\u044c \u0442\u0430\u043c \u0438 \u0437\u0430\u0434\u044b\u0445\u0430\u0435\u0448\u044c\u0441\u044f"): being wet used to mean "dig a wall
  // pocket at water level and sit in it for up to 2 minutes". The pocket is a sealed coffin -
  // wet inside, hiding set, so every escape routine refused to run. Dry land first, pocket only
  // as a last resort and only for 30s.
  if (botWet(b) && !b.__wallBury && !inCollapseZone(b)) {
    const dry = nearestDry(b, 16)
    if (dry) {
      log('HIDE wet -> shore at ' + dry.x + ' ' + dry.y + ' ' + dry.z + ' (d=' + (dry.d || 0).toFixed(1) + ')')
      try { b.pathfinder.setGoal(null) } catch (e) {}
      b.__dryRunUntil = Date.now() + 20000
      const ok = await b.pathfinder.goto(new goals.GoalNear(dry.x, dry.y, dry.z, 1)).then(() => true).catch(() => false)
      log('HIDE shore reached=' + ok + ' at ' + pos(b))
      return
    }
    log('HIDE wet -> wallBury capped 30s at', pos(b))
    await wallBury(b, 30000)
    return
  }""")

sub('bury-flag', """  b.__wallBury = true
  lastHideAt = Date.now()""", """  b.__wallBury = true
  b.__buryAbort = false
  lastHideAt = Date.now()""")

sub('bury-waitloop', """    const lim = Math.max(20000, waitMs || 60000)
    while (Date.now() - t0 < lim && b.entity && b.health > 0) {
      // dawn: skeletons burn, leave even if night budget remains
      if (Date.now() - t0 > 15000 && !isNight(b) && !isDusk(b)) break
      await sleep(800)
    }""",
    """    const lim = Math.min(30000, Math.max(20000, waitMs || 60000))
    while (Date.now() - t0 < lim && b.entity && b.health > 0) {
      // dawn: skeletons burn, leave even if night budget remains
      if (Date.now() - t0 > 15000 && !isNight(b) && !isDusk(b)) break
      // a pocket that fills with water, or low health, ends the wait immediately
      if (b.__buryAbort || botWet(b) || b.health < 12) { log('WALL_BURY abort wet/lowhp hp=' + Math.round(b.health) + ' at ' + pos(b)); break }
      await sleep(800)
    }""")

sub('watersafety-fn', """// ==================== AUDIT: a survival report card, every 4 minutes ====================""",
    """// ==================== WATER SAFETY: never sit in water until we drown ====================
// Puff used to walk into water, then get "owned" by a routine (hiding / wallBury / fleeing)
// that disabled the stuck guard AND the dry-out logic, so he bobbed there until he drowned -
// dozens of deaths with hp going 20 -> 0 while the log showed nothing but silence.
let waterSafeAt = 0
function wetNow (b) {
  try {
    if (!b.entity) return { feet: false, head: false }
    const ft = b.entity.position.floored()
    const f = b.blockAt(ft), h = b.blockAt(ft.offset(0, 1, 0))
    return { feet: !!(b.entity.isInWater || (f && /water/.test(f.name))), head: !!(h && /water/.test(h.name)) }
  } catch (e) { return { feet: false, head: false } }
}
function startWaterSafety (b) {
  if (b.__waterSafe) clearInterval(b.__waterSafe)
  b.__waterSafe = setInterval(() => {
    try {
      if (b !== bot) { if (b.__waterSafe) { clearInterval(b.__waterSafe); b.__waterSafe = null }; return }
      if (!b.entity || !b.isAlive || b.health <= 0) return
      const now = Date.now()
      const w = wetNow(b)
      if (w.feet || w.head) { if (!b.__wetSince) b.__wetSince = now } else { b.__wetSince = 0; return }
      const wetFor = now - b.__wetSince
      let air = null
      try { if (typeof b.oxygenLevel === 'number' && isFinite(b.oxygenLevel)) air = b.oxygenLevel } catch (e) {}
      // head under water, or 7s of bobbing, or the air bar running out = act NOW
      const panic = w.head || wetFor > 7000 || (air !== null && air < 9)
      if (!panic) return
      if (now - waterSafeAt < 4000) return
      waterSafeAt = now
      stats.waterEscapes = (stats.waterEscapes || 0) + 1
      log('WATER_SAFETY wet=' + (wetFor / 1000).toFixed(0) + 's head=' + (w.head ? 1 : 0) + ' air=' + air +
        ' hiding=' + hiding + ' bury=' + !!b.__wallBury + ' flee=' + !!b.__fleeing + ' at ' + pos(b))
      // drop every routine that owns us: being "hidden" is worthless if we are drowning
      try { hiding = false } catch (e) {}
      b.__buryAbort = true
      b.__wallBury = false
      b.__burying = false
      b.__fleeing = false
      try { b.pathfinder.setGoal(null) } catch (e) {}
      manualLockUntil = Math.min(manualLockUntil, now)
      jumpLockUntil = Math.min(jumpLockUntil, now)
      const dry = nearestDry(b, 22)
      if (dry) {
        log('WATER_SAFETY -> shore ' + dry.x + ' ' + dry.y + ' ' + dry.z + ' d=' + (dry.d || 0).toFixed(1))
        b.__lastGoal = { x: dry.x, y: dry.y, z: dry.z }
        try {
          const yaw = Math.atan2(-(dry.x + 0.5 - b.entity.position.x), dry.z + 0.5 - b.entity.position.z)
          b.look(yaw, w.head ? -0.5 : 0, true).catch(() => {})
        } catch (e) {}
        // swim/stride for the shore immediately, pathing follows
        try { b.setControlState('forward', true); b.setControlState('jump', true); b.setControlState('sprint', true) } catch (e) {}
        setTimeout(() => { try { b.setControlState('forward', false); b.setControlState('jump', false); b.setControlState('sprint', false) } catch (e) {} }, 2600)
        try { b.pathfinder.setGoal(new goals.GoalNear(dry.x, dry.y, dry.z, 1)) } catch (e) {}
      } else {
        log('WATER_SAFETY no shore -> pillar out at ' + pos(b))
        try { escapeWaterPillar(b) } catch (e) {}
      }
      // flags that never clear leave us standing still while mobs chew on us
      if (hiding && now - lastHideAt > 45000) { hiding = false; log('WATCHDOG hiding cleared ' + Math.round((now - lastHideAt) / 1000) + 's') }
      if (b.__fleeing && b.__fleeStart && now - b.__fleeStart > 25000) { b.__fleeing = false; log('WATCHDOG fleeing cleared ' + Math.round((now - b.__fleeStart) / 1000) + 's') }
    } catch (e) {}
  }, 400)
}

// ==================== AUDIT: a survival report card, every 4 minutes ====================""")

sub('watersafety-call', """    try { startAudit(b) } catch (e) { log('AUDIT_ERR', e && e.message) }""",
    """    try { startAudit(b) } catch (e) { log('AUDIT_ERR', e && e.message) }
    try { startWaterSafety(b) } catch (e) { log('WATERSAFE_ERR', e && e.message) }""")

sub('audit-extra', """' dug=' + (stats.dug || 0) + ' detours=' + (stats.detours || 0) +""",
    """' dug=' + (stats.dug || 0) + ' detours=' + (stats.detours || 0) +
        ' pffail=' + (stats.pfFail || 0) + ' pfdetour=' + (stats.pfDetour || 0) + ' wateresc=' + (stats.waterEscapes || 0) +""")

# =============================================== B. PATHFINDING: adaptive + route-around
sub('stuckspots', """function clampXZ (x, z) {""",
    """// Where we recently failed to move. Two uses: the detour search skips these sides, and the
// stuck guard escalates faster if we come back to the same wall twice.
let stuckSpots = []
function noteStuckSpot (b) {
  try {
    if (!b.entity || !fin3(b.entity.position)) return
    const p = b.entity.position
    stuckSpots.push({ x: p.x, z: p.z, t: Date.now() })
    const cut = Date.now() - 600000
    stuckSpots = stuckSpots.filter(s => s.t > cut)
    while (stuckSpots.length > 80) stuckSpots.shift()
  } catch (e) {}
}
function stuckSpotNear (b, x, z, r) {
  const cut = Date.now() - 600000
  for (const s of stuckSpots) { if (s.t > cut && Math.hypot(s.x - x, s.z - z) < (r || 4)) return true }
  return false
}

function clampXZ (x, z) {""")

sub('smartgoto', """function wrapLeashGoals (b) {
  const pf = b.pathfinder
  if (!pf || pf.__leashWrapped) return
  pf.__leashWrapped = true""",
    """// ---- adaptive path planning ----
// "No path to the goal!" used to be a dead end: we stood still, the stuck guard hopped in
// place, and the only remaining trick was to dig. Now a failed path is retried around the
// obstacle: wider arrival radius first, then a perpendicular detour, then we give up cleanly
// and let the director pick something reachable. Budget per attempt grows with distance and
// shrinks after repeated failures, so short walks stay snappy.
function pfTune (b, dist) {
  try {
    const pf = b.pathfinder
    pf.thinkTimeout = dist > 90 ? 9000 : dist > 40 ? 7000 : dist > 16 ? 5000 : 3500
    if (!b.__pfSearch) b.__pfSearch = pf.searchRadius || 100
    pf.tickTimeout = 45
  } catch (e) {}
}
function pfAdapt (b, ok) {
  try {
    const pf = b.pathfinder
    if (ok) {
      if (b.__pfFailStreak) log('PF_RECOVERED after ' + b.__pfFailStreak + ' fails')
      b.__pfFailStreak = 0
      if (pf.searchRadius !== 100) { pf.searchRadius = 100; log('PF_TUNE searchRadius=100 (path found)') }
    } else {
      b.__pfFailStreak = (b.__pfFailStreak || 0) + 1
      const ns = Math.max(48, Math.round((pf.searchRadius || 100) * 0.75))
      if (pf.searchRadius !== ns) { pf.searchRadius = ns; log('PF_TUNE searchRadius=' + ns + ' after ' + b.__pfFailStreak + ' fails') }
    }
  } catch (e) {}
}
function pfOwned (b) {
  // while an escape routine drives us, planning must not fight it
  return !!(b.__wallBury || b.__burying || b.__wetPillar || b.__pillarEscape || hiding || tunneling || diggingUp)
}
async function smartGoto (b, orig, goal) {
  const p0 = b.entity ? b.entity.position : null
  if (!p0 || !fin3(p0) || !goal || typeof goal.x !== 'number') return orig.call(b.pathfinder, goal)
  const gx = goal.x, gy = goal.y, gz = goal.z
  const dist = Math.hypot(gx - p0.x, gz - p0.z)
  b.__lastGoal = { x: gx, y: gy, z: gz }
  if (dist < 2 || dist > 240 || pfOwned(b)) return orig.call(b.pathfinder, goal)
  const t0 = Date.now()
  pfTune(b, dist)
  try {
    await orig.call(b.pathfinder, goal)
    pfAdapt(b, true)
    return
  } catch (e) {
    pfAdapt(b, false)
    stats.pfFail = (stats.pfFail || 0) + 1
    const budget = 22000
    // 1) relax the arrival radius: rough jungle terrain is often 3 blocks off "exactly here"
    for (const r of [4, 8, 14]) {
      if (!b.entity || !b.isAlive || Date.now() - t0 > budget) break
      const ok = await orig.call(b.pathfinder, new goals.GoalNear(gx, gy, gz, r)).then(() => true).catch(() => false)
      if (ok) { pfAdapt(b, true); stats.pfRadius = (stats.pfRadius || 0) + 1; log('PF_RADIUS ' + r + ' ' + Math.round(gx) + ',' + Math.round(gz) + ' from ' + pos(b)); return }
    }
    // 2) route around: step sideways off the straight line, then aim at the goal again
    const dx = gx - p0.x, dz = gz - p0.z
    const L = Math.hypot(dx, dz) || 1
    const px = -dz / L, pz = dx / L
    for (const side of [1, -1]) {
      for (const off of [6, 12, 20]) {
        if (!b.entity || !b.isAlive || Date.now() - t0 > budget || pfOwned(b)) break
        const wx = gx + px * off * side, wz = gz + pz * off * side
        if (stuckSpotNear(b, wx, wz, 3)) continue
        const okw = await orig.call(b.pathfinder, new goals.GoalNear(wx, gy, wz, 3)).then(() => true).catch(() => false)
        if (!okw) continue
        const ok2 = await orig.call(b.pathfinder, new goals.GoalNear(gx, gy, gz, 4)).then(() => true).catch(() => false)
        if (ok2) { pfAdapt(b, true); stats.pfDetour = (stats.pfDetour || 0) + 1; log('PF_DETOUR ' + (side > 0 ? 'R' : 'L') + off + ' -> ' + Math.round(gx) + ',' + Math.round(gz)); return }
        const ok3 = await orig.call(b.pathfinder, new goals.GoalNear(gx, gy, gz, 12)).then(() => true).catch(() => false)
        if (ok3) { stats.pfDetour = (stats.pfDetour || 0) + 1; log('PF_DETOUR_PART ' + (side > 0 ? 'R' : 'L') + off + ' -> ' + Math.round(gx) + ',' + Math.round(gz) + ' at ' + pos(b)); return }
      }
    }
    noteStuckSpot(b)
    log('PF_GIVEUP ' + Math.round(gx) + ',' + Math.round(gz) + ' d=' + dist.toFixed(0) + ' after ' + ((Date.now() - t0) / 1000).toFixed(0) + 's at ' + pos(b))
    throw e
  }
}

function wrapLeashGoals (b) {
  const pf = b.pathfinder
  if (!pf || pf.__leashWrapped) return
  pf.__leashWrapped = true""")

sub('goto-wrap', """      if (typeof a0 === 'number' && arguments.length >= 3 && fn === 'goto') {
        const c = clampXZ(a0, arguments[2])
        if (c) { log('LEASH_CLAMP goto ' + Math.round(a0) + ',' + Math.round(arguments[2]) + ' -> ' + Math.round(c[0]) + ',' + Math.round(c[1])); arguments[0] = c[0]; arguments[2] = c[1] }
      } else fixGoal(a0)
      return orig.apply(this, arguments)""",
    """      if (typeof a0 === 'number' && arguments.length >= 3 && fn === 'goto') {
        const c = clampXZ(a0, arguments[2])
        if (c) { log('LEASH_CLAMP goto ' + Math.round(a0) + ',' + Math.round(arguments[2]) + ' -> ' + Math.round(c[0]) + ',' + Math.round(c[1])); arguments[0] = c[0]; arguments[2] = c[1] }
        const gx = arguments[0], gz = arguments[2]
        const gyy = arguments.length > 1 && isFinite(arguments[1]) ? arguments[1] : (b.entity ? b.entity.position.y : 64)
        return smartGoto(b, orig, new goals.GoalBlock(Math.floor(gx), Math.floor(gyy), Math.floor(gz)))
      } else fixGoal(a0)
      if (fn === 'goto' && a0 && typeof a0 === 'object' && isFinite(a0.x)) return smartGoto(b, orig, a0)
      if (a0 && typeof a0 === 'object' && isFinite(a0.x)) b.__lastGoal = { x: a0.x, y: a0.y, z: a0.z }
      return orig.apply(this, arguments)""")

sub('tick-timeout', """    b.pathfinder.tickTimeout = 60""", """    b.pathfinder.tickTimeout = 45          // replan more often: terrain under jungle canopy changes under us""")

# stuck guard: note the spot, and stop hammering a dead path with in-place hops
sub('stuck-note', """      log('STUCK L' + level, 'wedged '""", """      noteStuckSpot(b)
      log('STUCK L' + level, 'wedged '""")

sub('replan-reset', """      if (flat > 0.7 || rise > 1.0) { stuckSince = 0; b.__stuckLevel = 0; b.__detourN = 0; return }   // moving again: detour budget resets""",
    """      if (flat > 0.7 || rise > 1.0) { stuckSince = 0; b.__stuckLevel = 0; b.__detourN = 0; b.__replanN = 0; return }   // moving again: budgets reset""")

sub('replan-l1', """      let pf = false; try { pf = b.pathfinder.isMoving() } catch (e) {}
      log('UNSTICK step-up' + (pf ? ' (pf driving)' : '') + ' at', pos(b))""",
    """      let pf = false; try { pf = b.pathfinder.isMoving() } catch (e) {}
      // BUG: if the pathfinder is "driving" but we are not moving, its path is dead. Hopping
      // in place next to it (the old behaviour, spammed hundreds of times) achieves nothing -
      // stop the dead path and re-plan, which now goes through the route-around ladder.
      if (pf && b.__lastGoal && !pfOwned(b)) {
        b.__replanN = (b.__replanN || 0) + 1
        noteStuckSpot(b)
        try { b.pathfinder.stop() } catch (e) {}
        if (b.__replanN > 4) {
          const g = b.__lastGoal; b.__lastGoal = null
          log('PF_ABANDON ' + Math.round(g.x) + ',' + Math.round(g.z) + ' unreachable -> pick another way at ' + pos(b))
          try { mission = null } catch (e) {}
          const p = b.entity.position
          const side = stuckSpotNear(b, p.x + 7, p.z + 5, 4) ? -1 : 1
          try { b.pathfinder.setGoal(new goals.GoalXZ(p.x + side * 8, p.z + 6)) } catch (e) {}
          await sleep(700)
          return
        }
        log('UNSTICK replan #' + b.__replanN + ' -> ' + Math.round(b.__lastGoal.x) + ',' + Math.round(b.__lastGoal.z) + ' at ' + pos(b))
        try { b.pathfinder.setGoal(new goals.GoalNear(b.__lastGoal.x, b.__lastGoal.y, b.__lastGoal.z, 4)) } catch (e) {}
        await sleep(500)
        return
      }
      log('UNSTICK step-up' + (pf ? ' (pf driving)' : '') + ' at', pos(b))""")

# the stuck guard must not go quiet while we are in water (that is how we drowned)
sub('guard-wet', """      if (unstickBusy || b.__fleeing || hiding || diggingUp || tunneling || b.__pillarEscape || deepNearCrater(b) || (!inHole && (!wantsToMove(b) || busyDoingSomething(b)))) {
        hist = []; stuckSince = 0; b.__stuckLevel = 0; return
      }""",
    """      const wet = wetNow(b)
      if (!wet.feet && !wet.head && (unstickBusy || b.__fleeing || hiding || diggingUp || tunneling || b.__pillarEscape || deepNearCrater(b) || (!inHole && (!wantsToMove(b) || busyDoingSomething(b))))) {
        hist = []; stuckSince = 0; b.__stuckLevel = 0; return
      }""")

open(F, 'w', encoding='utf8').write(s)
print('OK patch12 applied:', len(done), 'edits:', ', '.join(done))
