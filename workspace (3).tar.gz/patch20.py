#!/usr/bin/env python3
# patch20: the tree bug. collectBlock happily targets a log 8 blocks up, so Puff climbed into
# the crown, sat in the leaves "gathering" (have 0 birch_log) and got stuck in foliage.
# Wood is chopped at the BASE of the trunk, never in the crown, and sitting in leaves now
# means "chop down through the trunk", not "wait for a path that does not exist".
import sys

F = 'bot.js'
s = open(F, encoding='utf8').read()
done = []

def sub(name, old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        print('!! %-16s found %d (expected %d)' % (name, n, count)); sys.exit(1)
    s = s.replace(old, new, count); done.append(name)

sub('tree-descend', """  while (countItem(b, countName) < target && b.entity && b.health > 0 && mission && guard++ < 150) {
    const positions = b.findBlocks({ matching: ids, maxDistance: 28, count: 8 })
    if (!positions.length) { log('GATHER none nearby'); await suckDrops(b, 12); break }""",
    """  while (countItem(b, countName) < target && b.entity && b.health > 0 && mission && guard++ < 150) {
    if (b.entity && /log/.test(countName)) {
      // If we are standing ON or IN a tree (leaves under/around us) there is no path and no
      // clever plan - the way down is to chop the block under our feet and fall one block,
      // which also harvests the trunk on the way. That is how a player fells a tree.
      const ft = b.entity.position.floored()
      const under = b.blockAt(ft.offset(0, -1, 0))
      const inside = b.blockAt(ft)
      const onTree = under && (LOG_TYPES.indexOf(under.name) >= 0 || /leaves/.test(under.name))
      const inCrown = inside && /leaves/.test(inside.name)
      if (onTree || inCrown) {
        b.__allowDig = true
        try {
          if (onTree) await withTimeout(digBlock(b, ft.offset(0, -1, 0)), 15000, false)
          if (inCrown) await withTimeout(digBlock(b, ft), 12000, false)
        } finally { b.__allowDig = false }
        await sleep(500)
        try { await collectNear(b, 7) } catch (e) {}
        log('TREE_DESCEND chopped under=' + (under ? under.name : '-') + ' now=' + pos(b))
      }
    }
    let positions = b.findBlocks({ matching: ids, maxDistance: 28, count: 8 })
    if (!positions.length) { log('GATHER none nearby'); await suckDrops(b, 12); break }
    if (/log/.test(countName)) {
      // base of the trunk only: a log with another log under it is mid-trunk and needs a
      // ladder, and the crown is 6-10 up. Bases are on the ground, at our own height.
      const bases = positions.filter(p => { const bel = b.blockAt(p.offset(0, -1, 0)); return !(bel && LOG_TYPES.indexOf(bel.name) >= 0) })
      if (bases.length) positions = bases
      const feetY = b.entity ? b.entity.position.y : 64
      const low = positions.filter(p => p.y <= feetY + 3)
      if (low.length) positions = low
    }""")

open(F, 'w', encoding='utf8').write(s)
print('OK patch20 applied:', len(done), 'edits:', ', '.join(done))
