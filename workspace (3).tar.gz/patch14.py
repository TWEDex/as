#!/usr/bin/env python3
# patch14: per-attempt timeouts. A single A* attempt could still burn 16s on a 6-block hop,
# so "adaptive" was not yet "prompt". Every attempt now has a hard clock and gets cancelled.
import sys

F = 'bot.js'
s = open(F, encoding='utf8').read()
done = []

def sub(name, old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        print('!! %-16s found %d (expected %d)' % (name, n, count)); sys.exit(1)
    s = s.replace(old, new, count); done.append(name)

sub('pftry-fn', """async function smartGoto (b, orig, goal) {""",
    """// One path attempt with a hard clock. Without it a single A* search on a 6-block hop could
// eat 16 seconds (thinkTimeout only bounds one search, not the retries inside the plugin),
// which is exactly the "stands there doing nothing" the owner keeps seeing.
async function pfTry (b, orig, goal, ms) {
  let to = null
  const pr = orig.call(b.pathfinder, goal)
  try {
    const raced = await Promise.race([
      pr.then(() => 'ok').catch(() => 'fail'),
      new Promise(res => { to = setTimeout(() => res('to'), ms || 4000) })
    ])
    if (raced === 'to') {
      try { b.pathfinder.stop() } catch (e) {}
      try { b.clearControlStates() } catch (e) {}
      stats.pfTimeout = (stats.pfTimeout || 0) + 1
    }
    return raced
  } catch (e) { return 'fail' } finally { if (to) clearTimeout(to) }
}

async function smartGoto (b, orig, goal) {""")

sub('first-attempt', """  pfTune(b, dist)
  try {
    await orig.call(b.pathfinder, goal)
    pfAdapt(b, true)
    return
  } catch (e) {""",
    """  pfTune(b, dist)
  // long hops get a longer single search (the travel routine owns them); short ones must
  // answer in a couple of seconds or we move on to the route-around ladder
  const attemptMs = dist > 60 ? 12000 : Math.max(2500, Math.min(6000, Math.round(dist * 120)))
  try {
    const r0 = await pfTry(b, orig, goal, attemptMs)
    if (r0 !== 'ok') { if (r0 === 'to' && dist > 60) { log('PF_LONG_TIMEOUT d=' + dist.toFixed(0) + ' - travel owns this'); throw new Error('long path timeout') } throw new Error('path ' + r0 + ' in ' + attemptMs + 'ms') }
    pfAdapt(b, true)
    return
  } catch (e) {""")

sub('radius-try', """      const ok = await orig.call(b.pathfinder, new goals.GoalNear(gx, gy, gz, r)).then(() => true).catch(() => false)""",
    """      const ok = (await pfTry(b, orig, new goals.GoalNear(gx, gy, gz, r), 4000)) === 'ok'""")

sub('detour-try', """        const okw = await orig.call(b.pathfinder, new goals.GoalNear(wx, gy, wz, 3)).then(() => true).catch(() => false)
        if (!okw) continue
        const ok2 = await orig.call(b.pathfinder, new goals.GoalNear(gx, gy, gz, 4)).then(() => true).catch(() => false)""",
    """        const okw = (await pfTry(b, orig, new goals.GoalNear(wx, gy, wz, 3), 4000)) === 'ok'
        if (!okw) continue
        const ok2 = (await pfTry(b, orig, new goals.GoalNear(gx, gy, gz, 4), 4500)) === 'ok'""")

sub('detour-partial', """        const ok3 = await orig.call(b.pathfinder, new goals.GoalNear(gx, gy, gz, 12)).then(() => true).catch(() => false)""",
    """        const ok3 = (await pfTry(b, orig, new goals.GoalNear(gx, gy, gz, 12), 4500)) === 'ok'""")

sub('giveup-log', """    noteStuckSpot(b)
    log('PF_GIVEUP '""", """    noteStuckSpot(b)
    log('PF_GIVEUP(to=' + (stats.pfTimeout || 0) + ') '""")

open(F, 'w', encoding='utf8').write(s)
print('OK patch14 applied:', len(done), 'edits:', ', '.join(done))
