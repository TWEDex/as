# -*- coding: utf-8 -*-
import io, sys
src = io.open('bot.js', encoding='utf-8').read()
def rep(old, new, tag=''):
    global src
    if src.count(old) != 1:
        print('MISS/DUP %s (%d)' % (tag, src.count(old))); sys.exit(1)
    src = src.replace(old, new, 1); print('ok    %s' % tag)

rep("""    if (cmd === 'stop') {
      stopDrive(b)
      try { b.pathfinder.setGoal(null) } catch (e) {}
      try { b.clearControlStates() } catch (e) {}
      return respond(sock, 'OK stopped')
    }""",
"""    if (cmd === 'stop') {
      // 'stop' must also drop the mission: a gather loop in the wrong biome used to spin
      // forever (GATHER timeout x N) because nothing else cleared `mission`
      mission = null
      try { hiding = false } catch (e) {}
      stopDrive(b)
      try { b.pathfinder.setGoal(null) } catch (e) {}
      try { b.clearControlStates() } catch (e) {}
      manualLockUntil = 0
      return respond(sock, 'OK stopped, mission cleared')
    }""", tag='stop clears mission')
io.open('bot.js', 'w', encoding='utf-8').write(src)
print('done')
