#!/usr/bin/env python3
# patch17: why the wood mission produced zero logs - (a) gatherBlocks started a SECOND
# collectBlock.collect() while the first was still walking (two collectors fight over the
# same path, both time out forever), (b) my new smartGoto ladder arrived with a widened
# radius, so collectBlock considered the block out of reach. Plus a real fallback: chop it.
import sys

F = 'bot.js'
s = open(F, encoding='utf8').read()
done = []

def sub(name, old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        print('!! %-16s found %d (expected %d)' % (name, n, count)); sys.exit(1)
    s = s.replace(old, new, count); done.append(name)

sub('pfraw', """  b.__softDig = true
  try { return await fn() } finally { b.__softDig = false;""",
    """  b.__softDig = true
  // while harvesting, path straight AT the block: the retry ladder arrives with a widened
  // radius (6-12), and collectBlock then says "not in reach" and gives up on the tree
  b.__pfRaw = true
  try { return await fn() } finally { b.__softDig = false; b.__pfRaw = false;""")

sub('pfraw-use', """  const gx = goal.x, gy = goal.y, gz = goal.z
  const dist = Math.hypot(gx - p0.x, gz - p0.z)""",
    """  if (b.__pfRaw) return orig.call(b.pathfinder, goal)
  const gx = goal.x, gy = goal.y, gz = goal.z
  const dist = Math.hypot(gx - p0.x, gz - p0.z)""")

sub('chop-one', """// walk over item entities we dropped/mined but never picked up (pickup range is tiny)""",
    """// Collector gave up twice? Then chop the trunk by hand: walk to it, break exactly that
// one block, pick up the drop. It is the difference between "no wood for 20 minutes" and
// one log every few seconds - and it still breaks ONE block, not a tunnel.
async function chopOne (b, positions) {
  try {
    if (!b.entity) return false
    const g = b.entity.position
    const near = positions.map(p => ({ p, d: g.distanceTo(p) })).sort((a, c) => a.d - c.d)
    for (const c of near.slice(0, 3)) {
      const k = b.blockAt(c.p)
      if (!k || LOG_TYPES.indexOf(k.name) < 0) continue
      if (c.d > 4.5) {
        const ok = await b.pathfinder.goto(new goals.GoalNear(c.p.x, c.p.y, c.p.z, 2)).then(() => true).catch(() => false)
        if (!ok) continue
      }
      const now = b.blockAt(c.p)
      if (!now || LOG_TYPES.indexOf(now.name) < 0) continue
      b.__allowDig = true
      try { await withTimeout(digBlock(b, c.p), 20000, false) } finally { b.__allowDig = false }
      await sleep(700)
      try { await collectNear(b, 7) } catch (e) {}
      log('CHOP_ONE ' + k.name + ' at ' + c.p + ' have=' + countItem(b, k.name))
      if (countItem(b, k.name) > 0) return true
    }
    return false
  } catch (e) { log('CHOP_ERR', e && e.message); return false }
}

// walk over item entities we dropped/mined but never picked up (pickup range is tiny)""")

sub('gather-wait', """    const r = await withTimeout(withSoftDig(b, () => b.collectBlock.collect(blocks, { iterations: Math.max(1, Math.min(8, need)), range: 4 })), 25000, 'timeout')
    if (r === 'timeout') log('GATHER timeout, retrying')
    const now = countItem(b, countName)
    if (now <= last) { stalls++; await suckDrops(b, 8); if (stalls >= 4) { log('GATHER stalled at', now, '- proceeding to build'); break } } else { stalls = 0; last = now }""",
    """    const job = withSoftDig(b, () => b.collectBlock.collect(blocks, { iterations: Math.max(1, Math.min(8, need)), range: 4 }))
    let r = await withTimeout(job, 25000, 'timeout')
    if (r === 'timeout') {
      log('GATHER timeout - waiting for the collect that is already running')
      r = await withTimeout(job.then(() => 'late-ok').catch(() => 'late-fail'), 40000, 'late-timeout')
      try { b.pathfinder.stop() } catch (e) {}
    }
    const now = countItem(b, countName)
    if (now <= last) {
      stalls++
      await suckDrops(b, 8)
      if (stalls >= 2 && /log/.test(countName)) await chopOne(b, positions)
      if (stalls >= 5) { log('GATHER stalled at', now, '- proceeding to build'); break }
    } else { stalls = 0; last = now }""")

open(F, 'w', encoding='utf8').write(s)
print('OK patch17 applied:', len(done), 'edits:', ', '.join(done))
