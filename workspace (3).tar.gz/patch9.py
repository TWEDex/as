# -*- coding: utf-8 -*-
import io, sys
src = io.open('bot.js', encoding='utf-8').read()

def rep(old, new, tag=''):
    global src
    if src.count(old) != 1:
        print('MISS/DUP %s (%d)' % (tag, src.count(old)))
        sys.exit(1)
    src = src.replace(old, new, 1)
    print('ok    %s' % tag)

LOOT_NEW = ("        b.__lootAt = Date.now()\n"
            "        if (FOOD_MOBS.has(String(e.name).toLowerCase())) { setTimeout(() => { try { collectNear(b, 16) } catch (err2) {} }, 900) }\n"
            "      } catch (err) {}\n")
LOOT_OLD = "        b.__lootAt = Date.now()\n      } catch (err) {}\n"

rep("function fightTarget (b, radius) {",
    "const FOOD_MOBS = new Set(['cow', 'pig', 'sheep', 'chicken', 'rabbit', 'mooshroom', 'goat'])\n"
    "function huntTarget (b, radius) {\n"
    "  let best = null; let bd = radius\n"
    "  if (!b.entity) return null\n"
    "  for (const id in b.entities) {\n"
    "    const e = b.entities[id]\n"
    "    if (!e || !e.position || !e.name || e === b.entity || !fin3(e.position)) continue\n"
    "    if (!FOOD_MOBS.has(String(e.name).toLowerCase())) continue\n"
    "    if (e.health !== undefined && e.health <= 0) continue\n"
    "    const d = e.position.distanceTo(b.entity.position)\n"
    "    if (d < bd) { bd = d; best = e }\n"
    "  }\n"
    "  return best\n"
    "}\n"
    "function fightTarget (b, radius) {", tag='huntTarget added')

rep("""  const radius = radiusOf(hp)
  const e = fightTarget(b, radius)""",
    """  const radius = radiusOf(hp)
  // hunger outranks fear: nothing edible in the bag and the bar is low -> hunt, whatever is nearby
  const starving = (b.food || 0) <= 12 && countFood(b) === 0
  const e = fightTarget(b, radius) || (starving && hp >= 6 ? huntTarget(b, 70) : null)
  if (e && FOOD_MOBS.has(String(e.name).toLowerCase())) b.__hunting = true
  else if (e) b.__hunting = false""", tag='combat hunts when starving')

n = src.count(LOOT_OLD)
if n != 2:
    print('LOOT anchors: expected 2, got %d' % n)
    sys.exit(1)
src = src.replace(LOOT_OLD, LOOT_NEW)
print('ok    loot after hunt kill x2')

rep("""  if (!isFinite(d)) { stopFight(b); return }""",
    """  if (!isFinite(d)) { stopFight(b); return }
  if (b.__hunting && now - (b.__huntLogAt || 0) > 5000) { b.__huntLogAt = now; log('HUNTING', nm, 'd=' + d.toFixed(1) + ' food=' + Math.round(b.food)) }""",
    tag='hunt log')

io.open('bot.js', 'w', encoding='utf-8').write(src)
print('done')
