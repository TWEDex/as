# -*- coding: utf-8 -*-
# Patches bot.js: (A) remove all canned chat, (B) real combat that kills mobs,
# (C) leash anchor (2 chunks) + goto clamp, (D) wooden hut builder, (E) pale oak wood lists.
import io, re, sys

src = io.open('bot.js', encoding='utf-8').read()
orig_len = len(src)

def rep(old, new, count=1, tag=''):
    global src
    n = src.count(old)
    if n == 0:
        print('MISS   %s' % tag); sys.exit(1)
    src = src.replace(old, new, count)
    print('ok     %s (%d occurrences)' % (tag, n))

# ============ A. NO CANNED REPLIES ============
i0 = src.find('// ---- compositional replies')
i1 = src.find('function findPlayerByName (b, name) {')
assert i0 > 0 and i1 > i0, 'block markers'
src = src[:i0] + src[i1:]
print('ok     A1 compositional-reply engine deleted (%d chars)' % (i1 - i0))

rep("const MODEL_ANSWER = process.env.PUFF_MODEL_ANSWER || 'да я просто Puff, играю тут'",
    "// NO canned text anywhere: Puff composes every chat line himself.")

rep("""function feedChat (b, user, text, whisper) {
  try {
    const t = String(text || '')
    chatRing.push({ t: Date.now(), u: user || '', x: t.slice(0, 200) })
    if (chatRing.length > 60) chatRing.shift()
    if (!user || user === USERNAME) return
    const low = norm(user)
    if (!social[low]) social[low] = { met: Date.now(), talks: 0, last: 0 }
    social[low].seen = Date.now()
    let toMe = whisper || addressedToMe(t)
    if (!toMe && isOwner(user) && t.length > 12) {
      // the owner talking in chat next to me counts - but at most once per 20s
      if (Date.now() - (social[low].ownerReply || 0) > 20000) { toMe = true; social[low].ownerReply = Date.now() }
    }
    if (!toMe) return
    const r = replyFor(b, user, t)
    if (!r) { log('CHAT_QUIET', user + ': ' + t.slice(0, 60)); return }
    setTimeout(() => say(b, r), 250 + Math.random() * 550)
  } catch (e) { log('CHATBRAIN_ERR', e && e.message) }
}""",
"""// addressed-but-unanswered messages pile up here; the agent (Puff) reads them with
// the 'asks' control command and answers in his own words with 'chat <text>'.
const pendingAsks = []
function feedChat (b, user, text, whisper) {
  try {
    const t = String(text || '')
    chatRing.push({ t: Date.now(), u: user || '', x: t.slice(0, 200) })
    if (chatRing.length > 60) chatRing.shift()
    if (!user || user === USERNAME) return
    const low = norm(user)
    if (!social[low]) social[low] = { met: Date.now(), talks: 0, last: 0 }
    social[low].seen = Date.now()
    let toMe = whisper || addressedToMe(t)
    if (!toMe && isOwner(user) && t.length > 12) {
      // the owner talking in chat next to me counts - but at most once per 20s
      if (Date.now() - (social[low].ownerAsk || 0) > 20000) { toMe = true; social[low].ownerAsk = Date.now() }
    }
    if (!toMe) return
    social[low].talks++; social[low].last = Date.now()
    pendingAsks.push({ t: Date.now(), u: user, x: t.slice(0, 200), w: !!whisper })
    if (pendingAsks.length > 30) pendingAsks.shift()
    log('ASK', (whisper ? '[whisper] ' : '') + user + ': ' + t.slice(0, 140))
  } catch (e) { log('CHATBRAIN_ERR', e && e.message) }
}""", tag='A3 feedChat -> ASK queue only')

rep("""    if (cmd === 'sayto') {
      const r = replyFor(b, args[0] || 'unknown', args.slice(1).join(' '))
      const ok = r ? say(b, r) : false
      return respond(sock, ok ? 'OK said: ' + r : 'ERR throttled or nothing to say')
    }""",
"""    if (cmd === 'asks') {
      const n = parseInt(args[0] || '10', 10)
      if (!pendingAsks.length) return respond(sock, 'no one waiting on an answer')
      return respond(sock, pendingAsks.slice(-n).map(a => new Date(a.t).toISOString().slice(11, 19) + ' ' + (a.w ? '*w ' : '') + a.u + ': ' + a.x).join(' || '))
    }
    if (cmd === 'clearasks') { pendingAsks.length = 0; return respond(sock, 'OK asks cleared') }
    if (cmd === 'sayto') {
      return respond(sock, 'ERR removed - no canned replies; answer yourself with: chat <text>')
    }""", tag='A4 sayto -> asks/clearasks')

rep("""    if (cmd === 'testchat') {
      const u = args[0] || 'Tester'
      const t = args.slice(1).join(' ')
      const before = stats.replies
      feedChat(b, u, t, false)
      await sleep(1600)
      return respond(sock, 'replied=' + (stats.replies > before ? 'yes' : 'no') + ' addressed=' + addressedToMe(t))
    }""",
"""    if (cmd === 'testchat') {
      const u = args[0] || 'Tester'
      const t = args.slice(1).join(' ')
      const before = pendingAsks.length
      feedChat(b, u, t, false)
      await sleep(200)
      return respond(sock, 'addressed=' + addressedToMe(t) + ' queued=' + (pendingAsks.length > before ? 'yes' : 'no') + ' (bot never auto-answers)')
    }""", tag='A5 testchat')

rep("""  const nowC = Date.now()
  if (nowC - (b.__craterCmdAt || 0) > 150000) {
    b.__craterCmdAt = nowC
    const cmds = ['/spawn', '/rtp', '/wild', '/hub', '/lobby', '/warp spawn']
    const n = (b.__craterCmdN = ((b.__craterCmdN || 0) + 1) % cmds.length)
    try { b.chat(cmds[n]); log('CRATER_CMD', cmds[n]) } catch (e) {}
  }
  try {
    const mate = nearestPlayerEntity(b, 64)
    if (mate && mate.name && String(mate.name) !== USERNAME && nowC - (b.__craterAskAt || 0) > 120000) {
      b.__craterAskAt = nowC
      const msg = mate.name + ', выручи, пожалуйста: я провалился в глубокую яму из сыпучего песка у спавна и сам не вылезу. Скинь мне вниз блоков 30 любых твёрдых — я построю башню и выберусь'
      try { b.chat(msg) } catch (e) {}
      log('CRATER_ASK', String(mate.name))
    }
  } catch (e) {}""",
"""  const nowC = Date.now()
  // no /spawn-style command spam and no pre-written pleas: if we are genuinely stuck it
  // lands in the log and Puff decides himself whether and how to ask for help.
  if (nowC - (b.__craterNotifiedAt || 0) > 120000) {
    b.__craterNotifiedAt = nowC
    log('CRATER_STUCK at ' + pos(b) + ' rim=' + rim + ' placeable=' + countPlaceable(b))
  }""", tag='A6 crater canned spam removed')

# ============ E. WOOD LISTS: pale oak was missing ============
rep("const LOG_TYPES = ['oak_log', 'birch_log', 'spruce_log', 'jungle_log', 'acacia_log', 'dark_oak_log', 'mangrove_log', 'cherry_log']",
    "const LOG_TYPES = ['pale_oak_log', 'oak_log', 'birch_log', 'spruce_log', 'jungle_log', 'acacia_log', 'dark_oak_log', 'mangrove_log', 'cherry_log']",
    tag='E1 LOG_TYPES + pale_oak')
rep("const PLANKS_ANY = ['oak_planks', 'birch_planks', 'spruce_planks', 'jungle_planks', 'acacia_planks', 'dark_oak_planks', 'mangrove_planks', 'cherry_planks']",
    "const PLANKS_ANY = ['pale_oak_planks', 'oak_planks', 'birch_planks', 'spruce_planks', 'jungle_planks', 'acacia_planks', 'dark_oak_planks', 'mangrove_planks', 'cherry_planks']",
    tag='E2 PLANKS_ANY + pale_oak')

# ============ B + C + D: new modules, inserted before startReflexes ============
MODULE = u"""
// ==================== COMBAT: we fight back and we WIN ====================
// Old defence code swung once per reflex tick (~1.1s) and only at hp>=10 while armed.
// Result: 127 deaths, 0 kills. This is a dedicated 240ms loop: best weapon, swing on the
// item cooldown, jump-crits, circle-strafe vs shooters, hit-and-run vs creepers, and it
// does not let go of a target until it is dead.
const MOB_HP = { zombie: 20, zombie_villager: 20, husk: 20, drowned: 20, skeleton: 20, stray: 20, bogged: 20, wither_skeleton: 20, creeper: 20, spider: 16, cave_spider: 16, silverfish: 8, enderman: 40, slime: 16, phantom: 20, pillager: 24, vindicator: 24, witch: 26, breeze: 20 }
const WEAPON_INFO = { netherite_sword: [8, 600], diamond_sword: [7, 600], iron_sword: [6, 500], stone_sword: [5, 620], golden_sword: [4, 500], wooden_sword: [4, 520], netherite_axe: [10, 1250], diamond_axe: [9, 1150], iron_axe: [9, 1050], stone_axe: [9, 1100], golden_axe: [7, 1000], wooden_axe: [7, 1000] }
const fightState = { lastSwing: 0, strafe: 1, strafeAt: 0, retreatUntil: 0, goalAt: 0 }
function bestWeapon (b) {
  let best = null
  try {
    for (const it of b.inventory.items()) {
      const info = WEAPON_INFO[it.name]
      if (!info) continue
      if (!best || info[0] > (WEAPON_INFO[best.name] || [0, 0])[0]) best = it
    }
  } catch (e) {}
  return best
}
function swingMs (wp) { const i = wp && WEAPON_INFO[wp.name]; return i ? i[1] : 640 }
function fightTarget (b, radius) {
  let worst = null; let ws = 1e9
  if (!b.entity) return null
  const hurt = String(b.__lastHurtBy || '')
  for (const id in b.entities) {
    const e = b.entities[id]
    if (!e || !e.position || !e.name || e === b.entity) continue
    const nm = String(e.name).toLowerCase()
    if (!HOSTILE.has(nm)) continue
    if (e.health !== undefined && e.health <= 0) continue
    const d = e.position.distanceTo(b.entity.position)
    if (d > radius) continue
    let s = d / Math.max(1, threatRadius(nm))
    if (hurt && String(e.id) === hurt) s -= 50                     // the one that hit us goes first
    if (nm === 'creeper' && d < 6) s -= 20                          // fuse is the real deadline
    if (s < ws) { ws = s; worst = e }
  }
  return worst
}
function stopFight (b) {
  b.__fighting = false; b.__fightAt = 0; b.__fightId = undefined
  try { b.setControlState('left', false); b.setControlState('right', false); b.setControlState('sprint', false) } catch (e) {}
}
function strafeAround (b, st, now) {
  if (now - st.strafeAt > 700) { st.strafeAt = now; st.strafe = Math.random() < 0.5 ? 1 : -1 }
  const L = st.strafe > 0, R = !L
  try { b.setControlState('left', L); b.setControlState('right', R); b.setControlState('back', false); b.setControlState('forward', false) } catch (e) {}
}
function markHit (b, e) {
  if (!b.__hit) b.__hit = {}
  b.__hit[e.id] = { name: e.name, t: Date.now() }
}
async function combatTick (b) {
  if (!b.entity || !b.isAlive || b.health <= 0) { stopFight(b); return }
  const now = Date.now()
  if (!reflexOn || b.__noFight) { if (b.__fighting) stopFight(b); return }
  const wp = bestWeapon(b)
  const armed = !!wp
  const hp = b.health
  if (hp < 6) { if (b.__fighting) stopFight(b); return }          // hopeless, let survival logic run
  const radius = armed ? (hp >= 10 ? 14 : 9) : 4.5
  const e = fightTarget(b, radius)
  if (!e) {
    if (b.__fighting) log('FIGHT_WON_OR_LOST', (b.__fightName || '?') + ' gone at ' + pos(b) + ' hp=' + Math.round(hp))
    stopFight(b)
    return
  }
  b.__fighting = true; b.__fightAt = now; b.__fightId = e.id; b.__fightName = e.name
  const nm = String(e.name).toLowerCase()
  const ranged = RANGED.has(nm)
  const d = e.position.distanceTo(b.entity.position)
  const look = e.position.offset(0, (e.height || 1.8) * 0.62, 0)
  try { if (armed && (!b.heldItem || b.heldItem.name !== wp.name)) b.equip(wp, 'hand').catch(() => {}) } catch (err) {}

  // ---- creeper: swing, then back off; never die standing next to it
  if (nm === 'creeper' && d < 3.2 && now > fightState.retreatUntil) {
    try { b.look(look, true) } catch (err) {}
    try { b.attack(e) } catch (err) {}
    markHit(b, e)
    fightState.lastSwing = now
    fightState.retreatUntil = now + 1900
    log('FIGHT_BUMP creeper d=' + d.toFixed(1))
  }
  if (nm === 'creeper' && now < fightState.retreatUntil) {
    try { b.pathfinder.setGoal(null) } catch (err) {}
    fleeFrom(b, e)
    return
  }
  // ---- low on health and unarmed: do not trade, run
  if (!armed && d < 2.2) {
    try { b.look(look, true) } catch (err) {}
    try { b.attack(e) } catch (err) {}                                  // fist + knockback
    markHit(b, e)
    fightState.lastSwing = now
    if (hp < 12) { stopFight(b); return }                               // survival logic takes over
  }
  // ---- close the distance
  if (d > 2.7) {
    if (now - fightState.goalAt > 900) {
      fightState.goalAt = now
      try { b.pathfinder.setGoal(new goals.GoalNear(e.position.x, e.position.y, e.position.z, 2)) } catch (err) {}
    }
    let pfMoving = false; try { pfMoving = b.pathfinder.isMoving() } catch (err) {}
    if (!pfMoving) {
      try { b.look(look, true) } catch (err) {}
      try { b.setControlState('forward', true); b.setControlState('sprint', d > 6); b.setControlState('left', false); b.setControlState('right', false) } catch (err) {}
      hop(b)
    }
    if (ranged && d < 10) strafeAround(b, fightState, now)
    if (d <= 3.4 && now - fightState.lastSwing >= swingMs(wp)) {
      fightState.lastSwing = now
      try { b.attack(e) } catch (err) {}
      markHit(b, e)
    }
    return
  }
  // ---- in swing range: strafe, look, swing on cooldown, jump-crit when grounded
  let pf = false; try { pf = b.pathfinder.isMoving() } catch (err) {}
  if (pf) { try { b.pathfinder.setGoal(null) } catch (err) {} }
  strafeAround(b, fightState, now)
  try { b.look(look, true) } catch (err) {}
  if (now - fightState.lastSwing >= swingMs(wp)) {
    fightState.lastSwing = now
    try { if (b.entity.onGround) { b.setControlState('jump', true); setTimeout(() => { try { b.setControlState('jump', false) } catch (err) {} }, 140) } } catch (err) {}
    try { b.attack(e) } catch (err) {}
    markHit(b, e)
    if (now - (b.__fightLogAt || 0) > 3000) {
      b.__fightLogAt = now
      log('FIGHT', nm, 'd=' + d.toFixed(1) + ' hp=' + Math.round(b.health) + ' wp=' + (wp ? wp.name : 'fist') + ' mobhp=' + (e.health !== undefined ? Math.round(e.health) : '?'))
    }
  }
}
function startCombat (b) {
  if (b.__combat) clearInterval(b.__combat)
  b.__combat = setInterval(() => { combatTick(b).catch(e => log('COMBAT_ERR', e && e.message)) }, 240)
  try {
    b.on('entityGone', e => {
      try {
        if (!e || !e.name || !HOSTILE.has(String(e.name).toLowerCase())) return
        if (!b.__hit || !b.__hit[e.id] || Date.now() - b.__hit[e.id].t > 15000) return
        stats.kills = (stats.kills || 0) + 1
        log('KILL', e.name, 'at', pos(b), 'total=' + stats.kills)
        delete b.__hit[e.id]
        b.__lootAt = Date.now()
      } catch (err) {}
    })
    b.on('entityHealth', e => {
      try {
        if (!e || !e.name || e.health === undefined || e.health > 0) return
        if (!HOSTILE.has(String(e.name).toLowerCase())) return
        if (!b.__hit || !b.__hit[e.id] || Date.now() - b.__hit[e.id].t > 15000) return
        stats.kills = (stats.kills || 0) + 1
        log('KILL', e.name, 'at', pos(b), 'total=' + stats.kills)
        delete b.__hit[e.id]
        b.__lootAt = Date.now()
      } catch (err) {}
    })
    b.on('entityHurt', e => { try { if (b.__hit && e) b.__hit[e.id] = { name: e.name, t: Date.now() } } catch (err) {} })
  } catch (err) { log('COMBAT_EV_ERR', err && err.message) }
  log('COMBAT on (240ms autoretaliate, jump-crit, strafe, creeper bump)')
}

// ==================== LEASH: stay inside 2 chunks of where we appeared ====================
const ANCHOR_FILE = '/home/agent/bot/anchor.json'
let anchor = null
let leashR = 32
let leashOn = true
try { const a = JSON.parse(fs.readFileSync(ANCHOR_FILE, 'utf8')); if (a && isFinite(a.x)) anchor = a } catch (e) {}
function saveAnchor () { try { fs.writeFileSync(ANCHOR_FILE, JSON.stringify(anchor || {})) } catch (e) {} }
function anchorOf (b) {
  if (!anchor && b && b.entity) {
    const p = b.entity.position
    anchor = { x: p.x, y: p.y, z: p.z, t: Date.now() }
    saveAnchor()
    log('ANCHOR set at ' + Math.round(p.x) + ' ' + Math.round(p.y) + ' ' + Math.round(p.z) + ' (leash ' + leashR + ')')
  }
  return anchor
}
function distAnchor (b) {
  const a = anchorOf(b)
  if (!a || !b.entity) return 0
  return Math.hypot(b.entity.position.x - a.x, b.entity.position.z - a.z)
}
function startLeash (b) {
  if (b.__leash) clearInterval(b.__leash)
  b.__leash = setInterval(() => {
    try {
      if (!leashOn || !b.entity || !b.isAlive) return
      const a = anchorOf(b)
      if (!a) return
      const d = distAnchor(b)
      if (d > leashR + 6 && Date.now() > manualLockUntil) {
        log('LEASH_RETURN from ' + pos(b) + ' d=' + d.toFixed(1) + ' -> anchor')
        try { mission = null } catch (e) {}
        try { b.pathfinder.setGoal(new goals.GoalNear(a.x, a.y, a.z, 3)) } catch (e) {}
      }
    } catch (e) { log('LEASH_ERR', e && e.message) }
  }, 5000)
}

// ==================== WOODEN HUT ====================
const PLANK_LIST = ['pale_oak_planks', 'oak_planks', 'birch_planks', 'spruce_planks', 'jungle_planks', 'acacia_planks', 'dark_oak_planks', 'mangrove_planks', 'cherry_planks', 'crimson_planks', 'warped_planks']
function plankCount (b) { return countAny(b, PLANK_LIST) }
async function ensurePlanks (b, want) {
  let have = plankCount(b)
  let guard = 0
  while (have < want && guard++ < 12) {
    const logName = LOG_TYPES.find(n => countItem(b, n) > 0)
    if (!logName) break
    const plankName = logName.replace('_log', '_planks')
    if (!mcData.itemsByName[plankName]) break
    await craftItem(b, plankName, Math.min(16, countItem(b, logName) * 4))
    const nh = plankCount(b)
    if (nh <= have) break
    have = nh
  }
  return have
}
function pickBuildSite (b) {
  const a = anchorOf(b)
  if (!a || !b.entity) return null
  const p = b.entity.position
  const dirs = []
  for (let r = 0; r <= 24; r += 3) {
    for (let k = 0; k < 12; k++) {
      const ang = k * Math.PI / 6
      dirs.push({ x: Math.round(a.x + Math.cos(ang) * r), z: Math.round(a.z + Math.sin(ang) * r) })
    }
  }
  for (const c of dirs) {
    let gy = null
    let ok = true
    for (let dx = -2; dx <= 2 && ok; dx++) {
      for (let dz = -2; dz <= 2 && ok; dz++) {
        const gx = c.x + dx; const gz = c.z + dz
        if (Math.hypot(gx - a.x, gz - a.z) > leashR - 2) { ok = false; break }
        let found = null
        for (let dy = -2; dy <= 3; dy++) {
          const y = Math.round(p.y) + dy
          const bl = b.blockAt(new Vec3(gx, y, gz))
          const up1 = b.blockAt(new Vec3(gx, y + 1, gz))
          const up2 = b.blockAt(new Vec3(gx, y + 2, gz))
          if (bl && bl.boundingBox === 'block' && bl.name !== 'crafting_table' &&
              (!up1 || up1.boundingBox !== 'block' || up1.name === 'short_grass' || up1.name === 'grass' || up1.name === 'fire') &&
              (!up2 || up2.boundingBox !== 'block')) { found = y; break }
        }
        if (found === null) ok = false
        else if (gy === null) gy = found
        else if (found !== gy) ok = false
      }
    }
    if (ok && gy !== null) return { x: c.x, y: gy, z: c.z }
  }
  return null
}
async function buildHut (b) {
  const site = pickBuildSite(b)
  if (!site) { log('BUILD no flat 5x5 inside the leash circle near anchor'); return false }
  log('BUILD site ' + site.x + ' ' + site.y + ' ' + site.z + ' planks=' + plankCount(b))
  if (!(await ensureCraftingTable(b))) { /* placing still works without a table */ }
  if (plankCount(b) < 20) await ensurePlanks(b, 48)
  if (plankCount(b) < 20) { log('BUILD need ~20 planks, have ' + plankCount(b) + ' - gather wood first'); return false }
  manualLockUntil = Math.max(manualLockUntil, Date.now() + 300000)
  b.__building = true
  const y0 = site.y + 1
  let placed = 0; let failed = 0
  const mat = () => PLANK_LIST.find(n => countItem(b, n) > 0)
  // 2 wall layers of the 5x5 ring (30 blocks), doorway kept open at +z, then a 3x3 roof (9)
  for (let layer = 0; layer < 2; layer++) {
    for (let dx = -2; dx <= 2; dx++) {
      for (let dz = -2; dz <= 2; dz++) {
        if (Math.abs(dx) !== 2 && Math.abs(dz) !== 2) continue
        if (dx === 0 && dz === 2) continue                           // doorway
        if (!b.entity || b.health < 7 || !b.isAlive) { log('BUILD abort hp=' + Math.round(b.health)); b.__building = false; return false }
        const m = mat()
        if (!m) { failed++; continue }
        const okp = await placeBlockAt(b, site.x + dx, y0 + layer, site.z + dz, m)
        if (okp) placed++; else failed++
        if (b.__fighting) { await sleep(1200); }                      // let the combat loop shoot first
      }
    }
    log('BUILD walls layer ' + layer + ' placed=' + placed + ' failed=' + failed)
  }
  for (let dx = -1; dx <= 1; dx++) {
    for (let dz = -1; dz <= 1; dz++) {
      if (!b.entity || !b.isAlive || b.health < 7) { b.__building = false; return false }
      const m = mat()
      if (!m) { failed++; continue }
      const okp = await placeBlockAt(b, site.x + dx, y0 + 2, site.z + dz, m)
      if (okp) placed++; else failed++
    }
  }
  log('BUILD roof placed=' + placed + ' failed=' + failed)
  // door, if we can craft one from the same planks
  try {
    const m = PLANK_LIST.find(n => countItem(b, n) >= 6)
    if (m) {
      const dn = m.replace('_planks', '_door')
      if (mcData.itemsByName[dn]) {
        if (await craftItem(b, dn, 1)) {
          if (await placeBlockAt(b, site.x, y0, site.z + 2, dn)) { log('BUILD door set'); placed++ }
        }
      }
    }
  } catch (e) { log('BUILD_DOOR_ERR', e && e.message) }
  b.__building = false
  manualLockUntil = Date.now() + 8000
  anchor = { x: site.x + 0.5, y: site.y, z: site.z + 0.5, t: Date.now(), home: true }
  saveAnchor()
  log('BUILD hut done placed=' + placed + ' failed=' + failed + ' home=' + site.x + ' ' + site.y + ' ' + site.z)
  return placed >= 18
}
"""
i = src.find('function startReflexes (b) {')
assert i > 0
src = src[:i] + MODULE + '\n' + src[i:]
print('ok     B/C/D modules inserted (%d chars)' % len(MODULE))

# reflex: while the combat loop is engaged, survival logic must not steal movement
rep("""        const t = hs[0]
        const armed = hasWeapon(b)""",
"""        const t = hs[0]
        const armed = hasWeapon(b)
        // combat owns this fight: no flee/hide/tower ping-pong on top of it
        if (b.__fighting && now - (b.__fightAt || 0) < 1600) { lastPos = b.entity.position.clone(); return }""",
    tag='B1 reflex yields to combat')

# start hooks on spawn
rep("    try { startReflexes(b) } catch (e) { log('REFLEX_ERR', e && e.message) }",
"""    try { startReflexes(b) } catch (e) { log('REFLEX_ERR', e && e.message) }
    try { anchorOf(b); startLeash(b) } catch (e) { log('ANCHOR_ERR', e && e.message) }
    try { startCombat(b) } catch (e) { log('COMBAT_ERR', e && e.message) }""", tag='B2 hooks on spawn')

# stats: kills counter
rep("let stats = { deaths: 0, stucks: 0, mined: 0, crafted: 0, replies: 0, walked: 0, missions: 0, jumps: 0, born: Date.now() }",
    "let stats = { deaths: 0, stucks: 0, mined: 0, crafted: 0, replies: 0, walked: 0, missions: 0, jumps: 0, kills: 0, born: Date.now() }", tag='B3 stats.kills')
rep("        mined: stats.mined, crafted: stats.crafted, replies: stats.replies, walked: Math.round(stats.walked),",
    "        mined: stats.mined, crafted: stats.crafted, replies: stats.replies, kills: stats.kills || 0, walked: Math.round(stats.walked),", tag='B4 heartbeat kills')
rep("' srv=' + (b.__srvPos ? (b.__srvPos.x.toFixed(1)",
    "' kills=' + (stats.kills || 0) + ' leash=' + Math.round(distAnchor(b)) + 'r' + (leashOn ? leashR : 0) + ' srv=' + (b.__srvPos ? (b.__srvPos.x.toFixed(1)", tag='B5 status shows kills/leash')

# goto clamped to the leash circle
rep("""    if (cmd === 'goto') {
      const x = parseFloat(args[0]); const y = parseFloat(args[1]); const z = parseFloat(args[2])
      if (isNaN(x) || isNaN(y) || isNaN(z)) return respond(sock, 'ERR goto <x y z>')
      stopDrive(b)""",
"""    if (cmd === 'goto') {
      let x = parseFloat(args[0]); let y = parseFloat(args[1]); let z = parseFloat(args[2])
      if (isNaN(x) || isNaN(y) || isNaN(z)) return respond(sock, 'ERR goto <x y z>')
      if (leashOn && anchor) {
        const dxg = x - anchor.x; const dzg = z - anchor.z
        const dg = Math.hypot(dxg, dzg)
        if (dg > leashR) { x = anchor.x + dxg * leashR / dg; z = anchor.z + dzg * leashR / dg; log('GOTO_CLAMP', 'target was ' + dg.toFixed(0) + ' from anchor') }
      }
      stopDrive(b)""", tag='C1 goto clamp')

# new control commands
rep("""    if (cmd === 'reflex') {""",
"""    if (cmd === 'anchor') {
      if (args[0] === 'here' || args[0] === 'set') { const p = b.entity.position; anchor = { x: p.x, y: p.y, z: p.z, t: Date.now() }; saveAnchor(); return respond(sock, 'OK anchor=' + pos(b)) }
      const x = parseFloat(args[0]); const y = parseFloat(args[1]); const z = parseFloat(args[2])
      if (!isNaN(x) && !isNaN(y) && !isNaN(z)) { anchor = { x, y, z, t: Date.now() }; saveAnchor(); return respond(sock, 'OK anchor=' + x + ' ' + y + ' ' + z) }
      const a = anchorOf(b)
      return respond(sock, a ? 'anchor=' + Math.round(a.x) + ' ' + Math.round(a.y) + ' ' + Math.round(a.z) + ' (home=' + !!a.home + ') dist=' + distAnchor(b).toFixed(1) + ' leash=' + (leashOn ? leashR + 'r' : 'off') : 'no anchor yet')
    }
    if (cmd === 'leash') {
      if (args[0] === 'off') { leashOn = false; return respond(sock, 'OK leash off') }
      if (args[0] === 'on') { leashOn = true; return respond(sock, 'OK leash on r=' + leashR) }
      const r = parseFloat(args[0])
      if (!isNaN(r) && r > 4) { leashR = r; leashOn = true; return respond(sock, 'OK leash r=' + leashR) }
      return respond(sock, 'leash ' + (leashOn ? 'on' : 'off') + ' r=' + leashR + ' (2 chunks = 32)')
    }
    if (cmd === 'build') {
      respond(sock, 'OK building hut, see log')
      buildHut(b).then(ok => { if (!ok) log('BUILD failed') })
      return
    }
    if (cmd === 'site') {
      const s = pickBuildSite(b)
      return respond(sock, s ? 'flat 5x5 at ' + s.x + ' ' + s.y + ' ' + s.z + ' dist=' + Math.hypot(s.x - anchorOf(b).x, s.z - anchorOf(b).z).toFixed(1) : 'no flat 5x5 inside the circle')
    }
    if (cmd === 'named') {
      const q = args.join(' ').toLowerCase()
      if (!q) return respond(sock, 'ERR named <substring>')
      const out = []
      for (const it of b.inventory.items()) {
        let s = ''
        try { s = String(it.customName || '') } catch (e) {}
        try { s += '|' + JSON.stringify(it.nbt || {}) } catch (e) {}
        if (s.toLowerCase().indexOf(q) >= 0) out.push('slot' + it.index + ' ' + it.name + ' x' + it.count + ' name=' + (String(it.customName || '').slice(0, 48) || '(in nbt)'))
      }
      return respond(sock, out.length ? 'FOUND ' + out.join(' , ') : 'nothing named like \"' + args.join(' ') + '\"')
    }
    if (cmd === 'toss') {
      const q = args.join(' ').toLowerCase()
      if (!q) return respond(sock, 'ERR toss <name substring> [player]')
      let it = null
      for (const i2 of b.inventory.items()) {
        let s = String(i2.customName || '') + '|' + JSON.stringify(i2.nbt || {})
        if (s.toLowerCase().indexOf(q) >= 0 || i2.name === args[0]) { it = i2; break }
      }
      if (!it) return respond(sock, 'ERR nothing named like \"' + args.join(' ') + '\" in inventory')
      const want = args[args.length - 1]
      let pl = null
      if (want && b.players[want] && b.players[want].entity) pl = b.players[want].entity
      else pl = nearestPlayerEntity(b, 14)
      if (!pl) return respond(sock, 'REFUSED: no player within 14 - the cassette goes ONLY to players, wait for them')
      const dd = pl.position.distanceTo(b.entity.position)
      if (dd > 14) return respond(sock, 'REFUSED: nearest player ' + dd.toFixed(1) + ' away')
      try { await b.equip(it, 'hand') } catch (e) {}
      try { b.lookAt(pl.position.offset(0, 1.1, 0), true, false) } catch (e) {}
      await sleep(260)
      try { b.tossItem(it, 1); log('TOSS', it.name + ' -> ' + (pl.username || pl.name) + ' d=' + dd.toFixed(1)); return respond(sock, 'OK threw it to ' + (pl.username || pl.name)) } catch (e) { return respond(sock, 'ERR toss ' + (e && e.message)) }
    }
    if (cmd === 'fighton') { b.__noFight = args[0] === 'off'; return respond(sock, 'OK combat ' + (b.__noFight ? 'off' : 'on')) }
    if (cmd === 'reflex') {""", tag='C2/D commands')

io.open('bot.js', 'w', encoding='utf-8').write(src)
print('written, %d -> %d chars' % (orig_len, len(src)))
