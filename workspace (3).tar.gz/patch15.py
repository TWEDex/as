#!/usr/bin/env python3
# patch15: fix MY OWN regression - every early return in unstick() skipped "unstickBusy=false",
# so the flag latched true forever: stuck guard silent, director printing DIR_BLOCK, Puff idle.
import sys

F = 'bot.js'
s = open(F, encoding='utf8').read()
done = []

def sub(name, old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        print('!! %-14s found %d (expected %d)' % (name, n, count)); sys.exit(1)
    s = s.replace(old, new, count); done.append(name)

sub('flag-decl', """let unstickBusy = false""", """let unstickBusy = false
let unstickBusyAt = 0""")

sub('open-try', """  unstickBusy = true
  const d0 = intendedDir(b)
  const yaw0 = b.entity.yaw
  try {""",
    """  unstickBusy = true
  unstickBusyAt = Date.now()
  const d0 = intendedDir(b)
  const yaw0 = b.entity.yaw
  try {
   try {""")

sub('close-finally', """  } catch (e) { log('UNSTICK_ERR', e && e.message ? e.message : String(e)) }
  try { b.clearControlStates() } catch (e) {}
  unstickBusy = false
}""",
    """   } catch (e) { log('UNSTICK_ERR', e && e.message ? e.message : String(e)) }
  } finally {
    // REGRESSION of my own (patch11/12): the new detour/replan branches return early, and a
    // return inside try skips the code after it - so unstickBusy latched true forever, the
    // stuck guard went silent and the director just printed DIR_BLOCK. finally covers every
    // return, present and future.
    try { b.clearControlStates() } catch (e) {}
    unstickBusy = false
  }
}""")

sub('stale-watchdog', """      const inHole = inShaft(b)""",
    """      // defence in depth: an await that never resolves must not disable the guard for good
      if (unstickBusy && Date.now() - unstickBusyAt > 60000) {
        log('UNSTICK_BUSY_STALE cleared after ' + Math.round((Date.now() - unstickBusyAt) / 1000) + 's')
        unstickBusy = false
      }
      const inHole = inShaft(b)""")

open(F, 'w', encoding='utf8').write(s)
print('OK patch15 applied:', len(done), 'edits:', ', '.join(done))
