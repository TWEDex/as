#!/usr/bin/env python3
# Walk Puff home along a line of waypoints, re-issuing the goal until he makes progress.
import subprocess, time, re, sys

HOME = (-574, 87)          # anchor x,z (his home circle)
STEP = 60
MAX_MIN = 22


def ctl(cmd, wait=6):
    try:
        r = subprocess.run(['python3', 'botctl.py', cmd, str(wait)],
                           capture_output=True, text=True, timeout=wait + 40)
        return (r.stdout or '').strip()
    except Exception as e:
        return 'ERR ' + str(e)


def where():
    s = ctl('pos', 5)
    m = re.search(r'pos=(-?\d+) (-?\d+) (-?\d+)', s)
    if not m:
        return None
    return (int(m.group(1)), int(m.group(2)), int(m.group(3)), s)


def line(a, b, step):
    import math
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    n = max(1, int(math.hypot(dx, dy) / step) + 1)
    out = []
    for i in range(1, n + 1):
        t = i / n
        out.append((round(a[0] + dx * t), round(a[1] + dy * t)))
    return out


start = where()
if not start:
    print('cannot read position')
    sys.exit(1)
pos = (start[0], start[2])
wps = line(pos, HOME, STEP)
print('start %s target %s waypoints %d' % (pos, HOME, len(wps)), flush=True)
t0 = time.time()
ctl('leash off', 5)
ctl('director off', 5)
cur = start[1]
i = 0
while i < len(wps) and time.time() - t0 < MAX_MIN * 60:
    wx, wz = wps[i]
    last = None
    stall = 0
    for k in range(24):
        w = where()
        if not w:
            time.sleep(5)
            continue
        cur = w[1]
        d = ((w[0] - wx) ** 2 + (w[2] - wz) ** 2) ** 0.5
        if d < 22:
            print('  reached wp%d (%d,%d) d=%.0f at %s' % (i, wx, wz, d, w[:3]), flush=True)
            break
        if last is not None and abs(d - last) < 3:
            stall += 1
        else:
            stall = 0
        last = d
        if stall > 3:
            # side-step: try an offset waypoint to get around a wall/water
            ox = wx + (18 if i % 2 else -18)
            print('  stalled wp%d d=%.0f -> sidestep via %d,%d' % (i, d, ox, wz), flush=True)
            ctl('stop', 4)
            ctl('goto %d %d %d' % (ox, cur, wz), 6)
            time.sleep(18)
            ctl('goto %d %d %d' % (wx, cur, wz), 6)
            stall = 0
        else:
            ctl('goto %d %d %d' % (wx, cur, wz), 6)
        time.sleep(14)
    i += 1
w = where()
print('final %s after %.1f min' % (str(w[:3]), (time.time() - t0) / 60), flush=True)
