const mineflayer = require('mineflayer')
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder')
// Owner order: bot must not break blocks anymore (players rescue it). MC_NODIG=off re-enables.
const NO_DIG = process.env.MC_NODIG !== 'off'
const collectblock = require('mineflayer-collectblock')
const autoeat = require('mineflayer-auto-eat')
process.on('unhandledRejection', e => log('UNH_REJ', e && e.message ? e.message : String(e)))
process.on('uncaughtException', e => log('UNCAUGHT', e && e.message ? e.message : String(e)))
const Vec3 = require('vec3')
const net = require('net')
const fs = require('fs')

const HOST = process.env.MC_HOST || 'lokomir.twdx.ru'
const PORT = parseInt(process.env.MC_PORT || '25566', 10)
const VERSION = process.env.MC_VERSION || '1.21.11'
const USERNAME = process.env.MC_USER || 'GLaDOS'
const AUTH = process.env.MC_AUTH || 'offline'
const LOG = '/home/agent/bot/bot.log'
const CONTROL_PORT = parseInt(process.env.CONTROL_PORT || '25590', 10)

let mcData
try { mcData = require('minecraft-data')(VERSION) } catch (e) { mcData = null }
const nbt = require('prismarine-nbt')
const AUTH_PASS = process.env.MC_PASS || 'Puffberry2026x'
function varintBuf (value) { const b = []; do { let t = value & 0x7f; value >>>= 7; if (value !== 0) t |= 0x80; b.push(t) } while (value !== 0); return Buffer.from(b) }
function stringBuf (s) { const sb = Buffer.from(s, 'utf8'); return Buffer.concat([varintBuf(sb.length), sb]) }
function ccaPacketId (state) {
  try { const pk = mcData.protocol[state].toServer.types.packet; const m = pk[1][0].type[1].mappings; for (const k in m) { if (m[k] === 'custom_click_action') return parseInt(k, 16) } } catch (e) {}
  return state === 'play' ? 0x41 : 0x08
}

function log (...a) {
  const line = new Date().toISOString().slice(11, 19) + ' ' + a.map(x => typeof x === 'string' ? x : JSON.stringify(x)).join(' ')
  try { fs.appendFileSync(LOG, line + '\n') } catch (e) {}
  for (const s of clients) { try { s.write(line + '\n') } catch (e) {} }
}

const clients = new Set()
let bot = null
let reconnects = 0
let stopped = false

function makeBot () {
  const b = mineflayer.createBot({
    host: HOST, port: PORT, version: VERSION, username: USERNAME,
    auth: AUTH, hideErrors: false, checkTimeoutInterval: 60000,
    respawn: true
  })
  b.loadPlugin(pathfinder)
  try { b.loadPlugin(collectblock.plugin) } catch (e) { log('CB_LOAD_ERR', e.message) }
  try { b.loadPlugin(autoeat.loader || autoeat.plugin || autoeat) } catch (e) { log('AE_LOAD_ERR', e.message) }

  // This server pushes periodic position syncs (~1/s, seen as SRV_TP). Mineflayer's handler
  // zeroes velocity and onGround on EVERY 'position' packet, which kills jump momentum mid-air,
  // cancels knockback and makes the bot hover next to ledges. If the "teleport" did not actually
  // move us (<1.5 blocks), it is an echo sync - restore the pre-packet physics state.
  b.__syncKeep = 0; b.__syncReal = 0
  try {
    let preSync = null
    let velDirty = false
    // knockback/explosion velocity arriving between ticks must survive an echo sync
    b._client.on('entity_velocity', (packet) => { try { if (b.entity && packet.entityId === b.entity.id) velDirty = true } catch (e) {} })
    b.on('physicsTick', () => {
      try { if (b.entity) { preSync = { p: b.entity.position.clone(), v: b.entity.velocity.clone(), g: b.entity.onGround, t: Date.now() }; velDirty = false } } catch (e) {}
    })
    b.on('forcedMove', () => {
      try {
        if (!b.entity || !preSync) return
        const dp = b.entity.position.distanceTo(preSync.p)
        if (dp < 1.5 && Date.now() - preSync.t < 600) {
          if (!velDirty) b.entity.velocity.set(preSync.v.x, preSync.v.y, preSync.v.z)
          b.entity.onGround = preSync.g
          b.__syncKeep++
        } else {
          b.__syncReal++
          preSync = { p: b.entity.position.clone(), v: b.entity.velocity.clone(), g: b.entity.onGround, t: Date.now() }
        }
      } catch (e) {}
    })
  } catch (e) { log('SYNCGUARD_ERR', e && e.message) }

  try {
    b._client.on('packet', (data, meta) => { if (!b.entity && meta && meta.name && meta.name !== 'keep_alive') log('PKT', meta.name) })
    b.__inPk = {}; b.__outPk = {}
    b._client.on('packet', (data, meta) => {
      if (!meta || !meta.name) return
      b.__inPk[meta.name] = (b.__inPk[meta.name] || 0) + 1
      if (meta.name === 'position') {
        const sx = typeof data.x === 'number' ? data.x : data.a; const sy = typeof data.y === 'number' ? data.y : data.b; const sz = typeof data.z === 'number' ? data.z : data.c
        if (typeof sx === 'number') {
          b.__srvPos = { x: sx, y: sy, z: sz, t: Date.now() }
          const d = b.__lastTpLog || 0
          if (Date.now() - d > 1000) { b.__lastTpLog = Date.now(); log('SRV_TP', sx.toFixed(2) + ' ' + sy.toFixed(2) + ' ' + sz.toFixed(2)) }
        }
      }
    })
    try { b._client.on('packet_send', (data, meta) => { if (meta && meta.name) b.__outPk[meta.name] = (b.__outPk[meta.name] || 0) + 1 }) } catch (e) {}
    b._client.on('state', (st) => log('STATE', typeof st === 'string' ? st : JSON.stringify(st)))
    b._client.on('add_resource_pack', (packet) => {
      log('ADD_RESOURCE_PACK', JSON.stringify(packet))
      const uuid = packet && packet.uuid
      try {
        b._client.write('resource_pack_receive', { uuid, result: 3 })
        b._client.write('resource_pack_receive', { uuid, result: 0 })
        log('RP_ACCEPT_SENT uuid=' + uuid)
      } catch (e) { log('RP_ERR', e && e.message) }
    })
    b._client.on('remove_resource_pack', (packet) => log('REMOVE_RESOURCE_PACK', JSON.stringify(packet)))
    // MOVED: register after inject_allowed
    // MOVED: register after inject_allowed
  } catch (e) { log('HOOKERR', e && e.message) }

  try {
    b.on('windowOpen', (w) => { try { dumpWindow(w) } catch (e) { log('WDUMP_ERR', e && e.message) } })
    b.on('windowClose', () => { log('WINDOW_CLOSE') })
  } catch (e) { log('WHOOK_ERR', e && e.message) }

  b.once('inject_allowed', () => {
    setupPathfinder(b)
    // Register dialog listeners now that client is ready
    try {
      b._client.on('show_dialog', (packet) => { try { log('SHOW_DIALOG ' + JSON.stringify(packet).slice(0, 4000)) } catch (e) { log('SHOW_DIALOG_ERR ' + (e && e.message)) } setTimeout(() => { try { handleAuthDialog(b, packet) } catch (e) { log('AUTHDLG_ERR ' + (e && e.message)) } }, 700) })
      b._client.on('clear_dialog', () => log('CLEAR_DIALOG'))
    } catch (e) { log('DIALOG_HOOK_ERR', e && e.message) }
  })
  b.once('spawn', () => {
    reconnects = 0
    cautionUntil = Date.now() + 9000
    log('SPAWN', pos(b), 'world=' + (b.world ? 'ok' : '?'))
    setupPathfinder(b)
    try {
      if (b.autoEat) {
        try {
          b.autoEat.setOpts({ priority: 'foodPoints', minHealth: 14, minHunger: 13, eatingTimeout: 5000, strictErrors: false, bannedFood: ['rotten_flesh', 'pufferfish', 'chorus_fruit', 'poisonous_potato', 'spider_eye'] })
        } catch (e) { log('AE_OPTS_ERR', e && e.message) }
        try { b.autoEat.enableAuto(); log('AUTOEAT enabled (v5 API)') } catch (e) { log('AE_ENABLE_ERR', e && e.message) }
      } else { log('AUTOEAT plugin missing') }
    } catch (e) { log('AE_ERR', e.message) }
    try { startReflexes(b) } catch (e) { log('REFLEX_ERR', e && e.message) }
    try { startStuckGuard(b) } catch (e) { log('SG_ERR', e && e.message) }
    try { startHeartbeat(b) } catch (e) { log('HB_ERR', e && e.message) }
    try { startAutoJump(b) } catch (e) { log('AJ_ERR', e && e.message) }
    try { startInputSync(b) } catch (e) { log('IS_ERR', e && e.message) }
    announceLoaded(b)
    if (process.env.MC_AUTOFREE === 'on') autoFree(b)
    try { startDirector(b) } catch (e) { log('DIRECTOR_ERR', e && e.message) }
  })
  // PERSISTENT spawn listener: mineflayer emits 'spawn' on EVERY respawn, but the
  // handler above is once(). The server respawns us right back into the mob nest we
  // died in - without an immediate escape run it is an endless death loop.
  b.__spawnCount = 0
  b.on('spawn', async () => {
    try {
      b.__spawnCount++
      if (b.__spawnCount <= 1) return                  // first login: once() handler covers it
      log('RESPAWN #' + (b.__spawnCount - 1) + ' at', pos(b))
      cautionUntil = Math.max(cautionUntil, Date.now() + 25000)
      const src = b.__deathPos || (b.entity ? b.entity.position.clone() : null)
      b.__deathPos = null
      mission = null
      // nest respawn: bury in place instead of running the mob gauntlet
      const sp0 = b.entity ? b.entity.position : null
      const nearNest = sp0 && (Math.hypot(sp0.x - NEST.x, sp0.z - NEST.z) < 30 || inDeathZone(sp0.x, sp0.z, 25))
      if (nearNest) {
        log('RESPAWN bury at', pos(b))
        if (await buryAtSpawn(b)) return
      }
      // instant raw sprint toward the most open away-direction (no time to wait for pathing)
      const ep = src ? escapePointFrom(b, src, 40) : null
      if (ep && b.entity) {
        const yaw = Math.atan2(-(ep.x - b.entity.position.x), ep.z - b.entity.position.z)
        try { b.look(yaw, 0, true) } catch (e) {}
        // only a brief lock so look+sprint settle; autoJump MUST stay active afterwards -
        // the old 6s lock stalled the sprint on every jungle step = respawn death spiral
        jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 800)
        b.__respawnSprintUntil = Date.now() + 15000
        try { b.setControlState('forward', true); b.setControlState('sprint', true) } catch (e) {}
        setTimeout(() => {
          try {
            b.setControlState('forward', false); b.setControlState('sprint', false)
            if (!b.entity || b.health <= 0 || mission) return
            const th = nearestHostile(b, 24)
            const src2 = (th && th.position) || src || b.entity.position
            const ep2 = escapePointFrom(b, src2, 55)
            if (ep2) { log('RESPAWN_RUN to ' + ep2.x + ' ' + ep2.z + (th ? ' (away from ' + th.name + ')' : '')); b.pathfinder.setGoal(new goals.GoalXZ(ep2.x, ep2.z)) }
          } catch (e) {}
        }, 2500)
      }
    } catch (e) { log('RESPAWN_ERR', e && e.message) }
  })
  b.on('kicked', reason => { log('KICKED', reason); stopped = true })
  b.on('error', err => log('ERROR', err && err.message ? err.message : String(err)))
  b.on('end', () => {
    log('END (disconnected)')
    try { if (b.__director) clearInterval(b.__director) } catch (e) {}
    try { if (b.__reflex) clearInterval(b.__reflex) } catch (e) {}
    try { if (b.__ajump) clearInterval(b.__ajump) } catch (e) {}
    try { if (b.__stuckGuard) clearInterval(b.__stuckGuard) } catch (e) {}
    try { if (b.__hb) clearInterval(b.__hb) } catch (e) {}
    try { if (b.__inputTimer) clearInterval(b.__inputTimer) } catch (e) {}
    try { if (b.__loadedTimer) clearInterval(b.__loadedTimer) } catch (e) {}
    if (!stopped) {
      reconnects++
      const delay = Math.min(45000, 3000 * Math.min(reconnects, 8))
      log('reconnect #' + reconnects + ' in ' + (delay / 1000) + 's')
      setTimeout(() => { if (!stopped) { bot = makeBot() } }, delay)
    }
  })
  b.on('chat', (user, msg) => { if (user !== USERNAME) { log('CHAT', user + ': ' + msg); try { feedChat(b, user, msg, false) } catch (e) {} } })
  b.on('whisper', (user, msg) => { log('WHISPER', user + ': ' + msg); try { feedChat(b, user, msg, true) } catch (e) {} })
  b.on('messagestr', (msg) => {
    log('MSG', msg)
    try { if (/Successful login|Logged-in due to Session/i.test(msg)) { b.__authOk = Date.now(); log('AUTH ok - movement unfrozen') } } catch (e) {}
    try { if (/^[<(]/.test(msg)) { const m = msg.match(/^[<(]([^>)>]{1,24})[>)>]\s*(.+)$/); if (m) feedChat(b, m[1].trim(), m[2], false) } } catch (e) {}
    const pw = process.env.MC_PASSWORD || ''
    if (pw && /login|register|авториз|пароль|\/reg|\/login/i.test(msg)) {
      if (!b.__registered) { b.chat('/register ' + pw + ' ' + pw); b.__registered = true; log('AUTH register sent') } else { b.chat('/login ' + pw); log('AUTH login sent') }
    }
  })
  b.on('blockBreakProgressUpdate', () => { lastDigAt = Date.now() })
  b.on('blockBreakProgressEnd', () => { lastDigAt = Date.now() })
  b.on('entityHurt', (e) => { try { if (e === b.entity) { lastHurtAt = Date.now(); log('HURT hp=' + Math.round(b.health) + ' food=' + Math.round(b.food)) } } catch (er) {} })
  b.on('login', () => log('LOGIN event (play state)'))
  try { b.on('entitySpawn', () => {}) } catch (e) {}
  b.on('death', () => { stats.deaths++; saveStats(); cautionUntil = Date.now() + 18000; lastHurtAt = 0; try { b.__deathPos = b.entity ? b.entity.position.clone() : null } catch (e) {}; try { noteDeathZone(b.__deathPos) } catch (e) {}; try { mission = null } catch (e) {}; try { b.pathfinder.setGoal(null) } catch (e) {}; log('DIED, respawning (total ' + stats.deaths + ')') })
  b.on('health', () => {})
  setTimeout(() => {
    if (!b.entity) {
      const st = b._client ? b._client.state : '?'
      log('STILL_CONNECTING state=' + st + ' ended=' + (b._client ? b._client.ended : '?'))
    }
  }, 9000)
  return b
}

function pos (b) {
  if (!b || !b.entity) return 'n/a'
  const p = b.entity.position
  return Math.floor(p.x) + ' ' + Math.floor(p.y) + ' ' + Math.floor(p.z)
}

function respond (sock, text) { try { sock.write(text + '\n') } catch (e) {} }

function sleep (ms) { return new Promise(r => setTimeout(r, ms)) }
function withTimeout (p, ms, val) { return Promise.race([Promise.resolve(p).catch(() => val), sleep(ms).then(() => val)]) }

function chatText (c) {
  if (c == null) return ''
  if (typeof c === 'string') {
    const t = c.trim()
    if (t.startsWith('{') || t.startsWith('[')) { try { return chatText(JSON.parse(t)) } catch (e) { return c } }
    return c
  }
  if (typeof c.toPlainText === 'function') { try { return c.toPlainText() } catch (e) {} }
  if (typeof c.toString === 'function') { try { const s = c.toString(); if (s && s !== '[object Object]') return s } catch (e) {} }
  let s = ''
  if (typeof c.text === 'string') s += c.text
  if (typeof c.translate === 'string') s += c.translate
  if (Array.isArray(c.extra)) for (const e of c.extra) s += chatText(e)
  return s
}
function dumpWindow (w) {
  if (!w) { log('WINDOW none'); return }
  let title = ''
  try { title = chatText(w.title) } catch (e) { title = String(w.title) }
  const parts = []
  for (let i = 0; i < w.slots.length; i++) {
    const it = w.slots[i]
    if (it) {
      let dn = ''
      try { dn = chatText(it.displayName) || it.displayName || '' } catch (e) { dn = it.displayName || '' }
      parts.push(i + '=' + it.name + (dn && dn !== it.name ? '("' + dn + '")' : '') + 'x' + it.count)
    }
  }
  log('WINDOW_OPEN title="' + title + '" type=' + w.type + ' id=' + w.id + ' slots=' + w.slots.length)
  log('WINDOW_ITEMS ' + (parts.length ? parts.join(' | ') : '(empty)'))
}
function sendCustomClickAction (b, id, payloadObj) {
  try {
    const client = b._client
    const state = client.state || 'configuration'
    const parts = [varintBuf(ccaPacketId(state)), stringBuf(id)]
    let nbtLen = 0
    if (payloadObj) {
      const nbtBytes = nbt.proto.createPacketBuffer('anonymousNbt', payloadObj)
      nbtLen = nbtBytes.length
      parts.push(varintBuf(nbtLen), nbtBytes)
    } else {
      parts.push(varintBuf(0))
    }
    const raw = Buffer.concat(parts)
    client.writeRaw(raw)
    log('DIALOG_RESP sent id=' + id + ' state=' + state + ' nbtLen=' + nbtLen + ' rawLen=' + raw.length)
    return true
  } catch (e) { log('DIALOG_RESP_ERR ' + (e && e.message ? e.message : String(e))); return false }
}
function handleAuthDialog (b, packet) {
  const dialog = packet && packet.dialog && packet.dialog.value ? packet.dialog.value : null
  if (!dialog) { log('AUTHDLG no dialog body'); return }
  const actions = (dialog.actions && dialog.actions.value && dialog.actions.value.value) || []
  const inputs = (dialog.inputs && dialog.inputs.value && dialog.inputs.value.value) || []
  const inputKeys = inputs.map(i => (i && i.key && i.key.value) || null).filter(Boolean)
  let submitId = null
  for (const a of actions) { const idv = a && a.action && a.action.value && a.action.value.id && a.action.value.id.value; if (idv && !/cancel/i.test(idv) && /submit|register|login|confirm|enter|ok/i.test(idv)) { submitId = idv; break } }
  if (!submitId) { for (const a of actions) { const idv = a && a.action && a.action.value && a.action.value.id && a.action.value.id.value; if (idv && !/cancel/i.test(idv)) { submitId = idv; break } } }
  if (!submitId) { log('AUTHDLG no submit action found'); return }
  const payload = { type: 'compound', value: {} }
  for (const k of inputKeys) payload.value[k] = { type: 'string', value: AUTH_PASS }
  log('AUTHDLG submit id=' + submitId + ' inputs=[' + inputKeys.join(',') + ']')
  sendCustomClickAction(b, submitId, inputKeys.length ? payload : null)
}

// how close each mob has to be before it is actually a problem
const THREAT = {
  creeper: 6, zombie: 9, husk: 9, drowned: 9, zombie_villager: 9, zombified_piglin: 9,
  spider: 10, cave_spider: 10, silverfish: 6, slime: 8, magma_cube: 8,
  skeleton: 20, stray: 20, bogged: 20, wither_skeleton: 11, pillager: 20, witch: 17,
  blaze: 15, evoker: 15, vindicator: 10, vex: 10, breeze: 13,
  enderman: 5, phantom: 9, warden: 26, hoglin: 10, zoglin: 10, piglin_brute: 10
}
function threatRadius (name) { return THREAT[String(name || '').toLowerCase()] || 9 }
// hostiles that are actually a threat at their current distance, worst first
function threatsNear (b, mul) {
  const out = []
  if (!b.entity) return out
  for (const id in b.entities) {
    const e = b.entities[id]
    if (!e || !e.position || !e.name || e === b.entity) continue
    if (!HOSTILE.has(String(e.name).toLowerCase())) continue
    if (e.health !== undefined && e.health <= 0) continue
    const d = e.position.distanceTo(b.entity.position)
    const r = threatRadius(e.name) * (mul || 1)
    if (d <= r) out.push({ e, d, r })
  }
  out.sort((x, y) => (x.d / x.r) - (y.d / y.r))
  return out
}
const HOSTILE = new Set(['zombie','zombie_villager','husk','drowned','skeleton','stray','wither_skeleton','bogged','creeper','spider','cave_spider','silverfish','enderman','slime','magma_cube','phantom','vindicator','evoker','pillager','vex','witch','blaze','zombified_piglin','piglin_brute','hoglin','zoglin','warden','breeze','cave_spider'])

function nearestHostile (b, radius) {
  let best = null; let bd = radius
  for (const id in b.entities) {
    const e = b.entities[id]
    if (!e || !e.position || !e.name || e === b.entity) continue
    if (!HOSTILE.has(String(e.name).toLowerCase())) continue
    if (e.health !== undefined && e.health <= 0) continue
    const d = e.position.distanceTo(b.entity.position)
    if (d < bd) { bd = d; best = e }
  }
  return best
}

const WEAPONS = ['netherite_sword','diamond_sword','iron_sword','stone_sword','golden_sword','wooden_sword','netherite_axe','diamond_axe','iron_axe','stone_axe','golden_axe','wooden_axe']
function equipBestWeapon (b) {
  const items = b.inventory.items()
  for (const w of WEAPONS) { const it = items.find(i => i.name === w); if (it) { b.equip(it, 'hand').catch(() => {}); return w } }
  return null
}
function hasWeapon (b) {
  try { for (const it of b.inventory.items()) { if (it && WEAPONS.includes(it.name)) return true } } catch (e) {}
  return false
}
const ARMOR_SLOTS = {
  head: ['netherite_helmet', 'diamond_helmet', 'iron_helmet', 'chainmail_helmet', 'golden_helmet', 'copper_helmet', 'leather_helmet', 'turtle_shell'],
  torso: ['netherite_chestplate', 'diamond_chestplate', 'iron_chestplate', 'chainmail_chestplate', 'golden_chestplate', 'copper_chestplate', 'leather_chestplate'],
  legs: ['netherite_leggings', 'diamond_leggings', 'iron_leggings', 'chainmail_leggings', 'golden_leggings', 'copper_leggings', 'leather_leggings'],
  feet: ['netherite_boots', 'diamond_boots', 'iron_boots', 'chainmail_boots', 'golden_boots', 'copper_boots', 'leather_boots']
}
function equipArmor (b) {
  try {
    const items = b.inventory.items()
    for (const slot in ARMOR_SLOTS) {
      for (const n of ARMOR_SLOTS[slot]) {
        const it = items.find(i => i.name === n)
        if (it) { try { b.equip(it, slot).catch(() => {}) } catch (e) {} ; break }
      }
    }
  } catch (e) {}
}
function nearestPlayerEntity (b, r) {
  let best = null; let bd = r
  if (!b.entity) return null
  for (const k in b.players) {
    const pl = b.players[k]
    if (!pl.entity || pl.entity === b.entity) continue
    const d = pl.entity.position.distanceTo(b.entity.position)
    if (d < bd) { bd = d; best = pl.entity }
  }
  return best
}
function fleeFrom (b, e) {
  if (!b.entity || !e || !e.position) return
  const bp = b.entity.position
  let ax = bp.x - e.position.x; let az = bp.z - e.position.z
  const len = Math.sqrt(ax * ax + az * az) || 1
  ax /= len; az /= len
  const mate = nearestPlayerEntity(b, 60)
  if (mate && b.health <= 16) {
    const mx = mate.position.x - bp.x; const mz = mate.position.z - bp.z
    const ml = Math.hypot(mx, mz) || 1
    const w = b.health <= 8 ? 1.6 : 0.7
    ax += (mx / ml) * w; az += (mz / ml) * w
    const nl = Math.hypot(ax, az) || 1
    ax /= nl; az /= nl
  }
  for (let i = 0; i < 8; i++) {
    const tx = Math.round(bp.x + ax * 6); const tz = Math.round(bp.z + az * 6)
    if (!isWaterAt(b, tx, tz)) break
    const c = Math.cos(Math.PI / 4); const s = Math.sin(Math.PI / 4)
    const nx = ax * c - az * s; const nz = ax * s + az * c
    ax = nx; az = nz
  }
  if (RANGED.has(String(e.name || '').toLowerCase())) {
    // strafing a shooter ruins its aim far better than running in a straight line
    const side = (Math.floor(Date.now() / 850) % 2 === 0) ? 1 : -1
    const px = -az * side; const pz = ax * side
    ax = ax * 0.35 + px * 0.95; az = az * 0.35 + pz * 0.95
    const nl2 = Math.hypot(ax, az) || 1; ax /= nl2; az /= nl2
    forceJumpUntil = Date.now() + 1400            // bunny-hop: arrows keep missing
  }
  // obstacle-aware steering: sprinting face-first into a tree kills the escape
  // (sprint momentum dies on every collision). If a wall blocks the run, turn 90 degrees.
  try {
    if (frontObstacle(b, { x: ax, z: az }, 1.25) === 'wall') {
      const r1x = -az, r1z = ax          // +90 degrees
      const r2x = az, r2z = -ax          // -90 degrees
      if (frontObstacle(b, { x: r1x, z: r1z }, 1.25) !== 'wall') { ax = r1x; az = r1z }
      else if (frontObstacle(b, { x: r2x, z: r2z }, 1.25) !== 'wall') { ax = r2x; az = r2z }
      else { ax = r1x; az = r1z }        // walled in both sides: turn anyway, stuck guard takes over
    }
  } catch (err) {}
  try {
    const dd = e.position ? bp.distanceTo(e.position) : 99
    if (dd < 3.5) b.look(Math.atan2(-ax, az), 0, true)              // emergency snap: turn NOW
    else b.lookAt(new Vec3(bp.x + ax * 10, bp.y + 1, bp.z + az * 10))
  } catch (err) {}
  try { b.setControlState('forward', true); b.setControlState('sprint', true) } catch (err) {}
}

const FOODS = ['golden_apple','cooked_beef','cooked_porkchop','cooked_mutton','cooked_chicken','cooked_rabbit','cooked_salmon','cooked_cod','beef','porkchop','mutton','chicken','rabbit','bread','baked_potato','apple','melon_slice','sweet_berries','carrot','potato','beetroot_soup','mushroom_stew','rabbit_stew','cookie','pumpkin_pie','dried_kelp']
function findFood (b) {
  const items = b.inventory.items()
  for (const f of FOODS) { const it = items.find(i => i.name === f); if (it) return it }
  return null
}
async function eatFood (b) {
  const f = findFood(b)
  if (!f) return false
  try { await b.equip(f, 'hand') } catch (e) { return false }
  try { b.setControlState('forward', false); b.setControlState('sprint', false) } catch (e) {}
  try { await b.consume(); log('ATE', f.name, 'hp=' + Math.round(b.health), 'food=' + Math.round(b.food)); return true } catch (e) { return false }
}

function setupPathfinder (b) {
  if (!b.__digWrapped) {
    b.__digWrapped = true
    const _dig0 = b.dig.bind(b)
    b.dig = async (block, force) => {
      if (NO_DIG && !b.__allowDig) return false
      return _dig0(block, force)
    }
    log('NODIG mode', NO_DIG)
  }
  if (!mcData) return
  try {
    const mv = new Movements(b, mcData)
    // Digging is a LAST RESORT, not a habit: laborCost = (1 + 3*digTime/1000) * digCost.
    // With digCost=2 a jump-up (~2) always beats digging a dirt step (~6.5), walking around
    // beats digging stone (~47 by hand), but genuine climb-outs through soft slopes stay possible.
    mv.canDig = true
    mv.digCost = 2
    mv.allow1by1towers = true
    mv.allowParkour = true
    mv.allowSprinting = true
    mv.liquidCost = 200
    mv.infiniteLiquidDropdownDistance = false
    try { mv.scafoldingBlocks = [mcData.blocksByName.cobblestone.id, mcData.blocksByName.dirt.id] } catch (e) {}
    b.pathfinder.setMovements(mv)
    b.__movements = mv
    // collectblock REPLACES pathfinder movements with its own on every collect() call
    // (defaults: canDig=true, digCost=1 = casual tunneling) - tune its instance to match
    try {
      if (b.collectBlock && b.collectBlock.movements) {
        b.collectBlock.movements.canDig = true
        b.collectBlock.movements.digCost = 2
        b.collectBlock.movements.allow1by1towers = true
        b.collectBlock.movements.allowParkour = true
        b.collectBlock.movements.allowSprinting = true
      }
    } catch (e) {}
    b.pathfinder.thinkTimeout = 6000
    b.pathfinder.tickTimeout = 60
    // Cap A* cost at (h(start) + searchRadius). On steep jungle hills an uncapped
    // search "thinks" past every timeout while the bot stands still (moved=0.0).
    // Capped, A* concludes fast and returns PARTIAL paths: the bot keeps walking
    // toward the target and greedy recomputes carry it the rest of the way.
    b.pathfinder.searchRadius = 100
    log('PF_READY thinkTimeout=' + b.pathfinder.thinkTimeout + ' searchRadius=' + b.pathfinder.searchRadius + ' digCost=2 (dig=last resort)')
  } catch (e) { log('PF_ERR', e && e.message ? e.message : String(e)) }
}

function solidAt (b, v) { const blk = b.blockAt(v); return !!(blk && blk.boundingBox === 'block') }
function isWaterAt (b, x, z) {
  if (!b.entity) return false
  const y = b.entity.position.y
  // -9..+3 around us AND a fixed ocean band: from a y=67 shore the old -3..+3 scan
  // MISSED the y=62-63 sea surface, so "dry" escape points kept landing in the ocean
  for (let dy = -9; dy <= 3; dy++) { const blk = b.blockAt(new Vec3(x, y + dy, z)); if (blk && /water|lava/.test(blk.name)) return true }
  for (let sy = 59; sy <= 64; sy++) { const blk = b.blockAt(new Vec3(x, sy, z)); if (blk && /water|lava/.test(blk.name)) return true }
  return false
}

function hostilesNear (b, r) {
  const out = []
  for (const id in b.entities) {
    const e = b.entities[id]
    if (!e || !e.position || !e.name || e === b.entity) continue
    if (!HOSTILE.has(String(e.name).toLowerCase())) continue
    if (e.health !== undefined && e.health <= 0) continue
    const d = e.position.distanceTo(b.entity.position)
    if (d <= r) out.push({ e, d })
  }
  out.sort((a, c) => a.d - c.d)
  return out
}

async function digBlock (b, v) {
  if (NO_DIG) return false
  const blk = b.blockAt(v)
  if (!blk || blk.boundingBox !== 'block') return false
  try { await b.lookAt(blk.position.offset(0.5, 0.5, 0.5)); await b.dig(blk); stats.mined++; await suckDrop(b, v); return true } catch (e) { return false }
}

// bot.dig() drops items NEXT TO the bot (outside pickup range, 10-tick pickup delay),
// and on slopes they ROLL downhill - walk to the item entity's CURRENT position,
// not to the mined cell (that version lost every drop: mined+15, inv empty)
async function suckDrop (b, v) {
  try {
    if (!b.entity) return
    let pf = false; try { pf = b.pathfinder.isMoving() } catch (e) {}
    if (pf) return                                        // pathfinder driving: don't fight its controls
    await sleep(640)                                      // item pickup delay + roll settling
    if (!b.entity) return
    let best = null; let bd = 1e9
    for (const id in b.entities) {
      const e = b.entities[id]
      if (!e || e.name !== 'item' || !e.position) continue
      const dh = Math.hypot(e.position.x - v.x - 0.5, e.position.z - v.z - 0.5)
      if (dh > 7 || Math.abs(e.position.y - v.y) > 12) continue
      const d3 = e.position.distanceTo(b.entity.position)
      if (d3 < bd) { bd = d3; best = e }
    }
    if (!best || bd < 1.0) return                         // nothing or already in pickup range
    const p = b.entity.position
    const dx = best.position.x - p.x; const dz = best.position.z - p.z
    const l = Math.hypot(dx, dz)
    const dyItem = best.position.y - p.y
    if (dyItem > 1.2) {
      // underwater drops FLOAT to the surface - swim up after them instead of
      // walking on the bottom (that lost every cove-dig drop: mined+8, inv empty)
      try { await b.look(Math.atan2(-dx, dz), -0.6, true) } catch (e) {}
      b.setControlState('forward', true); b.setControlState('jump', true)
      await sleep(Math.min(1500, 500 + Math.abs(dyItem) * 220))
      b.setControlState('forward', false); b.setControlState('jump', false)
      return
    }
    if (l > 6.5) return
    try { await b.look(Math.atan2(-dx, dz), 0, true) } catch (e) {}
    b.setControlState('forward', true)
    await sleep(Math.min(1100, Math.max(300, l * 320)))
    b.setControlState('forward', false)
  } catch (e) {}
}

async function ensureHeadroom (b) {
  if (!b || !b.entity) return
  const feet = b.entity.position.floored()
  for (const dy of [1, 2]) { const v = feet.offset(0, dy, 0); if (solidAt(b, v)) await digBlock(b, v) }
}

let escapeDirIdx = 0
let escaping = false
const ESCAPE_DIRS = [[1, 0], [0, 1], [-1, 0], [0, -1]]

async function pillarUp (b, levels) {
  jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 2500 + levels * 900)
  for (let i = 0; i < levels; i++) {
    if (!b.entity) return
    const matName = PLACEABLE.find(nm => countItem(b, nm) > 0)
    if (!matName) { log('PILLAR no material'); return }
    const mat = b.inventory.items().find(it => it.name === matName)
    try { await b.equip(mat, 'hand') } catch (e) {}
    const base = b.entity.position.floored()
    const baseBlk = b.blockAt(base)
    if (baseBlk && baseBlk.boundingBox === 'block') return
    const wet = botWet(b)
    // puddle/water column: the solid floor can be 2-4 cells below - build the tower
    // FROM THE FLOOR UP (fill = first open cell above the deepest solid found)
    let ref = null; let fill = null
    for (let dy = -1; dy >= -4; dy--) {
      const cand = b.blockAt(base.offset(0, dy, 0))
      if (cand && cand.boundingBox === 'block') {
        const above = b.blockAt(cand.position.offset(0, 1, 0))
        if (above && above.boundingBox !== 'block') { ref = cand; fill = cand.position.offset(0, 1, 0) }
        break
      }
    }
    if (!ref) { log('PILLAR no ref at', pos(b)); return }
    const y0 = b.entity.position.y
    const riseNeed = Math.max(1.08, fill.y + 1.15 - y0)
    b.setControlState('jump', true)
    const t0 = Date.now()
    while (Date.now() - t0 < (wet ? 2600 : 1300) && b.entity && b.entity.position.y < y0 + riseNeed) await sleep(60)
    b.setControlState('jump', false)
    if (!b.entity) return
    // water jump-hold bobs lower than a ground jump: accept a smaller rise when wet
    if (b.entity.position.y - y0 < (wet ? 0.3 : 0.55) || b.entity.position.y < fill.y + 0.9) {
      b.__noRiseN = (b.__noRiseN || 0) + 1
      log('PILLAR no rise at', pos(b), 'n=' + b.__noRiseN)
      if (b.__noRiseN >= 3 && !wet && !deepNearCrater(b)) {
        // flat dry floor + rejected jumps = possible client/server desync. Reconnect only
        // if the owner enabled MC_HEAL (forced reconnects here caused rejoin spam and
        // never actually fixed the wedged spot - the stuck-escalation ladder handles it).
        b.__noRiseN = 0
        if (healReconnect(b, 'pillar no-rise x3 at ' + pos(b))) return
        await sleep(1200); continue
      }
      await sleep(250); continue
    }
    b.__noRiseN = 0
    const still = b.blockAt(fill)
    if (still && still.boundingBox === 'block') { await sleep(200); continue }
    const r = await withTimeout(b.placeBlock(ref, new Vec3(0, 1, 0)), 3500, 'to')
    if (r === 'to') log('PILLAR place failed at', pos(b))
    await sleep(280)
  }
}
const PLACEABLE = ['dirt', 'coarse_dirt', 'rooted_dirt', 'mud', 'packed_mud', 'cobblestone', 'grass_block', 'moss_block', 'cobbled_deepslate', 'blackstone', 'netherrack', 'stone', 'sand', 'gravel', 'oak_planks', 'birch_planks', 'spruce_planks', 'oak_log', 'birch_log', 'spruce_log', 'jungle_log', 'acacia_log', 'pale_oak_log', 'cherry_log', 'dark_oak_log', 'mangrove_log', 'bamboo_block', 'pale_oak_planks', 'pale_oak_stairs', 'pale_oak_slab', 'stone_bricks', 'mossy_cobblestone', 'diorite', 'andesite', 'granite', 'deepslate', 'cobbled_deepslate_slab']
function countPlaceable (b) { let n = 0; for (const m of PLACEABLE) n += countItem(b, m); return n }
const GROUND_RE = /dirt|grass_block|podzol|mycelium|sand|gravel|stone|cobble|deepslate|granite|diorite|andesite|tuff|calcite|moss_block|mud|terracotta|netherrack|blackstone|basalt|_log|_wood|planks|bamboo_block|bricks|dripstone_block|amethyst_block|copper_block|quartz_block|purpur|magma_block|mossy/
async function ensurePlaceable (b, need, allowBelow = true) {
  if (countPlaceable(b) >= need) return true
  const feet = b.entity.position.floored()
  const cands = []
  // side walls at feet AND head level first; digging BELOW ourselves in a hole
  // deepened the trench from y56 to y52 and made the escape impossible
  for (const d of ESCAPE_DIRS) { cands.push(feet.offset(d[0], 0, d[1])); cands.push(feet.offset(d[0], 1, d[1])) }
  // bowl walls: +-1 cells are often already dug out - reach 2 out as well
  for (const d of ESCAPE_DIRS) { cands.push(feet.offset(d[0] * 2, 0, d[1] * 2)); cands.push(feet.offset(d[0] * 2, 1, d[1] * 2)) }
  if (allowBelow) {
    for (const d of ESCAPE_DIRS) cands.push(feet.offset(d[0], -1, d[1]))
    cands.push(feet.offset(0, -2, 0))                   // last resort: dig under ourselves (stone -> cobble = placeable)
  }
  // only ground-type blocks drop placeable items - digging jungle leaves/vines
  // "succeeded" 10x and yielded NOTHING (PILLAR no material spam)
  for (const v of cands) {
    if (countPlaceable(b) >= need) break
    const blk = b.blockAt(v)
    if (!blk || blk.boundingBox !== 'block') continue
    if (!GROUND_RE.test(blk.name)) continue
    if ((blk.hardness === undefined ? 1 : blk.hardness) < 0) continue
    await digBlock(b, v)
    await sleep(420)
  }
  return countPlaceable(b) > 0
}
function rimAbove (b) {
  if (!b.entity) return 0
  const feet = b.entity.position.floored()
  let rim = feet.y
  for (const d of ESCAPE_DIRS) {
    for (let dy = 12; dy >= 1; dy--) { const blk = b.blockAt(feet.offset(d[0], dy, d[1])); if (blk && blk.boundingBox === 'block') { if (feet.y + dy > rim) rim = feet.y + dy; break } }
  }
  return rim - feet.y
}
function manualWalkDry (b, ms) {
  if (!b.entity) return
  const bp = b.entity.position.floored()
  const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]]
  let bestDir = null; let bestScore = -1e9
  for (const d of dirs) {
    let score = 0
    for (let k = 1; k <= 4; k++) {
      const v = bp.offset(d[0] * k, 0, d[1] * k)
      const blk = b.blockAt(v)
      const below = b.blockAt(v.offset(0, -1, 0))
      if (blk && /water|lava/.test(blk.name)) { score -= 20; break }
      if (blk && blk.boundingBox === 'block') score -= 3
      else score += 2
      if (below && below.boundingBox === 'block') score += 1
    }
    if (score > bestScore) { bestScore = score; bestDir = d }
  }
  const d = bestDir || dirs[0]
  const yaw = Math.atan2(-d[0], d[1])
  jumpLockUntil = Math.max(jumpLockUntil, Date.now() + (ms || 1600) + 400)
  try { b.look(yaw, 0) } catch (e) {}
  try { b.setControlState('forward', true); b.setControlState('sprint', true); b.setControlState('jump', true) } catch (e) {}
  setTimeout(() => { try { b.setControlState('forward', false); b.setControlState('sprint', false); b.setControlState('jump', false) } catch (e) {} }, ms || 1600)
}
// climb a tower while HARVESTING the wall for material each level (the dug-out bowl
// has nothing at +-1 anymore; walls 2-3 out are solid). Fixes "PILLAR no material" loops.
async function pillarClimb (b, levels) {
  for (let i = 0; i < levels && b.entity && b.health > 0; i++) {
    if (countPlaceable(b) < 2) {
      let got = false
      const feet = b.entity.position.floored()
      for (let r = 1; r <= 3 && !got; r++) {
        for (const d of [[r, 0], [-r, 0], [0, r], [0, -r], [r, r], [r, -r], [-r, r], [-r, -r]]) {
          for (const dy of [-1, 0, 1]) {                        // -1 = crater FLOOR cells (stone/sand, sky above = safe)
            const v = feet.offset(d[0], dy, d[1])
            if (!diggableSurface(b, v)) continue               // buried cells cascade (sand hourglass)
            if (await withTimeout(digBlock(b, v), 9000, false)) { got = true; break }
          }
          if (got) break
        }
      }
      if (!got && countPlaceable(b) < 1) { log('CLIMB no material at all at', pos(b)); return }
    }
    const yBefore = b.entity.position.y
    await pillarUp(b, 1)
    await sleep(150)
    if (b.entity && b.entity.position.y - yBefore < 0.5) {
      // puddle deadlock: a water jump lifts ~0.4b but placing needs feet 0.9b above the
      // fill cell - walk to the dry bowl edge first, pillar from there
      if (botWet(b)) { log('CLIMB puddle -> walk dry at', pos(b)); manualWalkDry(b, 1800); await sleep(2000); continue }
      // CEILING deadlock (low corridor under the rim): a dry jump needs cells +2/+3 open -
      // dig through the roof, the drops become pillar material, then tower up the shaft
      const ft = b.entity.position.floored()
      let roofDug = false
      for (const dy of [2, 3]) {
        if (inCollapseZone(b)) break                            // no roof digs in the hourglass
        const cv = ft.offset(0, dy, 0)
        const cb = b.blockAt(cv)
        if (!cb || cb.boundingBox !== 'block') continue
        if (!GROUND_RE.test(cb.name) || (cb.hardness === undefined ? 1 : cb.hardness) < 0) continue
        const aboveRoof = b.blockAt(cv.offset(0, 1, 0))
        if (aboveRoof && aboveRoof.boundingBox === 'block') continue  // buried roof = cascade
        log('CLIMB roof +' + dy + ' at', pos(b))
        if (await withTimeout(digBlock(b, cv), 9000, false)) roofDug = true
      }
      if (roofDug) { await sleep(300); continue }
      if (countPlaceable(b) < 1) return
    }
  }
}
let diggingUp = false
async function digUpAndOut (b, levels) {
  if (diggingUp) return                                    // 3 concurrent ESCAPE_UPs fought over controls
  diggingUp = true
  try { await digUpAndOutInner(b, levels) } finally { diggingUp = false }
}
async function digUpAndOutInner (b, levels) {
  jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 30000)
  try { b.pathfinder.setGoal(null) } catch (e) {}
  if (!b.entity) return
  const feet0 = b.entity.position.floored()
  let rim = feet0.y
  for (const d of ESCAPE_DIRS) {
    for (let dy = 18; dy >= 0; dy--) { const blk = b.blockAt(feet0.offset(d[0], dy, d[1])); if (blk && blk.boundingBox === 'block') { if (feet0.y + dy > rim) rim = feet0.y + dy; break } }
  }
  const need = rim - feet0.y
  log('ESCAPE_UP rim=' + rim + ' y=' + feet0.y + ' need=' + need)
  if (inCollapseZone(b) && need >= 4) { await craterHold(b); return }
  await ensurePlaceable(b, need + 2, false)
  const d = ESCAPE_DIRS[0]
  manualLockUntil = Date.now() + 26000
  await withTimeout(b.pathfinder.goto(new goals.GoalBlock(feet0.x + d[0], rim + 1, feet0.z + d[1])), 24000, 'timeout')
  let climbed = b.entity ? (b.entity.position.y - feet0.y) : 0
  if (climbed < need - 0.5) {
    log('ESCAPE_UP pf gained ' + Math.round(climbed) + '/' + need + ' -> manual pillar')
    const extra = Math.min(14, need - Math.max(0, Math.round(climbed)) + 2)
    await pillarClimb(b, extra)
  }
  log('ESCAPE_UP now at', pos(b))
  if (!b.entity) return
  const a1 = Math.random() * Math.PI * 2
  manualLockUntil = Date.now() + 14000
  await withTimeout(b.pathfinder.goto(new goals.GoalXZ(Math.round(b.entity.position.x + Math.cos(a1) * 16), Math.round(b.entity.position.z + Math.sin(a1) * 16))), 14000, 'timeout')
}
let lastEscapeFeet = null
let lastEscapeAt = 0
async function escapeStuck (b) {
  if (escaping) return
  escaping = true
  jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 8000)
  try {
    const feet = b.entity.position.floored()
    const now = Date.now()
    const sameSpot = lastEscapeFeet && feet.distanceTo(lastEscapeFeet) < 2.5 && (now - lastEscapeAt) < 25000
    lastEscapeFeet = feet; lastEscapeAt = now
    if (sameSpot) { log('ESCAPE still stuck -> dig UP at', pos(b)); await digUpAndOut(b, 6); escaping = false; return }
    const enclosed = solidAt(b, feet.offset(1, 0, 0)) && solidAt(b, feet.offset(-1, 0, 0)) && solidAt(b, feet.offset(0, 0, 1)) && solidAt(b, feet.offset(0, 0, -1))
    const headWalls = ESCAPE_DIRS.filter(d => solidAt(b, feet.offset(d[0], 1, d[1]))).length
    const matName = PLACEABLE.find(nm => countItem(b, nm) > 0)
    if (enclosed && headWalls >= 3 && matName) {
      log('ESCAPE pillar up via', matName)
      await pillarUp(b, 3)
    } else {
      let best = null; let bestScore = -1e9
      for (const dir of ESCAPE_DIRS) {
        let score = 0
        for (let depth = 1; depth <= 2; depth++) {
          for (let dy = 0; dy <= 2; dy++) {
            const blk = b.blockAt(feet.offset(dir[0] * depth, dy, dir[1] * depth))
            if (!blk || blk.boundingBox !== 'block') score += 3
            else score += 1 / (1 + (blk.hardness || 1))
          }
        }
        if (score > bestScore) { bestScore = score; best = dir }
      }
      const dir = best || ESCAPE_DIRS[0]
      const yaw = Math.atan2(-dir[0], dir[1])
      for (let depth = 1; depth <= 2; depth++) {
        await digBlock(b, feet.offset(dir[0] * depth, 0, dir[1] * depth))
        await digBlock(b, feet.offset(dir[0] * depth, 1, dir[1] * depth))
        await digBlock(b, feet.offset(dir[0] * depth, 2, dir[1] * depth))
      }
      await ensureHeadroom(b)
      try { await b.look(yaw, 0) } catch (e) {}
      jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 1600)
      b.setControlState('forward', true); b.setControlState('jump', true)
      await sleep(700)
      b.setControlState('forward', false); b.setControlState('jump', false)
    }
  } catch (e) {}
  escaping = false
}

async function autoFree (b) {
  await sleep(600)
  for (let i = 0; i < 12; i++) {
    if (!b.entity || b.health <= 0) return
    const feet = b.entity.position.floored()
    const enclosed = solidAt(b, feet.offset(1, 0, 0)) && solidAt(b, feet.offset(-1, 0, 0)) && solidAt(b, feet.offset(0, 0, 1)) && solidAt(b, feet.offset(0, 0, -1))
    if (!enclosed) { log('AUTOFREE open at', pos(b)); return }
    log('AUTOFREE enclosed -> digging out')
    await ensureHeadroom(b)
    await escapeStuck(b)
    await sleep(700)
  }
  log('AUTOFREE gave up')
}

let reflexOn = true
let manualLockUntil = 0
let lastHeal = 0
function healReconnect (b, why, force) {
  // force = targeted resync when physics is provably desynced (jump rejected x3) -
  // NOT reconnect spam: own 150s cooldown, only fires from stuck-detection
  if (!force && process.env.MC_HEAL !== 'on') return false
  const now = Date.now()
  if (now - lastHeal < (force ? 150000 : 60000)) return false
  lastHeal = now
  log('HEAL_RECONNECT', why)
  stopDrive(b)
  mission = null
  try { b._client.end('heal') } catch (e) { try { b.quit('heal') } catch (e2) {} }
  return true
}
function sendLoaded (b, tag) {
  try {
    if (b.supportFeature && b.supportFeature('sendsPlayerLoadedPacket')) { b._client.write('player_loaded', {}); log('PLAYER_LOADED', tag) }
  } catch (e) { log('LOADED_ERR', e.message) }
}
function announceLoaded (b) {
  sendLoaded(b, 't+0.4')
  setTimeout(() => sendLoaded(b, 't+2'), 2000)
  setTimeout(() => sendLoaded(b, 't+5'), 5000)
  if (b.__loadedTimer) clearInterval(b.__loadedTimer)
  b.__loadedTimer = setInterval(() => { try { sendLoaded(b, 'keep') } catch (e) {} }, 25000)
}
function hop (b) {
  try { b.setControlState('jump', false) } catch (e) {}
  try { b.setControlState('jump', true) } catch (e) {}
}
function hopCycle (b) {
  b.__hopPhase = !b.__hopPhase
  try { b.setControlState('jump', b.__hopPhase) } catch (e) {}
}
function syncInput (b) {
  if (!b || !b._client || b._client.state !== 'play' || !b.entity) return
  let g = n => false
  try { g = n => !!b.getControlState(n) } catch (e) { return }
  const inputs = { forward: g('forward'), backward: g('back'), left: g('left'), right: g('right'), jump: g('jump'), shift: g('sneak'), sprint: g('sprint') }
  const key = Object.keys(inputs).map(k => inputs[k] ? '1' : '0').join('')
  b.__inputKey = key; b.__inputSent = Date.now()
  b.__inputWrites = (b.__inputWrites || 0) + 1
  try { b._client.write('player_input', { inputs }) } catch (e) { b.__inputErr = e.message; log('INPUT_ERR', e.message) }
}
function startInputSync (b) {
  if (b.__inputTimer) clearInterval(b.__inputTimer)
  b.__inputTimer = setInterval(() => { try { syncInput(b) } catch (e) {} }, 50)
}
function collectNear (b, r) {
  return new Promise(resolve => {
    if (!b.entity) return resolve(0)
    let items = []
    try { items = Object.values(b.entities).filter(e => e && e.name === 'item' && e.position && e.position.distanceTo(b.entity.position) <= r) } catch (e) { log('COLLECT_ERR', e.message); return resolve(0) }
    if (!items.length) return resolve(0)
    items.sort((x, y) => x.position.distanceTo(b.entity.position) - y.position.distanceTo(b.entity.position))
    let i = 0
    const next = () => {
      if (i >= items.length || !b.entity || b.health <= 0) return resolve(i)
      const it = items[i++]
      try { b.pathfinder.setGoal(new goals.GoalNear(it.position.x, it.position.y, it.position.z, 0.5)) } catch (e) {}
      let finished = false
      const fin = () => { if (finished) return; finished = true; try { b.pathfinder.setGoal(null) } catch (e) {} ; setTimeout(next, 260) }
      b.once('goal_reached', fin)
      setTimeout(fin, 6000)
    }
    next()
  })
}
function dryCol (b, feet, dx, dz) {
  const v = feet.offset(dx, 0, dz)
  for (let dy = 7; dy >= -4; dy--) {
    const blk = b.blockAt(v.offset(0, dy, 0))
    if (blk && blk.boundingBox === 'block') {
      for (const k of [1, 2]) { const air = b.blockAt(v.offset(0, dy + k, 0)); if (air && /water/.test(air.name)) return null }
      return { x: v.x, y: feet.y + dy + 1, z: v.z, d: Math.hypot(dx, dz) }
    }
  }
  return null
}
function nearestDry (b, r) {
  if (!b.entity) return null
  const feet = b.entity.position.floored()
  let best = null
  for (let dx = -r; dx <= r; dx++) {
    for (let dz = -r; dz <= r; dz++) {
      const d = Math.hypot(dx, dz)
      if (d < 0.9 || d > r) continue
      const c = dryCol(b, feet, dx, dz)
      if (c && (!best || d < best.d)) best = c
    }
  }
  return best
}
function stopDrive (b) {
  if (b.__drive) { clearInterval(b.__drive); b.__drive = null }
  try { b.clearControlStates() } catch (e) {}
}
function walkTo (b, tx, ty, tz, ms) {
  stopDrive(b)
  try { b.pathfinder.setGoal(null) } catch (e) {}
  manualLockUntil = Date.now() + (ms || 45000)
  const tEnd = Date.now() + (ms || 45000)
  let ticks = 0, winDist = null, blocked = 0, episode = 0, slideTicks = 0, side = 1
  const origin = b.entity.position.clone()
  let nextHealCheck = Date.now() + 16000
  b.__drive = setInterval(() => {
    try {
      if (!b.entity || b.health <= 0 || Date.now() > tEnd) { stopDrive(b); log('DRIVE_END', pos(b)); return }
      const p = b.entity.position
      const dh = Math.hypot(tx - p.x, tz - p.z)
      if (dh < 2) { stopDrive(b); log('DRIVE_ARRIVED', pos(b) + ' ydiff=' + (ty - p.y).toFixed(1)); return }
      if (dh < 5 && !isWaterAt(b, Math.round(p.x), Math.round(p.y), Math.round(p.z)) === false) { }
      ticks++
      if (Date.now() > nextHealCheck) {
        nextHealCheck = Date.now() + 16000
        if (Math.hypot(p.x - origin.x, p.z - origin.z) < 1.5) { if (healReconnect(b, 'drive no progress ' + dh.toFixed(0) + ' from spawn-point')) return }
      }
      if (slideTicks > 0) slideTicks--
      if (winDist === null) winDist = dh
      if (ticks % 5 === 0) {
        if (winDist - dh >= 0.5) { blocked = 0; if (episode > 0) { episode--; if (episode === 0) side = 1 } }
        else { blocked++ }
        winDist = dh
        if (blocked >= 2 && slideTicks === 0) {
          episode++
          if (episode >= 6) { stopDrive(b); log('DRIVE_STUCK', pos(b) + ' target ' + tx + ' ' + ty + ' ' + tz); return }
          if (blocked >= 3) { side = -side; blocked = 0 }
          if (episode === 3 && countPlaceable(b) > 0 && !inCollapseZone(b)) { log('DRIVE_BUILD', 'pillaring up with ' + countPlaceable(b) + ' blocks'); pillarUp(b, 2) ; slideTicks = 12 }
          slideTicks = 6
          log('DRIVE_SLIDE', 'no progress, ' + (dh).toFixed(1) + ' left, side ' + side + ' ep ' + episode + ' at ' + pos(b))
        }
      }
      try { b.lookAt(new Vec3(tx, p.y - 1.1, tz), true, false) } catch (e) {}
      const hl = Math.hypot(tx - p.x, tz - p.z) || 1
      const ax = (tx - p.x) / hl; const az = (tz - p.z) / hl
      let wet = false
      const selfWet = isWaterAt(b, Math.round(p.x), Math.round(p.y), Math.round(p.z))
      for (const k of [1, 2, 3, 4]) { if (!selfWet && isWaterAt(b, Math.round(p.x + ax * k), Math.round(p.y), Math.round(p.z + az * k))) { wet = true; break } }
      if (wet && slideTicks === 0) { slideTicks = 6; side = side > 0 ? 1 : -1; log('DRIVE_WATER', 'steer ashore at ' + pos(b)) }
      const sliding = slideTicks > 0
      try {
        b.setControlState('forward', true)
        b.setControlState('sprint', !sliding && dh > 10 && b.food > 10)
        b.setControlState('left', sliding && side > 0)
        b.setControlState('right', sliding && side < 0)
      } catch (e) {}
      if (b.food <= 8) { try { eatFood(b) } catch (e) {} }
    } catch (e) { stopDrive(b); log('DRIVE_ERR', e.message) }
  }, 400)
}
function groundYAt (b, feet, dx, dz, span) {
  const v = feet.offset(dx, 0, dz)
  for (let dy = span; dy >= -span; dy--) { const blk = b.blockAt(v.offset(0, dy, 0)); if (blk && blk.boundingBox === 'block') return feet.y + dy }
  return null
}
function pushInput (b) { syncInput(b) }
// ==================== MOVEMENT CORE (jump + stuck) ====================
let jumpLockUntil = 0
let forceJumpUntil = 0      // bunny-hop while dodging arrows
let lastDigAt = 0
let lastHurtAt = 0
let cautionUntil = 0        // just (re)spawned: don't start missions yet
let hiding = false
// where the bot died recently: mission targets are never picked near these
// (the fixed server spawn is a zombie nest - without this the wood mission
// keeps routing straight back into the place that just killed it)
const deathZones = []
// the server's fixed spawn point: a zombie/drowned/skeleton nest under dark jungle
// canopy (mobs don't burn there). 20+ deaths proved it - treat it as a no-go zone
// for mission targets, permanently.
const NEST = { x: -618, z: -654 }
function noteDeathZone (p) {
  if (!p) return
  deathZones.push({ x: p.x, z: p.z, t: Date.now() })
  if (deathZones.length > 12) deathZones.shift()
}
function pointSegDist (px, pz, ax, az, bx, bz) {
  const dx = bx - ax; const dz = bz - az
  const l2 = dx * dx + dz * dz
  let t = l2 ? ((px - ax) * dx + (pz - az) * dz) / l2 : 0
  t = Math.max(0, Math.min(1, t))
  return Math.hypot(px - (ax + t * dx), pz - (az + t * dz))
}
function inDeathZone (x, z, r) {
  const now = Date.now()
  for (let i = deathZones.length - 1; i >= 0; i--) {
    const dz = deathZones[i]
    if (now - dz.t > 1800000) { deathZones.splice(i, 1); continue }   // 30min TTL: under jungle canopy mobs don't burn
    if (Math.hypot(dz.x - x, dz.z - z) < (r || 40)) return true
  }
  return false
}
// nearest no-go center (nest or recent death zone) within r, as a Vec3 at our y - or null
function worstZone (b, r) {
  if (!b.entity) return null
  const p = b.entity.position
  let best = null; let bd = 1e9
  const cands = [NEST].concat(deathZones)
  for (const z of cands) { const d = Math.hypot(z.x - p.x, z.z - p.z); if (d < (r || 70) && d < bd) { bd = d; best = z } }
  return best ? new Vec3(best.x, p.y, best.z) : null
}
let lastHideAt = 0
const RANGED = new Set(['skeleton', 'stray', 'bogged', 'wither_skeleton', 'pillager', 'blaze', 'witch', 'breeze', 'evoker', 'vex', 'ghast', 'snow_golem', 'shulker'])
function relJump (b) { try { if (b.getControlState('jump')) b.setControlState('jump', false) } catch (e) {} }
function holdJump (b) { try { if (!b.getControlState('jump')) b.setControlState('jump', true) } catch (e) {} }
function faceDir (b) { const y = b.entity.yaw; return { x: -Math.sin(y), z: Math.cos(y) } }
function controlDir (b) {
  const g = n => { try { return !!b.getControlState(n) } catch (e) { return false } }
  let f = 0; let s = 0
  if (g('forward')) f += 1
  if (g('back')) f -= 1
  if (g('right')) s += 1
  if (g('left')) s -= 1
  if (!f && !s) return null
  const y = b.entity.yaw
  const sin = Math.sin(y); const cos = Math.cos(y)
  const x = s * cos - f * sin; const z = f * cos + s * sin
  const l = Math.hypot(x, z) || 1
  return { x: x / l, z: z / l }
}
// direction the bot is trying to travel: real velocity first, then inputs, then look
function intendedDir (b) {
  const v = b.entity.velocity
  const sp = Math.hypot(v.x, v.z)
  if (sp > 0.07) return { x: v.x / sp, z: v.z / sp }
  return controlDir(b) || faceDir(b)
}
function isSolidBlk (b, v) { const k = b.blockAt(v); return !!(k && k.boundingBox === 'block') }
function isFreeBlk (b, v) { const k = b.blockAt(v); return !k || k.boundingBox !== 'block' }
function isLiquidBlk (b, v) { const k = b.blockAt(v); return !!(k && /water|lava/.test(k.name)) }
// Pick the most open dry run about `dist` blocks directly away from `src` (mob or death spot).
// Used for flee goals and post-respawn repositioning in dense terrain.
function escapePointFrom (b, src, dist) {
  if (!b.entity || !src) return null
  const bp = b.entity.position
  let ax = bp.x - src.x; let az = bp.z - src.z
  const l = Math.hypot(ax, az)
  if (l < 0.5) { const a = Math.random() * Math.PI * 2; ax = Math.cos(a); az = Math.sin(a) } else { ax /= l; az /= l }
  dist = dist || 18
  const feet = bp.floored()
  let best = null; let bestScore = -1e9
  for (let i = 0; i < 10; i++) {
    const ang = Math.atan2(az, ax) + (i - 5) * 0.42          // fan of ~+-105 deg around "away"
    const dx = Math.cos(ang); const dz = Math.sin(ang)
    let score = 0
    for (let k = 4; k <= dist; k += 3) {
      const sx = Math.round(bp.x + dx * k); const sz = Math.round(bp.z + dz * k)
      if (isWaterAt(b, sx, sz)) { score -= 6; continue }
      let blocked = 0
      for (const dy of [0, 1, 2]) { const blk = b.blockAt(new Vec3(sx, feet.y + dy, sz)); if (blk && blk.boundingBox === 'block') blocked++ }
      if (blocked >= 2) score -= 4                            // wall: sprint dies here
      else if (blocked === 1) score += 1                      // one step: jumpable
      else score += 3                                         // clear run
    }
    score -= Math.abs(i - 5) * 0.2                            // slight bias to straight away
    if (score > bestScore) { bestScore = score; best = { x: Math.round(bp.x + dx * dist), z: Math.round(bp.z + dz * dist) } }
  }
  return best
}
// null = free, 'step' = climbable by jumping, 'wall' = too high / has ceiling, 'gap' = hole ahead
function frontObstacle (b, dir, reach) {
  const p = b.entity.position
  const r = reach || 0.72
  const fx = Math.floor(p.x + dir.x * r); const fz = Math.floor(p.z + dir.z * r); const fy = Math.floor(p.y)
  const low = isSolidBlk(b, new Vec3(fx, fy, fz))
  const high = isSolidBlk(b, new Vec3(fx, fy + 1, fz))
  if (!low && !high) {
    if (!isSolidBlk(b, new Vec3(fx, fy - 1, fz)) && !isSolidBlk(b, new Vec3(fx, fy - 2, fz))) return 'gap'
    return null
  }
  const topY = fy + (high ? 2 : 1)
  if (isFreeBlk(b, new Vec3(fx, topY, fz)) && isFreeBlk(b, new Vec3(fx, topY + 1, fz))) return 'step'
  return 'wall'
}
// Auto-jump: holds the jump control (mineflayer auto-jumps on every landing while held)
// exactly when there is something to climb, and releases it otherwise.
function startAutoJump (b) {
  if (b.__ajump) clearInterval(b.__ajump)
  b.__ajump = setInterval(() => {
    try {
      if (!b.entity || b.health <= 0 || b.physicsEnabled === false) return
      if (Date.now() < jumpLockUntil) return          // another routine owns the jump key
      let pf = false; try { pf = b.pathfinder.isMoving() } catch (e) {}
      if (pf) return                                  // pathfinder is driving: IT owns the jump key
                                                      // (fighting it cancelled sprint-jumps and towers)
      if (Date.now() < forceJumpUntil) { holdJump(b); return }   // dodging arrows: keep hopping
      const dir = controlDir(b)
      if (!dir) { relJump(b); return }                // no manual input: nothing to auto-jump for
      const d = dir
      const feet = b.entity.position.floored()
      if (b.entity.isInWater || isLiquidBlk(b, feet.offset(0, 1, 0))) {
        if (!b.entity.onGround) holdJump(b); else relJump(b)   // swim to the surface, don't bob in the shallows
        return
      }
      if (!isFreeBlk(b, feet.offset(0, 2, 0))) { relJump(b); return }   // ceiling: jumping is pointless
      const ob = frontObstacle(b, d)
      if (ob === 'gap') { relJump(b); return }        // never hop into a hole on purpose
      if (ob === 'wall') { relJump(b); return }       // too high -> stuck guard will dig it
      if (ob === 'step' || b.entity.isCollidedHorizontally) {
        holdJump(b)                                   // held jump == vanilla autojump on every landing
        return
      }
      relJump(b)
    } catch (e) {}
  }, 80)
}
function wantsToMove (b) {
  try { if (b.pathfinder.isMoving()) return true } catch (e) {}
  const g = n => { try { return !!b.getControlState(n) } catch (e) { return false } }
  if (g('forward') || g('back') || g('left') || g('right')) return true
  if (b.__drive) return true
  return false
}
// ==================== SELF TEST (objective jump/climb proof) ====================
async function selfTest (b) {
  const log2 = (...a) => log('SELFTEST', ...a)
  try {
    if (!b.entity) return log2('no entity')
    const wasMission = mission
    mission = { name: 'selftest' }
    stopDrive(b)
    try { b.pathfinder.setGoal(null) } catch (e) {}
    await sleep(300)
    const p0 = b.entity.position.clone()
    const feet = p0.floored()
    let cand = null
    for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, 1], [1, -1], [-1, -1]]) {
      const step = new Vec3(feet.x + d[0], feet.y, feet.z + d[1])
      if (!isSolidBlk(b, step)) continue
      if (!isFreeBlk(b, step.offset(0, 1, 0)) || !isFreeBlk(b, step.offset(0, 2, 0))) continue
      if (isLiquidBlk(b, step.offset(0, 1, 0))) continue
      if (!isFreeBlk(b, feet.offset(0, 1, 0))) continue
      cand = { d, step }
      break
    }
    if (!cand) { mission = wasMission; return log2('no 1-block step nearby at ' + pos(b) + ' - need flat ground with a ledge') }
    const yaw = Math.atan2(-cand.d[0], cand.d[1])
    log2('step ' + cand.step.x + ' ' + cand.step.y + ' ' + cand.step.z + ' dir=' + cand.d.join(',') + ' startY=' + p0.y.toFixed(2))
    let maxY = p0.y; let jumps = 0; let wasGround = true
    const sampler = setInterval(() => {
      try {
        if (!b.entity) return
        if (b.entity.position.y > maxY) maxY = b.entity.position.y
        if (wasGround && !b.entity.onGround) jumps++
        wasGround = !!b.entity.onGround
      } catch (e) {}
    }, 50)
    await b.look(yaw, 0.05, true)
    b.setControlState('forward', true)
    b.setControlState('sprint', false)
    const t0 = Date.now()
    let climbed = false
    while (Date.now() - t0 < 4000) {
      await sleep(120)
      if (!b.entity) break
      const f = b.entity.position.floored()
      if (f.x === cand.step.x && f.z === cand.step.z && f.y >= cand.step.y) { climbed = true; break }
    }
    b.setControlState('forward', false)
    clearInterval(sampler)
    const gained = maxY - p0.y
    log2('RESULT climbed=' + climbed + ' yGain=' + gained.toFixed(2) + ' airJumps=' + jumps + ' pos=' + pos(b) + ' stuckLevel=' + (b.__stuckLevel || 0))
    log2(climbed && gained > 0.7 ? 'PASS - steps up the ledge' : 'FAIL - did not climb (yGain ' + gained.toFixed(2) + ', jumps ' + jumps + ')')
    mission = wasMission
  } catch (e) { log2('ERR', e && e.message); mission = null }
}
// ==================== UNIVERSAL STUCK GUARD ====================
let unstickBusy = false
let lastUnstickAt = 0
let stuckCount = 0
let stuckSince = 0
let unstickAnchor = null
function busyDoingSomething (b) {
  if (Date.now() - lastDigAt < 2500) return true                       // mining a block takes seconds
  try { if (b.autoEat && b.autoEat.isEating) return true } catch (e) {}
  try { if (b.currentWindow) return true } catch (e) {}                // crafting / chest
  return false
}
function startStuckGuard (b) {
  if (b.__stuckGuard) clearInterval(b.__stuckGuard)
  let hist = []
  b.__stuckLevel = 0
  b.__stuckGuard = setInterval(() => {
    try {
      if (!b.entity || b.health <= 0) { hist = []; stuckSince = 0; b.__stuckLevel = 0; return }
      const now = Date.now()
      const p = b.entity.position
      hist.push({ t: now, x: p.x, y: p.y, z: p.z })
      while (hist.length && now - hist[0].t > 4200) hist.shift()
      if (unstickBusy || b.__fleeing || hiding || diggingUp || tunneling || b.__pillarEscape || deepNearCrater(b) || !wantsToMove(b) || busyDoingSomething(b)) {
        hist = []; stuckSince = 0; b.__stuckLevel = 0; return
      }
      if (unstickAnchor && p.distanceTo(unstickAnchor) > 2.2) { unstickAnchor = null; stuckSince = 0; b.__stuckLevel = 0 }
      const h0 = hist[0]
      const flat = Math.hypot(p.x - h0.x, p.z - h0.z)
      const rise = Math.abs(p.y - h0.y)
      if (flat > 0.7 || rise > 1.0) { stuckSince = 0; b.__stuckLevel = 0; return }
      if (!stuckSince) { stuckSince = now; return }                     // start the clock, act later
      const wedged = now - stuckSince
      const level = wedged > 12000 ? 4 : wedged > 7000 ? 3 : wedged > 4000 ? 2 : wedged > 2000 ? 1 : 0
      if (!level) return
      if (level === b.__stuckLevel && now - lastUnstickAt < 7000) return
      b.__stuckLevel = level
      stuckCount++; stats.stucks++
      lastUnstickAt = now
      unstickAnchor = p.clone()
      log('STUCK L' + level, 'wedged ' + (wedged / 1000).toFixed(0) + 's flat=' + flat.toFixed(2) + ' rise=' + rise.toFixed(2) + ' at ' + pos(b) + ' mission=' + (mission ? mission.name : '-'))
      unstick(b, level)
      // Auto-start explore if stuck at L2+ with no active mission
      if (level >= 2 && !mission && !b.__fleeing && !hiding) { try { log("STUCK_AUTO_EXPLORE at", pos(b)); startMission(b, "explore") } catch (e) {} }
    } catch (e) {}
  }, 400)
}
async function unstick (b, level) {
  if (unstickBusy) { if (Date.now() - (b.__dirLog||0) > 10000) { log("DIR_BLOCK unstickBusy"); b.__dirLog = Date.now() } return }
  unstickBusy = true
  const d0 = intendedDir(b)
  const yaw0 = b.entity.yaw
  try {
    if (level <= 1) {
      // cheapest nudge: hop TOWARD the intended direction (in-place hops climb nothing).
      // Do NOT steal the pathfinder goal; if it is driving, forward is already held.
      let pf = false; try { pf = b.pathfinder.isMoving() } catch (e) {}
      log('UNSTICK step-up' + (pf ? ' (pf driving)' : '') + ' at', pos(b))
      jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 1500)
      if (!pf) {
        try { await b.look(Math.atan2(-d0.x, d0.z), 0, true) } catch (e) {}
        try { b.setControlState('forward', true) } catch (e) {}
      }
      holdJump(b)
      await sleep(620)
      relJump(b)
      if (!pf) { try { b.setControlState('forward', false) } catch (e) {} }
      await sleep(380)
    } else if (level === 2) {
      log('UNSTICK sidestep at', pos(b))
      try { b.pathfinder.setGoal(null) } catch (e) {}
      jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 2000)
      try { await b.look(yaw0 + Math.PI / 2, 0, true) } catch (e) {}
      b.setControlState('forward', true); b.setControlState('jump', true); b.setControlState('sprint', true)
      await sleep(430)
      b.setControlState('forward', false); b.setControlState('jump', false); b.setControlState('sprint', false)
      await sleep(140)
      try { await b.look(Math.atan2(-d0.x, d0.z), 0, true) } catch (e) {}
      b.setControlState('forward', true); b.setControlState('jump', true)
      await sleep(650)
      b.setControlState('forward', false); b.setControlState('jump', false)
    } else if (level === 3) {
      jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 6000)
      const feet = b.entity.position.floored()
      const ob = frontObstacle(b, d0, 0.9)
      const aheadBlk = b.blockAt(new Vec3(Math.floor(b.entity.position.x + d0.x), feet.y, Math.floor(b.entity.position.z + d0.z)))
      const soft = aheadBlk && ((aheadBlk.hardness === undefined ? 1 : aheadBlk.hardness) <= 1.5 || hasPickaxe(b))
      if (ob !== 'wall' || !soft || inCollapseZone(b)) {
        // don't wreck the terrain: sprint-run sideways to get around the obstacle
        const side = (stuckCount % 2 === 0) ? 1 : -1
        log('UNSTICK bypass run ' + (side > 0 ? 'right' : 'left') + ' ob=' + ob + ' at', pos(b))
        try { b.pathfinder.setGoal(null) } catch (e) {}
        try { await b.look(yaw0 + side * Math.PI / 2, 0, true) } catch (e) {}
        b.setControlState('forward', true); b.setControlState('sprint', true); b.setControlState('jump', true)
        await sleep(1300)
        b.setControlState('forward', false); b.setControlState('jump', false); b.setControlState('sprint', false)
        return
      }
      log('UNSTICK dig ahead (soft wall) at', pos(b))
      try { b.pathfinder.setGoal(null) } catch (e) {}
      for (let k = 1; k <= 2; k++) {
        for (let dy = 0; dy <= 2; dy++) {
          await withTimeout(digBlock(b, new Vec3(Math.floor(b.entity.position.x + d0.x * k), feet.y + dy, Math.floor(b.entity.position.z + d0.z * k))), 8000, false)
        }
      }
      try { await b.look(Math.atan2(-d0.x, d0.z), 0, true) } catch (e) {}
      b.setControlState('forward', true); b.setControlState('jump', true)
      await sleep(950)
      b.setControlState('forward', false); b.setControlState('jump', false)
    } else {
      log('UNSTICK give up: drop mission, climb out at', pos(b))
      stopDrive(b)
      if (mission && mission.name !== 'selftest') { missionFail(mission.name); mission = null }
      try { b.clearControlStates() } catch (e) {}
      await sleep(400)
      await withTimeout(digUpAndOut(b, 8), 50000, null)
    }
  } catch (e) { log('UNSTICK_ERR', e && e.message ? e.message : String(e)) }
  try { b.clearControlStates() } catch (e) {}
  unstickBusy = false
}
// Dig a 2-deep pocket away from the threat and wait: breaks line of sight, saves us from skeletons.
async function hidePocket (b, threat, ms, seal) {
  if (hiding || !b.entity) return
  // hiding in water = drowning/getting shot: wall-burrow instead (seals + waits + digs out)
  if (botWet(b) && !b.__wallBury && !inCollapseZone(b)) { log('HIDE wet -> wallBury at', pos(b)); await wallBury(b, Math.min(ms || 90000, 120000)); return }
  if (inCollapseZone(b)) { log('HIDE skip in crater at', pos(b)); return }   // digging here = sinking
  hiding = true
  lastHideAt = Date.now()
  try {
    log('HIDE pocket at', pos(b), 'hp=' + Math.round(b.health), 'threat=' + (threat && threat.name) + (seal ? ' SEAL' : ''))
    try { b.pathfinder.setGoal(null) } catch (e) {}
    stopDrive(b)
    jumpLockUntil = Math.max(jumpLockUntil, Date.now() + Math.min(ms || 22000, 30000))
    manualLockUntil = Math.max(manualLockUntil, Date.now() + Math.min(ms || 22000, 30000))
    const feet = b.entity.position.floored()
    let dir = [1, 0]
    if (threat && threat.position) {
      const ax = b.entity.position.x - threat.position.x; const az = b.entity.position.z - threat.position.z
      const l = Math.hypot(ax, az) || 1
      dir = [Math.round(ax / l), Math.round(az / l)]
      if (!dir[0] && !dir[1]) dir = [1, 0]
    }
    for (let k = 1; k <= 2; k++) {
      await withTimeout(digBlock(b, feet.offset(dir[0] * k, 0, dir[1] * k)), 9000, false)
      await withTimeout(digBlock(b, feet.offset(dir[0] * k, 1, dir[1] * k)), 9000, false)
    }
    try { await b.look(Math.atan2(-dir[0], dir[1]), 0, true) } catch (e) {}
    b.setControlState('forward', true)
    await sleep(1100)
    b.setControlState('forward', false)
    b.setControlState('sneak', true)
    // sealed mode: wall the entrance up with the material we just mined. Zombies can't
    // dig, skeletons have no LOS - this is how a gearless bot survives a spawn-camp night.
    const e1 = feet.offset(dir[0], 0, dir[1]); const e2 = feet.offset(dir[0], 1, dir[1])
    let sealed = false
    // NOTE: threatsNear takes an AGGRO-RADIUS MULTIPLIER, not blocks - with mul=1.6 the gate
    // meant "no mobs within ~10-25 blocks" (never true at the nest), so we never sealed.
    // Only a mob literally inside the tunnel (<2.5b) must block sealing.
    let mobInside = false
    try { for (const th of threatsNear(b, 3)) { if (th.d < 2.5) { mobInside = true; break } } } catch (e) {}
    if (seal && !mobInside) {
      await ensurePlaceable(b, 2)
      const refB = b.blockAt(feet.offset(dir[0], -1, dir[1]))        // ground under the entrance cell
      if (countPlaceable(b) >= 1 && refB && refB.boundingBox === 'block') {
        const r1 = await withTimeout(b.placeBlock(refB, new Vec3(0, 1, 0)), 4000, 'to')
        if (r1 !== 'to') {
          sealed = true
          if (countPlaceable(b) >= 1) {
            const refT = b.blockAt(e1)                               // stack the second seal on the first
            if (refT) await withTimeout(b.placeBlock(refT, new Vec3(0, 1, 0)), 4000, 'to')
          }
          log('HIDE sealed at', pos(b))
        }
      }
    }
    const t0 = Date.now()
    const limit = ms || 22000
    while (Date.now() - t0 < limit) {
      if (!b.entity || b.health <= 0) break
      if (!sealed && Date.now() - t0 > 7000 && !threatsNear(b, 1.2).length) break
      if (!sealed && Date.now() - t0 > 12000 && threatsNear(b, 1.2).length) break  // tunnel breached / they found us: run instead
      // sealed: sleep out the night, leave at dawn when the area is clear
      if (sealed && Date.now() - t0 > 20000 && !isNight(b) && !isDusk(b) && !threatsNear(b, 1.2).length) break
      await sleep(700)
    }
    if (sealed) {
      await withTimeout(digBlock(b, e2), 9000, false)
      await withTimeout(digBlock(b, e1), 9000, false)
    }
    b.setControlState('sneak', false)
    // release OUR long locks immediately - a zombie waiting outside must be flee-able
    manualLockUntil = Math.min(manualLockUntil, Date.now() + 1500)
    jumpLockUntil = Math.min(jumpLockUntil, Date.now() + 1500)
    log('HIDE done at', pos(b), 'hp=' + Math.round(b.health))
  } catch (e) { log('HIDE_ERR', e && e.message) }
  hiding = false
}
// ==================== STATS + PERSISTENCE ====================
const HB_FILE = '/home/agent/bot/heartbeat.json'
const STATE_FILE = '/home/agent/bot/state.json'
const SOCIAL_FILE = '/home/agent/bot/social.json'
let stats = { deaths: 0, stucks: 0, mined: 0, crafted: 0, replies: 0, walked: 0, missions: 0, jumps: 0, born: Date.now() }
try { const s = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); if (s && typeof s === 'object') stats = Object.assign(stats, s) } catch (e) {}
function saveStats () { try { fs.writeFileSync(STATE_FILE, JSON.stringify(stats)) } catch (e) {} }
setInterval(saveStats, 20000)
process.on('exit', saveStats)
let missionBackoff = {}
function missionFail (name) { missionBackoff[name] = Date.now() + 45000 }
function missionAllowed (name) { return !(missionBackoff[name] && Date.now() < missionBackoff[name]) }
let hbLastPos = null
function startHeartbeat (b) {
  if (b.__hb) clearInterval(b.__hb)
  b.__hb = setInterval(() => {
    try {
      const p = b.entity ? b.entity.position : null
      if (p && hbLastPos) stats.walked += Math.hypot(p.x - hbLastPos.x, p.z - hbLastPos.z)
      if (p) hbLastPos = p.clone()
      const s = {
        t: Date.now(), pid: process.pid, up: Math.round(process.uptime()),
        pos: b.entity ? pos(b) : 'n/a', hp: Math.round(b.health || 0), food: Math.round(b.food || 0),
        dim: (b.game && b.game.dimension) || '?', day: b.time ? Math.floor((b.time.age || 0) / 24000) : 0,
        clock: b.time ? Math.round((b.time.age || 0) % 24000) : 0,
        mission: mission ? mission.name : null, director: directorOn,
        stuckLevel: b.__stuckLevel || 0, stuckTotal: stats.stucks, unstickBusy,
        drive: !!b.__drive, flee: !!b.__fleeing, reconnects, deaths: stats.deaths,
        mined: stats.mined, crafted: stats.crafted, replies: stats.replies, walked: Math.round(stats.walked),
        ground: b.entity ? !!b.entity.onGround : false, collided: b.entity ? !!b.entity.isCollidedHorizontally : false,
        inv: b.inventory ? b.inventory.items().slice(0, 14).map(i => i.name + ':' + i.count) : [],
        chat: chatRing.slice(-3).map(c => (c.u || '?') + ': ' + c.x)
      }
      fs.writeFileSync(HB_FILE, JSON.stringify(s))
    } catch (e) {}
  }, 3000)
}
// ==================== CHAT BRAIN ====================
const MY_NAME = (USERNAME || 'Puff').toLowerCase()
const NAME_RE = new RegExp('^\\s*(' + MY_NAME + '|' + MY_NAME.replace(/f/g, 'ff') + '|пуф+|puf+)([\\s,:!?\\.]|$)', 'i')
const NAME_ANY_RE = new RegExp('(' + MY_NAME + '|пуф+)', 'i')
const OWNERS = (process.env.PUFF_OWNERS || 'MrBaGued').split(',').map(x => x.trim().toLowerCase()).filter(Boolean)
function isOwner (user) { return OWNERS.indexOf(norm(user)) >= 0 }
const MODEL_ANSWER = process.env.PUFF_MODEL_ANSWER || 'да я просто Puff, играю тут'
let chatRing = []
let social = {}
try { social = JSON.parse(fs.readFileSync(SOCIAL_FILE, 'utf8')) || {} } catch (e) { social = {} }
function saveSocial () { try { fs.writeFileSync(SOCIAL_FILE, JSON.stringify(social)) } catch (e) {} }
setInterval(saveSocial, 30000)
let lastSpokeAt = 0
let spokeTimes = []
function canSpeak () {
  const now = Date.now()
  if (now - lastSpokeAt < 2600) return false
  spokeTimes = spokeTimes.filter(t => now - t < 300000)
  if (spokeTimes.length >= 9) return false
  return true
}
function say (b, text) {
  if (!b || !b.entity || !text) return false
  if (!canSpeak()) return false
  lastSpokeAt = Date.now()
  spokeTimes.push(Date.now())
  stats.replies++
  try { b.chat(text.slice(0, 240)); log('SAY', text.slice(0, 120)); return true } catch (e) { log('SAY_ERR', e && e.message); return false }
}
function norm (s) { return String(s || '').toLowerCase().replace(/[«»"'`~]/g, '').replace(/\s+/g, ' ').trim() }
function addressedToMe (text) {
  const t = norm(text)
  if (!t) return false
  if (NAME_RE.test(t)) return true                      // name at the start  <- what the user asked for
  const i = t.search(NAME_ANY_RE)
  return false /* user wants ONLY start match */
}
function stateBlurb (b) {
  const parts = []
  if (mission) parts.push('занят: ' + mission.name)
  else parts.push('свободен')
  parts.push('хп ' + Math.round(b.health || 0))
  const wood = countAny(b, LOG_TYPES); const pick = hasPickaxe(b)
  if (wood) parts.push('дерева ' + wood)
  if (pick) parts.push('кирка есть'); else parts.push('кирки нет')
  if (countFood(b)) parts.push('еды ' + countFood(b))
  return parts.join(', ')
}
// ---- compositional replies: every message is ASSEMBLED from live state (activity,
// health, night, recent deaths, who talks to me) - never a fixed list of full
// sentences. pick() rotates choices on a ~45s window + text hash so identical
// messages don't produce identical answers.
function pick (arr, seedStr) {
  let h = 0
  // replies counter in the seed: back-to-back answers rotate instead of repeating
  const s = String(seedStr || '') + '|' + Math.floor(Date.now() / 45000) + '|' + (stats.replies % 11)
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0
  return arr[h % arr.length]
}
function mobNameRu (n) {
  const m = { skeleton: 'скелета', zombie: 'зомби', spider: 'паука', creeper: 'крипера', drowned: 'утопленника', witch: 'ведьмы', enderman: 'эндермена' }
  return m[String(n || '').toLowerCase()] || 'кого-то страшного'
}
function activityPhrase (b) {
  if (hiding) return pick(['отсиживаюсь в норе, снаружи кто-то бродит', 'сижу закопанный, жду пока мобы разойдутся', 'спрятался, тут ночью небезопасно'], 'hide')
  if (b.__fleeing) {
    let th = null; try { th = nearestHostile(b, 30) } catch (e) {}
    return 'ухожу от ' + mobNameRu(th && th.name)
  }
  if (mission) {
    switch (mission.name) {
      case 'wood': return pick(['ищу нормальное дерево, тут всё на скалах', 'пытаюсь добыть дерево', 'мне бы дерева на инструменты'], 'wood')
      case 'stone': return pick(['высматриваю камень', 'нужен камень на нормальную кирку'], 'stone')
      case 'food': return pick(['ищу чего съестного', 'голодаю понемногу, ищу еду'], 'food')
      case 'shelter': return (isNight(b) || isDusk(b)) ? 'пережидаю ночь в укрытии' : 'возюсь с укрытием'
      case 'explore': return pick(['осматриваюсь вокруг', 'разведываю остров', 'ищу плоский лес подальше от спавна'], 'explore')
      case 'gather': return 'собираю блоки'
      default: return 'занят делом'
    }
  }
  return pick(['просто осматриваюсь', 'стою, прихожу в себя', 'бродил тут рядом', 'отдыхаю секунду'], 'idle')
}
function contextPhrase (b, who) {
  const bits = []
  if (b.health !== undefined && b.health < 10) bits.push('я весь побитый')
  if (b.food !== undefined && b.food < 10) bits.push('и голодный к тому же')
  if (isNight(b)) bits.push('тут ночь и мобы везде')
  if (deathZones.length && Date.now() - deathZones[deathZones.length - 1].t < 300000) bits.push('меня недавно тут завалили, если что')
  const s = social[String(who || '').toLowerCase()]
  if (s && s.talks > 3 && Date.now() - (s.met || 0) < 3600000) bits.push('мы с тобой уже болтали сегодня')
  return bits.length ? pick(bits, 'ctx' + bits.length + (who || '')) : ''
}
function replyFor (b, user, text) {
  const t = norm(text)
  const who = user || 'кто-то'
  const s = social[who.toLowerCase()] || (social[who.toLowerCase()] = { met: Date.now(), talks: 0, last: 0 })
  s.talks++; s.last = Date.now()
  // bare greeting -> stay quiet (user asked NOT to auto-answer hellos)
  if (/^(привет|здорово|хай|здоров|ку|hello|hi|hey|прив|доброе утро|добрый день|добрый вечер)$/.test(t)) return null
  if (/ты (бот|ии|ai|робот|программа|неживой)|ты живой|ты настоящий|кто тебя|чей ты|ты чья/.test(t)) return MODEL_ANSWER
  if (/как (тебя )?зовут|твоё имя|твое имя|кто ты такой|кто ты$/.test(t)) return 'Puff. ' + pick(['а ты ' + who + ', так?', 'имя как имя, нормальное', 'можно просто Пуфф'], 'name' + who)
  if (/где ты|ты где|где находишься|твои координаты|координаты/.test(t)) {
    return pick(['я на ' + pos(b), 'щас я ' + pos(b), 'коорды ' + pos(b) + '. ' + activityPhrase(b)], 'where')
  }
  if (/что делаешь|чем занят|чем занимаешься|как дела|как жизнь|что нового/.test(t)) {
    const extra = contextPhrase(b, who)
    return activityPhrase(b) + (extra ? ', ' + extra : '') + '. хп ' + Math.round(b.health || 0)
  }
  if (/помоги|спаси|выручи|нужна помощь|приди|иди сюда|ко мне/.test(t)) {
    const e = findPlayerByName(b, who)
    if (e) { try { b.pathfinder.setGoal(new goals.GoalNear(e.position.x, e.position.y, e.position.z, 2)) } catch (er) {}; return pick(['бегу к тебе', 'уже иду, ' + who, 'ок, выдвигаюсь'], 'come' + who) }
    return pick(['не вижу тебя рядом. скинь координаты?', 'ты где вообще? не вижу тебя', 'не найду тебя глазами, напиши коорды'], 'lost' + who)
  }
  if (/сколько у тебя (хп|здоровья)|ты жив|не умер/.test(t)) return 'хп ' + Math.round(b.health || 0) + ' из 20, ' + (b.health < 12 ? pick(['видал и хуже', 'могло быть хуже', 'держусь пока'], 'hp') : 'норма')
  if (/что в инвентаре|что у тебя есть|покажи инвентарь|инвентарь/.test(t)) {
    const it = b.inventory.items().slice(0, 8).map(i => i.name + ' x' + i.count).join(', ')
    return it ? 'в рюкзаке: ' + it : pick(['пусто, как в желудке утром', 'да почти ничего', 'инвентарь чист — всё смерть забрала'], 'inv')
  }
  if (/идём|пойдём|пошли|давай вместе|вместе/.test(t)) return pick(['давай. только куда?', 'пойдём, веди', 'ок, вместе так вместе. куда держим путь?'], 'go' + who)
  if (/спасибо|благодарю|спс/.test(t)) return pick(['не за что', 'да ладно, пустяки', 'обращайся', 'всегда пожалуйста'], 'thx' + t.length)
  if (/дурак|тупой|идиот|отстой|бот бесполезный|нуб/.test(t)) return pick(['бывает. что именно не так — скажи, поправлю', 'критику принял. конкретнее можешь?', 'ну ок. я самокритичный, переживу'], 'insult')
  if (/\?$/.test(t)) return pick(['хм, не знаю наверняка', 'без понятия, честно', 'не уверен, что отвечу внятно'], 'q' + t.length) + '. я сейчас ' + activityPhrase(b)
  // everything else: ack + live activity + optional flavor, assembled fresh
  let r = pick(['ага', 'понял', 'принято', 'ок', 'учту', 'ясно', 'хорошо', 'угу'], t)
  if (t.length > 25) r += ', ' + pick(['расскажи потом подробнее', 'звучит неплохо', 'надо обдумать', 'запомню'], t + 'x')
  r += '. ' + activityPhrase(b)
  const extra = contextPhrase(b, who)
  if (extra && (t.length + who.length) % 2 === 0) r += '. ' + extra
  return r
}
function findPlayerByName (b, name) {
  const n = norm(name)
  for (const id in b.entities) {
    const e = b.entities[id]
    if (!e || e.type !== 'player' || !e.username) continue
    if (norm(e.username) === n || norm(e.username).indexOf(n) === 0) return e
  }
  return null
}
function feedChat (b, user, text, whisper) {
  try {
    const t = String(text || '')
    chatRing.push({ t: Date.now(), u: user || '', x: t.slice(0, 200) })
    if (chatRing.length > 60) chatRing.shift()
    if (!user || user === USERNAME) return
    const low = norm(user)
    if (!social[low]) social[low] = { met: Date.now(), talks: 0, last: 0 }
    social[low].seen = Date.now()
    let toMe = whisper || addressedToMe(t)
    if (!toMe && isOwner(user) && t.length > 12) {
      // the owner talking in chat next to me counts - but at most once per 20s
      if (Date.now() - (social[low].ownerReply || 0) > 20000) { toMe = true; social[low].ownerReply = Date.now() }
    }
    if (!toMe) return
    const r = replyFor(b, user, t)
    if (!r) { log('CHAT_QUIET', user + ': ' + t.slice(0, 60)); return }
    setTimeout(() => say(b, r), 250 + Math.random() * 550)
  } catch (e) { log('CHATBRAIN_ERR', e && e.message) }
}

function startReflexes (b) {
  let lastStuckPos = null; let lastStuckTime = Date.now();
  let lastPos = null; let lastMove = Date.now(); let lastEscape = 0; let lastDefLog = 0
  if (b.__reflex) clearInterval(b.__reflex)
  b.__reflex = setInterval(() => {
    try {
      // STUCK JUMP: if trying to move but not actually moving for 1.5s, force a jump
      try {
        const isMovingCtrl = b.controlState && (b.controlState.forward || b.controlState.back || b.controlState.left || b.controlState.right);
        const pfMoving = b.pathfinder && b.pathfinder.isMoving ? b.pathfinder.isMoving() : false;
        if (isMovingCtrl || pfMoving) {
          const p = b.entity ? b.entity.position : null;
          if (p && lastStuckPos && p.distanceTo(lastStuckPos) < 0.5 && Date.now() - lastStuckTime > 1500) {
            if (Date.now() > jumpLockUntil) {
              b.setControlState('jump', true);
              setTimeout(() => { try { b.setControlState('jump', false) } catch(e){} }, 300);
              lastStuckTime = Date.now();
            }
          }
          if (!lastStuckPos || (p && p.distanceTo(lastStuckPos) > 0.5)) {
            lastStuckPos = p ? p.clone() : null;
            lastStuckTime = Date.now();
          }
        } else {
          lastStuckPos = null;
          lastStuckTime = Date.now();
        }
      } catch (e) {}

      if (!reflexOn) { lastPos = null; return }
      if (!b.entity || b.health <= 0) { lastPos = null; return }
      const now = Date.now()
      // fleeing / respawn-sprinting: NEVER dig - digging while chased = death spiral.
      // toggled centrally here so canDig always restores itself afterwards
      try {
        const wantDig = !b.__fleeing && !hiding && now > (b.__respawnSprintUntil || 0)
        if (b.__movements && b.__movements.canDig !== wantDig) b.__movements.canDig = wantDig
        if (b.collectBlock && b.collectBlock.movements && b.collectBlock.movements.canDig !== wantDig) b.collectBlock.movements.canDig = wantDig
      } catch (e) {}
      // anti-starvation: directorTick is blocked while missions run, but food keeps dropping -
      // eat here instead (junk food only as a last resort, never while fleeing/hiding)
      if (!b.__fleeing && !hiding && b.food <= 7 && now - (b.__lastStarveEat || 0) > 15000) {
        try {
          const junk = b.food <= 5 ? b.inventory.items().find(i => i.name === 'rotten_flesh' || i.name === 'spider_eye' || i.name === 'poisonous_potato') : null
          if (countFood(b) > 0) { b.__lastStarveEat = now; eatFood(b).catch(() => {}) } else if (junk) {
            b.__lastStarveEat = now
            b.equip(junk, 'hand').then(() => b.consume()).then(() => log('ATE emergency', junk.name, 'food=' + Math.round(b.food))).catch(() => {})
          }
        } catch (e) {}
      }
      // starving with empty hands: abort whatever mission is running so director picks food
      if (b.food <= 4 && countFood(b) === 0 && mission && mission.name !== 'food' && !isNight(b) && now - (b.__lastStarveAbort || 0) > 30000) {
        b.__lastStarveAbort = now
        log('STARVE_ABORT food=' + Math.round(b.food) + ' mission=' + mission.name)
        try { b.pathfinder.setGoal(null) } catch (e) {}
        mission = null
      }
      if (b.isAlive === false && b.health > 0) { b.isAlive = true; log('ISALIVE_RESTORED', 'hp=' + Math.round(b.health)) }
      if (b.__srvPos && Date.now() - b.__srvPos.t > 12000 && b.__inWater) {
        if (Date.now() - (b.__helpAsked || 0) > 90000) { b.__helpAsked = Date.now(); log('WATER_PIN', 'no server updates, stuck at ' + pos(b)) }
      }
      if (b.game && b.game.gameMode === 'creative') { log('MODE_FIX'); try { b.game.gameMode = 'survival' } catch (e) {} }
      const fp = b.entity.position.floored()
      const hb = b.blockAt(fp.offset(0, 1, 0))
      const inWater = !!(hb && /water|lava/.test(hb.name))
      const feetWet = !!(b.blockAt(fp) && /water|lava/.test(b.blockAt(fp).name))
      if (!inWater && !feetWet && b.entity.onGround) b.__lastDry = { x: fp.x, y: fp.y, z: fp.z, t: now }
      if ((inWater || feetWet) && !(b.__drive && Date.now() < manualLockUntil) && !b.__wallBury && !b.__burying && !hiding && !inCollapseZone(b) && !tunneling && !diggingUp && !deepNearCrater(b)) {
        if (!b.__inWater) { b.__inWater = true; try { b.pathfinder.setGoal(null) } catch (e) {} }
        // being shot at while swimming = death spiral (50 deaths in 10 min): wall-burrow NOW
        if (now - (b.__lastWallBury || 0) > 45000) {
          let wt = null
          try { wt = threatsNear(b, 1.0)[0] } catch (e) {}
          if (wt && wt.d < 14) {
            b.__fleeing = false
            b.__lastWallBury = now
            log('WATER_THREAT ' + (wt.e.name || '?') + ' d=' + wt.d.toFixed(1) + ' -> wallBury')
            wallBury(b, 90000)
            return
          }
        }
        if (now - (b.__dryRun || 0) > 6000) {
          b.__dryRun = now
          const dry = nearestDry(b, 16)
          if (dry && dry.d < 4) {
            const key = Math.round(b.entity.position.x) + ',' + Math.round(b.entity.position.z)
            if (b.__wetKey === key) b.__wetFails = (b.__wetFails || 0) + 1
            else { b.__wetKey = key; b.__wetFails = 1 }
            if (b.__wetFails >= 2 && b.__wetFails < 5) escapeWaterPillar(b)
            if (b.__wetFails >= 5 && dry.d < 3.5 && !b.__wetBurst) {
              b.__wetBurst = true
              log('WATER_BURST at dry shore d=' + dry.d.toFixed(1) + ' at', pos(b))
              try { b.lookAt(new Vec3(dry.x + 0.5, dry.y + 0.5, dry.z + 0.5), true) } catch (e) {}
              try { b.setControlState('forward', true); b.setControlState('sprint', true); b.setControlState('jump', true) } catch (e) {}
              setTimeout(() => { try { b.setControlState('forward', false); b.setControlState('sprint', false); b.setControlState('jump', false) } catch (e) {}; b.__wetBurst = false; b.__wetFails = 0 }, 2200)
            }
          } else if (dry) { b.__wetFails = 0 }
          if (dry) {
            log('WATER_OUT', 'to ' + Math.round(dry.x) + ' ' + dry.y + ' ' + Math.round(dry.z) + ' d=' + dry.d.toFixed(1))
            try { b.lookAt(new Vec3(dry.x + 0.5, dry.y, dry.z + 0.5), true, false) } catch (e) {}
            try { b.setControlState('forward', true); b.setControlState('sprint', false) } catch (e) {}
            hop(b)
            const hb = setInterval(() => hop(b), 400)
            setTimeout(() => { clearInterval(hb); try { b.setControlState('jump', false) } catch (e) {} }, 1400)
            setTimeout(() => { try { b.setControlState('forward', false) } catch (e) {} }, 2600)
          } else {
            const ld = (b.__lastDry && now - b.__lastDry.t < 300000) ? b.__lastDry : null
            if (ld) {
              log('WATER_OUT', 'swim to last dry ' + ld.x + ' ' + ld.z + ' at', pos(b))
              try { b.look(Math.atan2(-(ld.x + 0.5 - b.entity.position.x), ld.z + 0.5 - b.entity.position.z), -0.1, true) } catch (e) {}
              try { b.setControlState('forward', true); b.setControlState('sprint', true) } catch (e) {}
              setTimeout(() => { try { b.setControlState('forward', false); b.setControlState('sprint', false) } catch (e) {} }, 5000)
            } else {
              log('WATER_OUT', 'no dry ground near ' + pos(b))
              try { b.setControlState('jump', true) } catch (e) {}
              setTimeout(() => { try { b.setControlState('jump', false) } catch (e) {} }, 800)
            }
          }
        }
        lastPos = b.entity.position.clone()
        return
      } else if (b.__inWater) {
        b.__inWater = false
        try { b.setControlState('jump', false); b.setControlState('forward', false); b.setControlState('sprint', false) } catch (e) {}
      }
      const hsMul = hasWeapon(b) && b.health >= 14 ? 0.6 : 1.0
      let hs = threatsNear(b, hsMul)
      // dropped campers: a ranged follower that keeps its distance and never lands a hit
      // is ignored for a while, otherwise missions never resume (it aggroed for 3+ min straight)
      if (b.__ignore && now < b.__ignore.until) {
        hs = hs.filter(x => !(x.e.id === b.__ignore.id && x.d > x.r * 0.7 && now - lastHurtAt > 8000))
      }
      // hysteresis: while fleeing, keep fleeing while the chaser is anywhere inside 1.4x radius,
      // so a threat hovering at the boundary cannot flip-flop the state (goal ping-pong)
      if (!hs.length && b.__fleeing) {
        let wide = threatsNear(b, hsMul * 1.4)
        if (b.__ignore && now < b.__ignore.until) wide = wide.filter(x => x.e.id !== b.__ignore.id)
        if (wide.length) hs = wide
      }
      if (hs.length) { b.__fleeClearAt = 0 }
      if (hs.length) {
        const t = hs[0]
        const armed = hasWeapon(b)
        const ranged = RANGED.has(String(t.e.name || '').toLowerCase())
        // cornered by MELEE (zombie walked into the trench / caught us at pocket exit):
        // raw sprint barely outpaces it - tower up 4 instead, they cannot pillar after us
        if (!ranged && !armed && t.d < 4.5 && b.health <= 16 && now - (b.__towerCd || 0) > 40000 && !botWet(b) && !b.__burying && !b.__wallBury && !hiding && !inCollapseZone(b)) {
          if (b.__pillarEscape) { lastPos = b.entity.position.clone(); return }
          b.__towerCd = now
          log('TOWER_ESCAPE ' + t.e.name + ' d=' + t.d.toFixed(1) + ' hp=' + Math.round(b.health))
          ;(async () => {
            b.__pillarEscape = true
            try {
              try { b.pathfinder.setGoal(null) } catch (e) {}
              b.__fleeing = false
              manualLockUntil = Math.max(manualLockUntil, Date.now() + 12000)
              if (countPlaceable(b) < 4) await ensurePlaceable(b, 4)
              if (countPlaceable(b) >= 1) await pillarUp(b, 4)
            } catch (e) {}
            b.__pillarEscape = false
          })()
          lastPos = b.entity.position.clone()
          return
        }
        if (b.__pillarEscape) { lastPos = b.entity.position.clone(); return }
        // night + gearless + mob within 14: don't run around the jungle all night -
        // flee-escaping kept dying (water/undergrowth slow us, canopy keeps mobs spawning).
        // Seal into a pocket and sleep out the night instead.
        if ((b.entity.isInWater || feetWet) && t.d < 16 && !hiding && !b.__wallBury && now - (b.__lastWallBury || 0) > 45000) {
          b.__fleeing = false
          b.__lastWallBury = now
          log('WATER_THREAT flee ' + t.e.name + ' d=' + t.d.toFixed(1) + ' -> wallBury')
          wallBury(b, 90000)
          return
        }
        if (!armed && (isNight(b) || isDusk(b)) && t.d < 22 && b.health > 10 && now - lastHideAt > 70000) {
          b.__fleeing = false
          lastPos = b.entity.position.clone()
          log('HIDE_TRIGGER night ' + t.e.name + ' d=' + t.d.toFixed(1) + ' hp=' + Math.round(b.health))
          hidePocket(b, t.e, 240000, true)
          return
        }
        if (ranged && !armed && b.health <= 13 && b.health > 4 && now - lastHideAt > 70000) {
          b.__fleeing = false
          if (now - lastDefLog > 4000) { lastDefLog = now; log('HIDE_TRIGGER', t.e.name + ' hp=' + Math.round(b.health) + ' d=' + t.d.toFixed(1)) }
          lastPos = b.entity.position.clone()
          hidePocket(b, t.e, 26000, true)
          return
        }
        if (armed && b.health >= 10 && now > manualLockUntil) {
          b.__fleeing = false
          equipBestWeapon(b)
          try { b.lookAt(t.e.position.offset(0, (t.e.height || 1.8) * 0.6, 0)) } catch (e) {}
          if (t.d > 3.0) { try { b.pathfinder.setGoal(new goals.GoalNear(t.e.position.x, t.e.position.y, t.e.position.z, 2)) } catch (e) {} }
          try { b.attack(t.e) } catch (e) {}
          if (now - lastDefLog > 4000) { lastDefLog = now; log('DEFEND', t.e.name, 'd=' + t.d.toFixed(1)) }
        } else if (now > manualLockUntil || (b.__drive && t.d < 8)) {
          if (!b.__fleeing) { b.__fleeing = true; b.__fleeGoalAt = 0; b.__fleeStart = now; try { b.pathfinder.setGoal(null) } catch (e) {} }
          if (b.__drive && Date.now() < manualLockUntil) { log('DRIVE_ABORT', 'flee ' + t.e.name); stopDrive(b) }
          if (ranged && !armed && b.health >= 14 && now - (b.__fleeStart || now) > 20000 && t.d > t.r * 0.7 && now - lastHurtAt > 10000) {
            // anti-camp: it just follows at range and never hits - drop aggro, resume living
            b.__ignore = { id: t.e.id, until: now + 30000 }
            b.__fleeing = false
            log('FLEE_DROP', t.e.name + ' keeps distance d=' + t.d.toFixed(1) + ' - ignoring for 30s')
            try { b.pathfinder.setGoal(null) } catch (e) {}
            try { b.clearControlStates() } catch (e) {}
          } else {
            // in dense terrain raw sprinting runs face-first into trees and the chaser catches up;
            // let the pathfinder route the escape around obstacles, raw sprint only while it thinks.
            // commit to each escape vector for 4s: re-picking every 2.2s made the bot zigzag in
            // place while zombies kept contact distance (d=4-8 forever) and eventually killed it
            if (now - (b.__fleeGoalAt || 0) > 4000 && !hiding) {
              b.__fleeGoalAt = now
              const ep = escapePointFrom(b, t.e.position, ranged ? 28 : 32)
              if (ep) { try { b.pathfinder.setGoal(new goals.GoalXZ(ep.x, ep.z)) } catch (e) {} }
            }
            let pfMoving = false; try { pfMoving = b.pathfinder.isMoving() } catch (e) {}
            if (!pfMoving) fleeFrom(b, t.e)
            if (now - lastDefLog > 4000) { lastDefLog = now; log('FLEE', t.e.name, 'd=' + t.d.toFixed(1), 'hp=' + Math.round(b.health) + ((ranged ? ' zigzag ' : ' ') + (pfMoving ? 'pf' : 'raw'))) }
          }
        }
      } else if (b.__fleeing) {
        // coast for 2.5s before standing down (kills boundary flip-flop for good)
        if (!b.__fleeClearAt) b.__fleeClearAt = now
        if (now - b.__fleeClearAt >= 2500) {
          b.__fleeing = false; b.__fleeClearAt = 0
          if (Date.now() > manualLockUntil && !b.__drive) {
            try { b.setControlState('forward', false); b.setControlState('sprint', false); b.setControlState('left', false); b.setControlState('right', false); b.setControlState('jump', false) } catch (e) {}
          }
        }
      }
      const p = b.entity.position
      if (lastPos && p.distanceTo(lastPos) < 0.2) { if (now - lastMove > 8000) lastMove = now } else { lastMove = now }
      lastPos = p.clone()
    } catch (e) {}
  }, 500)
}

let mission = null
function missionActive () { return !!mission }

function countItem (b, name) {
  let n = 0
  for (const it of b.inventory.items()) if (it.name === name) n += it.count
  return n
}

async function placeBlockAt (b, x, y, z, itemName) {
  if (!b.entity) return false
  const targetPos = new Vec3(x, y, z)
  const cur = b.blockAt(targetPos)
  if (cur && cur.boundingBox === 'block') return true
  const inv = b.inventory.items().find(i => i.name === itemName)
  if (!inv) return false
  try { await b.equip(inv, 'hand') } catch (e) { return false }
  if (b.entity.position.distanceTo(targetPos) > 4) {
    try { b.pathfinder.setGoal(new goals.GoalNear(x, y, z, 3)); await once(b, 'goal_reached', 12000) } catch (e) {}
    try { b.pathfinder.setGoal(null) } catch (e) {}
  }
  const dirs = [new Vec3(0, -1, 0), new Vec3(1, 0, 0), new Vec3(-1, 0, 0), new Vec3(0, 0, 1), new Vec3(0, 0, -1), new Vec3(0, 1, 0)]
  for (const d of dirs) {
    const ref = b.blockAt(targetPos.plus(d))
    if (ref && ref.boundingBox === 'block') {
      const r = await withTimeout(b.placeBlock(ref, d.scaled(-1)), 4000, 'to')
      if (r !== 'to') return true
    }
  }
  return false
}

async function gatherBlocks (b, findNames, countName, target) {
  const ids = findNames.map(n => mcData.blocksByName[n]).filter(Boolean).map(bt => bt.id)
  let guard = 0
  let stalls = 0
  let last = countItem(b, countName)
  while (countItem(b, countName) < target && b.entity && b.health > 0 && mission && guard++ < 150) {
    const positions = b.findBlocks({ matching: ids, maxDistance: 28, count: 8 })
    if (!positions.length) { log('GATHER none nearby'); await suckDrops(b, 12); break }
    const blocks = positions.map(p => b.blockAt(p)).filter(Boolean)
    const need = target - countItem(b, countName)
    const r = await withTimeout(b.collectBlock.collect(blocks, { iterations: Math.max(1, Math.min(8, need)), range: 4 }), 25000, 'timeout')
    if (r === 'timeout') log('GATHER timeout, retrying')
    const now = countItem(b, countName)
    if (now <= last) { stalls++; await suckDrops(b, 8); if (stalls >= 4) { log('GATHER stalled at', now, '- proceeding to build'); break } } else { stalls = 0; last = now }
  }
  log('GATHER have', countItem(b, countName), countName)
}

// walk over item entities we dropped/mined but never picked up (pickup range is tiny)
async function suckDrops (b, r) {
  try {
    if (!b.entity) return
    const p = b.entity.position
    const near = []
    // cylindrical search: trunk drops tumble off cliffs and land 15+ blocks BELOW
    for (const id in b.entities) {
      const e = b.entities[id]
      if (e && e.name === 'item' && e.position) {
        const dh = Math.hypot(e.position.x - p.x, e.position.z - p.z)
        if (dh < (r || 8) && Math.abs(e.position.y - p.y) < 24) near.push(e)
      }
    }
    if (!near.length) return
    near.sort((x, y) => x.position.distanceTo(p) - y.position.distanceTo(p))
    log('SUCK drops x' + Math.min(8, near.length))
    for (const e of near.slice(0, 8)) {
      if (!b.entity || !mission || b.__fleeing || hiding) break
      await gotoT(b, new goals.GoalNear(e.position.x, e.position.y, e.position.z, 1), 4000)
      await sleep(450)
    }
  } catch (e2) {}
}

async function buildShelter (b, mat) {
  const o = b.entity.position.floored()
  log('BUILD origin', o.x, o.y, o.z, 'mat', mat)
  const cells = []
  for (let dx = -2; dx <= 2; dx++) {
    for (let dz = -2; dz <= 2; dz++) {
      const perim = (Math.abs(dx) === 2 || Math.abs(dz) === 2)
      if (perim) {
        for (let dy = 0; dy <= 1; dy++) {
          if (dx === 2 && dz === 0) continue
          cells.push([dx, dy, dz])
        }
      }
    }
  }
  for (let dx = -2; dx <= 2; dx++) { for (let dz = -2; dz <= 2; dz++) cells.push([dx, 2, dz]) }
  let placed = 0
  for (const c of cells) {
    if (!mission) break
    if (await placeBlockAt(b, o.x + c[0], o.y + c[1], o.z + c[2], mat)) placed++
    await sleep(50)
  }
  log('BUILD placed', placed, '/', cells.length)
}

async function missionShelter (b) {
  log('MISSION shelter START at', pos(b))
  try {
    await autoFree(b)
    if (!hasWeapon(b) && (isNight(b) || isDusk(b))) {
      // gearless at night: gathering 55 dirt in the open is suicide - seal into a
      // pocket and sleep out the night instead (zombies can't dig, arrows need LOS)
      let rounds = 0
      while (mission && b.entity && b.health > 0 && (isNight(b) || isDusk(b)) && rounds++ < 8) {
        if (botWet(b)) await wallBury(b, 120000)
        else await hidePocket(b, nearestHostile(b, 20), 240000, true)
        if (mission && (isNight(b) || isDusk(b))) await sleep(3000)
      }
      log('MISSION shelter: dawn at', pos(b))
    } else {
      await gatherBlocks(b, ['dirt', 'grass_block'], 'dirt', 55)
      if (mission) await buildShelter(b, 'dirt')
    }
  } catch (e) { log('MISSION_ERR', e && e.message ? e.message : String(e)) }
  log('MISSION shelter END')
  mission = null
}

async function missionGather (b, blockName, n) {
  log('MISSION gather START', blockName, n)
  try {
    await autoFree(b)
    await gatherBlocks(b, [blockName], blockName, n)
  } catch (e) { log('MISSION_ERR', e && e.message ? e.message : String(e)) }
  log('MISSION gather END')
  mission = null
}

// Craft+place a crafting table when 3x3 recipes need one and none is in reach.
// Returns the table Block, or null. (Fixes the stone-mission hot loop: cobble was
// banked but stone_pickaxe silently failed to craft with no table anywhere.)
async function ensureCraftingTable (b) {
  try {
    const ct = mcData.blocksByName.crafting_table
    if (!ct) return null
    let tb = b.findBlock({ matching: ct.id, maxDistance: 5 })
    if (tb) return tb
    if (countItem(b, 'crafting_table') < 1) {
      const pl = PLANKS_ANY.find(n => countItem(b, n) >= 4)
      if (!pl) return null
      if (!await craftItem(b, 'crafting_table', 1)) return null
    }
    const ctItem = b.inventory.items().find(i => i.name === 'crafting_table')
    if (!ctItem) return null
    const feet = b.entity.position.floored()
    for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]]) {
      const ground = b.blockAt(feet.offset(d[0], -1, d[1]))
      const cell = b.blockAt(feet.offset(d[0], 0, d[1]))
      const head = b.blockAt(feet.offset(d[0], 1, d[1]))
      if (!ground || ground.boundingBox !== 'block') continue
      if (!cell || cell.boundingBox === 'block') continue
      if (head && head.boundingBox === 'block') continue
      try {
        await b.equip(ctItem, 'hand')
        const r = await withTimeout(b.placeBlock(ground, new Vec3(0, 1, 0)), 4000, 'to')
        if (r === 'to') continue
        tb = b.findBlock({ matching: ct.id, maxDistance: 5 })
        if (tb) { log('TABLE placed at', tb.position.x + ' ' + tb.position.y + ' ' + tb.position.z); return tb }
      } catch (e) { log('TABLE_PLACE_ERR', e && e.message) }
    }
    return null
  } catch (e) { log('TABLE_ERR', e && e.message); return null }
}
async function craftItem (b, name, count) {
  const item = mcData.itemsByName[name]
  if (!item) return false
  let table = null
  const ct = mcData.blocksByName.crafting_table
  if (ct) { const tb = b.findBlock({ matching: ct.id, maxDistance: 5 }); if (tb) table = tb }
  let recipes = b.recipesFor(item.id, null, 1, table)
  if (!recipes.length && table) recipes = b.recipesFor(item.id, null, 1, null)
  if (!recipes.length && name !== 'crafting_table') {
    // 3x3 recipe with no table in reach: make one, place it, retry once
    table = await ensureCraftingTable(b)
    if (table) { recipes = b.recipesFor(item.id, null, 1, table); if (!recipes.length) recipes = b.recipesFor(item.id, null, 1, null) }
  }
  if (!recipes.length) return false
  try { await b.craft(recipes[0], count || 1, table); stats.crafted += (count || 1); log('CRAFT', name, 'x' + (count || 1)); return true } catch (e) { log('CRAFT_FAIL', name, e && e.message); return false }
}

const LOG_TYPES = ['oak_log', 'birch_log', 'spruce_log', 'jungle_log', 'acacia_log', 'dark_oak_log', 'mangrove_log', 'cherry_log']
// walk down a trunk to its base: the bottom log is reachable, the canopy is not
function trunkBase (b, p) {
  let base = p.clone()
  for (let dy = 1; dy <= 30; dy++) {
    const below = b.blockAt(new Vec3(p.x, p.y - dy, p.z))
    if (below && LOG_TYPES.indexOf(below.name) >= 0) base = below.position.clone()
    else break
  }
  return base
}
function findNearestLog (b, r, exclude, relaxed) {
  const ids = LOG_TYPES.map(n => mcData.blocksByName[n]).filter(Boolean).map(bt => bt.id)
  if (!ids.length) return null
  let positions = []
  try { positions = b.findBlocks({ matching: ids, maxDistance: r, count: 250 }) } catch (e) {}
  if (!positions.length) return null
  const feet = b.entity.position
  const bases = new Map()
  for (const p of positions) {
    const key = p.x + ',' + p.z
    if (!bases.has(key)) bases.set(key, trunkBase(b, p))
  }
  let best = null; let bestD = 1e9
  for (const base of bases.values()) {
    if (exclude && exclude.has(base.x + ',' + base.y + ',' + base.z)) continue
    if (inDeathZone(base.x, base.z, 40)) continue                    // died by this tree recently - pick another area
    if (relaxed) {
      // the whole jungle sits in the "corridor": strict pass found nothing, so only
      // keep the nest core excluded - death zones still guard the actually lethal spots
      if (Math.hypot(base.x - NEST.x, base.z - NEST.z) < 35) continue
    } else {
      if (Math.hypot(base.x - NEST.x, base.z - NEST.z) < 60) continue  // spawn-nest corridor: never route wood through it
      if (pointSegDist(NEST.x, NEST.z, feet.x, feet.z, base.x, base.z) < 45) continue  // straight route would cross the nest
    }
    if (base.y - feet.y > 30 || feet.y - base.y > 20) continue     // unreachable cliff/canopy
    const d = Math.hypot(base.x - feet.x, base.z - feet.z)
    // slope/cliff-top trunk: no longer hard-skipped (we can dig + pillar toward it now),
    // but heavily penalized so level-ground trunks are always attempted first.
    const up = Math.max(0, base.y - feet.y)
    const score = d + (up > 2 ? up * 2.5 : 0) + (up > 6 && up > d * 0.6 ? 25 : 0)
    if (score < bestD) { bestD = score; best = base }
  }
  if (best) log('WOOD trunk base', best.x + ' ' + best.y + ' ' + best.z, 'score=' + Math.round(bestD))
  return best
}
// goto with a hard deadline; resolves to 'reached' | 'timeout' | 'fail:<reason>' and always
// leaves the pathfinder idle afterwards, so callers can chain strategies without overlap
async function gotoT (b, goal, ms) {
  let res
  try {
    res = await Promise.race([
      b.pathfinder.goto(goal).then(() => 'reached').catch(e => 'fail:' + ((e && e.name) || 'err')),
      sleep(ms).then(() => 'timeout')
    ])
  } catch (e) { res = 'fail:err' }
  // library quirk: when A* finds no path at all, 'path_update' arrives with an empty
  // path and goto RESOLVES as success. Verify we actually satisfy the goal.
  if (res === 'reached' && b.entity) {
    try {
      const p = b.entity.position.floored()
      if (!goal.isEnd(p) && !goal.isEnd(p.offset(0, 1, 0))) res = 'fail:noPath'
    } catch (e) {}
  }
  if (res !== 'reached') {
    try { b.pathfinder.stop() } catch (e) {}
    await sleep(120)
    try { b.pathfinder.setGoal(null) } catch (e) {}
    await sleep(580)                                   // hard pacing: never spin goto loops
  }
  return res
}
// No paths anywhere = tiny island / water pocket / walled niche. Swim or walk to dry land.
// Underwater pillarUp() can't work: one hop lifts <1 block in water, floored() never
// changes and every place lands into the block we stand on. Swim up deliberately
// (+1.25b), then place into the cell we just left, against the block below it.
async function waterPillarOnce (b) {
  if (!b.entity) return false
  const matName = PLACEABLE.find(nm => countItem(b, nm) > 0)
  if (!matName) return false
  const mat = b.inventory.items().find(it => it.name === matName)
  try { await b.equip(mat, 'hand') } catch (e) {}
  const start = b.entity.position.clone()
  const baseCell = start.floored()                        // the water cell we will fill
  const baseBlk = b.blockAt(baseCell)
  if (baseBlk && baseBlk.boundingBox === 'block') return true
  // swim-jump up until our FEET clear the cell, then place into the cell we left.
  // (old version computed target=feet-1 AFTER the wait: in a puddle that was the
  // solid floor -> "already solid, return true" short-circuit = infinite no-op)
  b.setControlState('jump', true)
  const t0 = Date.now()
  while (Date.now() - t0 < 1800 && b.entity && b.entity.position.y < start.y + 1.15) await sleep(70)
  b.setControlState('jump', false)
  if (!b.entity) return false
  if (b.entity.position.y - start.y < 0.55) return false  // puddle/pinned: caller handles
  const ref = b.blockAt(baseCell.offset(0, -1, 0))
  if (!ref || ref.boundingBox !== 'block') return false
  const still = b.blockAt(baseCell)
  if (still && still.boundingBox === 'block') return true
  const r = await withTimeout(b.placeBlock(ref, new Vec3(0, 1, 0)), 3500, 'to')
  return r !== 'to'
}
// wet = submerged OR standing in a puddle (feet cell water). hidePocket in a puddle
// dug+sealed the trench floor and WASTED our pillar sand - always wallBury when wet.
function botWet (b) {
  try {
    if (!b.entity) return false
    if (b.entity.isInWater) return true
    const fb = b.blockAt(b.entity.position.floored())
    return !!(fb && /water/.test(fb.name))
  } catch (e) { return false }
}
// stuck in water with an unreachable 1-block shore (the spawn cove is exactly that):
// pillar straight up through the water column - placing blocks underwater works,
// and from the surface the shore is a trivial walk
async function escapeWaterPillar (b) {
  if (b.__wetPillar || !b.entity) return
  b.__wetPillar = true
  try {
    log('WATER_PILLAR up from water at', pos(b))
    manualLockUntil = Math.max(manualLockUntil, Date.now() + 20000)
    for (let k = 0; k < 10 && b.entity && b.health > 0; k++) {
      const ft = b.entity.position.floored()
      const here = b.blockAt(ft)
      const inW = b.entity.isInWater || !!(here && /water/.test(here.name))
      if (!inW) break
      if (countPlaceable(b) < 1) await ensurePlaceable(b, 3, false)
      if (countPlaceable(b) < 1) break
      const y0 = b.entity.position.y
      const ok = await waterPillarOnce(b)
      if (!ok && b.entity && b.entity.position.y - y0 < 0.3) {
        // pinned in the cove (server rejects every move): carve horizontally toward
        // dry land, free our own cells, then tower up with digUpAndOut
        const dry = nearestDry(b, 16)
        if (dry) {
          log('WATER_CARVE toward ' + Math.round(dry.x) + ' ' + Math.round(dry.z) + ' at', pos(b))
          const ft = b.entity.position.floored()
          await withTimeout(digBlock(b, ft), 6000, false)
          await withTimeout(digBlock(b, ft.offset(0, 1, 0)), 6000, false)
          const dx = dry.x + 0.5 - b.entity.position.x; const dz = dry.z + 0.5 - b.entity.position.z
          const l = Math.hypot(dx, dz) || 1
          const ux = Math.round(dx / l); const uz = Math.round(dz / l)
          for (let step = 1; step <= 3; step++) {
            for (const dy of [0, 1]) await withTimeout(digBlock(b, ft.offset(ux * step, dy, uz * step)), 6000, false)
          }
          try { await b.look(Math.atan2(-dx, dz), 0, true) } catch (e) {}
          b.setControlState('forward', true); b.setControlState('sprint', true)
          await sleep(1400)
          b.setControlState('forward', false); b.setControlState('sprint', false)
          await digUpAndOut(b, 8)
        }
        break
      }
      await sleep(300)
    }
    log('WATER_PILLAR done at', pos(b), 'placeable=' + countPlaceable(b))
  } catch (e) { log('WPILLAR_ERR', e && e.message) }
  b.__wetPillar = false
}
// dig without suckDrop: underwater suckDrop swims up after floating drops and drags
// the bot out of the niche mid-work. Retries once on "Digging aborted" (arrow knockback).
async function digRaw (b, v) {
  if (NO_DIG) return false
  for (let att = 0; att < 2; att++) {
    const blk = b.blockAt(v)
    if (!blk || blk.boundingBox !== 'block') return true          // already open = fine
    const hard = blk.hardness === undefined ? 1 : blk.hardness
    if (hard < 0) return false
    try { await b.lookAt(blk.position.offset(0.5, 0.5, 0.5)); await b.dig(blk); stats.mined++; return true } catch (e) { await sleep(200) }
  }
  return false
}
// niche chosen in a PREVIOUS life (same process): terrain edits persist through death,
// so every respawn CONTINUES the same hole instead of restarting a fresh scan
let wallNiche = null
// WATER-TRENCH KILLBOX escape: respawning in water with a skeleton on the rim killed us
// 280+ times - swim/flee/hidePocket all fail while wet. Burrow into the nearest SAND wall
// at water level (cover in ~6s), THEN deepen + seal from inside, sleep out the night,
// digUpAndOut surfaces ON THE SHORE above the wall.
async function wallBury (b, waitMs) {
  if (!b.entity || b.__wallBury || hiding) return false
  if (inCollapseZone(b)) { log('WALL_BURY skip in crater at', pos(b)); return false }
  b.__wallBury = true
  lastHideAt = Date.now()
  try {
    try { b.pathfinder.setGoal(null) } catch (e) {}
    try { b.clearControlStates() } catch (e) {}
    b.__fleeing = false
    manualLockUntil = Math.max(manualLockUntil, Date.now() + 60000)
    jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 60000)
    const GR = /dirt|grass_block|podzol|sand|gravel|stone|cobble|deepslate|granite|diorite|andesite|tuff|calcite|mud|terracotta|moss_block|netherrack|blackstone|basalt|mossy/
    // reuse the niche from a previous life if it is still near
    let best = null
    if (wallNiche && Date.now() - wallNiche.t < 900000 && b.entity.position.distanceTo(new Vec3(wallNiche.x, wallNiche.y, wallNiche.z)) < 10) {
      best = { v: new Vec3(wallNiche.x, wallNiche.y, wallNiche.z), d: wallNiche.d, name: 'cached' }
    }
    if (!best) {
      for (let t = 0; t < 20 && !best; t++) {
        if (!b.entity || b.health <= 0) return false
        const feet0 = b.entity.position.floored()
        // pass 1: SOFT only (sand/dirt/gravel/mud ~2.5s underwater); pass 2: anything diggable
        for (const maxHard of [0.9, 1.6]) {
          for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1], [2, 0], [-2, 0], [0, 2], [0, -2]]) {
            for (const dy of [0, 1]) {
              const v = feet0.offset(d[0], dy, d[1])
              const blk = b.blockAt(v)
              if (!blk || blk.boundingBox !== 'block' || !GR.test(blk.name)) continue
              const hard = blk.hardness === undefined ? 1 : blk.hardness
              if (hard < 0 || hard > maxHard) continue
              const head = b.blockAt(v.offset(0, 1, 0))
              if (head && head.boundingBox === 'block' && (head.hardness === undefined ? 1 : head.hardness) > maxHard) continue
              const score = hard * 3 + Math.hypot(d[0], d[1])
              if (!best || score < best.score) best = { v, d, score, name: blk.name }
            }
          }
          if (best) break
        }
        if (!best) await sleep(400)
      }
    }
    if (!best) { log('WALL_BURY no wall near', pos(b)); return false }
    wallNiche = { x: best.v.x, y: best.v.y, z: best.v.z, d: best.d, t: Date.now() }
    log('WALL_BURY into ' + best.name + ' ' + best.v.x + ' ' + best.v.y + ' ' + best.v.z + ' from', pos(b), 'hp=' + Math.round(b.health))
    // PHASE 1 - get under cover FAST (2 sand cells ~5s): low + head, then move in
    if (!(await withTimeout(digRaw(b, best.v), 12000, false))) { log('WALL_BURY dig failed'); return false }
    if (!b.entity || b.health <= 0) return true
    await withTimeout(digRaw(b, best.v.offset(0, 1, 0)), 7000, false)
    if (!b.entity || b.health <= 0) return true
    try { await b.look(Math.atan2(-best.d[0], best.d[1]), -0.1, true) } catch (e) {}
    b.setControlState('forward', true); b.setControlState('jump', true)
    await sleep(900)
    b.setControlState('forward', false); b.setControlState('jump', false)
    if (!b.entity || b.health <= 0) return true
    // PHASE 2 - from inside: deepen (drops land INSIDE the niche = seal material), collect, seal
    const deep = best.v.offset(best.d[0], 0, best.d[1])
    await withTimeout(digRaw(b, deep), 8000, false)
    await withTimeout(digRaw(b, deep.offset(0, 1, 0)), 6000, false)
    try { await b.look(Math.atan2(-best.d[0], best.d[1]), -0.1, true) } catch (e) {}
    b.setControlState('forward', true)
    await sleep(700)
    b.setControlState('forward', false)
    await sleep(400)
    try { await collectNear(b, 3) } catch (e) {}
    if (!b.entity || b.health <= 0) return true
    const feet2 = b.entity.position.floored()
    const inCell = feet2.distanceTo(deep) === 0 || feet2.distanceTo(best.v) === 0
    let sealed = false
    const ent = best.v                                        // first cell = entrance from the trench
    const entBlk = b.blockAt(ent)
    if (inCell && countPlaceable(b) >= 1 && entBlk && entBlk.boundingBox !== 'block') {
      for (const dd of [[0, -1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, 1, 0]]) {
        const ref = b.blockAt(ent.offset(dd[0], dd[1], dd[2]))
        if (!ref || ref.boundingBox !== 'block') continue
        const r = await withTimeout(b.placeBlock(ref, new Vec3(-dd[0], -dd[1], -dd[2])), 4000, 'to')
        if (r !== 'to') { sealed = true; break }
      }
    }
    log('WALL_BURY in=' + inCell + ' sealed=' + sealed + ' placeable=' + countPlaceable(b) + ' at', pos(b), 'hp=' + Math.round(b.health))
    if (!inCell && !sealed) return false
    const t0 = Date.now()
    const lim = Math.max(20000, waitMs || 60000)
    while (Date.now() - t0 < lim && b.entity && b.health > 0) {
      // dawn: skeletons burn, leave even if night budget remains
      if (Date.now() - t0 > 15000 && !isNight(b) && !isDusk(b)) break
      await sleep(800)
    }
    if (!b.entity || b.health <= 0) return true
    await digUpAndOut(b, 10)
    wallNiche = null
    manualLockUntil = Math.min(manualLockUntil, Date.now() + 1500)
    jumpLockUntil = Math.min(jumpLockUntil, Date.now() + 1500)
    return true
  } catch (e) { log('WALL_BURY_ERR', e && e.message); return false }
  finally { b.__wallBury = false }
}
// SAND HOURGLASS around world spawn (the drained cove trench + bowl we dug):
// ANY dig triggers sand collapse that swallows the bot (hp 20->6 suffocating, floor
// y56->51, then rising fill). No digging, no pillaring inside - the stable ground
// starts at x >= -612 (walked fine at y61-63): just travel east.
const COLLAPSE_ZONE = { x1: -636, x2: -610, z1: -668, z2: -640 }
function inCollapseZone (b) {
  try { const p = b.entity.position; return p.x >= COLLAPSE_ZONE.x1 && p.x <= COLLAPSE_ZONE.x2 && p.z >= COLLAPSE_ZONE.z1 && p.z <= COLLAPSE_ZONE.z2 } catch (e) { return false }
}
// deep underground near the crater (tunnel/pocket/shaft): water reflexes, unstick and
// forced heal-reconnects are all pointless-to-harmful here (the pocket is flooded; a wet
// jump "no-rise" there once triggered a heal -> reconnect -> pillar -> heal LOOP)
function deepNearCrater (b) {
  try { const p = b.entity.position; return p.y < 50 && rimAbove(b) >= 10 && Math.abs(p.x + 612) < 40 && Math.abs(p.z + 654) < 40 } catch (e) { return false }
}
// only cells with OPEN SKY above are safe to dig in the hourglass: a buried cell
// releases the whole column above it (that cascade entombed us at y52, hp 20->6).
// Surface cells of the talus piles yield sand with only a local 1-2 cell slide.
function diggableSurface (b, v) {
  const blk = b.blockAt(v)
  if (!blk || blk.boundingBox !== 'block') return false
  if (!GROUND_RE.test(blk.name)) return false
  if ((blk.hardness === undefined ? 1 : blk.hardness) < 0) return false
  const up = b.blockAt(v.offset(0, 1, 0))
  return !(up && up.boundingBox === 'block')
}
async function harvestSurface (b, need) {
  const feet = b.entity.position.floored()
  for (let r = 1; r <= 4 && countPlaceable(b) < need; r++) {
    for (const d of [[r, 0], [-r, 0], [0, r], [0, -r], [r, r], [r, -r], [-r, r], [-r, -r]]) {
      for (let dy = -1; dy <= 6 && countPlaceable(b) < need; dy++) {
        const v = feet.offset(d[0], dy, d[1])
        if (!diggableSurface(b, v)) continue
        if (b.entity.position.distanceTo(new Vec3(v.x + 0.5, v.y + 0.5, v.z + 0.5)) > 4.6) continue
        await withTimeout(digBlock(b, v), 9000, false)
      }
    }
  }
  return countPlaceable(b)
}
let zoneRunning = false
async function zoneRunEast (b) {
  if (!b.entity || zoneRunning) return
  zoneRunning = true
  try {
    log('ZONE_RUN east from', pos(b), 'hp=' + Math.round(b.health))
    jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 34000)
    const z0 = Math.round(b.entity.position.z) + 0.5
    walkTo(b, -604.5, 63, z0, 25000)
    const t0 = Date.now()
    while (Date.now() - t0 < 25000 && b.entity && b.health > 0 && b.entity.position.x < -612) await sleep(500)
    if (!b.entity || b.health <= 0) return
    if (b.entity.position.x >= -612) { log('ZONE_RUN out at', pos(b)); return }
    // drive stalled in the fill: raw sprint east, hop the soft slopes
    stopDrive(b)
    manualLockUntil = Math.max(manualLockUntil, Date.now() + 9000)
    try { b.pathfinder.setGoal(null) } catch (e) {}
    try { await b.look(-Math.PI / 2, -0.15, true) } catch (e) {}
    b.setControlState('forward', true); b.setControlState('sprint', true); b.setControlState('jump', true)
    const t1 = Date.now()
    while (Date.now() - t1 < 7000 && b.entity && b.health > 0 && b.entity.position.x < -611) await sleep(250)
    try { b.clearControlStates() } catch (e) {}
    log('ZONE_RUN raw end at', pos(b))
  } catch (e) { log('ZONE_RUN_ERR', e && e.message) }
  finally { zoneRunning = false }
}
// IN THE CRATER: digging AND placing both trigger collapses (floor y52->44 over an hour
// of escape attempts). Standing still is stable. Hold position, try server teleport
// commands, ask passing players to drop blocks; pillar out only when material arrives
// (a placed tower on settled floor is the one safe build - one-off updates only).
async function craterHold (b) {
  if (!b.entity || tunneling) return
  const rim = rimAbove(b)
  const inCrater = inCollapseZone(b)
  if (inCrater && rim >= 3 && countPlaceable(b) >= rim + 3) {
    log('CRATER material=' + countPlaceable(b) + ' rim=' + rim + ' -> climbing out at', pos(b))
    jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 45000)
    manualLockUntil = Math.max(manualLockUntil, Date.now() + 45000)
    await pillarClimb(b, rim + 2)
    if (b.entity && rimAbove(b) < 3) {
      log('CRATER OUT at', pos(b))
      wallNiche = null
      try { b.pathfinder.setGoal(new goals.GoalXZ(-598, Math.round(b.entity.position.z))) } catch (e) {}
    }
    return
  }
  const nowC = Date.now()
  if (nowC - (b.__craterCmdAt || 0) > 150000) {
    b.__craterCmdAt = nowC
    const cmds = ['/spawn', '/rtp', '/wild', '/hub', '/lobby', '/warp spawn']
    const n = (b.__craterCmdN = ((b.__craterCmdN || 0) + 1) % cmds.length)
    try { b.chat(cmds[n]); log('CRATER_CMD', cmds[n]) } catch (e) {}
  }
  try {
    const mate = nearestPlayerEntity(b, 64)
    if (mate && mate.name && String(mate.name) !== USERNAME && nowC - (b.__craterAskAt || 0) > 120000) {
      b.__craterAskAt = nowC
      const msg = mate.name + ', выручи, пожалуйста: я провалился в глубокую яму из сыпучего песка у спавна и сам не вылезу. Скинь мне вниз блоков 30 любых твёрдых — я построю башню и выберусь'
      try { b.chat(msg) } catch (e) {}
      log('CRATER_ASK', String(mate.name))
    }
  } catch (e) {}
  // no teleport commands and no helper in sight? dig our way out through the bedrock
  try {
    const mate2 = nearestPlayerEntity(b, 48)
    const playerNear = mate2 && mate2.name && String(mate2.name) !== USERNAME
    const resumable = !inCrater && rim >= 5            // mid-tunnel east of the zone: always continue
    if (rim >= 5 && (resumable || countPlaceable(b) < rim + 3) && (!inCrater || !playerNear) && nowC - (b.__tunnelTriedAt || 0) > (resumable ? 90000 : 600000)) {
      b.__tunnelTriedAt = nowC
      await tunnelEast(b)
    }
  } catch (e) { log('CRATER tunnel err', e && e.message) }
}

// ===== TUNNEL_EAST (deploy 50): dig OUT of the sand crater =====
// The crater floor is STONE (y40-42): below the sand bowl lies stable bedrock that
// does not collapse. East wall at floor level = stone to x=-611, gravel pockets at
// y44+, a DIRT pocket at (-609, y35-37). Plan: mine a safe tunnel east at y~40-42
// (never touch sand/gravel - they flow), drop into the dirt pocket for pillar
// material, tunnel on east past the gravel to x=-602, then climb a 1-wide shaft
// through stable ground to the surface (rim ~y61). Hand-mining stone drops nothing,
// hence the dirt pocket detour.
const SAFE_TUNNEL = new Set(['stone', 'deepslate', 'dirt', 'grass_block', 'cobblestone', 'mossy_cobblestone', 'andesite', 'granite', 'diorite', 'tuff', 'calcite', 'sandstone', 'smooth_sandstone', 'red_sandstone', 'clay', 'mud', 'packed_mud', 'mud_bricks', 'stone_bricks', 'deepslate_bricks', 'cobbled_deepslate', 'iron_ore', 'coal_ore', 'copper_ore', 'gold_ore', 'lapis_ore', 'deepslate_iron_ore', 'deepslate_coal_ore', 'deepslate_copper_ore', 'deepslate_gold_ore', 'deepslate_lapis_ore', 'coarse_dirt', 'rooted_dirt', 'podzol', 'dirt_path', 'terracotta', 'white_terracotta', 'orange_terracotta', 'brown_terracotta'])
const FLOWY = new Set(['sand', 'red_sand', 'gravel', 'suspicious_sand', 'suspicious_gravel'])
let tunneling = false
function cellSafeTunnel (b, v) {
  const blk = b.blockAt(v)
  if (!blk) return false                       // unloaded chunk: treat as unsafe
  if (/lava/.test(blk.name)) return false
  if (blk.boundingBox !== 'block') return true // air / water: passable
  return SAFE_TUNNEL.has(blk.name)
}
function cellFlowy (b, v) { const blk = b.blockAt(v); return !!(blk && FLOWY.has(blk.name)) }
function rowSafeLen (b, x0, x1, y, z) {
  let n = 0; let holes = 0
  for (let x = x0; x <= x1; x++) {
    if (!cellSafeTunnel(b, new Vec3(x, y, z)) || !cellSafeTunnel(b, new Vec3(x, y + 1, z))) break
    const headBlk = b.blockAt(new Vec3(x, y + 1, z))
    const headSolid = !!(headBlk && headBlk.boundingBox === 'block')
    // flowy block over the head cell would bury us WHEN WE MINE that cell; if the head
    // cell is already open, the flowy block above has been resting fine - leave it be
    if (headSolid && cellFlowy(b, new Vec3(x, y + 2, z))) break
    // a row needs a walkable floor, but small dips are fine (stepTo hop-jumps over them);
    // the old-tunnel CEILING row y+1 has a hole every column - rejected by the hole cap
    if (!solidAt(b, new Vec3(x, y - 1, z))) { holes++; if (holes > 4) break }
    n++
  }
  return n
}
async function stepTo (b, dx, dz, ms) {
  if (!b.entity) return
  try { await b.lookAt(b.entity.position.offset(dx * 3, 0, dz * 3)) } catch (e) {}
  let wet = botWet(b)
  try { const fb = b.blockAt(b.entity.position.floored()); if (fb && fb.name === 'water') wet = true } catch (e) {}
  // wading/swimming is ~3x slower and currents push us back: sprint + pulse-jump = swim stroke
  b.setControlState('forward', true)
  if (wet) b.setControlState('sprint', true)
  const t0 = Date.now(); const p0 = b.entity.position.clone()
  const lim = ms || (wet ? 3600 : 1200)
  let lastJump = 0
  while (b.entity && Date.now() - t0 < lim && b.entity.position.distanceTo(p0) < (wet ? 0.6 : 0.75)) {
    // jump ONLY when actually stuck: pulse-jumping in shallow water throws us into the air
    // (no control there) and the current walks us back - bottom-walking wins
    const blocked = Date.now() - t0 > 500 && b.entity.position.distanceTo(p0) < 0.2
    if (blocked && Date.now() - lastJump > 650) {
      lastJump = Date.now()
      b.setControlState('jump', true)
      setTimeout(() => { try { b.setControlState('jump', false) } catch (e) {} }, 280)
    }
    await sleep(50)
  }
  b.setControlState('forward', false)
  try { b.setControlState('jump', false); b.setControlState('sprint', false) } catch (e) {}
  await sleep(120)
}
async function digDownTo (b, targetY) {
  let guard = 0
  while (b.entity && b.health > 0 && b.entity.position.floored().y > targetY && guard++ < 14) {
    const below = b.entity.position.floored().offset(0, -1, 0)
    const blk = b.blockAt(below)
    if (!blk) return false
    if (blk.boundingBox !== 'block') { await sleep(350); continue }   // open/water: sink or wait
    if (FLOWY.has(blk.name) || /lava/.test(blk.name)) { log('DIGDOWN unsafe ' + blk.name, pos(b)); return false }
    if (!await withTimeout(digBlock(b, below), 14000, false)) return false
    await sleep(420)
  }
  return !!(b.entity && b.entity.position.floored().y <= targetY)
}
async function minePocket (b, want) {
  const c0 = b.entity.position.floored()
  const cells = []
  for (let dx = -2; dx <= 2; dx++) for (let dy = -2; dy <= 3; dy++) for (let dz = -3; dz <= 3; dz++) cells.push(c0.offset(dx, dy, dz))
  cells.sort((a, c) => a.distanceTo(c0) - c.distanceTo(c0))
  for (const v of cells) {
    if (!b.entity || countPlaceable(b) >= want) break
    const blk = b.blockAt(v)
    if (!blk || blk.name !== 'dirt' || blk.boundingBox !== 'block') continue
    if (!b.entity || v.distanceTo(b.entity.position) > 4.2) continue
    await withTimeout(digBlock(b, v), 6000, false)
    await sleep(100)
  }
}
async function tunnelEastLeg (b, xEnd) {
  const p0 = b.entity.position.floored()
  const need = xEnd - p0.x + 1
  let rowY = null; let rowZ = null; let bestLen = -1
  outer:
  for (let y = p0.y; y >= p0.y - 3; y--) {
    for (const dz of [0, -1, 1, -2, 2]) {
      const len = rowSafeLen(b, p0.x, xEnd, y, p0.z + dz)
      if (len > bestLen) { bestLen = len; rowY = y; rowZ = p0.z + dz }
      if (len >= need) break outer
    }
  }
  if (rowY === null || bestLen < need) { log('TUNNEL no safe row: best=' + bestLen + '/' + need + ' at y=' + rowY + ' z=' + rowZ); return false }
  log('TUNNEL row y=' + rowY + ' z=' + rowZ + ' -> x=' + xEnd)
  if (!(await digDownTo(b, rowY))) return false
  let guard = 0
  while (b.entity && b.entity.position.floored().z !== rowZ && guard++ < 4) {
    const ft = b.entity.position.floored()
    const dzs = Math.sign(rowZ - ft.z)
    const a = new Vec3(ft.x, ft.y, ft.z + dzs); const c = new Vec3(ft.x, ft.y + 1, ft.z + dzs)
    if (!cellSafeTunnel(b, a) || !cellSafeTunnel(b, c)) { log('TUNNEL z-align blocked at', pos(b)); return false }
    if (b.blockAt(c) && b.blockAt(c).boundingBox === 'block') await digBlock(b, c)
    if (b.blockAt(a) && b.blockAt(a).boundingBox === 'block') await digBlock(b, a)
    await stepTo(b, 0, dzs, 1300)
  }
  if (!b.entity || b.entity.position.floored().z !== rowZ) return false
  // NOTE: face column = first solid column at/after the bot's LEADING EDGE (x+0.31), not
  // floor(x)+1: straddling the border (x=-602.08 -> floor -603) made the old logic re-dig
  // an already-open column forever while the real wall one cell east went untouched.
  while (b.entity && b.health > 0 && b.entity.position.x < xEnd) {
    const ft = b.entity.position.floored()
    if (ft.y > rowY) { if (!(await digDownTo(b, rowY))) return false; continue }
    if (ft.y < rowY - 1) {
      log('TUNNEL fell to y' + ft.y + ', climbing back to row y' + rowY, pos(b))
      for (let k = 0; k < 4 && b.entity && b.entity.position.floored().y < rowY; k++) { await pillarUp(b, 1); await sleep(250) }
      if (!b.entity || b.entity.position.floored().y < rowY) return false
      continue
    }
    let faceX = Math.floor(b.entity.position.x + 0.31)
    while (faceX <= xEnd + 1) {
      const f0 = b.blockAt(new Vec3(faceX, rowY, rowZ))
      const h0 = b.blockAt(new Vec3(faceX, rowY + 1, rowZ))
      if ((f0 && f0.boundingBox === 'block') || (h0 && h0.boundingBox === 'block')) break
      faceX++
    }
    if (faceX > xEnd + 1) {
      // corridor already open ahead: walk/swim to the end (currents make this slow)
      let walkTries = 0
      while (b.entity && b.health > 0 && b.entity.position.x < xEnd - 0.3 && walkTries++ < 60) {
        await stepTo(b, 1, 0)
        if (Date.now() - (b.__tunLogAt || 0) > 60000) { b.__tunLogAt = Date.now(); log('TUNNEL walk progress', pos(b)) }
      }
      break
    }
    let tries = 0
    let xBefore = b.entity.position.x
    while (b.entity && b.health > 0 && tries++ < 8) {
      const feetV = new Vec3(faceX, rowY, rowZ)
      const headV = new Vec3(faceX, rowY + 1, rowZ)
      const abvV = new Vec3(faceX, rowY + 2, rowZ)
      if (!cellSafeTunnel(b, feetV) || !cellSafeTunnel(b, headV) || cellFlowy(b, abvV)) {
        const hb = b.blockAt(headV); const fb = b.blockAt(feetV)
        log('TUNNEL face unsafe at ' + faceX + ' ' + rowY + ' ' + rowZ + ': feet=' + String(fb && fb.name) + ' head=' + String(hb && hb.name))
        return false
      }
      let dugOk = true
      for (const v of [headV, feetV]) {
        const blk = b.blockAt(v)
        if (!blk || blk.boundingBox !== 'block') continue
        await withTimeout(digBlock(b, v), 16000, false)
        const after = b.blockAt(v)
        if (after && after.boundingBox === 'block') {
          dugOk = false
          log('TUNNEL dig fail at ' + v.x + ' ' + v.y + ' ' + v.z + ' (' + after.name + ') try=' + tries)
          break
        }
      }
      if (!dugOk) { await sleep(500); continue }
      await stepTo(b, 1, 0)
      if (!b.entity) break
      if (b.entity.position.x - xBefore > 0.15) break   // made progress toward/past the face
      xBefore = b.entity.position.x
    }
    const fAfter = b.blockAt(new Vec3(faceX, rowY, rowZ))
    const hAfter = b.blockAt(new Vec3(faceX, rowY + 1, rowZ))
    if ((fAfter && fAfter.boundingBox === 'block') || (hAfter && hAfter.boundingBox === 'block')) {
      log('TUNNEL face wont clear at ' + faceX + ' (server-side protected?) at', pos(b))
      return false
    }
    if (b.entity && b.entity.position.x - xBefore <= 0.15 && b.entity.position.x < faceX - 0.69) { log('TUNNEL column stall at', pos(b), 'face=' + faceX); return false }
    if (Date.now() - (b.__tunLogAt || 0) > 60000) { b.__tunLogAt = Date.now(); log('TUNNEL progress', pos(b)) }
  }
  return !!(b.entity && b.entity.position.x >= xEnd - 0.4)
}
async function climbShaft (b, levels) {
  jumpLockUntil = Math.max(jumpLockUntil, Date.now() + levels * 3200 + 20000)
  manualLockUntil = Math.max(manualLockUntil, Date.now() + levels * 3200 + 20000)
  let noRise = 0
  for (let i = 0; i < levels && b.entity && b.health > 0; i++) {
    if (rimAbove(b) < 2) { log('SHAFT surfaced at', pos(b)); return }
    const ft = b.entity.position.floored()
    let ok = true
    for (const dy of [1, 2]) {
      const v = ft.offset(0, dy, 0)
      const cb = b.blockAt(v)
      if (!cb) { ok = false; break }
      if (cb.boundingBox === 'block') {
        // gravel lenses are diggable (fast, drop material, brief burial is survivable at hp20);
        // sand would flow en masse and suffocate - still a hard abort
        if (!SAFE_TUNNEL.has(cb.name) && cb.name !== 'gravel') { log('SHAFT unsafe above: ' + cb.name, pos(b)); ok = false; break }
        if (!await withTimeout(digBlock(b, v), 14000, false)) { ok = false; break }
        const settled = b.blockAt(v)
        if (settled && settled.boundingBox === 'block' && settled.name === 'gravel') await withTimeout(digBlock(b, v), 8000, false)
      }
    }
    if (!ok) return
    if (countPlaceable(b) < 1) { log('SHAFT no material at', pos(b)); return }
    const yBefore = b.entity.position.y
    await pillarUp(b, 1)
    await sleep(150)
    if (b.entity && b.entity.position.y - yBefore < 0.5) {
      noRise++
      log('SHAFT no rise n=' + noRise, pos(b))
      if (noRise >= 3) return
      await sleep(500)
      i--
      continue
    }
    noRise = 0
    if (Date.now() - (b.__shaftLogAt || 0) > 60000) { b.__shaftLogAt = Date.now(); log('SHAFT climb', pos(b), 'material=' + countPlaceable(b)) }
  }
}
async function pfGoto (b, x, y, z, ms) {
  const tEnd = Date.now() + (ms || 300000)
  const arrived = () => !!(b.entity && Math.abs(b.entity.position.x - x) < 1.4 && Math.abs(b.entity.position.z - z) < 1.4 && b.entity.position.y < y + 1.2 && b.entity.position.y > y - 8)
  let fails = 0
  while (b.entity && b.health > 0 && Date.now() < tEnd && !arrived()) {
    const t0 = Date.now()
    try { await withTimeout(b.pathfinder.goto(new goals.GoalBlock(x, y, z)), Math.min(45000, Math.max(5000, tEnd - Date.now())), 'to') } catch (e) {}
    if (!b.entity || arrived()) break
    const took = Date.now() - t0
    fails = took < 3000 ? fails + 1 : 0
    if (fails > 6) { log('PF_GOTO no-path giving up at', pos(b)); break }
    log('PF_GOTO partial at', pos(b))
    await sleep(took < 3000 ? 3000 : 400)
  }
  try { b.pathfinder.setGoal(null) } catch (e) {}
  return arrived()
}
async function tunnelEast (b) {
  if (NO_DIG) { log('TUNNEL skipped: digging disabled by owner'); return }
  if (tunneling || diggingUp || !b.entity) return
  const POCKET = { x: -609, y: 36, z: -654 }
  const EXIT_X = -601
  if (Math.hypot(b.entity.position.x - POCKET.x, b.entity.position.z - POCKET.z) > 40) { log('TUNNEL too far from pocket at', pos(b)); return }
  tunneling = true; diggingUp = true
  try { b.pathfinder.setGoal(null) } catch (e) {}
  stopDrive(b)
  const lockMs = () => { jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 900000); manualLockUntil = Math.max(manualLockUntil, Date.now() + 900000) }
  lockMs()
  try {
    log('TUNNEL start at', pos(b), 'rim=' + rimAbove(b) + ' material=' + countPlaceable(b))
    // AuthMe freezes movement until login completes (the early tunnel stalls were pre-login
    // freeze): wait for the auth confirm.
    let authWait = 0
    while (b.entity && !b.__authOk && authWait++ < 24) await sleep(5000)
    if (!b.entity) return
    if (!b.__authOk) { log('TUNNEL abort: no auth confirm at', pos(b)); return }
    await sleep(3000)
    if (!b.entity) return
    lockMs()
    // PHASE 1 - pillar material.
    // In the crater: harvest open-sky sand first (fast, no travel).
    if (countPlaceable(b) < 12 && inCollapseZone(b)) {
      await harvestSurface(b, 16)
      log('TUNNEL sand harvest material=' + countPlaceable(b), pos(b))
      lockMs()
    }
    // Otherwise (or not enough): the dirt pockets under the stable step (-606..-609, y34-38).
    if (countPlaceable(b) < 12) {
      if (!b.entity) return
      // line up on the pocket z-lane before any leg/digdown so we descend ONTO the pockets
      if (Math.abs(b.entity.position.z + 654) > 3) {
        await pfGoto(b, Math.round(b.entity.position.x), Math.round(b.entity.position.y), -654, 90000)
        if (!b.entity) return
      }
      if (b.entity.position.x < -609.5) {
        if (!(await tunnelEastLeg(b, -609))) { log('TUNNEL abort leg1 at', pos(b)); return }
      } else if (b.entity.position.x > -605.5) {
        if (!(await pfGoto(b, -609, 36, -654, 300000))) { log('TUNNEL abort: walk west at', pos(b)); return }
      }
      lockMs()
      if (!b.entity) return
      if (b.entity.position.floored().y > 36) {
        if (!(await digDownTo(b, 36))) { log('TUNNEL abort digdown at', pos(b)); return }
      }
      await minePocket(b, 16)
      log('TUNNEL pocket material=' + countPlaceable(b), pos(b))
      if (countPlaceable(b) < 6) { log('TUNNEL abort: pocket too poor'); return }
      lockMs()
    } else {
      log('TUNNEL material rich (' + countPlaceable(b) + ') at', pos(b))
    }
    if (!b.entity) return
    // surfacing at night = endermen/skeletons on the rim: wait it out underground
    let nightWait = 0
    while (b.entity && (isNight(b) || isDusk(b)) && nightWait++ < 60) {
      if (nightWait === 1) log('TUNNEL night - waiting underground before surfacing')
      // a player may have teleported us out mid-run (happened: MrCeldou /tp to -402 108)
      if (!deepNearCrater(b) && !inCollapseZone(b) && rimAbove(b) < 5) { log('TUNNEL relocated (teleport?), aborting at', pos(b)); wallNiche = null; return }
      await sleep(20000); lockMs()
    }
    if (!b.entity) return
    if (!deepNearCrater(b) && !inCollapseZone(b) && rimAbove(b) < 5) { log('TUNNEL relocated before climb at', pos(b)); wallNiche = null; return }
    // PHASE 2 - climb straight up from the pocket (x=-609, dx=9 from spawn: server accepts
    // digs here again; the flooded east corridor to -601 was unwalkable against the current).
    // Stone y36-49 eats ~14 placements, the dirt layer y50+ resupplies (2 drops per level).
    for (let attempt = 0; attempt < 3 && b.entity && b.health > 0; attempt++) {
      const need = Math.max(rimAbove(b) + 2, 64 - Math.round(b.entity.position.y))
      log('TUNNEL climb attempt=' + attempt + ' need=' + need + ' material=' + countPlaceable(b), pos(b))
      await climbShaft(b, need)
      lockMs()
      if (!b.entity || rimAbove(b) < 3) break
      if (attempt < 2) {
        log('TUNNEL climb blocked, shifting east at', pos(b))
        if (!(await tunnelEastLeg(b, Math.round(b.entity.position.x) + 2))) break
        lockMs()
      }
    }
    if (b.entity && rimAbove(b) < 3) { log('TUNNEL OUT at', pos(b)); wallNiche = null }
    else log('TUNNEL incomplete rim=' + rimAbove(b), pos(b))
  } catch (e) { log('TUNNEL_ERR', e && e.message) }
  finally { tunneling = false; diggingUp = false }
}
// Respawned at/near the mob nest: RUNNING through the den is a proven death spiral
// (10+ deaths a night). Dig 2 down, seal overhead, let the mobs lose interest (~30s
// without LOS), regen, then dig out. Zombies can't dig, skeletons need LOS.
async function buryAtSpawn (b) {
  if (!b.entity) return false
  // digging at spawn = digging into the hourglass: skip bury, let RESPAWN_RUN sprint east
  if (inCollapseZone(b)) { log('BURY skip: collapse zone at', pos(b)); return false }
  b.__burying = true
  try {
    manualLockUntil = Math.max(manualLockUntil, Date.now() + 90000)
    jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 90000)
    try { b.pathfinder.setGoal(null) } catch (e) {}
    try { b.clearControlStates() } catch (e) {}
    // bury owns movement from here on: reflex may have set __fleeing pre-respawn,
    // and escapeIsland breaks instantly on that flag - do our own forced swim
    b.__fleeing = false
    // chunks may not be loaded yet at respawn: blockAt() returns null everywhere,
    // dryCol/nearestDry find "no dry land" and we drown on a shore we can't see.
    // wait for the world before digging or swimming.
    for (let w = 0; w < 30; w++) {
      if (!b.entity || b.health <= 0) return false
      if (b.blockAt(b.entity.position.floored().offset(0, -1, 0))) break
      await sleep(200)
    }
    let feet = b.entity.position.floored()
    let below = b.blockAt(feet.offset(0, -1, 0))
    if (!below || below.boundingBox !== 'block' || b.entity.isInWater) {
      // spawn point sits in shallow water - can't dig liquid: swim ashore first
      let dry = null; try { dry = nearestDry(b, 24) } catch (e) {}
      log('BURY wet spawn -> swim ashore at', pos(b), dry ? ('dry=' + Math.round(dry.x) + ' ' + Math.round(dry.z)) : 'no dry near')
      // being shot at while swimming = death spiral: skip the swim, wall-burrow immediately
      let shotAt = false
      try { const wt = threatsNear(b, 1.0)[0]; shotAt = !!(wt && wt.d < 14) } catch (e) {}
      if (shotAt) { log('BURY under fire -> wallBury now'); if (await wallBury(b, 70000)) return true }
      if (dry && !shotAt) {
        const t0 = Date.now()
        try { b.setControlState('forward', true); b.setControlState('jump', true) } catch (e) {}
        while (Date.now() - t0 < 5000 && b.entity && b.health > 0) {
          if (b.__wallBury) break                          // wallBury took over: don't fight its controls
          try { await b.look(Math.atan2(-(dry.x + 0.5 - b.entity.position.x), dry.z + 0.5 - b.entity.position.z), -0.15, true) } catch (e) {}
          await sleep(300)
          const ft = b.entity.position.floored()
          const bl = b.blockAt(ft.offset(0, -1, 0))
          if (b.entity.onGround && bl && bl.boundingBox === 'block' && !b.entity.isInWater) break
        }
        try { b.setControlState('forward', false); b.setControlState('jump', false) } catch (e) {}
      }
      if (!b.entity || b.health <= 0) return false
      feet = b.entity.position.floored()
      below = b.blockAt(feet.offset(0, -1, 0))
      if (!below || below.boundingBox !== 'block' || b.entity.isInWater) {
        // trench killbox: wall-burrow FIRST (swimming ashore gets us shot to death),
        // pillar escape only if no soft wall is reachable
        if (b.__wallBury) { await sleep(2000); return true }
        if (await wallBury(b, 70000)) return true
        await escapeWaterPillar(b)                      // cove shore is often a 1b ledge we can't climb
        if (!b.entity || b.health <= 0) return false
        feet = b.entity.position.floored()
        below = b.blockAt(feet.offset(0, -1, 0))
        if (!below || below.boundingBox !== 'block' || b.entity.isInWater) { log('BURY still wet, sprint fallback'); return false }
      }
    }
    const ok1 = await withTimeout(digBlock(b, feet.offset(0, -1, 0)), 10000, false)
    if (!ok1 || !b.entity) {
      // trench floor is STONE (slow, dig times out) but the walls are SAND:
      // burrow sideways, seal, sleep out the night - sprinting above ground at night got us endermaned
      log('BURY dig failed -> wallBury')
      if (b.entity && b.health > 0 && await wallBury(b, 90000)) return true
      log('BURY wallBury failed, falling back to sprint')
      return false
    }
    await sleep(280)
    await withTimeout(digBlock(b, feet.offset(0, -2, 0)), 10000, false)
    await sleep(280)
    // seal the cell above our head (the original feet cell) against a side wall
    let sealed = false
    for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const wall = b.blockAt(new Vec3(feet.x + d[0], feet.y, feet.z + d[1]))
      if (wall && wall.boundingBox === 'block' && countPlaceable(b) >= 1) {
        const r = await withTimeout(b.placeBlock(wall, new Vec3(-d[0], 0, -d[1])), 4000, 'to')
        if (r !== 'to') { sealed = true; break }
      }
    }
    log('BURY sealed=' + sealed + ' at', pos(b), 'hp=' + Math.round(b.health))
    const t0 = Date.now()
    while (Date.now() - t0 < 70000 && b.entity && b.health > 0) await sleep(1000)
    if (!b.entity || b.health <= 0) return true            // died waiting: next respawn cycle takes over
    await digUpAndOut(b, 6)
    manualLockUntil = Math.min(manualLockUntil, Date.now() + 1500)
    jumpLockUntil = Math.min(jumpLockUntil, Date.now() + 1500)
    return true
  } catch (e) { log('BURY_ERR', e && e.message); return false }
  finally { b.__burying = false }
}
async function escapeIsland (b) {
  if (!b.entity) return
  log('ISLAND_ESCAPE at', pos(b))
  try { b.pathfinder.setGoal(null) } catch (e) {}
  jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 9000)
  let dry = null
  try { dry = nearestDry(b, 20) } catch (e) {}
  if (!dry && b.__lastDry && Date.now() - b.__lastDry.t < 300000) dry = { x: b.__lastDry.x, y: b.__lastDry.y, z: b.__lastDry.z }
  let yaw
  if (dry) yaw = Math.atan2(-(dry.x + 0.5 - b.entity.position.x), dry.z + 0.5 - b.entity.position.z)
  else { const a = Math.random() * Math.PI * 2; yaw = Math.atan2(-Math.cos(a), Math.sin(a)) }
  log('ISLAND_ESCAPE heading ' + (dry ? ('to dry ' + dry.x + ' ' + dry.y + ' ' + dry.z) : 'random swim'))
  try { b.look(yaw, dry ? -0.15 : 0.1, true) } catch (e) {}
  try { b.setControlState('forward', true); b.setControlState('sprint', true); b.setControlState('jump', true) } catch (e) {}
  const t0 = Date.now()
  while (Date.now() - t0 < 8000 && b.entity && b.health > 0 && !b.__fleeing) {
    await sleep(300)
    if (dry && b.entity) {
      const d = Math.hypot(dry.x + 0.5 - b.entity.position.x, dry.z + 0.5 - b.entity.position.z)
      if (d < 1.3) break
    }
    // keep looking straight ahead while swimming; re-aim at dry land periodically
    if (dry && b.entity && (Date.now() - t0) % 1500 < 300) { try { b.look(Math.atan2(-(dry.x + 0.5 - b.entity.position.x), dry.z + 0.5 - b.entity.position.z), -0.15, true) } catch (e) {} }
  }
  try { b.setControlState('forward', false); b.setControlState('sprint', false); b.setControlState('jump', false) } catch (e) {}
}
function enclosedHere (b) {
  if (!b.entity) return false
  const feet = b.entity.position.floored()
  return solidAt(b, feet.offset(1, 0, 0)) && solidAt(b, feet.offset(-1, 0, 0)) &&
         solidAt(b, feet.offset(0, 0, 1)) && solidAt(b, feet.offset(0, 0, -1))
}
// Travel WITHOUT wrecking the terrain: greedy stepping-stones -> XZ-only retry -> side
// bypasses. Digging happens only when physically enclosed (and is capped).
async function travelTo (b, target, tries) {
  tries = tries || 40
  // cliff-top target (plateau wall): the gentle side is elsewhere - fail fast and let
  // the blacklist/explore drift relocate us instead of burning the full budget here
  let dy0 = 0; try { dy0 = target.y - b.entity.position.y } catch (e) {}
  const tEnd = Date.now() + (dy0 > 10 ? 50000 : 90000)
  let failStreak = 0
  let zeroStreak = 0
  let digs = 0
  let fleeWaits = 0
  let climbed = false
  for (let i = 0; i < tries && mission && b.entity && b.health > 0 && Date.now() < tEnd; i++) {
    if (b.__fleeing || hiding) {                       // under attack: survival first, don't fight the flee goal
      if (++fleeWaits > 75) { log('TRAVEL abort: under attack at', pos(b)); return false }
      await sleep(400)
      i--
      continue
    }
    fleeWaits = 0
    const p = b.entity.position
    if (p.distanceTo(target) < 4) return true
    const dx = target.x - p.x; const dz = target.z - p.z
    const flat = Math.hypot(dx, dz) || 1
    let goal
    if (flat <= 14) goal = new goals.GoalNear(target.x, target.y, target.z, 2)
    else { const s = Math.min(12, flat * 0.6); goal = new goals.GoalXZ(Math.round(p.x + dx / flat * s), Math.round(p.z + dz / flat * s)) }
    const r = await gotoT(b, goal, 16000)
    if (!b.entity) break
    if (b.entity.position.distanceTo(target) < 4.5) return true
    const moved = p.distanceTo(b.entity.position)
    if (moved > 1.5) { failStreak = 0; zeroStreak = 0; continue }
    failStreak++
    if (moved < 0.5) zeroStreak++; else zeroStreak = 0
    log('TRAVEL ' + r + ' moved=' + moved.toFixed(1) + ' failStreak=' + failStreak + ' at', pos(b))
    if (zeroStreak >= 3) { zeroStreak = 0; failStreak = 0; await escapeIsland(b); continue }
    if (enclosedHere(b) || rimAbove(b) >= 3) {
      if (digs++ >= 3) { log('TRAVEL give up: walled in at', pos(b)); return false }
      log('TRAVEL enclosed -> dig out at', pos(b))
      await withTimeout(digUpAndOut(b, 6), 40000, null)
      failStreak = 0
      continue
    }
    if (failStreak === 1) {
      // maybe only the target's Y is unreachable - walk to its column and look around
      const r2 = await gotoT(b, new goals.GoalXZ(Math.round(target.x), Math.round(target.z)), 12000)
      if (b.entity && b.entity.position.distanceTo(target) < 6) return true
      if (r2 === 'reached' && failStreak === 1) failStreak = 2
      continue
    }
    // target sits up a slope/cliff and pathing keeps failing: do what a player does -
    // dig scaffold material and pillar up toward it (once per travelTo, budget-capped)
    if (failStreak >= 2 && !climbed && target.y - p.y >= 3 && target.y - p.y <= 14) {
      climbed = true
      const need = Math.min(12, Math.ceil(target.y - p.y) + 2)
      log('TRAVEL climb: target ' + Math.round(target.y - p.y) + 'b above at', pos(b))
      await ensurePlaceable(b, need)
      if (countPlaceable(b) < 1) { log('TRAVEL climb: no material at', pos(b)); failStreak = 0; zeroStreak = 0; continue }
      try { await b.look(Math.atan2(-(target.x - p.x), target.z - p.z), 0, true) } catch (e) {}
      const y0 = b.entity ? b.entity.position.y : 0
      for (let k = 0; k < need && mission && b.entity && b.health > 0 && !b.__fleeing && b.entity.position.y < target.y - 1.5; k++) {
        await pillarUp(b, 1)
        await sleep(250)
      }
      log('TRAVEL climb done: +' + (b.entity ? (b.entity.position.y - y0).toFixed(1) : '?') + 'b at', pos(b))
      failStreak = 0; zeroStreak = 0
      continue
    }
    // bypass: waypoint 10 blocks to the side of the direct line, alternate sides
    const side = (failStreak % 2 === 0) ? 1 : -1
    const px = -dz / flat; const pz = dx / flat
    const wx = Math.round(p.x + dx / flat * 3 + px * 10 * side)
    const wz = Math.round(p.z + dz / flat * 3 + pz * 10 * side)
    log('TRAVEL blocked -> bypass ' + (side > 0 ? 'right' : 'left') + ' via ' + wx + ' ' + wz + ' at', pos(b))
    await gotoT(b, new goals.GoalXZ(wx, wz), 12000)
    if (failStreak >= 4) failStreak = 2   // keep alternating bypasses, never escalate to digging
  }
  return b.entity ? b.entity.position.distanceTo(target) < 6 : false
}
async function wander (b, far) {
  let angle
  if (far) { if (b.__heading === undefined || Math.random() < 0.12) b.__heading = Math.random() * Math.PI * 2; angle = b.__heading } else { angle = Math.random() * Math.PI * 2 }
  for (let attempt = 0; attempt < 3; attempt++) {
    let fw = 0
    while ((b.__fleeing || hiding) && fw++ < 75 && b.entity && b.health > 0) await sleep(400)
    if (!b.entity || b.health <= 0) return false
    const dist = far ? (30 + Math.random() * 16) : (12 + Math.random() * 8)
    let gx = 0; let gz = 0; let ok = false
    for (let t = 0; t < 8; t++) {
      gx = Math.round(b.entity.position.x + Math.cos(angle) * dist)
      gz = Math.round(b.entity.position.z + Math.sin(angle) * dist)
      if (!isWaterAt(b, gx, gz)) { ok = true; break }
      angle += Math.PI / 3
    }
    if (!ok) { angle += 2.1; continue }
    // NOTE: no manualLockUntil here - it used to suppress the flee/defend reflexes
    // for the whole wander, and the bot ate arrows face-first while "exploring".
    try { b.pathfinder.setGoal(null) } catch (e) {}
    const before = b.entity ? b.entity.position.clone() : null
    const r = await gotoT(b, new goals.GoalXZ(gx, gz), far ? 22000 : 15000)
    const moved = (before && b.entity) ? before.distanceTo(b.entity.position) : 99
    if (moved > 2.5) { if (far) b.__heading = angle; return true }
    log('WANDER ' + r + ' moved=' + moved.toFixed(1) + ' -> turn, at', pos(b))
    angle += 2.1                       // walked into something: pick a new direction
    if (far) b.__heading = angle
  }
  await escapeIsland(b)                // every direction failed: swim out of wherever we are
  return false
}
async function missionWood (b) {
  if (NO_DIG) return
  log('MISSION wood START at', pos(b))
  try {
    await autoFree(b)
    let target = null
    let guard = 0
    let unreachable = 0
    const skipped = new Set()
    while (mission && guard++ < 24) {
      target = findNearestLog(b, 64, skipped)
      if (!target) target = findNearestLog(b, 64, skipped, true)
      if (target) {
        const key = target.x + ',' + target.y + ',' + target.z
        log('WOOD logs at', target.x, target.y, target.z, 'dist', Math.round(b.entity.position.distanceTo(target)))
        const reached = await travelTo(b, target)
        log('WOOD reached', reached, 'at', pos(b))
        if (reached) break
        // could not walk there: blacklist this trunk and look for another one instead of digging
        skipped.add(key); unreachable++
        log('WOOD trunk unreachable (' + unreachable + ' skipped), looking for another')
        if (unreachable >= 4) { log('WOOD no reachable trunk around'); missionFail('wood'); mission = null; return }
        target = null
        continue
      }
      const far = guard > 4
      if (!far && worstZone(b, 60)) {
        // standing in the nest corridor: relocate before scanning for trunks again
        const ep = escapePointFrom(b, worstZone(b, 60), 70)
        if (ep) { log('WOOD leaving death zone via ' + ep.x + ' ' + ep.z, 'at', pos(b)); await travelTo(b, new Vec3(ep.x, b.entity.position.y, ep.z), 10); continue }
      }
      log('WOOD exploring' + (far ? ' far' : '') + ' at', pos(b))
      const before = b.entity.position.clone()
      const moved = await wander(b, far)
      if (!moved && enclosedHere(b)) { log('WOOD enclosed -> escape'); await escapeStuck(b) }
      try { await autoFree(b) } catch (e) {}
    }
    if (!target) { log('WOOD no logs found after exploring'); missionFail('wood'); mission = null; return }
    const blk = b.blockAt(target)
    const logType = (blk && blk.name) || 'oak_log'
    // we stand within 4b of the base log now: break it DIRECTLY first - gatherBlocks'
    // findBlocks reported "none nearby" while literally on the trunk (lost the whole trip)
    if (blk && LOG_TYPES.indexOf(blk.name) >= 0) { await digBlock(b, target); await sleep(400) }
    await gatherBlocks(b, [logType], logType, 8)
    log('WOOD logs gathered', countItem(b, logType), logType)
    const plankType = logType.endsWith('_stem') ? logType.replace('_stem', '_planks') : logType.replace('_log', '_planks')
    // craft(recipe, N) runs the recipe N TIMES (planks: 1 log -> 4 per run), so
    // N must be grounded in what we actually hold, else 'missing ingredient'
    const nl = countItem(b, logType)
    if (nl > 0) await craftItem(b, plankType, nl)
    let pl = countAny(b, PLANKS_ANY)
    if (pl >= 4) await craftItem(b, 'crafting_table', 1)
    pl = countAny(b, PLANKS_ANY)
    if (pl >= 2) await craftItem(b, 'stick', Math.min(2, Math.floor(pl / 2)))
    const o = b.entity.position.floored()
    let placed = false
    for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1]]) {
      if (await placeBlockAt(b, o.x + d[0], o.y, o.z + d[1], 'crafting_table')) { placed = true; break }
    }
    // placeBlockAt returns true when the cell was ALREADY solid - verify the table really exists
    try {
      const ct = mcData.blocksByName.crafting_table
      if (ct) placed = !!b.findBlock({ matching: ct.id, maxDistance: 6 })
    } catch (e) {}
    log('WOOD table placed', placed)
    if (placed) {
      await craftItem(b, 'wooden_pickaxe', 1)
      await craftItem(b, 'wooden_axe', 1)
      await craftItem(b, 'wooden_sword', 1)
    }
    log('WOOD DONE pickaxe', countItem(b, 'wooden_pickaxe'), 'axe', countItem(b, 'wooden_axe'), 'sword', countItem(b, 'wooden_sword'), 'at', pos(b))
  } catch (e) { log('WOOD_ERR', e && e.message ? e.message : String(e)) }
  mission = null
}

const PASSIVE = new Set(['cow', 'pig', 'sheep', 'chicken', 'rabbit', 'mooshroom', 'goat'])
const PICKS = ['netherite_pickaxe', 'diamond_pickaxe', 'iron_pickaxe', 'stone_pickaxe', 'golden_pickaxe', 'wooden_pickaxe']
const PLANKS_ANY = ['oak_planks', 'birch_planks', 'spruce_planks', 'jungle_planks', 'acacia_planks', 'dark_oak_planks', 'mangrove_planks', 'cherry_planks']
function countAny (b, names) { let n = 0; for (const nm of names) n += countItem(b, nm); return n }
function hasPickaxe (b) { return countAny(b, PICKS) > 0 }
function hasStonePick (b) { return countAny(b, ['stone_pickaxe', 'iron_pickaxe', 'diamond_pickaxe', 'netherite_pickaxe']) > 0 }
function countFood (b) { return countAny(b, FOODS) }
// NOTE: b.time.day is the DAY COUNTER (0,1,2,...851), b.time.age is total ticks.
// Using .day here made isNight() always false (851 % 24000 = 851 = "morning") -
// the bot never knew it was night and ran wood missions straight into the dark.
function timeOfDay (b) { try { const a = Math.floor(b.time.age); return ((a % 24000) + 24000) % 24000 } catch (e) { return 6000 } }
function isNight (b) { const t = timeOfDay(b); return t >= 13000 && t < 23500 }
function isDusk (b) { const t = timeOfDay(b); return t >= 11500 && t < 13000 }
function nearestPassive (b, r) {
  let best = null; let bd = r
  for (const id in b.entities) {
    const e = b.entities[id]
    if (!e || !e.position || !e.name || e === b.entity) continue
    if (!PASSIVE.has(String(e.name).toLowerCase())) continue
    if (e.health !== undefined && e.health <= 0) continue
    const d = e.position.distanceTo(b.entity.position)
    if (d < bd) { bd = d; best = e }
  }
  return best
}
function findNearestBlock (b, names, r) {
  const ids = names.map(n => mcData.blocksByName[n]).filter(Boolean).map(x => x.id)
  if (!ids.length) return null
  let positions = []
  try { positions = b.findBlocks({ matching: ids, maxDistance: r, count: 24 }) } catch (e) {}
  if (!positions || !positions.length) return null
  const feet = b.entity.position
  positions.sort((p, q) => feet.distanceTo(p) - feet.distanceTo(q))
  return positions[0]
}
async function missionStone (b) {
  log('MISSION stone START at', pos(b))
  try {
    await autoFree(b)
    if (!hasPickaxe(b)) { log('STONE need pickaxe first'); mission = null; return }
    if (countItem(b, 'stick') < 2 && countAny(b, PLANKS_ANY) >= 2) await craftItem(b, 'stick', 4)
    let target = null; let guard = 0
    while (mission && guard++ < 20) {
      target = findNearestBlock(b, ['stone', 'cobblestone', 'deepslate', 'cobbled_deepslate', 'andesite', 'diorite', 'granite'], 48)
      if (target) break
      const far = guard > 4
      log('STONE exploring' + (far ? ' far' : '') + ' at', pos(b))
      const moved = await wander(b, far)
      if (!moved && enclosedHere(b)) await escapeStuck(b)
      try { await autoFree(b) } catch (e) {}
    }
    if (!target) { log('STONE no stone found'); mission = null; return }
    await travelTo(b, target)
    await gatherBlocks(b, ['stone', 'cobblestone', 'deepslate', 'cobbled_deepslate', 'andesite', 'diorite', 'granite'], 'cobblestone', 12)
    const cob = countItem(b, 'cobblestone')
    if (cob >= 2) {
      if (countItem(b, 'stick') < 2) { const pl = PLANKS_ANY.find(n => countItem(b, n) > 1); if (pl) await craftItem(b, 'stick', 4) }
      await ensureCraftingTable(b)
      await craftItem(b, 'stone_pickaxe', 1)
      await craftItem(b, 'stone_sword', 1)
      await craftItem(b, 'stone_axe', 1)
    }
    log('MISSION stone DONE cob', cob, 'pick', countItem(b, 'stone_pickaxe'), 'at', pos(b))
    if (countItem(b, 'stone_pickaxe') === 0) { missionFail('stone'); log('STONE pick missing - backoff 45s') }
  } catch (e) { log('STONE_ERR', e && e.message ? e.message : String(e)) }
  mission = null
}
async function missionFood (b) {
  log('MISSION food START at', pos(b))
  try {
    await autoFree(b)
    const bush = findNearestBlock(b, ['sweet_berry_bush'], 40)
    if (bush && mission) { const rb = await travelTo(b, bush); if (rb) await gatherBlocks(b, ['sweet_berry_bush'], 'sweet_berries', 8) }
    if (countFood(b) >= 6) { log('MISSION food DONE berries', countFood(b)); mission = null; return }
    let guard = 0
    while (mission && guard++ < 20) {
      const a = nearestPassive(b, 40)
      if (!a) { const moved = await wander(b, guard > 3); if (!moved && enclosedHere(b)) await escapeStuck(b); continue }
      await travelTo(b, a.position)
      let tries = 0
      while (mission && tries++ < 30 && a.position && a.isValid !== false) {
        if (a.health !== undefined && a.health <= 0) break
        try { b.lookAt(a.position.offset(0, 0.6, 0)) } catch (e) {}
        try { b.attack(a) } catch (e) {}
        if (a.position.distanceTo(b.entity.position) > 2.6) { try { b.pathfinder.setGoal(new goals.GoalNear(a.position.x, a.position.y, a.position.z, 2)) } catch (e) {} }
        await sleep(340)
      }
      try { b.pathfinder.setGoal(null) } catch (e) {}
      await sleep(1200)
      if (countFood(b) >= 6) break
    }
    log('MISSION food DONE', countFood(b))
  } catch (e) { log('FOOD_ERR', e && e.message ? e.message : String(e)) }
  mission = null
}
async function missionExplore (b) {
  log('MISSION explore START at', pos(b))
  try {
    await autoFree(b)
    // standing in a death zone (nest corridor / recent deaths)? leave it FIRST -
    // aimless wandering inside the zone is how we racked up 15+ deaths a night
    const zc = worstZone(b, 70)
    if (zc && mission && b.entity) {
      const ep = escapePointFrom(b, zc, 75)
      if (ep) {
        log('EXPLORE leaving death zone via ' + ep.x + ' ' + ep.z, 'at', pos(b))
        await travelTo(b, new Vec3(ep.x, b.entity.position.y, ep.z), 10)
      }
    }
    for (let i = 0; i < 3 && mission; i++) { await wander(b); try { await autoFree(b) } catch (e) {} }
  } catch (e) {}
  log('MISSION explore END')
  mission = null
}
let directorOn = true
if (process.env.MC_DIRECTOR === 'off') directorOn = false
async function directorTick (b) {
  try {
    if (!directorOn) return
    if (!b.entity || b.health <= 0) return
    if (mission) { if (Date.now() - (b.__dirLog||0) > 10000) { log("DIR_BLOCK mission=" + mission.name); b.__dirLog = Date.now() } return }
    if (b.__fleeing || hiding) { if (Date.now() - (b.__dirLog||0) > 10000) { log("DIR_BLOCK fleeing=" + !!b.__fleeing + " hiding=" + !!hiding); b.__dirLog = Date.now() } return }
    if (Date.now() < cautionUntil) { if (Date.now() - (b.__dirLog||0) > 10000) { log("DIR_BLOCK caution=" + Math.round((cautionUntil - Date.now())/1000) + "s"); b.__dirLog = Date.now() } return }
    if (Date.now() < manualLockUntil) { if (Date.now() - (b.__dirLog||0) > 10000) { log("DIR_BLOCK lock=" + Math.round((manualLockUntil - Date.now())/1000) + "s"); b.__dirLog = Date.now() } return }
    let moving = false; try { moving = b.pathfinder.isMoving() } catch (e) {}
    if (moving) return
    if (unstickBusy) { if (Date.now() - (b.__dirLog||0) > 10000) { log("DIR_BLOCK unstickBusy"); b.__dirLog = Date.now() } return }
    if (threatsNear(b, 0.7).length) { if (Date.now() - (b.__dirLog||0) > 10000) { log("DIR_BLOCK threats=" + threatsNear(b,0.7).length); b.__dirLog = Date.now() } return }                      // no new missions with a real threat on us
    if (b.health < 18 && b.food < 20 && countFood(b) > 0) { await eatFood(b); return }
    // --- anti-starvation outranks tool-making ---
    // wheat is not edible raw, but 3 wheat = 1 bread (needs a crafting table within 5b)
    if (b.food < 17 && countItem(b, 'wheat') >= 3) await craftItem(b, 'bread', Math.min(Math.floor(countItem(b, 'wheat') / 3), 3))
    if (b.food < 16 && countFood(b) > 0) { await eatFood(b); return }
    if (b.food <= 6 && countFood(b) === 0) {
      // last resort: junk food beats starving to death in a loop
      const junk = b.inventory.items().find(i => i.name === 'rotten_flesh' || i.name === 'spider_eye' || i.name === 'poisonous_potato')
      if (junk) {
        try { await b.equip(junk, 'hand'); await b.consume(); log('ATE emergency', junk.name, 'food=' + Math.round(b.food)); return } catch (e) {}
      }
      if (missionAllowed('food') && !isNight(b) && !isDusk(b)) { startMission(b, 'food'); return }
    }
    // near-death or critically hungry with nothing edible in inv: food mission beats tools
    if ((b.health < 8 || b.food < 10) && countFood(b) === 0 && !isNight(b) && !isDusk(b)) {
      if (missionAllowed('food')) { startMission(b, 'food'); return }
      if (missionAllowed('explore')) { startMission(b, 'explore'); return }
      return
    }
    equipArmor(b)
    if (rimAbove(b) >= 3) {
      if (inCollapseZone(b) || deepNearCrater(b)) { if (Date.now() - (b.__craterLogAt || 0) > 120000) { b.__craterLogAt = Date.now(); log('CRATER hold at', pos(b), 'rim=' + rimAbove(b) + ' material=' + countPlaceable(b)) } await craterHold(b); return }
      log('DIRECTOR in hole -> escape at', pos(b)); await digUpAndOut(b, 8); return
    }
    // 0) gearless at night: sealed pocket till dawn FIRST - the tool grind can wait,
    //    the wood mission kept routing back through the spawn nest after dark
    if ((isNight(b) || isDusk(b)) && !hasWeapon(b)) { startMission(b, 'shelter'); return }
    // 1) tools first - a wooden pickaxe+sword unlocks everything else
    if (!hasPickaxe(b) || !hasWeapon(b)) {
      if (missionAllowed('wood')) { startMission(b, 'wood'); return }
      if (missionAllowed('explore')) { startMission(b, 'explore'); return }
      return
    }
    // 2) stone upgrade
    if (!hasStonePick(b)) {
      if (missionAllowed('stone')) { startMission(b, 'stone'); return }
      if (missionAllowed('wood')) { startMission(b, 'wood'); return }
      return
    }
    // 3) night -> shelter
    const day = Math.floor((b.time && b.time.age ? b.time.age : 0) / 24000)
    if ((isNight(b) || isDusk(b)) && b.__shelterDay !== day) { b.__shelterDay = day; startMission(b, 'shelter'); return }
    // 4) hungry -> food
    if (b.food < 15 || (b.health < 16 && countFood(b) === 0)) {
      if (missionAllowed('food')) { startMission(b, 'food'); return }
      if (missionAllowed('explore')) { startMission(b, 'explore'); return }
      return
    }
    // 5) otherwise explore / develop
    startMission(b, missionAllowed('explore') ? 'explore' : (missionAllowed('shelter') ? 'shelter' : 'gather'))
  } catch (e) { log('DIRECTOR_ERR', e && e.message ? e.message : String(e)) }
}
function startDirector (b) {
  if (b.__director) { clearInterval(b.__director); b.__director = null }
  if (!directorOn) { log('DIRECTOR off'); return }
  b.__director = setInterval(() => { directorTick(b) }, 4000)
  log('DIRECTOR on')
}
function startMission (b, name, arg1, arg2) {
  mission = { name }
  stats.missions++
  log('DIRECTOR picked', name, 'hp=' + Math.round(b.health), 'food=' + Math.round(b.food))
  if (name === 'shelter') { missionShelter(b); return 'shelter' }
  if (name === 'wood') { missionWood(b); return 'wood' }
  if (name === 'stone') { missionStone(b); return 'stone' }
  if (name === 'food') { missionFood(b); return 'food' }
  if (name === 'explore') { missionExplore(b); return 'explore' }
  if (name === 'gather') { missionGather(b, arg1 || 'dirt', parseInt(arg2 || '32', 10)); return 'gather ' + arg1 }
  mission = null
  return null
}

async function handle (raw, sock) {
  const parts = raw.split(/\s+/)
  const cmd = (parts[0] || '').toLowerCase()
  const args = parts.slice(1)
  const b = bot
  try {
    if (cmd === 'help') {
      return respond(sock, 'commands: mission <shelter|wood|gather <block> <n>|stop> status pos goto <x y z> follow <player> break <x y z> collect <name> [n] craft <item> [n] placeat <x y z> [item] find <block> [r] [n] fight [secs] [radius] mobs [r] eat lookat <name> look <yaw> <pitch> chat <msg> reflex <on|off> free stop window click <slot> [left|right] [mode] clickitem <name> inventory equip <item> drop <item> [n] quit')
    }
    if (!b || !b.entity) return respond(sock, 'ERR bot not spawned yet')

    if (cmd === 'status' || cmd === 'pos') {
      return respond(sock, 'pos=' + pos(b) + ' alive=' + b.isAlive + ' hp=' + Math.round(b.health) + ' food=' + Math.round(b.food) + ' yaw=' + b.entity.yaw.toFixed(2) + ' time=' + (b.time ? b.time.day : '?') + ' dim=' + (b.game ? b.game.dimension : '?') + ' srv=' + (b.__srvPos ? (b.__srvPos.x.toFixed(1) + ',' + b.__srvPos.y.toFixed(1) + ',' + b.__srvPos.z.toFixed(1) + '@' + Math.round((Date.now() - b.__srvPos.t) / 1000) + 's') : '?') + ' drive=' + (b.__drive ? 'on' : 'off') + ' lock=' + Math.max(0, Math.round((manualLockUntil - Date.now()) / 1000)) + 's' + ' sync=' + (b.__syncKeep || 0) + '/' + (b.__syncReal || 0) + ' stucks=' + stuckCount)
    }
    if (cmd === 'goto') {
      const x = parseFloat(args[0]); const y = parseFloat(args[1]); const z = parseFloat(args[2])
      if (isNaN(x) || isNaN(y) || isNaN(z)) return respond(sock, 'ERR goto <x y z>')
      stopDrive(b)
      b.pathfinder.setGoal(new goals.GoalNear(x, y, z, 1))
      respond(sock, 'OK pathfinding to ' + x + ' ' + y + ' ' + z)
      b.once('goal_reached', () => log('ARRIVED', pos(b)))
      return
    }
    if (cmd === 'follow') {
      const name = args[0]
      const target = b.players[name] && b.players[name].entity
      if (!target) return respond(sock, 'ERR no player ' + name)
      b.pathfinder.setGoal(new goals.GoalFollow(target, 2), true)
      return respond(sock, 'OK following ' + name)
    }
    if (cmd === 'break' || cmd === 'breakhere') {
      let target
      if (cmd === 'breakhere') {
        target = b.blockAtCursor ? b.blockAtCursor() : null
        if (!target) {
          const ray = b.raycast ? b.raycast({ maxDistance: 5 }) : null
          target = ray ? ray.block : null
        }
      } else {
        const x = parseInt(args[0], 10); const y = parseInt(args[1], 10); const z = parseInt(args[2], 10)
        if (isNaN(x) || isNaN(y) || isNaN(z)) return respond(sock, 'ERR break <x y z>')
        target = b.blockAt(new Vec3(x, y, z))
      }
      if (!target || target.type === 0) return respond(sock, 'ERR no block there')
      respond(sock, 'OK breaking ' + target.name + ' at ' + target.position)
      try {
        await b.lookAt(target.position.offset(0.5, 0.5, 0.5))
        if (b.entity.position.distanceTo(target.position) > 4) {
          b.pathfinder.setGoal(new goals.GoalNear(target.position.x, target.position.y, target.position.z, 3))
          await once(b, 'goal_reached', 20000).catch(() => {})
        }
        b.__allowDig = true
        try { await b.dig(target) } finally { b.__allowDig = false }
        log('DUG', target.name)
        collectNear(b, 6).then(n => { if (n) log('DROPS collected', n) })
      } catch (e) { log('DIG_FAIL', e && e.message ? e.message : String(e)) }
      return
    }
    if (cmd === 'collect') {
      const name = args[0]
      const count = parseInt(args[1] || '1', 10)
      if (!name) return respond(sock, 'ERR collect <name> [n]')
      const bt = mcData.blocksByName[name]
      if (!bt) return respond(sock, 'ERR unknown block ' + name)
      if (!b.collectBlock) return respond(sock, 'ERR collectblock plugin missing')
      const positions = b.findBlocks({ matching: bt.id, maxDistance: 48, count: count * 4 })
      const targets = positions.map(p => b.blockAt(p)).filter(Boolean)
      if (!targets.length) return respond(sock, 'ERR no ' + name + ' within 48 blocks')
      manualLockUntil = Date.now() + Math.min(180000, 20000 + count * 6000)
      respond(sock, 'OK collecting up to ' + count + ' ' + name + ' (' + targets.length + ' found)')
      b.collectBlock.collect(targets, { iterations: count, range: 4 })
        .then(() => log('COLLECT_DONE', name))
        .catch(e => log('COLLECT_ERR', e && e.message ? e.message : String(e)))
      return
    }
    if (cmd === 'craft') {
      const name = args[0]
      const count = parseInt(args[1] || '1', 10)
      if (!name) return respond(sock, 'ERR craft <item> [n]')
      const item = mcData.itemsByName[name]
      if (!item) return respond(sock, 'ERR unknown item ' + name)
      let table = null
      const ct = mcData.blocksByName.crafting_table
      if (ct) {
        const tb = b.findBlock({ matching: ct.id, maxDistance: 5 })
        if (tb) table = tb
      }
      let recipes = b.recipesFor(item.id, null, 1, table)
      if (!recipes.length && table) recipes = b.recipesFor(item.id, null, 1, null)
      if (!recipes.length) return respond(sock, 'ERR no recipe for ' + name + ' (missing materials or need table)')
      try {
        await b.craft(recipes[0], count, table)
      } catch (e) {
        return respond(sock, 'ERR craft failed: ' + (e && e.message ? e.message : e))
      }
      return respond(sock, 'OK crafted ' + count + ' ' + name + (table ? ' (used table)' : ''))
    }
    if (cmd === 'place') {
      const name = args[0]
      const item = mcData.itemsByName[name]
      if (!item) return respond(sock, 'ERR unknown item ' + name)
      const inv = b.inventory.items().find(i2 => i2.name === name)
      if (!inv) return respond(sock, 'ERR no ' + name + ' in inventory')
      try { await b.equip(inv, 'hand') } catch (e) {}
      const feet = b.entity.position.floored()
      let target
      const x = parseFloat(args[1]); const y = parseFloat(args[2]); const z = parseFloat(args[3])
      if (!isNaN(x) && !isNaN(y) && !isNaN(z)) target = new Vec3(x, y, z)
      else {
        const yaw = b.entity.yaw
        const fx = Math.round(-Math.sin(yaw)); const fz = Math.round(-Math.cos(yaw))
        target = feet.offset(fx, 0, fz)
      }
      const FACES = [new Vec3(0, 1, 0), new Vec3(0, -1, 0), new Vec3(1, 0, 0), new Vec3(-1, 0, 0), new Vec3(0, 0, 1), new Vec3(0, 0, -1)]
      let done = false
      for (const f of FACES) {
        const refPos = target.plus(f.scaled(-1))
        const ref = b.blockAt(refPos)
        if (ref && ref.boundingBox === 'block' && b.entity.position.distanceTo(refPos) < 4.5) {
          const r = await withTimeout(b.placeBlock(ref, f), 3500, 'to')
          if (r !== 'to') { done = true; break }
        }
      }
      return respond(sock, done ? 'OK placed ' + name + ' at ' + target.toString() : 'ERR place failed at ' + target.toString())
    }
    if (cmd === 'look') {
      const yaw = parseFloat(args[0]); const pitch = parseFloat(args[1] || '0')
      await b.look(yaw, pitch)
      return respond(sock, 'OK looked')
    }
    if (cmd === 'hb') {
      try { return respond(sock, fs.readFileSync(HB_FILE, 'utf8')) } catch (e) { return respond(sock, 'ERR no heartbeat yet') }
    }
    if (cmd === 'stats') {
      return respond(sock, JSON.stringify(stats) + ' lastUnstick=' + Math.round((Date.now() - lastUnstickAt) / 1000) + 's ago')
    }
    if (cmd === 'social') {
      const rows = Object.keys(social).map(k => k + '(talks=' + social[k].talks + ',last=' + Math.round((Date.now() - (social[k].last || 0)) / 1000) + 's)')
      return respond(sock, rows.length ? rows.join(' ') : 'nobody yet')
    }
    if (cmd === 'lastchat') {
      return respond(sock, chatRing.length ? chatRing.slice(-10).map(c => (c.u || '?') + ': ' + c.x).join(' | ') : 'empty')
    }
    if (cmd === 'sayto') {
      const r = replyFor(b, args[0] || 'unknown', args.slice(1).join(' '))
      const ok = r ? say(b, r) : false
      return respond(sock, ok ? 'OK said: ' + r : 'ERR throttled or nothing to say')
    }
    if (cmd === 'rawsay') {
      const msg = args.join(' ')
      if (!msg) return respond(sock, 'ERR rawsay <text>')
      try { b.chat(msg); respond(sock, 'OK rawsaid: ' + msg.slice(0, 80)) } catch (e) { respond(sock, 'ERR ' + (e && e.message)) }
      return
    }
    if (cmd === 'testchat') {
      const u = args[0] || 'Tester'
      const t = args.slice(1).join(' ')
      const before = stats.replies
      feedChat(b, u, t, false)
      await sleep(1600)
      return respond(sock, 'replied=' + (stats.replies > before ? 'yes' : 'no') + ' addressed=' + addressedToMe(t))
    }
    if (cmd === 'selftest') {
      respond(sock, 'OK selftest started, see log')
      selfTest(b)
      return
    }
    if (cmd === 'chat') {
      b.chat(args.join(' '))
      return respond(sock, 'OK said')
    }
    if (cmd === 'jump') {
      if (args[0] === 'on' || args[0] === 'off') { b.setControlState('jump', args[0] === 'on'); syncInput(b); return respond(sock, 'OK jump held ' + (args[0] === 'on')) }
      b.setControlState('jump', true); setTimeout(() => b.setControlState('jump', false), 300); syncInput(b); return respond(sock, 'OK jumped')
    }
    if (cmd === 'sneak') { const on = args[0] !== 'off'; b.setControlState('sneak', on); return respond(sock, 'OK sneak ' + on) }
    if (cmd === 'sprint') { const on = args[0] !== 'off'; b.setControlState('sprint', on); return respond(sock, 'OK sprint ' + on) }
    if (cmd === 'forward') { const on = args[0] !== 'off'; b.setControlState('forward', on); return respond(sock, 'OK forward ' + on) }
    if (cmd === 'inventory') {
      const items = b.inventory.items().map(i => i.name + ' x' + i.count)
      return respond(sock, items.length ? items.join(', ') : 'empty')
    }
    if (cmd === 'window') {
      const w = b.currentWindow
      if (!w) return respond(sock, 'no window open')
      dumpWindow(w)
      let title = ''; try { title = chatText(w.title) } catch (e) {}
      const parts = []
      for (let i = 0; i < w.slots.length; i++) { const it = w.slots[i]; if (it) { let dn = ''; try { dn = chatText(it.displayName) || '' } catch (e) {} parts.push(i + '=' + it.name + (dn && dn !== it.name ? '("' + dn + '")' : '') + 'x' + it.count) } }
      return respond(sock, 'title="' + title + '" type=' + w.type + ' slots=' + w.slots.length + ' | ' + (parts.join(' | ') || 'empty'))
    }
    if (cmd === 'click') {
      const w = b.currentWindow
      if (!w) return respond(sock, 'ERR no window open')
      const slot = parseInt(args[0], 10)
      if (isNaN(slot)) return respond(sock, 'ERR click <slot> [left|right] [mode]')
      const mouseButton = args[1] === 'right' ? 1 : 0
      const mode = parseInt(args[2] || '0', 10)
      try { w.click(slot, mouseButton, mode); return respond(sock, 'OK clicked slot ' + slot) } catch (e) { return respond(sock, 'ERR click ' + (e && e.message ? e.message : e)) }
    }
    if (cmd === 'clickitem') {
      const w = b.currentWindow
      if (!w) return respond(sock, 'ERR no window open')
      const name = args.join(' ').toLowerCase()
      for (let i = 0; i < w.slots.length; i++) {
        const it = w.slots[i]
        if (!it) continue
        let dn = ''; try { dn = (chatText(it.displayName) || '').toLowerCase() } catch (e) {}
        const nm = (it.name || '').toLowerCase()
        if (name && (dn.includes(name) || nm.includes(name))) {
          try { w.click(i, 0, 0); return respond(sock, 'OK clicked slot ' + i + ' ' + it.name + '("' + (chatText(it.displayName) || '') + '")') } catch (e) { return respond(sock, 'ERR click ' + (e && e.message ? e.message : e)) }
        }
      }
      return respond(sock, 'ERR no slot matching "' + name + '"')
    }
    if (cmd === 'equip') {
      const name = args[0]
      const inv = b.inventory.items().find(i => i.name === name)
      if (!inv) return respond(sock, 'ERR no ' + name)
      await b.equip(inv, 'hand')
      return respond(sock, 'OK equipped ' + name)
    }
    if (cmd === 'drop') {
      const name = args[0]; const count = parseInt(args[1] || '1', 10)
      const inv = b.inventory.items().find(i => i.name === name)
      if (!inv) return respond(sock, 'ERR no ' + name)
      await b.toss(name === 'air' ? null : inv.type, null, Math.min(count, inv.count))
      return respond(sock, 'OK dropped ' + name)
    }
    if (cmd === 'fight') {
      const secs = Math.min(parseFloat(args[0] || '6'), 60)
      const radius = parseFloat(args[1] || '6')
      const end = Date.now() + secs * 1000
      let hits = 0
      manualLockUntil = Date.now() + secs * 1000
      respond(sock, 'OK fighting up to ' + secs + 's radius ' + radius)
      ;(async () => {
        let last = ''
        while (Date.now() < end && b.entity && b.health > 0) {
          const h = nearestHostile(b, radius)
          if (!h) break
          equipBestWeapon(b)
          try { await b.lookAt(h.position.offset(0, h.height ? h.height * 0.6 : 0.9, 0)) } catch (e) {}
          const d = h.position.distanceTo(b.entity.position)
          try {
            if (d > 3.3) b.pathfinder.setGoal(new goals.GoalNear(h.position.x, h.position.y, h.position.z, 2))
            else b.pathfinder.setGoal(null)
          } catch (e) {}
          try { b.attack(h); hits++ } catch (e) {}
          if (h.name !== last) { log('FIGHT', h.name, 'd=' + d.toFixed(1), 'hp=' + (h.health !== undefined ? Math.round(h.health) : '?')); last = h.name }
          await sleep(340)
        }
        try { b.pathfinder.setGoal(null) } catch (e) {}
        log('FIGHT_END hits=' + hits)
      })()
      return
    }
    if (cmd === 'mobs') {
      const radius = parseFloat(args[0] || '16')
      const out = []
      for (const id in b.entities) {
        const e = b.entities[id]
        if (!e || !e.position || !e.name || e === b.entity) continue
        const d = e.position.distanceTo(b.entity.position)
        if (d > radius) continue
        const hostile = HOSTILE.has(String(e.name).toLowerCase())
        if (!hostile && args[1] !== 'all') continue
        out.push((hostile ? '!' : ' ') + e.name + ' d=' + d.toFixed(1) + (e.health !== undefined ? ' hp=' + Math.round(e.health) : ''))
      }
      return respond(sock, out.length ? out.join(' | ') : 'none')
    }
    if (cmd === 'find') {
      const name = args[0]
      const radius = parseFloat(args[1] || '32')
      const cnt = parseInt(args[2] || '5', 10)
      if (!name) return respond(sock, 'ERR find <block> [radius] [count]')
      const bt = mcData.blocksByName[name]
      if (!bt) return respond(sock, 'ERR unknown block ' + name)
      const positions = b.findBlocks({ matching: bt.id, maxDistance: radius, count: cnt })
      if (!positions.length) return respond(sock, 'no ' + name + ' within ' + radius)
      const out = positions.map(p => p.x + ' ' + p.y + ' ' + p.z)
      return respond(sock, name + '(' + positions.length + '): ' + out.join(' | '))
    }
    if (cmd === 'eat') {
      const food = findFood(b)
      if (!food) return respond(sock, 'ERR no food in inventory')
      try { await b.equip(food, 'hand'); await b.consume(); return respond(sock, 'OK ate ' + food.name + ' food=' + Math.round(b.food)) } catch (e) { return respond(sock, 'ERR eat ' + (e && e.message ? e.message : e)) }
    }
    if (cmd === 'lookat') {
      const name = (args[0] || '').toLowerCase()
      let target = null; let bd = 1e9
      for (const id in b.entities) {
        const e = b.entities[id]
        if (!e || !e.position || e === b.entity) continue
        const nm = String(e.name || '').toLowerCase()
        const un = String(e.username || '').toLowerCase()
        if (name && nm !== name && un !== name) continue
        if (!name && e.type !== 'player' && un === '') continue
        const d = e.position.distanceTo(b.entity.position)
        if (d < bd) { bd = d; target = e }
      }
      if (!target) return respond(sock, 'ERR no target ' + (name || ''))
      try { await b.lookAt(target.position.offset(0, 1.4, 0)) } catch (e) {}
      return respond(sock, 'OK looking at ' + (target.username || target.name) + ' d=' + bd.toFixed(1))
    }
    if (cmd === 'placeat') {
      const x = parseInt(args[0], 10); const y = parseInt(args[1], 10); const z = parseInt(args[2], 10)
      if (isNaN(x) || isNaN(y) || isNaN(z)) return respond(sock, 'ERR placeat <x y z> [item]')
      let inv
      if (args[3]) inv = b.inventory.items().find(i => i.name === args[3])
      else inv = b.heldItem
      if (!inv) return respond(sock, 'ERR no block item to place')
      await b.equip(inv, 'hand')
      const targetPos = new Vec3(x, y, z)
      const dirs = [new Vec3(0, -1, 0), new Vec3(1, 0, 0), new Vec3(-1, 0, 0), new Vec3(0, 0, 1), new Vec3(0, 0, -1), new Vec3(0, 1, 0)]
      if (b.entity.position.distanceTo(targetPos) > 4.5) {
        b.pathfinder.setGoal(new goals.GoalNear(x, y, z, 3))
        await once(b, 'goal_reached', 15000).catch(() => {})
      }
      for (const d of dirs) {
        const ref = b.blockAt(targetPos.plus(d))
        if (ref && ref.type !== 0) {
          try { await b.placeBlock(ref, d.scaled(-1)); return respond(sock, 'OK placed ' + inv.name + ' at ' + x + ' ' + y + ' ' + z) } catch (e) { return respond(sock, 'ERR place ' + (e && e.message ? e.message : e)) }
        }
      }
      return respond(sock, 'ERR no adjacent solid block at ' + x + ' ' + y + ' ' + z)
    }
    if (cmd === 'mission') {
      const name = (args[0] || '').toLowerCase()
      if (name === 'stop' || name === 'none') { mission = null; try { b.pathfinder.setGoal(null) } catch (e) {}; try { b.clearControlStates() } catch (e) {}; return respond(sock, 'OK mission stopped') }
      if (!name) return respond(sock, 'ERR mission <shelter|wood|gather <block> <n>|stop>')
      if (mission) return respond(sock, 'ERR mission already running: ' + mission.name)
      const started = startMission(b, name, args[1], args[2])
      if (!started) return respond(sock, 'ERR unknown mission ' + name)
      return respond(sock, 'OK mission ' + started + ' running')
    }
    if (cmd === 'reflex') {
      reflexOn = args[0] !== 'off'
      return respond(sock, 'OK reflex ' + (reflexOn ? 'on' : 'off'))
    }
    if (cmd === 'director') {
      directorOn = args[0] !== 'off'
      if (directorOn) startDirector(b); else if (b.__director) { clearInterval(b.__director); b.__director = null }
      return respond(sock, 'OK director ' + (directorOn ? 'on' : 'off'))
    }
    if (cmd === 'free') {
      respond(sock, 'OK freeing')
      autoFree(b)
      return
    }
    if (cmd === 'pillar') {
      const steps = parseInt(args[0] || '4', 10)
      ;(async () => {
        for (let i = 0; i < steps; i++) {
          if (!b.entity || b.health <= 0) break
          const ok = await ensurePlaceable(b, 1)
          if (!ok && countPlaceable(b) < 1) { log('PILLAR', 'no blocks'); break }
          const feet = b.entity.position.floored()
          const ref = b.blockAt(feet.offset(0, -1, 0))
          if (!ref || ref.boundingBox !== 'block') { log('PILLAR', 'no reference at ' + feet.toString()); break }
          try { b.setControlState('jump', true) } catch (e) {}
          await sleep(220)
          const it = b.inventory.items().find(x => PLACEABLE.includes(x.name))
          let placed = false
          if (it) { const r = await withTimeout(b.placeBlock(ref, new Vec3(0, 1, 0)), 3000, 'to'); placed = (r !== 'to') }
          await sleep(280)
          try { b.setControlState('jump', false) } catch (e) {}
          log('PILLAR', i + ' placed=' + placed + ' y=' + pos(b))
        }
      })()
      return respond(sock, 'OK pillaring ' + steps + ' steps')
    }
    if (cmd === 'escapeup') {
      respond(sock, 'OK digging up')
      digUpAndOut(b, parseInt(args[0] || '6', 10))
      return
    }
    if (cmd === 'evaljs') {
      // live diagnostics: evaluate an async expression with bot/b in scope
      const expr = args.join(' ')
      try {
        const fn = new Function('bot', 'b', 'mcData', 'sleep', 'return (async () => (' + expr + '))()')
        const r = await fn(b, b, mcData, sleep)
        const s = typeof r === 'string' ? r : JSON.stringify(r)
        return respond(sock, 'EVAL ' + String(s).slice(0, 1800))
      } catch (e) { return respond(sock, 'EVAL_ERR ' + (e && e.message ? e.message : String(e))) }
    }
    if (cmd === 'probe') {
      if (!b || !b.entity) return respond(sock, 'ERR no entity')
      const feet = b.entity.position.floored()
      let out = 'PROBE y=' + feet.y + ' pos=' + pos(b)
      for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1], [2, 0], [-2, 0], [0, 2], [0, -2], [4, 0], [-4, 0], [0, 4], [0, -4]]) {
        let h = '?'
        for (let dy = 8; dy >= -5; dy--) { const blk = b.blockAt(feet.offset(d[0], dy, d[1])); if (blk && blk.boundingBox === 'block') { h = feet.y + dy; break } }
        out += ' [' + d[0] + ',' + d[1] + ']=' + h
      }
      return respond(sock, out)
    }
    if (cmd === 'stackup') { const n = parseInt(args[0] || '2', 10); manualLockUntil = Date.now() + n * 4000 + 6000; pillarUp(b, n); return respond(sock, 'OK pillaring ' + n) }
    if (cmd === 'pickup') {
      const r = parseInt(args[0] || '24', 10)
      const n = Object.values(b.entities).filter(e => e && e.name === 'item' && e.position && e.position.distanceTo(b.entity.position) <= r).length
      if (!n) return respond(sock, 'no items within ' + r)
      collectNear(b, r).then(k => log('PICKUP done', k + ' items, ' + pos(b)))
      return respond(sock, 'OK picking up ' + n + ' items')
    }
    if (cmd === 'dryout') {
      const dry = nearestDry(b, 16)
      if (!dry) return respond(sock, 'no dry ground within 16')
      walkTo(b, dry.x + 0.5, dry.y, dry.z + 0.5, 40000)
      return respond(sock, 'OK to dry ' + Math.round(dry.x) + ' ' + dry.y + ' ' + Math.round(dry.z) + ' d=' + dry.d.toFixed(1))
    }
    if (cmd === 'walk') {
      const x = parseFloat(args[0]); const y = parseFloat(args[1]); const z = parseFloat(args[2])
      if (isNaN(x) || isNaN(z)) return respond(sock, 'ERR walk <x y z> [secs]')
      const secs = parseInt(args[3] || '45', 10)
      walkTo(b, x, isNaN(y) ? b.entity.position.y : y, z, secs * 1000)
      return respond(sock, 'OK walking to ' + x + ' ' + (isNaN(y) ? '?' : y) + ' ' + z + ' for ' + secs + 's')
    }
    if (cmd === 'near') {
      const feet = b.entity.position.floored()
      let out = 'NEAR y=' + feet.y
      for (const d of [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1], [2, 0], [-2, 0], [0, 2], [0, -2]]) {
        const col = []
        for (let dy = -1; dy <= 4; dy++) { const blk = b.blockAt(feet.offset(d[0], dy, d[1])); col.push(dy + ':' + (blk ? blk.name.replace(/_block$/, '') : '-')) }
        out += ' [' + d[0] + ',' + d[1] + '] ' + col.join(' ')
      }
      const below = []
      for (let dy = -1; dy >= -4; dy--) { const blk = b.blockAt(feet.offset(0, dy, 0)); below.push(dy + ':' + (blk ? blk.name.replace(/_block$/, '') : '-')) }
      out += ' BELOW ' + below.join(' ')
      return respond(sock, out)
    }
    if (cmd === 'scan') {
      const feet = b.entity.position.floored()
      const span = parseInt(args[0] || '10', 10)
      let out = 'SCAN y=' + feet.y
      const dirs = [[1, 0, 'E'], [-1, 0, 'W'], [0, 1, 'S'], [0, -1, 'N'], [1, 1, 'SE'], [-1, -1, 'NW'], [1, -1, 'NE'], [-1, 1, 'SW']]
      for (const d of dirs) {
        const seq = []
        for (let dist = 3; dist <= 33; dist += 3) {
          const c = dryCol(b, feet, d[0] * dist, d[1] * dist)
          const g = c ? (feet.y + 0 + (c.y - feet.y - 1)) : null
          seq.push(dist + ':' + (c ? c.y + 'd' : (groundYAt(b, feet, d[0] * dist, d[1] * dist, span) === null ? '?' : 'W')))
        }
        out += ' ' + d[2] + '[' + seq.join(' ') + ']'
      }
      return respond(sock, out)
    }
    if (cmd === 'phys') { b.physicsEnabled = args[0] !== 'off'; return respond(sock, 'OK physics=' + b.physicsEnabled) }
    if (cmd === 'loaded') { sendLoaded(b, 'manual'); return respond(sock, 'OK player_loaded sent') }
    if (cmd === 'input') {
      const names = ['forward', 'back', 'left', 'right', 'jump', 'sneak', 'sprint']
      const errs = []
      const c = n => { try { return !!b.getControlState(n) } catch (e) { errs.push('get:' + n + ':' + e.message); return false } }
      if (args[0] === 'send') { syncInput(b); b.__inputKey = '' ; syncInput(b) }
      if (args.length >= 3) { try { b.setControlState(args[1], args[2] === 'on') } catch (e) { errs.push('set:' + e.message) } ; b.__inputKey = ''; syncInput(b) }
      const st = names.map(n => n + ':' + (c(n) ? 1 : 0)).join(' ')
      let err = 'none'
      try { b._client.write('player_input', { inputs: { forward: c('forward'), backward: c('back'), left: c('left'), right: c('right'), jump: c('jump'), shift: c('sneak'), sprint: c('sprint') } }) } catch (e) { err = e.message }
      return respond(sock, 'errs=' + (errs.join('|') || 'none') + ' raw=' + (() => { try { return JSON.stringify(b.controlState) } catch (e) { return 'throw ' + e.message } })() + ' INPUTS writes=' + (b.__inputWrites || 0) + ' err=' + err + ' state=' + st + ' feature=' + (b.supportFeature ? b.supportFeature('newPlayerInputPacket') : '?') + ' pos=' + pos(b))
    }
    if (cmd === 'diag') {
      const e = b.entity
      const cs = JSON.stringify(b.controlState)
      const out = 'DIAG pos=' + e.position.x.toFixed(2) + ',' + e.position.y.toFixed(2) + ',' + e.position.z.toFixed(2) + ' vel=' + JSON.stringify({ x: +e.velocity.x.toFixed(3), y: +e.velocity.y.toFixed(3), z: +e.velocity.z.toFixed(3) }) +
        ' onGround=' + b.onGround + ' yaw=' + e.yaw.toFixed(2) + ' pitch=' + e.pitch.toFixed(2) +
        ' ctrl=' + cs + ' alive=' + e.isPlayer + ' state=' + (b._client && b._client.state) + ' phys=' + (b.physics ? b.physics.gravity + '/' + b.physics.airDamping : '?')
      const names = ['position', 'flying', 'player_input', 'player_loaded', 'arm_animation']
      const snap = () => names.map(n => n + ':' + (b.__outPk[n] || 0) + '/' + (b.__inPk[n] || 0)).join(' ')
      const s0 = snap()
      const p0 = e.position.clone()
      try { b.setControlState('forward', true) } catch (er) {}
      await sleep(2000)
      try { b.setControlState('forward', false) } catch (er) {}
      const p1 = b.entity.position
      const s1 = snap()
      return respond(sock, out + ' | pk_out/in_before ' + s0 + ' | pk_after ' + s1 + ' | moved=' + Math.hypot(p1.x - p0.x, p1.z - p0.z).toFixed(3) + ' dy=' + (p1.y - p0.y).toFixed(3))
    }
    if (cmd === 'stop') {
      stopDrive(b)
      try { b.pathfinder.setGoal(null) } catch (e) {}
      try { b.clearControlStates() } catch (e) {}
      return respond(sock, 'OK stopped')
    }
    if (cmd === 'quit') {
      respond(sock, 'OK quitting')
      stopped = true
      setTimeout(() => { try { b.quit() } catch (e) {}; process.exit(0) }, 300)
      return
    }
    respond(sock, 'ERR unknown command: ' + cmd)
  } catch (e) {
    log('CMD_ERR', cmd, e && e.message ? e.message : String(e))
    respond(sock, 'ERR ' + (e && e.message ? e.message : String(e)))
  }
}

function once (emitter, event, timeout) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => { emitter.removeListener(event, onOk); reject(new Error('timeout')) }, timeout)
    function onOk () { clearTimeout(t); resolve() }
    emitter.once(event, onOk)
  })
}

function startControl () {
  const server = net.createServer(sock => {
    clients.add(sock)
    let buf = ''
    sock.on('data', d => {
      buf += d.toString()
      let idx
      while ((idx = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, idx).trim()
        buf = buf.slice(idx + 1)
        if (line) handle(line, sock)
      }
    })
    sock.on('close', () => clients.delete(sock))
    sock.on('error', () => clients.delete(sock))
  })
  server.listen(CONTROL_PORT, '127.0.0.1', () => log('control on 127.0.0.1:' + CONTROL_PORT))
}

startControl()
log('connecting to', HOST + ':' + PORT, 'version', VERSION, 'auth', AUTH, 'as', USERNAME)
bot = makeBot()
