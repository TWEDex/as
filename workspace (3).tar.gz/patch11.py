#!/usr/bin/env python3
# patch11: "learn to survive" - stop the dig-everything habit, make home sticky,
# heal the position desync that made the leash drag Puff back into the mob nest.
import re, sys

F = 'bot.js'
s = open(F, encoding='utf8').read()
done = []

def sub(name, old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        print('!! %-24s found %d times (expected %d)' % (name, n, count)); sys.exit(1)
    s = s.replace(old, new, count)
    done.append(name)

# ---------------------------------------------------------------- 1. movement: never auto-dig
sub('movements-nodig', """    mv.canDig = true
    mv.digCost = 2""", """    // BUG #1 (owner pointed it out): with canDig the A* planner treats "break a block"
    // as a normal, cheap edge, so on a jungle hill it tunnels through dirt/leaves/stone
    // instead of walking 3 blocks around. Digging is now only allowed by the explicit
    // escape routines (digBlock / digUpAndOut via __allowDig), never by the path planner.
    mv.canDig = false
    mv.digCost = 500""")

sub('collect-nodig', """        b.collectBlock.movements.canDig = true
        b.collectBlock.movements.digCost = 2""", """        b.collectBlock.movements.canDig = false   // collect() used to chew through the terrain
        b.collectBlock.movements.digCost = 500""")

sub('pf-ready-log", ', """    log('PF_READY thinkTimeout=' + b.pathfinder.thinkTimeout + ' searchRadius=' + b.pathfinder.searchRadius + ' digCost=2 (dig=last resort)')""",
    """    log('PF_READY thinkTimeout=' + b.pathfinder.thinkTimeout + ' searchRadius=' + b.pathfinder.searchRadius + ' canDig=false (walk around, dig only to escape)')""")

sub('reflex-nodig', """        const wantDig = !b.__fleeing && !hiding && now > (b.__respawnSprintUntil || 0)""",
    """        // the reflex loop used to hand digging back every time we were not fleeing, which
        // quietly re-enabled the tunnel-through-everything habit. Path planning never digs.
        const wantDig = false""")

# ---------------------------------------------------------------- 2. digBlock: hard rock = go around
sub('dig-hard', """  try { await b.lookAt(blk.position.offset(0.5, 0.5, 0.5)); await b.dig(blk); stats.mined++; await suckDrop(b, v); return true } catch (e) { return false }""",
    """  // BUG #2: we spent minutes punching stone/wood we had no tool for, standing still while
  // mobs closed in. If it is hard and we have no pick, that is not a wall to break - it is
  // a wall to walk around.
  const hd = typeof blk.hardness === 'number' ? blk.hardness : 1
  if (hd > 3 && !hasPickaxe(b)) {
    if (Date.now() - (b.__hardWarned || 0) > 20000) {
      b.__hardWarned = Date.now()
      log('DIG_SKIP ' + blk.name + ' at ' + v + ' hardness=' + hd + ' no tool -> detour')
    }
    return false
  }
  try {
    await b.lookAt(blk.position.offset(0.5, 0.5, 0.5)); await b.dig(blk)
    stats.mined++; stats.dug = (stats.dug || 0) + 1
    if (Date.now() % 60000 < 500) log('DUG ' + blk.name + ' total=' + stats.dug)
    await suckDrop(b, v); return true
  } catch (e) { return false }""")

# ---------------------------------------------------------------- 3. unstick: detour BEFORE digging
sub('detour-first', """      if (ob !== 'wall' || !soft || inCollapseZone(b)) {""",
    """      b.__detourN = b.__detourN || 0
      // BUG #3 (the owner's words: "ты их ломаешь, даже не зная что их можно обойти").
      // Three cheap detours - sidestep, then sidestep + forward, then a longer arc -
      // are tried before a single block is broken. Only a real dead end gets dug out.
      if (b.__detourN < 3 && ob !== 'none' && !inCollapseZone(b)) {
        b.__detourN++
        stats.detours = (stats.detours || 0) + 1
        const side = (b.__detourN % 2 === 0) ? 1 : -1
        const arc = b.__detourN === 3 ? 1500 : 850
        log('UNSTICK DETOUR #' + b.__detourN + ' ob=' + ob + ' ' + (side > 0 ? 'right' : 'left') + ' at ' + pos(b) + ' (no breaking)')
        try { b.pathfinder.setGoal(null) } catch (e) {}
        try { await b.look(yaw0 + side * Math.PI / 2, 0, true) } catch (e) {}
        b.setControlState('forward', true); b.setControlState('jump', true)
        await sleep(arc)
        b.setControlState('forward', false); b.setControlState('jump', false)
        await sleep(150)
        try { await b.look(Math.atan2(-d0.x, d0.z), 0, true) } catch (e) {}
        b.setControlState('forward', true)
        await sleep(700)
        b.setControlState('forward', false)
        return
      }
      if (ob !== 'wall' || !soft || inCollapseZone(b)) {""")

sub('detour-reset', """      if (flat > 0.7 || rise > 1.0) { stuckSince = 0; b.__stuckLevel = 0; return }""",
    """      if (flat > 0.7 || rise > 1.0) { stuckSince = 0; b.__stuckLevel = 0; b.__detourN = 0; return }   // moving again: detour budget resets""")

# ---------------------------------------------------------------- 4. home is sticky, not "wherever we respawned"
sub('anchor-files', """const ANCHOR_FILE = '/home/agent/bot/anchor.json'
let anchor = null""", """const ANCHOR_FILE = '/home/agent/bot/anchor.json'
const ANCHOR_BAK = '/home/agent/bot/anchor.bak.json'
// BUG #4, the big one: reanchorIfFar() happily moved "home" to wherever we respawned.
// We respawn at world spawn, which IS the zombie nest, so the leash dragged us back into
// it, we died there, re-anchored there... 500+ deaths and the empty inventory came from
// that loop. Home = the 2-chunk circle where Puff appeared; nothing casual moves it.
const SPAWN = { x: -618, z: -654 }
const APPEARED = { x: -574, y: 67, z: 87 }
function nearBadXZ (x, z) {
  if (!isFinite(x) || !isFinite(z)) return true
  return Math.hypot(x - NEST.x, z - NEST.z) < 70 || Math.hypot(x - SPAWN.x, z - SPAWN.z) < 70
}
let anchor = null
let anchorBak = null""")

sub('anchor-load', """try { const a = JSON.parse(fs.readFileSync(ANCHOR_FILE, 'utf8')); if (a && isFinite(a.x)) anchor = a } catch (e) {}
function saveAnchor () { try { fs.writeFileSync(ANCHOR_FILE, JSON.stringify(anchor || {})) } catch (e) {} }""",
    """try { const a = JSON.parse(fs.readFileSync(ANCHOR_FILE, 'utf8')); if (a && isFinite(a.x)) anchor = a } catch (e) {}
try { const a = JSON.parse(fs.readFileSync(ANCHOR_BAK, 'utf8')); if (a && isFinite(a.x)) anchorBak = a } catch (e) {}
function saveAnchor () {
  try {
    // keep the previous good home in a backup instead of overwriting history
    if (anchorBak && isFinite(anchorBak.x) && !nearBadXZ(anchorBak.x, anchorBak.z)) fs.writeFileSync(ANCHOR_BAK, JSON.stringify(anchorBak))
    if (anchor && isFinite(anchor.x)) {
      if (!nearBadXZ(anchor.x, anchor.z)) {
        if (!anchorBak || anchorBak.x !== anchor.x || anchorBak.z !== anchor.z) fs.writeFileSync(ANCHOR_BAK, JSON.stringify(anchor))
      }
    }
    fs.writeFileSync(ANCHOR_FILE, JSON.stringify(anchor || {}))
  } catch (e) {}
}
// self-heal a poisoned anchor file: death-nest centre -> last good home -> house -> circle
// where Puff appeared. Runs at load, so a bad write can never re-imprison us.
function healAnchor () {
  const hm = (typeof HOME !== 'undefined' && HOME && isFinite(HOME.x)) ? { x: HOME.x, y: HOME.y, z: HOME.z, t: Date.now(), home: true } : null
  const good = (a) => a && isFinite(a.x) && isFinite(a.z) && !nearBadXZ(a.x, a.z)
  if (good(anchor)) return
  const from = anchor ? (Math.round(anchor.x) + ',' + Math.round(anchor.z)) : 'null'
  if (good(anchorBak)) { anchor = anchorBak } else if (hm) { anchor = hm } else { anchor = { x: APPEARED.x, y: APPEARED.y, z: APPEARED.z, t: Date.now(), home: true } }
  log('ANCHOR_HEAL was ' + from + ' (death zone) -> ' + Math.round(anchor.x) + ',' + Math.round(anchor.z))
  saveAnchor()
}""")

sub('anchor-of', """function anchorOf (b) {
  if (!anchor && b && b.entity && fin3(b.entity.position)) {
    const p = b.entity.position
    anchor = { x: p.x, y: p.y, z: p.z, t: Date.now() }
    saveAnchor()""", """function anchorOf (b) {
  if (!anchor && b && b.entity && fin3(b.entity.position)) {
    const p = b.entity.position
    if (nearBadXZ(p.x, p.z)) return null          // never adopt the nest as the centre
    anchor = { x: p.x, y: p.y, z: p.z, t: Date.now() }
    saveAnchor()""")

sub('reanchor-guard', """  const d = Math.hypot(p.x - anchor.x, p.z - anchor.z)
  if (d > Math.max(leashR * 3, 80)) {
    log('ANCHOR re-set at '""", """  const d = Math.hypot(p.x - anchor.x, p.z - anchor.z)
  if (d > Math.max(leashR * 3, 80)) {
    if (nearBadXZ(p.x, p.z) || anchor.home || (typeof HOME !== 'undefined' && HOME)) {
      // We are far from home and either standing in the grinder or we already HAVE a home:
      // walking back is the answer, moving the circle is the trap that killed us 500 times.
      log('ANCHOR_REFUSE ' + Math.round(p.x) + ',' + Math.round(p.z) + ' kept home at ' +
          Math.round(anchor.x) + ',' + Math.round(anchor.z) + ' (d=' + d.toFixed(0) + ')')
      try { walkHomeLong(b) } catch (e) { log('HOME_HOP_ERR', e && e.message) }
      return
    }
    anchorBak = anchor
    log('ANCHOR re-set at '""")

# ---------------------------------------------------------------- 5. long way home, leash corridor
sub('walkhome', """function distAnchor (b) {""", """let homeWalkUntil = 0
// Hops the long way back to the home circle with the clamp lifted (otherwise every goal is
// pinned onto the rim and we mill around 700 blocks away forever).
async function walkHomeLong (b) {
  if (!b.entity || !anchor || !b.isAlive) return
  if (Date.now() < homeWalkUntil) return
  homeWalkUntil = Date.now() + 180000
  const wasOn = leashOn
  leashOn = false
  let hops = 0
  try {
    while (b.entity && b.isAlive && hops < 10) {
      const p = b.entity.position
      const d = Math.hypot(p.x - anchor.x, p.z - anchor.z)
      if (d < leashR) break
      hops++
      const ux = (anchor.x - p.x) / d, uz = (anchor.z - p.z) / d
      const step = Math.min(64, d)
      log('HOME_HOP #' + hops + ' d=' + d.toFixed(0) + ' -> ' + Math.round(p.x + ux * step) + ',' + Math.round(p.z + uz * step))
      try { b.pathfinder.setGoal(null) } catch (e) {}
      // BUG #5: goto() throws "No path to the goal!" and we just stood there. Shrink the
      // hop until something is reachable, and if nothing is, stop and let combat/director
      // handle it instead of looping in place.
      let ok = false
      for (const frac of [1, 0.5, 0.25]) {
        const g = new goals.GoalNear(p.x + ux * step * frac, anchor.y, p.z + uz * step * frac, 4)
        ok = await b.pathfinder.goto(g).then(() => true).catch(() => false)
        if (ok) break
      }
      if (!ok) { log('HOME_HOP blocked at ' + pos(b) + ' - giving up this hop'); break }
    }
  } catch (e) { log('HOME_HOP_ERR', e && e.message) } finally {
    leashOn = wasOn
    homeWalkUntil = 0
    log('HOME_HOP end at ' + pos(b) + ' d=' + (anchor ? distAnchor(b).toFixed(1) : '?'))
  }
}

function distAnchor (b) {""")

# ---------------------------------------------------------------- 6. client/server desync
sub('leash-desync', """      if (!leashOn || !b.entity || !b.isAlive) return
      const a = anchorOf(b)
      if (!a) return
      const d = distAnchor(b)""", """      if (!leashOn || !b.entity || !b.isAlive) return
      if (Date.now() < homeWalkUntil) return                    // long walk home in progress
      // BUG #6: the client entity drifted 15-20 blocks from where the server actually has
      // us, so the leash computed a 700-block distance and hammered an impossible
      // GoalNear every 5s (LEASH_RETURN spam + UNSTICK step-up spam, nothing else running).
      if (b.__srvPos && fin3(b.__srvPos) && Date.now() - b.__srvPos.t < 15000) {
        const dd = Math.hypot(b.entity.position.x - b.__srvPos.x, b.entity.position.z - b.__srvPos.z)
        if (dd > 14) {
          log('LEASH_DESYNC local ' + pos(b) + ' vs srv ' + b.__srvPos.x.toFixed(1) + ',' + b.__srvPos.z.toFixed(1) + ' = ' + dd.toFixed(0) + 'b -> snap')
          try { b.entity.position = new Vec3(b.__srvPos.x, b.__srvPos.y, b.__srvPos.z) } catch (e) {}
          try { mission = null } catch (e) {}
          try { b.pathfinder.setGoal(null) } catch (e) {}
          return
        }
      }
      const a = anchorOf(b)
      if (!a) return
      const d = distAnchor(b)""")

# ---------------------------------------------------------------- 7. spawn: never adopt the nest
sub('respawn-reanchor', """      log('RESPAWN #' + (b.__spawnCount - 1) + ' at', pos(b))
      try { reanchorIfFar(b) } catch (e) {}""", """      log('RESPAWN #' + (b.__spawnCount - 1) + ' at', pos(b))
      // do NOT re-anchor from the respawn point: the respawn point is the nest.
      try {
        if (b.entity && fin3(b.entity.position) && nearBadXZ(b.entity.position.x, b.entity.position.z)) {
          log('RESPAWN_IN_GRINDER -> walking home, leash stays on ' + (anchor ? Math.round(anchor.x) + ',' + Math.round(anchor.z) : '?'))
          walkHomeLong(b)
        } else {
          reanchorIfFar(b)
        }
      } catch (e) {}""")

# ---------------------------------------------------------------- 8. heal at startup
sub('start-director-audit', """    try { startDirector(b) } catch (e) { log('DIRECTOR_ERR', e && e.message) }""",
    """    try { healAnchor() } catch (e) { log('ANCHOR_HEAL_ERR', e && e.message) }
    try { startDirector(b) } catch (e) { log('DIRECTOR_ERR', e && e.message) }
    try { startAudit(b) } catch (e) { log('AUDIT_ERR', e && e.message) }""")

# ---------------------------------------------------------------- 9. audit: measure the habits
sub('audit-fn', """// ==================== LEASH: stay inside 2 chunks of where we appeared ====================""",
    """// ==================== AUDIT: a survival report card, every 4 minutes ====================
// "Learn to survive" means measurable: how often we get stuck, how many blocks we break,
// how many detours replaced a broken block, how we died. Without the numbers there is no
// way to know which habit to fix next.
function startAudit (b) {
  if (b.__audit) clearInterval(b.__audit)
  b.__audit = setInterval(() => {
    try {
      if (b !== bot) { if (b.__audit) { clearInterval(b.__audit); b.__audit = null }; return }
      const d = lastDeathCause || '-'
      log('AUDIT hp=' + Math.round(b.health) + ' food=' + Math.round(b.food) +
        ' kills=' + stats.kills + ' deaths=' + stats.deaths + ' lastdeath=' + d +
        ' stucks=' + stats.stucks + ' dug=' + (stats.dug || 0) + ' detours=' + (stats.detours || 0) +
        ' mined=' + stats.mined + ' crafted=' + stats.crafted +
        ' leash=' + (leashOn ? 'on' : 'off') + ' home=' + (anchor ? Math.round(anchor.x) + ',' + Math.round(anchor.z) + ' d=' + distAnchor(b).toFixed(0) : '-') +
        ' inv=' + b.inventory.items().length)
    } catch (e) {}
  }, 240000)
}

// ==================== LEASH: stay inside 2 chunks of where we appeared ====================""")


# ---------------------------------------------------------------- 10. remember HOW we died
sub('death-cause', "let stats = { deaths: 0,", """let lastDeathCause = ''
let stats = { deaths: 0,""")
sub('death-cause2', """  b.on('death', () => { stats.deaths++; try {""",
    """  b.on('death', () => { stats.deaths++; try {
      // BUG #7: we had 523 deaths and no idea what killed us. Attribute it: a mob that
      // hit us in the last 8s, else starvation, else the environment.
      lastDeathCause = (b.__lastHurtBy && Date.now() - (b.__lastHurtAt || 0) < 9000) ? b.__lastHurtBy
        : ((b.food || 20) <= 2 ? 'starvation' : (b.__inWater ? 'drown/water' : 'unknown'))
      log('DEATH_CAUSE ' + lastDeathCause + ' hp=0 food=' + Math.round(b.food) + ' at ' + pos(b))""")
sub('hurt-by', """    b.on('entityHurt', e => { try { if (b.__hit && e) b.__hit[e.id] = { name: e.name, t: Date.now() } } catch (err) {} })""",
    """    b.on('entityHurt', (e, dmg, src) => { try {
      if (b.__hit && e) b.__hit[e.id] = { name: e.name, t: Date.now() }
      if (b.entity && e && e.id === b.entity.id && src && src.name) { b.__lastHurtBy = src.name; b.__lastHurtAt = Date.now() }
    } catch (err) {} })""")

open(F, 'w', encoding='utf8').write(s)
print('OK patch11 applied:', len(done), 'edits:', ', '.join(done))
