#!/usr/bin/env python3
# patch16: patch11 made the planner never dig, which also made trees unreachable (a trunk is
# normally sealed by its own crown). Exception ONLY while harvesting, with digCost high enough
# that walking around any real hill still beats breaking a block. Plus explicit foliage clearing.
import sys

F = 'bot.js'
s = open(F, encoding='utf8').read()
done = []

def sub(name, old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        print('!! %-16s found %d (expected %d)' % (name, n, count)); sys.exit(1)
    s = s.replace(old, new, count); done.append(name)

sub('softdig', """async function digBlock (b, v) {""",
    """// Harvesting exception to "the planner never digs": patch11 also made trees unreachable,
// because a trunk is normally sealed by its own crown - canDig=false then simply means
// "wood exists, cannot get it". So ONLY while collectBlock works we allow digging, with
// digCost=60: one dirt block costs more than ~150 blocks of walking, so any real detour
// around a hill still wins, and only a true enclosure (leaves around a log) gets broken.
// Restored to (canDig=false, digCost=500) the moment the harvest call is over.
async function withSoftDig (b, fn) {
  const mvs = [b.__movements, (b.collectBlock && b.collectBlock.movements)].filter(Boolean)
  const was = mvs.map(m => m.canDig)
  mvs.forEach(m => { m.canDig = true; m.digCost = 60 })
  try { return await fn() } finally { mvs.forEach((m, i) => { m.canDig = was[i]; m.digCost = 500 }) }
}
const FOLIAGE_RE = /leaves|sapling|vine|fern|flower|grass$|dead_bush|large_fern|tall_grass/
// leaves are not terrain: taking the crown off a trunk is how you reach the wood, and it
// costs no tools, so it is always cheaper than a tunnel anywhere
async function clearFoliage (b, tp) {
  try {
    let n = 0
    for (const d of [[0, 1, 0], [1, 1, 0], [-1, 1, 0], [0, 1, 1], [0, 1, -1], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [1, 2, 0], [-1, 2, 0], [0, 2, 1], [0, 2, -1]]) {
      if (!b.entity || b.health <= 0) break
      const v = tp.offset(d[0], d[1], d[2])
      const k = b.blockAt(v)
      if (k && FOLIAGE_RE.test(k.name)) { if (await withTimeout(digRaw(b, v), 3000, false)) n++ }
    }
    if (n) log('CLEAR_FOLIAGE ' + n + ' near ' + tp)
    return n
  } catch (e) { return 0 }
}

async function digBlock (b, v) {""")

sub('gather-softdig', """    const blocks = positions.map(p => b.blockAt(p)).filter(Boolean)
    const need = target - countItem(b, countName)
    const r = await withTimeout(b.collectBlock.collect(blocks, { iterations: Math.max(1, Math.min(8, need)), range: 4 }), 25000, 'timeout')""",
    """    const blocks = positions.map(p => b.blockAt(p)).filter(Boolean)
    const need = target - countItem(b, countName)
    if (/log|wood|plank/.test(countName)) { for (const p of positions) await clearFoliage(b, p) }
    const r = await withTimeout(withSoftDig(b, () => b.collectBlock.collect(blocks, { iterations: Math.max(1, Math.min(8, need)), range: 4 })), 25000, 'timeout')""")

sub('collect-cmd', """      b.collectBlock.collect(targets, { iterations: count, range: 4 })""",
    """      withSoftDig(b, () => b.collectBlock.collect(targets, { iterations: count, range: 4 }))""")


# the reflex loop re-forces canDig every 400ms - it must respect the harvest exception
sub('reflex-softdig', """        const wantDig = false""",
    """        const wantDig = !!b.__softDig       // walking never digs; harvest sets __softDig (patch16)""")

sub('softdig-flag', """  mvs.forEach(m => { m.canDig = true; m.digCost = 60 })
  try { return await fn() } finally { mvs.forEach((m, i) => { m.canDig = was[i]; m.digCost = 500 }) }""",
    """  mvs.forEach(m => { m.canDig = true; m.digCost = 60 })
  b.__softDig = true
  try { return await fn() } finally { b.__softDig = false; mvs.forEach((m, i) => { m.canDig = was[i]; m.digCost = 500 }) }""")

open(F, 'w', encoding='utf8').write(s)
print('OK patch16 applied:', len(done), 'edits:', ', '.join(done))
