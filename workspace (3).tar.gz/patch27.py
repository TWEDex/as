#!/usr/bin/env python3
# patch27: the audit told me the cause of death - three in a row "slain by Drowned", wateresc=42.
# Combat was chasing aquatic mobs into the water and fighting while standing in it: no sprint,
# no air, slow swings. Water is not a battlefield.
import sys

F = 'bot.js'
s = open(F, encoding='utf8').read()
done = []

def sub(name, old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        print('!! %-18s found %d (expected %d)' % (name, n, count)); sys.exit(1)
    s = s.replace(old, new, count); done.append(name)

sub('no-fight-water', """  if (b.__hunting && now - (b.__huntLogAt || 0) > 5000) { b.__huntLogAt = now; log('HUNTING', nm, 'd=' + d.toFixed(1) + ' food=' + Math.round(b.food)) }""",
    """  // MEASURED, not guessed: AUDIT showed the last deaths as "slain by Drowned" and wateresc=42.
  // In water we cannot sprint, cannot breathe and swing slowly, and drowned drag us under -
  // so an aquatic fight is refused and the answer is dry land, not more courage.
  const cellWet = (p) => { try { const k = b.blockAt(new Vec3(Math.floor(p.x), Math.floor(p.y + 0.2), Math.floor(p.z))); return !!(k && /water/.test(k.name)) } catch (err) { return false } }
  const weWet = botWet(b)
  const enemyWet = okPos(e.position) ? cellWet(e.position) : false
  const aquatic = /drowned|guardian|squid|cod|salmon|pufferfish|tropical_fish/.test(nm)
  if ((aquatic && enemyWet) || weWet) {
    if (now - (b.__waterEvadeAt || 0) > 3000) {
      b.__waterEvadeAt = now
      stats.waterEvade = (stats.waterEvade || 0) + 1
      log('NO_FIGHT_WATER ' + nm + ' d=' + d.toFixed(1) + ' we_wet=' + weWet + ' enemy_wet=' + enemyWet + ' -> dry land')
      const dry = nearestDry(b, 24)
      if (dry) { try { b.pathfinder.setGoal(new goals.GoalNear(dry.x, dry.y, dry.z, 1)) } catch (err) {} }
      else { try { escapeWaterPillar(b) } catch (err) {} }
    }
    stopFight(b)
    return
  }
  if (b.__hunting && now - (b.__huntLogAt || 0) > 5000) { b.__huntLogAt = now; log('HUNTING', nm, 'd=' + d.toFixed(1) + ' food=' + Math.round(b.food)) }""")

sub('liquid-cost', """    mv.liquidCost = 200""", """    mv.liquidCost = 900          // entering water costs more than a long walk along the shore""")

sub('panic-threat', """      const panic = w.head || wetFor > 7000 || (air !== null && air < 9)""",
    """      // with a mob on our tail, "wet" is not a nuisance but a death sentence (drowned kills)
      let chaseNear = false
      try { chaseNear = threatsNear(b, 1).length > 0 } catch (e) {}
      const panic = w.head || wetFor > 7000 || (air !== null && air < 9) || (chaseNear && wetFor > 1500)""")

open(F, 'w', encoding='utf8').write(s)
print('OK patch27 applied:', len(done), 'edits:', ', '.join(done))
