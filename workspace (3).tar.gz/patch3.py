# -*- coding: utf-8 -*-
# 'shelter' mission must build a real wooden hut instead of sealing into a pocket
# (the pocket loop is what bricked the client with NaN coords).
import io, sys
src = io.open('bot.js', encoding='utf-8').read()

def rep(old, new, tag=''):
    global src
    if src.count(old) != 1:
        print('MISS/DUP %s (%d)' % (tag, src.count(old))); sys.exit(1)
    src = src.replace(old, new, 1)
    print('ok    %s' % tag)

rep("  if (name === 'shelter') { missionShelter(b); return 'shelter' }",
    "  if (name === 'shelter') { missionHome(b); return 'home' }",
    tag='shelter -> missionHome')

rep("function startMission (b, name, arg1, arg2) {",
"""async function missionHome (b) {
  // 'shelter' = build an actual wooden hut inside the leash circle. Digging a sealed pocket
  // is what kept us dying (and NaN-bricked the client once), so it is the LAST option, only
  // when there is nothing to build with.
  const planks = plankCount(b)
  const logs = countAny(b, LOG_TYPES)
  if (planks >= 20 || logs >= 6) {
    const ok = await buildHut(b)
    mission = null
    if (ok) { log('HOME built, hp=' + Math.round(b.health)); return }
    log('HOME build failed, falling back')
  }
  if (!hasWeapon(b) && logs === 0 && missionAllowed('wood')) { startMission(b, 'wood'); return }
  missionShelter(b)
}

function startMission (b, name, arg1, arg2) {""",
    tag='missionHome added')

io.open('bot.js', 'w', encoding='utf-8').write(src)
print('done')
