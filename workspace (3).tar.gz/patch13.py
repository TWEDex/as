#!/usr/bin/env python3
# patch13: make the new path ladder FASTER (22s of standing still per failure was too slow),
# give the long walk home lateral escape routes, and let deliberate swims be deliberate.
import sys

F = 'bot.js'
s = open(F, encoding='utf8').read()
done = []

def sub(name, old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        print('!! %-18s found %d (expected %d)' % (name, n, count)); sys.exit(1)
    s = s.replace(old, new, count); done.append(name)

# ---- 1. responsive thinking budget: a 20-block step must not cost 22 seconds ----
sub('pftune', """    pf.thinkTimeout = dist > 90 ? 9000 : dist > 40 ? 7000 : dist > 16 ? 5000 : 3500""",
    """    pf.thinkTimeout = dist > 90 ? 8000 : dist > 40 ? 5500 : dist > 16 ? 4000 : 2500""")

sub('budget', """  const t0 = Date.now()
  pfTune(b, dist)""",
    """  const t0 = Date.now()
  // the whole retry ladder has to fit in a budget that scales with the hop: standing still
  // for 22s while mobs close in is exactly the "does nothing" behaviour the owner called out.
  const budget = Math.min(11000, 1600 + dist * 80)
  pfTune(b, dist)""")

sub('budget-use', """    stats.pfFail = (stats.pfFail || 0) + 1
    const budget = 22000
    // 1) relax the arrival radius: rough jungle terrain is often 3 blocks off "exactly here"
    for (const r of [4, 8, 14]) {""",
    """    stats.pfFail = (stats.pfFail || 0) + 1
    // 1) relax the arrival radius: rough jungle terrain is often 3 blocks off "exactly here"
    for (const r of [6, 12]) {""")

sub('detour-offs', """    for (const side of [1, -1]) {
      for (const off of [6, 12, 20]) {""",
    """    for (const side of [1, -1]) {
      for (const off of [8, 18]) {""")

# ---- 2. the long walk home gets its own lateral routes ----
sub('homehop', """      const step = Math.min(64, d)
      log('HOME_HOP #' + hops + ' d=' + d.toFixed(0) + ' -> ' + Math.round(p.x + ux * step) + ',' + Math.round(p.z + uz * step))
      try { b.pathfinder.setGoal(null) } catch (e) {}
      // BUG #5: goto() throws "No path to the goal!" and we just stood there. Shrink the
      // hop until something is reachable, and if nothing is, stop and let combat/director
      // handle it instead of looping in place.
      let ok = false
      for (const frac of [1, 0.5, 0.25]) {
        const g = new goals.GoalNear(p.x + ux * step * frac, anchor.y, p.z + uz * step * frac, 4)
        ok = await b.pathfinder.goto(g).then(() => true).catch(() => false)
        if (ok) break
      }
      if (!ok) { log('HOME_HOP blocked at ' + pos(b) + ' - giving up this hop'); break }""",
    """      const step = Math.min(44, d)
      const qx = -uz, qz = ux                    // perpendicular: the way around a ridge
      log('HOME_HOP #' + hops + ' d=' + d.toFixed(0) + ' -> ' + Math.round(p.x + ux * step) + ',' + Math.round(p.z + uz * step))
      try { b.pathfinder.setGoal(null) } catch (e) {}
      // BUG #5: goto() throwing "No path to the goal!" used to end the walk and leave us
      // standing in the open. Now each hop is tried shorter, then sideways around whatever
      // blocks it, and only then do we hand control back to the director.
      const tries = []
      for (const frac of [1, 0.6, 0.3]) tries.push([ux * step * frac, uz * step * frac, 5])
      for (const side of [1, -1]) for (const off of [10, 20]) tries.push([ux * step * 0.6 + qx * off * side, uz * step * 0.6 + qz * off * side, 4])
      let ok = false
      for (const t of tries) {
        if (!b.entity || !b.isAlive || Date.now() > homeWalkUntil) break
        const g = new goals.GoalNear(p.x + t[0], anchor.y, p.z + t[1], t[2])
        ok = await b.pathfinder.goto(g).then(() => true).catch(() => false)
        if (ok) break
      }
      if (!ok) { log('HOME_HOP blocked at ' + pos(b) + ' d=' + d.toFixed(0) + ' - director takes over'); break }""")

# ---- 3. a deliberate swim stays deliberate ----
sub('swim-intent', """      const panic = w.head || wetFor > 7000 || (air !== null && air < 9)
      if (!panic) return""",
    """      const panic = w.head || wetFor > 7000 || (air !== null && air < 9)
      if (!panic) return
      // crossing a cove on purpose is fine - unless our head is under (then air wins)
      try {
        const g = b.__lastGoal
        if (g && !w.head && Math.hypot(g.x - b.entity.position.x, g.z - b.entity.position.z) < 10) {
          const gb = b.blockAt(new Vec3(Math.floor(g.x), Math.floor(g.y), Math.floor(g.z)))
          if (gb && /water/.test(gb.name)) return
        }
      } catch (e) {}""")

# ---- 4. the ladder must not shrink the search forever ----
sub('pfadapt-floor', """      b.__pfFailStreak = (b.__pfFailStreak || 0) + 1
      const ns = Math.max(48, Math.round((pf.searchRadius || 100) * 0.75))""",
    """      b.__pfFailStreak = (b.__pfFailStreak || 0) + 1
      // 48 is the floor: below that A* cannot even see a route around a hill, and every
      // failure would then look like "unreachable" when it is only "not searched far enough"
      const ns = Math.max(48, Math.round((pf.searchRadius || 100) * 0.75))""")

open(F, 'w', encoding='utf8').write(s)
print('OK patch13 applied:', len(done), 'edits:', ', '.join(done))
