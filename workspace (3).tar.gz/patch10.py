# -*- coding: utf-8 -*-
# Survival hardening: (1) burst-damage panic retreat, (2) no new fights below 12 hp,
# (3) remember what we dropped on death and run back for it while it still exists.
import io, sys
src = io.open('bot.js', encoding='utf-8').read()

def rep(old, new, tag=''):
    global src
    if src.count(old) != 1:
        print('MISS/DUP %s (%d)' % (tag, src.count(old)))
        sys.exit(1)
    src = src.replace(old, new, 1)
    print('ok    %s' % tag)

rep("""  if (hp < 6) { if (b.__fighting) stopFight(b); return }          // hopeless, let survival logic run""",
"""  if (hp < 6) { if (b.__fighting) stopFight(b); return }          // hopeless, let survival logic run
  // burst-damage panic: 6+ hearts lost inside 4s means this fight ends with our death,
  // however good our own dps looks - break off and let the flee/hide logic do its job
  if (!b.__dmgBuf || now - 4000 > (b.__dmgBuf.t0 || 0)) b.__dmgBuf = { t0: now, hp0: hp }
  if (hp < (b.__dmgBuf.hp0 || 20) - 5) {
    if (b.__fighting) { log('FIGHT_PANIC', (b.__fightName || '?') + ' hp=' + Math.round(hp)); stopFight(b) }
    b.__dmgBuf = { t0: now, hp0: hp }
    return
  }
  // a brand new engagement only while healthy; a mob already in our face is fair game
  if (!b.__fighting && hp < 12 && bestWeapon(b) && !fightTarget(b, 3.2)) return""",
    tag='panic retreat + healthy-only engage')

rep("""  b.on('death', () => { stats.deaths++; saveStats();""",
"""  b.on('death', () => { stats.deaths++; try {
      const carry = b.inventory.items().filter(i => i && i.name).map(i => i.name + 'x' + i.count)
      const gear = carry.filter(s => /sword|pickaxe|axe|ingot|helmet|chestplate|leggings|boots|planks|log/.test(s))
      if (gear.length && b.entity) {
        b.__dropRun = { x: b.entity.position.x, y: b.entity.position.y, z: b.entity.position.z, t: Date.now(), gear: gear.slice(0, 6).join(',') }
        log('DROP_AT ' + Math.round(b.__dropRun.x) + ' ' + Math.round(b.__dropRun.y) + ' ' + Math.round(b.__dropRun.z) + ' [' + b.__dropRun.gear + ']')
        // items live ~5 minutes: once we are back on our feet, sprint there and loot ourselves
        setTimeout(() => {
          try {
            const dr = b.__dropRun
            if (!dr || !b.entity || !b.isAlive) return
            if (Date.now() - dr.t > 165000) { b.__dropRun = null; return }
            const d = Math.hypot(b.entity.position.x - dr.x, b.entity.position.z - dr.z)
            if (d > 80 || d < 5) return
            if (b.health < 19 || (b.food || 20) < 15) return
            log('DROP_RUN back ' + d.toFixed(0) + ' blocks for [' + dr.gear + ']')
            b.pathfinder.setGoal(new goals.GoalNear(dr.x, dr.y, dr.z, 4))
            setTimeout(() => { try { collectNear(b, 18) } catch (e) {} }, 7000)
            setTimeout(() => { try { collectNear(b, 22); b.__dropRun = null } catch (e) {} }, 16000)
          } catch (e) {}
        }, 9000)
      }
    } catch (e) {}
    saveStats();""", tag='drop memory + recovery run')

io.open('bot.js', 'w', encoding='utf-8').write(src)
print('done')
