# -*- coding: utf-8 -*-
# Custom-name detection: in 1.21 the display name lives in item.customName as a parsed
# nbt compound ({value:{extra:{value:[{value:{text:{value:"Наши проекты #4"}}]}}}}) and
# String(customName) is "[object Object]" - so nothing ever matched. Serialize properly.
import io, sys
src = io.open('bot.js', encoding='utf-8').read()

def rep(old, new, tag=''):
    global src
    if src.count(old) != 1:
        print('MISS/DUP %s (%d)' % (tag, src.count(old))); sys.exit(1)
    src = src.replace(old, new, 1)
    print('ok    %s' % tag)

FUNC = """// everything a custom name can hide in on 1.21: parsed customName compound, item
// components, legacy nbt - serialized as JSON so we can grep it as text
function itemTextBlob (it) {
  let s = ''
  try { s += String(it.displayName || '') } catch (e) {}
  try { s += '|' + JSON.stringify(it.customName || null) } catch (e) {}
  try { s += '|' + JSON.stringify(it.componentMap || null) } catch (e) {}
  try { s += '|' + JSON.stringify(it.components || null) } catch (e) {}
  try { s += '|' + JSON.stringify(it.nbt || null) } catch (e) {}
  try { s += '|' + it.name } catch (e) {}
  return s.toLowerCase()
}
function prettyName (it) {
  try {
    const c = it.customName
    if (typeof c === 'string') return c
    const v = c && c.value ? c.value : c
    if (v && v.extra && v.extra.value && v.extra.value.length) {
      const first = v.extra.value[0]
      const t = first && first.text ? (first.text.value !== undefined ? first.text.value : first.text) : JSON.stringify(first)
      return String(t)
    }
    if (v && v.text) return String(v.text.value !== undefined ? v.text.value : v.text)
  } catch (e) {}
  return String(it.displayName || it.name || '')
}

"""

rep("const CASSETTE = (process.env.PUFF_CASSETTE || 'наши проекты #4').toLowerCase()",
    FUNC + "const CASSETTE = (process.env.PUFF_CASSETTE || 'наши проекты #4').toLowerCase()",
    tag='helpers inserted')

rep("""    for (const it of b.inventory.items()) {
      let s = ''
      try { s = String(it.customName || '') } catch (e) {}
      try { s += '|' + JSON.stringify(it.nbt || {}) } catch (e) {}
      if (s.toLowerCase().indexOf(CASSETTE) >= 0) return it
    }""",
"""    for (const it of b.inventory.items()) {
      if (itemTextBlob(it).indexOf(CASSETTE) >= 0) return it
    }""", tag='findCassette matcher')

rep("""      for (const it of b.inventory.items()) {
        let s = ''
        try { s = String(it.customName || '') } catch (e) {}
        try { s += '|' + JSON.stringify(it.nbt || {}) } catch (e) {}
        if (s.toLowerCase().indexOf(q) >= 0) out.push('slot' + it.index + ' ' + it.name + ' x' + it.count + ' name=' + (String(it.customName || '').slice(0, 48) || '(in nbt)'))
      }""",
"""      for (const it of b.inventory.items()) {
        if (itemTextBlob(it).indexOf(q) >= 0) out.push('slot' + it.index + ' ' + it.name + ' x' + it.count + ' name=' + prettyName(it).slice(0, 60))
      }""", tag='named matcher')

rep("""      for (const i2 of b.inventory.items()) {
        let s = String(i2.customName || '') + '|' + JSON.stringify(i2.nbt || {})
        if (s.toLowerCase().indexOf(q) >= 0 || i2.name === args[0]) { it = i2; break }
      }""",
"""      for (const i2 of b.inventory.items()) {
        if (itemTextBlob(i2).indexOf(q) >= 0 || i2.name === args[0]) { it = i2; break }
      }""", tag='toss matcher')

rep("log('TOSS', it.name + ' -> ' + (pl.username || pl.name)",
    "log('TOSS', prettyName(it).slice(0, 40) + ' -> ' + (pl.username || pl.name)",
    tag='toss log name')
rep("return respond(sock, 'OK threw it to ' + (pl.username || pl.name))",
    "return respond(sock, 'OK threw \"' + prettyName(it).slice(0, 40) + '\" to ' + (pl.username || pl.name))",
    tag='toss response name')

io.open('bot.js', 'w', encoding='utf-8').write(src)
print('done')
