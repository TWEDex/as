#!/usr/bin/env python3
# patch22: a house is not a home until we sleep in it. Without a bed the server keeps
# respawning Puff at world spawn = the zombie nest, which is where the 500+ death loop and
# every lost inventory came from. So: as soon as the hut is finished, put the bed the players
# gave us inside and sleep - that moves the respawn point home, no /spawnpoint, no op.
import sys

F = 'bot.js'
s = open(F, encoding='utf8').read()
done = []

def sub(name, old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        print('!! %-16s found %d (expected %d)' % (name, n, count)); sys.exit(1)
    s = s.replace(old, new, count); done.append(name)

sub('bed-fn', """async function buildHut (b) {""",
    """// Sleeping in a bed is the only op-free way to move a respawn point on vanilla servers.
async function bedInsideHut (b, site, y0) {
  try {
    const bed = b.inventory.items().find(i => /_bed$/.test(i.name))
    if (!bed) { log('BED none carried - ask the players for 3 wool (3 wool + 3 planks = bed)'); return false }
    const cx = Math.floor(site.x), cy = Math.floor(y0), cz = Math.floor(site.z)
    const reached = await b.pathfinder.goto(new goals.GoalNear(cx + 1.5, cy, cz + 0.5, 1)).then(() => true).catch(() => false)
    await sleep(400)
    if (!b.entity) return false
    const f = b.entity.position.floored()
    let ref = b.blockAt(f.offset(0, -1, 0))
    if (!ref || ref.boundingBox !== 'block') ref = b.blockAt(f.offset(0, -2, 0))
    if (!ref || ref.boundingBox !== 'block') { log('BED no floor under us at ' + f + ' reached=' + reached); return false }
    try { await b.equip(bed, 'hand') } catch (e) {}
    let ok = await withTimeout(b.placeBlock(ref, new Vec3(0, 1, 0)), 6000, false)
    if (!ok) {
      for (const fv of [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]]) {
        const side = b.blockAt(f.offset(fv[0], -1, fv[2]))
        if (!side || side.boundingBox !== 'block') continue
        ok = await withTimeout(b.placeBlock(side, new Vec3(-fv[0], 1, -fv[2])), 5000, false)
        if (ok) break
      }
    }
    const ids = Object.keys(mcData.blocksByName).filter(n => /_bed$/.test(n)).map(n => mcData.blocksByName[n].id)
    const ps = b.findBlocks({ matching: ids, maxDistance: 10, count: 2 })
    log('BED placed=' + !!ok + ' found=' + (ps.length ? String(ps[0]) : 'none') + ' reached=' + reached + ' at ' + pos(b))
    if (!ps.length) return false
    const bp = ps[0]
    if (!fin3(bp)) { log('BED bad position'); return false }
    try { await b.lookAt(new Vec3(bp.x + 0.5, bp.y + 0.5, bp.z + 0.5), true) } catch (e) {}
    await sleep(300)
    let slept = false
    try {
      await withTimeout(b.useBlock(bp, { faces: [new Vec3(0, 0, 1), new Vec3(0, 0, -1), new Vec3(1, 0, 0), new Vec3(-1, 0, 0)] }), 6000, false)
      slept = true
    } catch (e) { log('BED_USE_ERR', e && e.message) }
    HOME = { x: cx, y: cy, z: cz }
    try { saveHome() } catch (e) {}
    log('BED slept=' + slept + ' respawn should now be home at ' + cx + ' ' + cy + ' ' + cz)
    try {
      const tool = b.inventory.items().find(i => /sword|axe|pickaxe/.test(i.name))
      if (tool) await b.equip(tool, 'hand')
    } catch (e) {}
    return slept
  } catch (e) { log('BED_ERR', e && e.message); return false }
}

async function buildHut (b) {""")

sub('bed-hook', """  log('BUILD hut done placed=' + placed + ' failed=' + failed + ' home=' + site.x + ' ' + site.y + ' ' + site.z)
  return placed >= 18""",
    """  log('BUILD hut done placed=' + placed + ' failed=' + failed + ' home=' + site.x + ' ' + site.y + ' ' + site.z)
  // finish the house = make it the place we come back to after a death
  if (placed >= 18) { try { await bedInsideHut(b, site, y0) } catch (e) { log('BED_ERR', e && e.message) } }
  return placed >= 18""")

open(F, 'w', encoding='utf8').write(s)
print('OK patch22 applied:', len(done), 'edits:', ', '.join(done))
