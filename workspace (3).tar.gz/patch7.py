# -*- coding: utf-8 -*-
import io, sys
src = io.open('bot.js', encoding='utf-8').read()
def rep(old, new, tag=''):
    global src
    if src.count(old) < 1:
        print('MISS %s' % tag); sys.exit(1)
    src = src.replace(old, new); print('ok    %s x%d' % (tag, src.count(new)))
rep("b.tossItem(findCassette(b) || it, 1)", "(await ? 0 : 0)", tag='noop') if False else None
rep("b.tossItem(it, 1)", "b.tossStack(it)", tag='toss cmd')
rep("b.tossItem(findCassette(b) || it, 1)", "(function(){})()", tag='noop2') if False else None
src = src.replace("try { b.tossItem(findCassette(b) || it, 1); log('CASSETTE_GIVEN'", "try { const cur = findCassette(b) || it; b.tossStack(cur); log('CASSETTE_GIVEN'")
io.open('bot.js', 'w', encoding='utf-8').write(src)
print('done')
