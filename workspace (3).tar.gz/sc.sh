#!/bin/bash
sshpass -p 1507 ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -p 22222 agent@186.246.50.215 "$@"
