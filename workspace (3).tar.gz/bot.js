const mineflayer = require('mineflayer')
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder')
// Owner order: bot must not break blocks anymore (players rescue it). MC_NODIG=off re-enables.
const NO_DIG = process.env.MC_NODIG !== 'off'
const collectblock = require('mineflayer-collectblock')
const autoeat = require('mineflayer-auto-eat')
process.on('unhandledRejection', e => log('UNH_REJ', e && e.message ? e.message : String(e)))
process.on('uncaughtException', e => log('UNCAUGHT', e && e.message ? e.message : String(e)))
const Vec3 = require('vec3')
const net = require('net')
const fs = require('fs')

const HOST = process.env.MC_HOST || 'lokomir.twdx.ru'
const PORT = parseInt(process.env.MC_PORT || '25566', 10)
const VERSION = process.env.MC_VERSION || '1.21.11'
const USERNAME = process.env.MC_USER || 'GLaDOS'
const AUTH = process.env.MC_AUTH || 'offline'
const LOG = '/home/agent/bot/bot.log'
const CONTROL_PORT = parseInt(process.env.CONTROL_PORT || '25590', 10)

let mcData
try { mcData = require('minecraft-data')(VERSION) } catch (e) { mcData = null }
const nbt = require('prismarine-nbt')
const AUTH_PASS = process.env.MC_PASS || 'Puffberry2026x'
function varintBuf (value) { const b = []; do { let t = value & 0x7f; value >>>= 7; if (value !== 0) t |= 0x80; b.push(t) } while (value !== 0); return Buffer.from(b) }
function stringBuf (s) { const sb = Buffer.from(s, 'utf8'); return Buffer.concat([varintBuf(sb.length), sb]) }
function ccaPacketId (state) {
  try { const pk = mcData.protocol[state].toServer.types.packet; const m = pk[1][0].type[1].mappings; for (const k in m) { if (m[k] === 'custom_click_action') return parseInt(k, 16) } } catch (e) {}
  return state === 'play' ? 0x41 : 0x08
}

function log (...a) {
  const line = new Date().toISOString().slice(11, 19) + ' ' + a.map(x => typeof x === 'string' ? x : JSON.stringify(x)).join(' ')
  try { fs.appendFileSync(LOG, line + '\n') } catch (e) {}
  for (const s of clients) { try { s.write(line + '\n') } catch (e) {} }
}

const clients = new Set()
let bot = null
let reconnects = 0
let stableSince = 0       // when the current connection spawned - a long healthy run resets the backoff
let lastEndReason = ''    // why the connection dropped (kick / error / eof)
// backoff for reconnect streaks: the first drop is quick, a broken streak waits minutes
const RECONNECT_DELAYS = [0, 12000, 45000, 90000, 240000, 600000]
// keep our own position when the server sends a small correction (MC_KEEPPOS=off to disable)
const keepPosOn = String(process.env.MC_KEEPPOS || 'on').toLowerCase() !== 'off'
let stopped = false

function makeBot () {
  const b = mineflayer.createBot({
    host: HOST, port: PORT, version: VERSION, username: USERNAME,
    auth: AUTH, hideErrors: false, checkTimeoutInterval: 60000,
    respawn: true
  })
  b.loadPlugin(pathfinder)
  try { b.loadPlugin(collectblock.plugin) } catch (e) { log('CB_LOAD_ERR', e.message) }
  try { b.loadPlugin(autoeat.loader || autoeat.plugin || autoeat) } catch (e) { log('AE_LOAD_ERR', e.message) }

  // ---- position / teleport shield -------------------------------------------------
  // This server (Paper) re-sends a "player position" packet whenever its idea of our
  // position differs from ours - we measured 2-5 of them PER SECOND while walking and
  // climbing (38122 of them in one log). Mineflayer answers such a packet by ZEROING
  // the velocity, clearing onGround and resetting jumpTicks. That is precisely what
  // made this bot:
  //   * not feel knockback - the impulse was wiped before the physics ever used it,
  //   * bounce against a ledge without ever climbing it - jumpTicks died every 200ms,
  //   * look like it is "jumping but not jumping", standing at a block like an afk bot.
  // node-minecraft-protocol emits the raw 'packet' event BEFORE the named 'position'
  // event, so we can snapshot the exact physics state right before it is destroyed
  // and put it back afterwards.
  b.__syncKeep = 0; b.__syncReal = 0; b.__kb = null
  try {
    let preSync = null
    b._client.on('packet', (data, meta) => {
      try {
        if (!meta || meta.name !== 'position' || !b.entity) return
        preSync = {
          p: b.entity.position.clone(),
          v: b.entity.velocity.clone(),
          g: b.entity.onGround,
          j: b.jumpTicks || 0,
          t: Date.now()
        }
      } catch (e) {}
    })
    // a knockback impulse (hit / explosion) must survive the next position packet
    b._client.on('entity_velocity', (packet) => {
      try {
        if (!b.entity || packet.entityId !== b.entity.id) return
        // mineflayer already applied the impulse to entity.velocity
        b.__kb = { x: b.entity.velocity.x, y: b.entity.velocity.y, z: b.entity.velocity.z, t: Date.now() }
      } catch (e) {}
    })
    b.on('forcedMove', () => {
      try {
        if (!b.entity || !preSync) return
        const now = Date.now()
        const dp = b.entity.position.distanceTo(preSync.p)
        if (dp >= 2.0 || now - preSync.t > 800) { b.__syncReal++; preSync = null; return }  // a real teleport - accept it
        b.__syncKeep++
        // 0) the server's own copy of our position lags behind (it only learns from the
        // movement packets we send). Snapping back to that stale copy is what kept the
        // bot crawling backwards instead of climbing. Keep our own spot for small
        // corrections - the server accepts it as ordinary movement.
        if (keepPosOn && dp < 1.2) {
          try { b.entity.position.copy(preSync.p) } catch (e) {}
        }
        // 1) the impulse is newer than our snapshot -> the packet just wiped it, put it back
        const kb = b.__kb
        if (kb && kb.t > preSync.t) {
          b.entity.velocity.set(kb.x, kb.y, kb.z)
          b.__kb = null
        } else {
          // 2) otherwise restore the velocity the packet destroyed (knockback included)
          b.entity.velocity.set(preSync.v.x, preSync.v.y, preSync.v.z)
        }
        // 3) keep the jump alive - mineflayer resets jumpTicks on every position packet
        if (preSync.j > 0) b.jumpTicks = preSync.j
        // 4) keep the ground contact
        b.entity.onGround = preSync.g
      } catch (e) {}
    })
  } catch (e) { log('SYNCGUARD_ERR', e && e.message) }

  try {
    b._client.on('packet', (data, meta) => { if (!b.entity && meta && meta.name && meta.name !== 'keep_alive') log('PKT', meta.name) })
    b.__inPk = {}; b.__outPk = {}
    b._client.on('packet', (data, meta) => {
      if (!meta || !meta.name) return
      b.__inPk[meta.name] = (b.__inPk[meta.name] || 0) + 1
      if (meta.name === 'position') {
        const sx = typeof data.x === 'number' ? data.x : data.a; const sy = typeof data.y === 'number' ? data.y : data.b; const sz = typeof data.z === 'number' ? data.z : data.c
        if (typeof sx === 'number') {
          b.__srvPos = { x: sx, y: sy, z: sz, t: Date.now() }
          const d = b.__lastTpLog || 0
          if (Date.now() - d > 1000) { b.__lastTpLog = Date.now(); log('SRV_TP', sx.toFixed(2) + ' ' + sy.toFixed(2) + ' ' + sz.toFixed(2)) }
        }
      }
    })
    try { b._client.on('packet_send', (data, meta) => { if (meta && meta.name) b.__outPk[meta.name] = (b.__outPk[meta.name] || 0) + 1 }) } catch (e) {}
    b._client.on('state', (st) => log('STATE', typeof st === 'string' ? st : JSON.stringify(st)))
    b._client.on('add_resource_pack', (packet) => {
      log('ADD_RESOURCE_PACK', JSON.stringify(packet))
      const uuid = packet && packet.uuid
      try {
        b._client.write('resource_pack_receive', { uuid, result: 3 })
        b._client.write('resource_pack_receive', { uuid, result: 0 })
        log('RP_ACCEPT_SENT uuid=' + uuid)
      } catch (e) { log('RP_ERR', e && e.message) }
    })
    b._client.on('remove_resource_pack', (packet) => log('REMOVE_RESOURCE_PACK', JSON.stringify(packet)))
    // MOVED: register after inject_allowed
    // MOVED: register after inject_allowed
  } catch (e) { log('HOOKERR', e && e.message) }

  try {
    b.on('windowOpen', (w) => { try { dumpWindow(w) } catch (e) { log('WDUMP_ERR', e && e.message) } })
    b.on('windowClose', () => { log('WINDOW_CLOSE') })
  } catch (e) { log('WHOOK_ERR', e && e.message) }

  b.once('inject_allowed', () => {
    setupPathfinder(b)
    // Register dialog listeners now that client is ready
    try {
      b._client.on('show_dialog', (packet) => { try { log('SHOW_DIALOG ' + JSON.stringify(packet).slice(0, 4000)) } catch (e) { log('SHOW_DIALOG_ERR ' + (e && e.message)) } setTimeout(() => { try { handleAuthDialog(b, packet) } catch (e) { log('AUTHDLG_ERR ' + (e && e.message)) } }, 700) })
      b._client.on('clear_dialog', () => log('CLEAR_DIALOG'))
    } catch (e) { log('DIALOG_HOOK_ERR', e && e.message) }
  })
  b.once('spawn', () => {
    stableSince = Date.now()
    cautionUntil = Date.now() + 9000
    log('SPAWN', pos(b), 'world=' + (b.world ? 'ok' : '?'))
    setupPathfinder(b)
    try {
      if (b.autoEat) {
        try {
          b.autoEat.setOpts({ priority: 'foodPoints', minHealth: 14, minHunger: 13, eatingTimeout: 5000, strictErrors: false, bannedFood: ['rotten_flesh', 'pufferfish', 'chorus_fruit', 'poisonous_potato', 'spider_eye'] })
        } catch (e) { log('AE_OPTS_ERR', e && e.message) }
        try { b.autoEat.enableAuto(); log('AUTOEAT enabled (v5 API)') } catch (e) { log('AE_ENABLE_ERR', e && e.message) }
      } else { log('AUTOEAT plugin missing') }
    } catch (e) { log('AE_ERR', e.message) }
    try { startReflexes(b) } catch (e) { log('REFLEX_ERR', e && e.message) }
    try { anchorOf(b); reanchorIfFar(b); startLeash(b) } catch (e) { log('ANCHOR_ERR', e && e.message) }
    wrapLook(b)
    try { startCombat(b) } catch (e) { log('COMBAT_ERR', e && e.message) }
    try { startNaNProbe(b) } catch (e) { log('NANPROBE_ERR', e && e.message) }
    try { startCassette(b) } catch (e) { log('CASSETTE_HOOK_ERR', e && e.message) }
    try { startStuckGuard(b) } catch (e) { log('SG_ERR', e && e.message) }
    try { startHeartbeat(b) } catch (e) { log('HB_ERR', e && e.message) }
    try { startAutoJump(b) } catch (e) { log('AJ_ERR', e && e.message) }
    try { startInputSync(b) } catch (e) { log('IS_ERR', e && e.message) }
    announceLoaded(b)
    try { b.__puffBrain = { addressedToMe, composeReply, topicOf, norm } } catch (e) {}
    if (process.env.MC_AUTOFREE === 'on') autoFree(b)
    try { healAnchor() } catch (e) { log('ANCHOR_HEAL_ERR', e && e.message) }
    try { startDirector(b) } catch (e) { log('DIRECTOR_ERR', e && e.message) }
    try { startAudit(b) } catch (e) { log('AUDIT_ERR', e && e.message) }
    try { startWaterSafety(b) } catch (e) { log('WATERSAFE_ERR', e && e.message) }
  })
  // PERSISTENT spawn listener: mineflayer emits 'spawn' on EVERY respawn, but the
  // handler above is once(). The server respawns us right back into the mob nest we
  // died in - without an immediate escape run it is an endless death loop.
  b.__spawnCount = 0
  b.on('spawn', async () => {
    try {
      b.__spawnCount++
      if (b.__spawnCount <= 1) return                  // first login: once() handler covers it
      log('RESPAWN #' + (b.__spawnCount - 1) + ' at', pos(b))
      // do NOT re-anchor from the respawn point: the respawn point is the nest.
      try {
        if (b.entity && fin3(b.entity.position) && nearBadXZ(b.entity.position.x, b.entity.position.z)) {
          log('RESPAWN_IN_GRINDER -> running home, leash holds off 75s (old anchor ' + (anchor ? Math.round(anchor.x) + ',' + Math.round(anchor.z) : '?') + ')')
          homeRunUntil = Date.now() + 75000
          walkHomeLong(b)
        } else {
          reanchorIfFar(b)
        }
      } catch (e) {}
      cautionUntil = Math.max(cautionUntil, Date.now() + 25000)
      const src = b.__deathPos || (b.entity ? b.entity.position.clone() : null)
      b.__deathPos = null
      mission = null
      // nest respawn: bury in place instead of running the mob gauntlet
      const sp0 = b.entity ? b.entity.position : null
      const nearNest = sp0 && (Math.hypot(sp0.x - NEST.x, sp0.z - NEST.z) < 30 || inDeathZone(sp0.x, sp0.z, 25))
      if (nearNest) {
        log('RESPAWN bury at', pos(b))
        if (await buryAtSpawn(b)) return
      }
      // instant raw sprint toward the most open away-direction (no time to wait for pathing)
      const ep = src ? escapePointFrom(b, src, 40) : null
      if (ep && b.entity) {
        const yaw = Math.atan2(-(ep.x - b.entity.position.x), ep.z - b.entity.position.z)
        try { b.look(yaw, 0, true) } catch (e) {}
        // only a brief lock so look+sprint settle; autoJump MUST stay active afterwards -
        // the old 6s lock stalled the sprint on every jungle step = respawn death spiral
        jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 800)
        b.__respawnSprintUntil = Date.now() + 15000
        try { b.setControlState('forward', true); b.setControlState('sprint', true) } catch (e) {}
        setTimeout(() => {
          try {
            b.setControlState('forward', false); b.setControlState('sprint', false)
            if (!b.entity || b.health <= 0 || mission) return
            const th = nearestHostile(b, 24)
            const src2 = (th && th.position) || src || b.entity.position
            const ep2 = escapePointFrom(b, src2, 55)
            if (ep2) { log('RESPAWN_RUN to ' + ep2.x + ' ' + ep2.z + (th ? ' (away from ' + th.name + ')' : '')); b.pathfinder.setGoal(new goals.GoalXZ(ep2.x, ep2.z)) }
          } catch (e) {}
        }, 2500)
      }
    } catch (e) { log('RESPAWN_ERR', e && e.message) }
  })
  b.on('kicked', reason => { log('KICKED', reason); lastEndReason = 'kick: ' + reason })
  b.on('error', err => log('ERROR', err && err.message ? err.message : String(err)))
  b.on('end', (reason) => {
    log('END (disconnected)')
    try { if (b.__director) clearInterval(b.__director) } catch (e) {}
    try { if (b.__reflex) clearInterval(b.__reflex) } catch (e) {}
    try { if (b.__ajump) clearInterval(b.__ajump) } catch (e) {}
    try { if (b.__stuckGuard) clearInterval(b.__stuckGuard) } catch (e) {}
    try { if (b.__hb) clearInterval(b.__hb) } catch (e) {}
    try { if (b.__inputTimer) clearInterval(b.__inputTimer) } catch (e) {}
    try { if (b.__loadedTimer) clearInterval(b.__loadedTimer) } catch (e) {}
    // COMBAT/LEASH/CASSETTE were missing here: a dead client kept swinging and dragging
    // goals around for hours (two "Puffs" inside one process, phantom positions in the log)
    try { if (b.__combat) clearInterval(b.__combat); b.__combat = null } catch (e) {}
    try { if (b.__leash) clearInterval(b.__leash); b.__leash = null } catch (e) {}
    try { if (b.__cassette) clearInterval(b.__cassette); b.__cassette = null } catch (e) {}
    try { if (b.__reflex) { clearInterval(b.__reflex); b.__reflex = null } } catch (e) {}
    if (!stopped) {
      // Reconnect policy: a streak of failures backs off hard instead of hammering the
      // server every 3 seconds (that is what the user called "reconnect spam"). A session
      // that stayed up for 5+ minutes counts as healthy, so the next drop starts over.
      const healthy = stableSince && (Date.now() - stableSince) > 300000
      reconnects = healthy ? 1 : reconnects + 1
      const isKick = /kick/i.test(lastEndReason)
      const delay = isKick
        ? Math.max(RECONNECT_DELAYS[Math.min(reconnects, RECONNECT_DELAYS.length - 1)], 60000)
        : RECONNECT_DELAYS[Math.min(reconnects, RECONNECT_DELAYS.length - 1)]
      log('reconnect #' + reconnects + ' in ' + Math.round(delay / 1000) + 's (reason: ' + (lastEndReason || '?') + ')')
      setTimeout(() => { if (!stopped) { bot = makeBot() } }, delay)
    }
  })
  b.on('chat', (user, msg) => { if (user !== USERNAME) { log('CHAT', user + ': ' + msg); try { feedChat(b, user, msg, false) } catch (e) {} } })
  b.on('whisper', (user, msg) => { log('WHISPER', user + ': ' + msg); try { feedChat(b, user, msg, true) } catch (e) {} })
  b.on('messagestr', (msg) => {
    log('MSG', msg)
    // The server says exactly how we died ("Puff was slain by Zombie"); entityHurt gives no
    // source in this mineflayer, so this is the only reliable cause. Without it I kept
    // guessing: 534 deaths and no idea which hazard to fix first.
    try {
      if (/Puff/.test(msg) && /slain by|killed by|shot by|fired by|struck by|drowned|suffocated|fell from|went too deep|burned to death|was squashed|died|magic|expired|tried to swim in lava|was blown/i.test(msg)) {
        let c = 'env'
        let m = msg.match(/(?:slain by|killed by|shot by|fired by|struck by)\s*([A-Za-z' _]{2,24})/i)
        if (m) c = m[1].trim().split(/[\s(]+/)[0].toLowerCase()
        else if (/drowned|suffocat/.test(msg)) c = 'drown'
        else if (/lava/.test(msg)) c = 'lava'
        else if (/fell from|high place/.test(msg)) c = 'fall'
        else if (/too deep/.test(msg)) c = 'void'
        else if (/burned/.test(msg)) c = 'burn'
        else if (/blown|explos/.test(msg)) c = 'creeper'
        else if (/magic/.test(msg)) c = 'magic'
        lastDeathCause = c
        log('DEATH_MSG cause=' + c + ' :: ' + msg)
      }
    } catch (e) {}
    try { if (/Successful login|Logged-in due to Session/i.test(msg)) { b.__authOk = Date.now(); log('AUTH ok - movement unfrozen') } } catch (e) {}
    try { if (/^[<(]/.test(msg)) { const m = msg.match(/^[<(]([^>)>]{1,24})[>)>]\s*(.+)$/); if (m) feedChat(b, m[1].trim(), m[2], false) } } catch (e) {}
    const pw = process.env.MC_PASSWORD || ''
    if (pw && /login|register|авториз|пароль|\/reg|\/login/i.test(msg)) {
      if (!b.__registered) { b.chat('/register ' + pw + ' ' + pw); b.__registered = true; log('AUTH register sent') } else { b.chat('/login ' + pw); log('AUTH login sent') }
    }
  })
  b.on('blockBreakProgressUpdate', () => { lastDigAt = Date.now() })
  b.on('blockBreakProgressEnd', () => { lastDigAt = Date.now() })
  b.on('entityHurt', (e) => { try { if (e === b.entity) { lastHurtAt = Date.now(); log('HURT hp=' + Math.round(b.health) + ' food=' + Math.round(b.food)) } } catch (er) {} })
  b.on('login', () => log('LOGIN event (play state)'))
  try { b.on('entitySpawn', () => {}) } catch (e) {}
  b.on('death', () => { stats.deaths++; try {
      // BUG #7: we had 523 deaths and no idea what killed us. Attribute it: a mob that
      // hit us in the last 8s, else starvation, else the environment.
      lastDeathCause = (b.__lastHurtBy && Date.now() - (b.__lastHurtAt || 0) < 9000) ? b.__lastHurtBy
        : ((b.food || 20) <= 2 ? 'starvation' : (b.__inWater ? 'drown/water' : 'unknown'))
      log('DEATH_CAUSE ' + lastDeathCause + ' hp=0 food=' + Math.round(b.food) + ' at ' + pos(b))
      const carry = b.inventory.items().filter(i => i && i.name).map(i => i.name + 'x' + i.count)
      const gear = carry.filter(s => /sword|pickaxe|axe|ingot|helmet|chestplate|leggings|boots|planks|log/.test(s))
      if (gear.length && b.entity) {
        b.__dropRun = { x: b.entity.position.x, y: b.entity.position.y, z: b.entity.position.z, t: Date.now(), gear: gear.slice(0, 6).join(',') }
        log('DROP_AT ' + Math.round(b.__dropRun.x) + ' ' + Math.round(b.__dropRun.y) + ' ' + Math.round(b.__dropRun.z) + ' [' + b.__dropRun.gear + ']')
        // items live ~5 minutes: once we are back on our feet, sprint there and loot ourselves
        setTimeout(() => {
          try {
            const dr = b.__dropRun
            if (!dr || !b.entity || !b.isAlive) return
            if (Date.now() - dr.t > 165000) { b.__dropRun = null; return }
            const d = Math.hypot(b.entity.position.x - dr.x, b.entity.position.z - dr.z)
            if (d > 80 || d < 5) return
            if (b.health < 19 || (b.food || 20) < 15) return
            log('DROP_RUN back ' + d.toFixed(0) + ' blocks for [' + dr.gear + ']')
            b.pathfinder.setGoal(new goals.GoalNear(dr.x, dr.y, dr.z, 4))
            setTimeout(() => { try { collectNear(b, 18) } catch (e) {} }, 7000)
            setTimeout(() => { try { collectNear(b, 22); b.__dropRun = null } catch (e) {} }, 16000)
          } catch (e) {}
        }, 9000)
      }
    } catch (e) {}
    saveStats(); cautionUntil = Date.now() + 18000; lastHurtAt = 0; try { b.__deathPos = b.entity ? b.entity.position.clone() : null } catch (e) {}; try { noteDeathZone(b.__deathPos) } catch (e) {}; try { mission = null } catch (e) {}; try { b.pathfinder.setGoal(null) } catch (e) {}; log('DIED, respawning (total ' + stats.deaths + ')') })
  b.on('health', () => {})
  setTimeout(() => {
    if (!b.entity) {
      const st = b._client ? b._client.state : '?'
      log('STILL_CONNECTING state=' + st + ' ended=' + (b._client ? b._client.ended : '?'))
    }
  }, 9000)
  return b
}

function pos (b) {
  if (!b || !b.entity) return 'n/a'
  const p = b.entity.position
  return Math.floor(p.x) + ' ' + Math.floor(p.y) + ' ' + Math.floor(p.z)
}

function respond (sock, text) { try { sock.write(text + '\n') } catch (e) {} }

function sleep (ms) { return new Promise(r => setTimeout(r, ms)) }
function withTimeout (p, ms, val) { return Promise.race([Promise.resolve(p).catch(() => val), sleep(ms).then(() => val)]) }

function chatText (c) {
  if (c == null) return ''
  if (typeof c === 'string') {
    const t = c.trim()
    if (t.startsWith('{') || t.startsWith('[')) { try { return chatText(JSON.parse(t)) } catch (e) { return c } }
    return c
  }
  if (typeof c.toPlainText === 'function') { try { return c.toPlainText() } catch (e) {} }
  if (typeof c.toString === 'function') { try { const s = c.toString(); if (s && s !== '[object Object]') return s } catch (e) {} }
  let s = ''
  if (typeof c.text === 'string') s += c.text
  if (typeof c.translate === 'string') s += c.translate
  if (Array.isArray(c.extra)) for (const e of c.extra) s += chatText(e)
  return s
}
function dumpWindow (w) {
  if (!w) { log('WINDOW none'); return }
  let title = ''
  try { title = chatText(w.title) } catch (e) { title = String(w.title) }
  const parts = []
  for (let i = 0; i < w.slots.length; i++) {
    const it = w.slots[i]
    if (it) {
      let dn = ''
      try { dn = chatText(it.displayName) || it.displayName || '' } catch (e) { dn = it.displayName || '' }
      parts.push(i + '=' + it.name + (dn && dn !== it.name ? '("' + dn + '")' : '') + 'x' + it.count)
    }
  }
  log('WINDOW_OPEN title="' + title + '" type=' + w.type + ' id=' + w.id + ' slots=' + w.slots.length)
  log('WINDOW_ITEMS ' + (parts.length ? parts.join(' | ') : '(empty)'))
}
function sendCustomClickAction (b, id, payloadObj) {
  try {
    const client = b._client
    const state = client.state || 'configuration'
    const parts = [varintBuf(ccaPacketId(state)), stringBuf(id)]
    let nbtLen = 0
    if (payloadObj) {
      const nbtBytes = nbt.proto.createPacketBuffer('anonymousNbt', payloadObj)
      nbtLen = nbtBytes.length
      parts.push(varintBuf(nbtLen), nbtBytes)
    } else {
      parts.push(varintBuf(0))
    }
    const raw = Buffer.concat(parts)
    client.writeRaw(raw)
    log('DIALOG_RESP sent id=' + id + ' state=' + state + ' nbtLen=' + nbtLen + ' rawLen=' + raw.length)
    return true
  } catch (e) { log('DIALOG_RESP_ERR ' + (e && e.message ? e.message : String(e))); return false }
}
function handleAuthDialog (b, packet) {
  const dialog = packet && packet.dialog && packet.dialog.value ? packet.dialog.value : null
  if (!dialog) { log('AUTHDLG no dialog body'); return }
  const actions = (dialog.actions && dialog.actions.value && dialog.actions.value.value) || []
  const inputs = (dialog.inputs && dialog.inputs.value && dialog.inputs.value.value) || []
  const inputKeys = inputs.map(i => (i && i.key && i.key.value) || null).filter(Boolean)
  let submitId = null
  for (const a of actions) { const idv = a && a.action && a.action.value && a.action.value.id && a.action.value.id.value; if (idv && !/cancel/i.test(idv) && /submit|register|login|confirm|enter|ok/i.test(idv)) { submitId = idv; break } }
  if (!submitId) { for (const a of actions) { const idv = a && a.action && a.action.value && a.action.value.id && a.action.value.id.value; if (idv && !/cancel/i.test(idv)) { submitId = idv; break } } }
  if (!submitId) { log('AUTHDLG no submit action found'); return }
  const payload = { type: 'compound', value: {} }
  for (const k of inputKeys) payload.value[k] = { type: 'string', value: AUTH_PASS }
  log('AUTHDLG submit id=' + submitId + ' inputs=[' + inputKeys.join(',') + ']')
  sendCustomClickAction(b, submitId, inputKeys.length ? payload : null)
}

// how close each mob has to be before it is actually a problem
const THREAT = {
  creeper: 6, zombie: 9, husk: 9, drowned: 9, zombie_villager: 9, zombified_piglin: 9,
  spider: 10, cave_spider: 10, silverfish: 6, slime: 8, magma_cube: 8,
  skeleton: 20, stray: 20, bogged: 20, wither_skeleton: 11, pillager: 20, witch: 17,
  blaze: 15, evoker: 15, vindicator: 10, vex: 10, breeze: 13,
  enderman: 5, phantom: 9, warden: 26, hoglin: 10, zoglin: 10, piglin_brute: 10
}
function threatRadius (name) { return THREAT[String(name || '').toLowerCase()] || 9 }
// hostiles that are actually a threat at their current distance, worst first
function threatsNear (b, mul) {
  const out = []
  if (!b.entity) return out
  for (const id in b.entities) {
    const e = b.entities[id]
    if (!e || !e.position || !e.name || e === b.entity) continue
    if (!HOSTILE.has(String(e.name).toLowerCase())) continue
    if (e.health !== undefined && e.health <= 0) continue
    const d = e.position.distanceTo(b.entity.position)
    const r = threatRadius(e.name) * (mul || 1)
    if (d <= r) out.push({ e, d, r })
  }
  out.sort((x, y) => (x.d / x.r) - (y.d / y.r))
  return out
}
const HOSTILE = new Set(['zombie','zombie_villager','husk','drowned','skeleton','stray','wither_skeleton','bogged','creeper','spider','cave_spider','silverfish','enderman','slime','magma_cube','phantom','vindicator','evoker','pillager','vex','witch','blaze','zombified_piglin','piglin_brute','hoglin','zoglin','warden','breeze','cave_spider'])

function nearestHostile (b, radius) {
  let best = null; let bd = radius
  for (const id in b.entities) {
    const e = b.entities[id]
    if (!e || !e.position || !e.name || e === b.entity) continue
    if (!HOSTILE.has(String(e.name).toLowerCase())) continue
    if (e.health !== undefined && e.health <= 0) continue
    const d = e.position.distanceTo(b.entity.position)
    if (d < bd) { bd = d; best = e }
  }
  return best
}

const WEAPONS = ['netherite_sword','diamond_sword','iron_sword','stone_sword','golden_sword','wooden_sword','netherite_axe','diamond_axe','iron_axe','stone_axe','golden_axe','wooden_axe']
function equipBestWeapon (b) {
  const items = b.inventory.items()
  for (const w of WEAPONS) { const it = items.find(i => i.name === w); if (it) { b.equip(it, 'hand').catch(() => {}); return w } }
  return null
}
function hasWeapon (b) {
  try { for (const it of b.inventory.items()) { if (it && WEAPONS.includes(it.name)) return true } } catch (e) {}
  return false
}
const ARMOR_SLOTS = {
  head: ['netherite_helmet', 'diamond_helmet', 'iron_helmet', 'chainmail_helmet', 'golden_helmet', 'copper_helmet', 'leather_helmet', 'turtle_shell'],
  torso: ['netherite_chestplate', 'diamond_chestplate', 'iron_chestplate', 'chainmail_chestplate', 'golden_chestplate', 'copper_chestplate', 'leather_chestplate'],
  legs: ['netherite_leggings', 'diamond_leggings', 'iron_leggings', 'chainmail_leggings', 'golden_leggings', 'copper_leggings', 'leather_leggings'],
  feet: ['netherite_boots', 'diamond_boots', 'iron_boots', 'chainmail_boots', 'golden_boots', 'copper_boots', 'leather_boots']
}
function equipArmor (b) {
  try {
    const items = b.inventory.items()
    for (const slot in ARMOR_SLOTS) {
      for (const n of ARMOR_SLOTS[slot]) {
        const it = items.find(i => i.name === n)
        if (it) { try { b.equip(it, slot).catch(() => {}) } catch (e) {} ; break }
      }
    }
  } catch (e) {}
}
function nearestPlayerEntity (b, r) {
  let best = null; let bd = r
  if (!b.entity) return null
  for (const k in b.players) {
    const pl = b.players[k]
    if (!pl.entity || pl.entity === b.entity) continue
    const d = pl.entity.position.distanceTo(b.entity.position)
    if (d < bd) { bd = d; best = pl.entity }
  }
  return best
}
function fleeFrom (b, e) {
  if (!b.entity || !e || !e.position) return
  const bp = b.entity.position
  let ax = bp.x - e.position.x; let az = bp.z - e.position.z
  const len = Math.sqrt(ax * ax + az * az) || 1
  ax /= len; az /= len
  const mate = nearestPlayerEntity(b, 60)
  if (mate && b.health <= 16) {
    const mx = mate.position.x - bp.x; const mz = mate.position.z - bp.z
    const ml = Math.hypot(mx, mz) || 1
    const w = b.health <= 8 ? 1.6 : 0.7
    ax += (mx / ml) * w; az += (mz / ml) * w
    const nl = Math.hypot(ax, az) || 1
    ax /= nl; az /= nl
  }
  for (let i = 0; i < 8; i++) {
    const tx = Math.round(bp.x + ax * 6); const tz = Math.round(bp.z + az * 6)
    if (!isWaterAt(b, tx, tz)) break
    const c = Math.cos(Math.PI / 4); const s = Math.sin(Math.PI / 4)
    const nx = ax * c - az * s; const nz = ax * s + az * c
    ax = nx; az = nz
  }
  if (RANGED.has(String(e.name || '').toLowerCase())) {
    // strafing a shooter ruins its aim far better than running in a straight line
    const side = (Math.floor(Date.now() / 850) % 2 === 0) ? 1 : -1
    const px = -az * side; const pz = ax * side
    ax = ax * 0.35 + px * 0.95; az = az * 0.35 + pz * 0.95
    const nl2 = Math.hypot(ax, az) || 1; ax /= nl2; az /= nl2
    forceJumpUntil = Date.now() + 1400            // bunny-hop: arrows keep missing
  }
  // obstacle-aware steering: sprinting face-first into a tree kills the escape
  // (sprint momentum dies on every collision). If a wall blocks the run, turn 90 degrees.
  try {
    if (frontObstacle(b, { x: ax, z: az }, 1.25) === 'wall') {
      const r1x = -az, r1z = ax          // +90 degrees
      const r2x = az, r2z = -ax          // -90 degrees
      if (frontObstacle(b, { x: r1x, z: r1z }, 1.25) !== 'wall') { ax = r1x; az = r1z }
      else if (frontObstacle(b, { x: r2x, z: r2z }, 1.25) !== 'wall') { ax = r2x; az = r2z }
      else { ax = r1x; az = r1z }        // walled in both sides: turn anyway, stuck guard takes over
    }
  } catch (err) {}
  try {
    const dd = e.position ? bp.distanceTo(e.position) : 99
    if (dd < 3.5) b.look(Math.atan2(-ax, az), 0, true)              // emergency snap: turn NOW
    else b.lookAt(new Vec3(bp.x + ax * 10, bp.y + 1, bp.z + az * 10))
  } catch (err) {}
  try { b.setControlState('forward', true); b.setControlState('sprint', true) } catch (err) {}
}

const FOODS = ['golden_apple','cooked_beef','cooked_porkchop','cooked_mutton','cooked_chicken','cooked_rabbit','cooked_salmon','cooked_cod','beef','porkchop','mutton','chicken','rabbit','bread','baked_potato','apple','melon_slice','sweet_berries','carrot','potato','beetroot_soup','mushroom_stew','rabbit_stew','cookie','pumpkin_pie','dried_kelp']
function findFood (b) {
  const items = b.inventory.items()
  for (const f of FOODS) { const it = items.find(i => i.name === f); if (it) return it }
  return null
}
async function eatFood (b) {
  const f = findFood(b)
  if (!f) return false
  try { await b.equip(f, 'hand') } catch (e) { return false }
  try { b.setControlState('forward', false); b.setControlState('sprint', false) } catch (e) {}
  try { await b.consume(); log('ATE', f.name, 'hp=' + Math.round(b.health), 'food=' + Math.round(b.food)); return true } catch (e) { return false }
}

function setupPathfinder (b) {
  if (!b.__digWrapped) {
    b.__digWrapped = true
    const _dig0 = b.dig.bind(b)
    b.dig = async (block, force) => {
      if (NO_DIG && !b.__allowDig) return false
      return _dig0(block, force)
    }
    log('NODIG mode', NO_DIG)
  }
  if (!mcData) return
  try {
    const mv = new Movements(b, mcData)
    // Digging is a LAST RESORT, not a habit: laborCost = (1 + 3*digTime/1000) * digCost.
    // With digCost=2 a jump-up (~2) always beats digging a dirt step (~6.5), walking around
    // beats digging stone (~47 by hand), but genuine climb-outs through soft slopes stay possible.
    // BUG #1 (owner pointed it out): with canDig the A* planner treats "break a block"
    // as a normal, cheap edge, so on a jungle hill it tunnels through dirt/leaves/stone
    // instead of walking 3 blocks around. Digging is now only allowed by the explicit
    // escape routines (digBlock / digUpAndOut via __allowDig), never by the path planner.
    mv.canDig = false
    mv.digCost = 500
    mv.canOpenDoors = true                     // a door is not a wall - the whole point
    mv.allow1by1towers = true
    mv.allowParkour = true
    mv.allowSprinting = true
    mv.liquidCost = 900          // entering water costs more than a long walk along the shore
    mv.infiniteLiquidDropdownDistance = false
    try { mv.scafoldingBlocks = [mcData.blocksByName.cobblestone.id, mcData.blocksByName.dirt.id] } catch (e) {}
    b.pathfinder.setMovements(mv)
    b.__movements = mv
    wrapLeashGoals(b)                              // the 2-chunk line, applied to every goal
    // collectblock REPLACES pathfinder movements with its own on every collect() call
    // (defaults: canDig=true, digCost=1 = casual tunneling) - tune its instance to match
    try {
      if (b.collectBlock && b.collectBlock.movements) {
        b.collectBlock.movements.canDig = false   // collect() used to chew through the terrain
        b.collectBlock.movements.digCost = 500
        b.collectBlock.movements.canOpenDoors = true
        b.collectBlock.movements.allow1by1towers = true
        b.collectBlock.movements.allowParkour = true
        b.collectBlock.movements.allowSprinting = true
      }
    } catch (e) {}
    b.pathfinder.thinkTimeout = 6000
    b.pathfinder.tickTimeout = 45          // replan more often: terrain under jungle canopy changes under us
    // Cap A* cost at (h(start) + searchRadius). On steep jungle hills an uncapped
    // search "thinks" past every timeout while the bot stands still (moved=0.0).
    // Capped, A* concludes fast and returns PARTIAL paths: the bot keeps walking
    // toward the target and greedy recomputes carry it the rest of the way.
    b.pathfinder.searchRadius = 100
    log('PF_READY thinkTimeout=' + b.pathfinder.thinkTimeout + ' searchRadius=' + b.pathfinder.searchRadius + ' canDig=false (walk around, dig only to escape)')
  } catch (e) { log('PF_ERR', e && e.message ? e.message : String(e)) }
}

function solidAt (b, v) { const blk = b.blockAt(v); return !!(blk && blk.boundingBox === 'block') }
function isWaterAt (b, x, z) {
  if (!b.entity) return false
  const y = b.entity.position.y
  // -9..+3 around us AND a fixed ocean band: from a y=67 shore the old -3..+3 scan
  // MISSED the y=62-63 sea surface, so "dry" escape points kept landing in the ocean
  for (let dy = -9; dy <= 3; dy++) { const blk = b.blockAt(new Vec3(x, y + dy, z)); if (blk && /water|lava/.test(blk.name)) return true }
  for (let sy = 59; sy <= 64; sy++) { const blk = b.blockAt(new Vec3(x, sy, z)); if (blk && /water|lava/.test(blk.name)) return true }
  return false
}

function hostilesNear (b, r) {
  const out = []
  for (const id in b.entities) {
    const e = b.entities[id]
    if (!e || !e.position || !e.name || e === b.entity) continue
    if (!HOSTILE.has(String(e.name).toLowerCase())) continue
    if (e.health !== undefined && e.health <= 0) continue
    const d = e.position.distanceTo(b.entity.position)
    if (d <= r) out.push({ e, d })
  }
  out.sort((a, c) => a.d - c.d)
  return out
}

// Harvesting exception to "the planner never digs": patch11 also made trees unreachable,
// because a trunk is normally sealed by its own crown - canDig=false then simply means
// "wood exists, cannot get it". So ONLY while collectBlock works we allow digging, with
// digCost=60: one dirt block costs more than ~150 blocks of walking, so any real detour
// around a hill still wins, and only a true enclosure (leaves around a log) gets broken.
// Restored to (canDig=false, digCost=500) the moment the harvest call is over.
async function withSoftDig (b, fn) {
  const mvs = [b.__movements, (b.collectBlock && b.collectBlock.movements)].filter(Boolean)
  const was = mvs.map(m => m.canDig)
  mvs.forEach(m => { m.canDig = true; m.digCost = 60 })
  b.__softDig = true
  // while harvesting, path straight AT the block: the retry ladder arrives with a widened
  // radius (6-12), and collectBlock then says "not in reach" and gives up on the tree
  b.__pfRaw = true
  try { return await fn() } finally { b.__softDig = false; b.__pfRaw = false; mvs.forEach((m, i) => { m.canDig = was[i]; m.digCost = 500 }) }
}
const FOLIAGE_RE = /leaves|sapling|vine|fern|flower|grass$|dead_bush|large_fern|tall_grass/
// leaves are not terrain: taking the crown off a trunk is how you reach the wood, and it
// costs no tools, so it is always cheaper than a tunnel anywhere
async function clearFoliage (b, tp) {
  try {
    let n = 0
    for (const d of [[0, 1, 0], [1, 1, 0], [-1, 1, 0], [0, 1, 1], [0, 1, -1], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [1, 2, 0], [-1, 2, 0], [0, 2, 1], [0, 2, -1]]) {
      if (!b.entity || b.health <= 0) break
      const v = tp.offset(d[0], d[1], d[2])
      const k = b.blockAt(v)
      if (k && FOLIAGE_RE.test(k.name)) { if (await withTimeout(digRaw(b, v), 3000, false)) n++ }
    }
    if (n) log('CLEAR_FOLIAGE ' + n + ' near ' + tp)
    return n
  } catch (e) { return 0 }
}

async function digBlock (b, v) {
  if (NO_DIG) return false
  const blk = b.blockAt(v)
  if (!blk || blk.boundingBox !== 'block') return false
  // a plank wall is "soft" and the unstick routine used to smash straight through it.
  // our own building is not a wall to break, it is a wall to open the door of.
  if (STRUCT_RE.test(blk.name) && !b.__allowDig) {
    if (/door/.test(blk.name)) { await actDoor(b, v, true); return false }
    if (!b.__structWarned || Date.now() - b.__structWarned > 20000) {
      b.__structWarned = Date.now()
      log('DIG_PROTECT own block ' + blk.name + ' at ' + v + ' - use the door')
    }
    return false
  }
  // BUG #2: we spent minutes punching stone/wood we had no tool for, standing still while
  // mobs closed in. If it is hard and we have no pick, that is not a wall to break - it is
  // a wall to walk around.
  const hd = typeof blk.hardness === 'number' ? blk.hardness : 1
  if (hd > 3 && !hasPickaxe(b)) {
    if (Date.now() - (b.__hardWarned || 0) > 20000) {
      b.__hardWarned = Date.now()
      log('DIG_SKIP ' + blk.name + ' at ' + v + ' hardness=' + hd + ' no tool -> detour')
    }
    return false
  }
  try {
    await b.lookAt(blk.position.offset(0.5, 0.5, 0.5)); await b.dig(blk)
    stats.mined++; stats.dug = (stats.dug || 0) + 1
    if (Date.now() % 60000 < 500) log('DUG ' + blk.name + ' total=' + stats.dug)
    await suckDrop(b, v); return true
  } catch (e) { return false }
}

// bot.dig() drops items NEXT TO the bot (outside pickup range, 10-tick pickup delay),
// and on slopes they ROLL downhill - walk to the item entity's CURRENT position,
// not to the mined cell (that version lost every drop: mined+15, inv empty)
async function suckDrop (b, v) {
  try {
    if (!b.entity) return
    let pf = false; try { pf = b.pathfinder.isMoving() } catch (e) {}
    if (pf) return                                        // pathfinder driving: don't fight its controls
    await sleep(640)                                      // item pickup delay + roll settling
    if (!b.entity) return
    let best = null; let bd = 1e9
    for (const id in b.entities) {
      const e = b.entities[id]
      if (!e || e.name !== 'item' || !e.position) continue
      const dh = Math.hypot(e.position.x - v.x - 0.5, e.position.z - v.z - 0.5)
      if (dh > 7 || Math.abs(e.position.y - v.y) > 12) continue
      const d3 = e.position.distanceTo(b.entity.position)
      if (d3 < bd) { bd = d3; best = e }
    }
    if (!best || bd < 1.0) return                         // nothing or already in pickup range
    const p = b.entity.position
    const dx = best.position.x - p.x; const dz = best.position.z - p.z
    const l = Math.hypot(dx, dz)
    const dyItem = best.position.y - p.y
    if (dyItem > 1.2) {
      // underwater drops FLOAT to the surface - swim up after them instead of
      // walking on the bottom (that lost every cove-dig drop: mined+8, inv empty)
      try { await b.look(Math.atan2(-dx, dz), -0.6, true) } catch (e) {}
      b.setControlState('forward', true); b.setControlState('jump', true)
      await sleep(Math.min(1500, 500 + Math.abs(dyItem) * 220))
      b.setControlState('forward', false); b.setControlState('jump', false)
      return
    }
    if (l > 6.5) return
    try { await b.look(Math.atan2(-dx, dz), 0, true) } catch (e) {}
    b.setControlState('forward', true)
    await sleep(Math.min(1100, Math.max(300, l * 320)))
    b.setControlState('forward', false)
  } catch (e) {}
}

async function ensureHeadroom (b) {
  if (!b || !b.entity) return
  const feet = b.entity.position.floored()
  for (const dy of [1, 2]) { const v = feet.offset(0, dy, 0); if (solidAt(b, v)) await digBlock(b, v) }
}

let escapeDirIdx = 0
let escaping = false
const ESCAPE_DIRS = [[1, 0], [0, 1], [-1, 0], [0, -1]]

async function pillarUp (b, levels) {
  jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 2500 + levels * 900)
  for (let i = 0; i < levels; i++) {
    if (!b.entity) return
    const matName = PLACEABLE.find(nm => countItem(b, nm) > 0)
    if (!matName) { log('PILLAR no material'); return }
    const mat = b.inventory.items().find(it => it.name === matName)
    try { await b.equip(mat, 'hand') } catch (e) {}
    const base = b.entity.position.floored()
    const baseBlk = b.blockAt(base)
    if (baseBlk && baseBlk.boundingBox === 'block') return
    const wet = botWet(b)
    // puddle/water column: the solid floor can be 2-4 cells below - build the tower
    // FROM THE FLOOR UP (fill = first open cell above the deepest solid found)
    let ref = null; let fill = null
    for (let dy = -1; dy >= -4; dy--) {
      const cand = b.blockAt(base.offset(0, dy, 0))
      if (cand && cand.boundingBox === 'block') {
        const above = b.blockAt(cand.position.offset(0, 1, 0))
        if (above && above.boundingBox !== 'block') { ref = cand; fill = cand.position.offset(0, 1, 0) }
        break
      }
    }
    if (!ref) { log('PILLAR no ref at', pos(b)); return }
    const y0 = b.entity.position.y
    const riseNeed = Math.max(1.08, fill.y + 1.15 - y0)
    b.setControlState('jump', true)
    const t0 = Date.now()
    while (Date.now() - t0 < (wet ? 2600 : 1300) && b.entity && b.entity.position.y < y0 + riseNeed) await sleep(60)
    b.setControlState('jump', false)
    if (!b.entity) return
    // water jump-hold bobs lower than a ground jump: accept a smaller rise when wet
    if (b.entity.position.y - y0 < (wet ? 0.3 : 0.55) || b.entity.position.y < fill.y + 0.9) {
      b.__noRiseN = (b.__noRiseN || 0) + 1
      log('PILLAR no rise at', pos(b), 'n=' + b.__noRiseN)
      if (b.__noRiseN >= 3 && !wet && !deepNearCrater(b)) {
        // flat dry floor + rejected jumps = possible client/server desync. Reconnect only
        // if the owner enabled MC_HEAL (forced reconnects here caused rejoin spam and
        // never actually fixed the wedged spot - the stuck-escalation ladder handles it).
        b.__noRiseN = 0
        if (healReconnect(b, 'pillar no-rise x3 at ' + pos(b))) return
        await sleep(1200); continue
      }
      await sleep(250); continue
    }
    b.__noRiseN = 0
    const still = b.blockAt(fill)
    if (still && still.boundingBox === 'block') { await sleep(200); continue }
    const r = await withTimeout(b.placeBlock(ref, new Vec3(0, 1, 0)), 3500, 'to')
    if (r === 'to') log('PILLAR place failed at', pos(b))
    await sleep(280)
  }
}
const PLACEABLE = ['dirt', 'coarse_dirt', 'rooted_dirt', 'mud', 'packed_mud', 'cobblestone', 'grass_block', 'moss_block', 'cobbled_deepslate', 'blackstone', 'netherrack', 'stone', 'sand', 'gravel', 'oak_planks', 'birch_planks', 'spruce_planks', 'oak_log', 'birch_log', 'spruce_log', 'jungle_log', 'acacia_log', 'pale_oak_log', 'cherry_log', 'dark_oak_log', 'mangrove_log', 'bamboo_block', 'pale_oak_planks', 'pale_oak_stairs', 'pale_oak_slab', 'stone_bricks', 'mossy_cobblestone', 'diorite', 'andesite', 'granite', 'deepslate', 'cobbled_deepslate_slab']
function countPlaceable (b) { let n = 0; for (const m of PLACEABLE) n += countItem(b, m); return n }
const GROUND_RE = /dirt|grass_block|podzol|mycelium|sand|gravel|stone|cobble|deepslate|granite|diorite|andesite|tuff|calcite|moss_block|mud|terracotta|netherrack|blackstone|basalt|_log|_wood|planks|bamboo_block|bricks|dripstone_block|amethyst_block|copper_block|quartz_block|purpur|magma_block|mossy/
async function ensurePlaceable (b, need, allowBelow = true) {
  if (countPlaceable(b) >= need) return true
  const feet = b.entity.position.floored()
  const cands = []
  // side walls at feet AND head level first; digging BELOW ourselves in a hole
  // deepened the trench from y56 to y52 and made the escape impossible
  for (const d of ESCAPE_DIRS) { cands.push(feet.offset(d[0], 0, d[1])); cands.push(feet.offset(d[0], 1, d[1])) }
  // bowl walls: +-1 cells are often already dug out - reach 2 out as well
  for (const d of ESCAPE_DIRS) { cands.push(feet.offset(d[0] * 2, 0, d[1] * 2)); cands.push(feet.offset(d[0] * 2, 1, d[1] * 2)) }
  if (allowBelow) {
    for (const d of ESCAPE_DIRS) cands.push(feet.offset(d[0], -1, d[1]))
    cands.push(feet.offset(0, -2, 0))                   // last resort: dig under ourselves (stone -> cobble = placeable)
  }
  // only ground-type blocks drop placeable items - digging jungle leaves/vines
  // "succeeded" 10x and yielded NOTHING (PILLAR no material spam)
  for (const v of cands) {
    if (countPlaceable(b) >= need) break
    const blk = b.blockAt(v)
    if (!blk || blk.boundingBox !== 'block') continue
    if (!GROUND_RE.test(blk.name)) continue
    if ((blk.hardness === undefined ? 1 : blk.hardness) < 0) continue
    await digBlock(b, v)
    await sleep(420)
  }
  return countPlaceable(b) > 0
}
function rimAbove (b) {
  if (!b.entity) return 0
  const feet = b.entity.position.floored()
  let rim = feet.y
  for (const d of ESCAPE_DIRS) {
    for (let dy = 12; dy >= 1; dy--) { const blk = b.blockAt(feet.offset(d[0], dy, d[1])); if (blk && blk.boundingBox === 'block') { if (feet.y + dy > rim) rim = feet.y + dy; break } }
  }
  return rim - feet.y
}
// A narrow shaft the bot dug itself: walls on all four sides and the rim well above.
// In a shaft there is no sidestep and no step-up - the only way out is to dig/tower up,
// and the bot can bob around inside one for hours without ever escalating.
function inShaft (b) {
  if (!b.entity) return false
  const feet = b.entity.position.floored()
  const enclosed = solidAt(b, feet.offset(1, 0, 0)) && solidAt(b, feet.offset(-1, 0, 0)) &&
    solidAt(b, feet.offset(0, 0, 1)) && solidAt(b, feet.offset(0, 0, -1))
  return enclosed && rimAbove(b) >= 2.5
}
function manualWalkDry (b, ms) {
  if (!b.entity) return
  const bp = b.entity.position.floored()
  const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]]
  let bestDir = null; let bestScore = -1e9
  for (const d of dirs) {
    let score = 0
    for (let k = 1; k <= 4; k++) {
      const v = bp.offset(d[0] * k, 0, d[1] * k)
      const blk = b.blockAt(v)
      const below = b.blockAt(v.offset(0, -1, 0))
      if (blk && /water|lava/.test(blk.name)) { score -= 20; break }
      if (blk && blk.boundingBox === 'block') score -= 3
      else score += 2
      if (below && below.boundingBox === 'block') score += 1
    }
    if (score > bestScore) { bestScore = score; bestDir = d }
  }
  const d = bestDir || dirs[0]
  const yaw = Math.atan2(-d[0], d[1])
  jumpLockUntil = Math.max(jumpLockUntil, Date.now() + (ms || 1600) + 400)
  try { b.look(yaw, 0) } catch (e) {}
  try { b.setControlState('forward', true); b.setControlState('sprint', true); b.setControlState('jump', true) } catch (e) {}
  setTimeout(() => { try { b.setControlState('forward', false); b.setControlState('sprint', false); b.setControlState('jump', false) } catch (e) {} }, ms || 1600)
}
// climb a tower while HARVESTING the wall for material each level (the dug-out bowl
// has nothing at +-1 anymore; walls 2-3 out are solid). Fixes "PILLAR no material" loops.
async function pillarClimb (b, levels) {
  for (let i = 0; i < levels && b.entity && b.health > 0; i++) {
    if (countPlaceable(b) < 2) {
      let got = false
      const feet = b.entity.position.floored()
      for (let r = 1; r <= 3 && !got; r++) {
        for (const d of [[r, 0], [-r, 0], [0, r], [0, -r], [r, r], [r, -r], [-r, r], [-r, -r]]) {
          for (const dy of [-1, 0, 1]) {                        // -1 = crater FLOOR cells (stone/sand, sky above = safe)
            const v = feet.offset(d[0], dy, d[1])
            if (!diggableSurface(b, v)) continue               // buried cells cascade (sand hourglass)
            if (await withTimeout(digBlock(b, v), 9000, false)) { got = true; break }
          }
          if (got) break
        }
      }
      if (!got && countPlaceable(b) < 1) { log('CLIMB no material at all at', pos(b)); return }
    }
    const yBefore = b.entity.position.y
    await pillarUp(b, 1)
    await sleep(150)
    if (b.entity && b.entity.position.y - yBefore < 0.5) {
      // puddle deadlock: a water jump lifts ~0.4b but placing needs feet 0.9b above the
      // fill cell - walk to the dry bowl edge first, pillar from there
      if (botWet(b)) { log('CLIMB puddle -> walk dry at', pos(b)); manualWalkDry(b, 1800); await sleep(2000); continue }
      // CEILING deadlock (low corridor under the rim): a dry jump needs cells +2/+3 open -
      // dig through the roof, the drops become pillar material, then tower up the shaft
      const ft = b.entity.position.floored()
      let roofDug = false
      for (const dy of [2, 3]) {
        if (inCollapseZone(b)) break                            // no roof digs in the hourglass
        const cv = ft.offset(0, dy, 0)
        const cb = b.blockAt(cv)
        if (!cb || cb.boundingBox !== 'block') continue
        if (!GROUND_RE.test(cb.name) || (cb.hardness === undefined ? 1 : cb.hardness) < 0) continue
        const aboveRoof = b.blockAt(cv.offset(0, 1, 0))
        if (aboveRoof && aboveRoof.boundingBox === 'block') continue  // buried roof = cascade
        log('CLIMB roof +' + dy + ' at', pos(b))
        if (await withTimeout(digBlock(b, cv), 9000, false)) roofDug = true
      }
      if (roofDug) { await sleep(300); continue }
      if (countPlaceable(b) < 1) return
    }
  }
}
let diggingUp = false
async function digUpAndOut (b, levels) {
  if (diggingUp) return                                    // 3 concurrent ESCAPE_UPs fought over controls
  diggingUp = true
  try { await digUpAndOutInner(b, levels) } finally { diggingUp = false }
}
async function digUpAndOutInner (b, levels) {
  jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 30000)
  try { b.pathfinder.setGoal(null) } catch (e) {}
  if (!b.entity) return
  const feet0 = b.entity.position.floored()
  let rim = feet0.y
  for (const d of ESCAPE_DIRS) {
    for (let dy = 18; dy >= 0; dy--) { const blk = b.blockAt(feet0.offset(d[0], dy, d[1])); if (blk && blk.boundingBox === 'block') { if (feet0.y + dy > rim) rim = feet0.y + dy; break } }
  }
  const need = rim - feet0.y
  log('ESCAPE_UP rim=' + rim + ' y=' + feet0.y + ' need=' + need)
  if (inCollapseZone(b) && need >= 4) { await craterHold(b); return }
  await ensurePlaceable(b, need + 2, false)
  const d = ESCAPE_DIRS[0]
  manualLockUntil = Date.now() + 26000
  const walledIn = solidAt(b, feet0.offset(1, 0, 0)) && solidAt(b, feet0.offset(-1, 0, 0)) &&
    solidAt(b, feet0.offset(0, 0, 1)) && solidAt(b, feet0.offset(0, 0, -1))
  if (walledIn) {
    // the pathfinder cannot walk out of a 1x1 shaft - tower straight up instead
    log('ESCAPE_UP walled in -> pillar straight up need=' + need)
    await pillarClimb(b, Math.min(14, need + 2))
  } else {
    await withTimeout(b.pathfinder.goto(new goals.GoalBlock(feet0.x + d[0], rim + 1, feet0.z + d[1])), 24000, 'timeout')
    let climbed = b.entity ? (b.entity.position.y - feet0.y) : 0
    if (climbed < need - 0.5) {
      log('ESCAPE_UP pf gained ' + Math.round(climbed) + '/' + need + ' -> manual pillar')
      const extra = Math.min(14, need - Math.max(0, Math.round(climbed)) + 2)
      await pillarClimb(b, extra)
    }
  }
  log('ESCAPE_UP now at', pos(b))
  if (!b.entity) return
  const a1 = Math.random() * Math.PI * 2
  manualLockUntil = Date.now() + 14000
  await withTimeout(b.pathfinder.goto(new goals.GoalXZ(Math.round(b.entity.position.x + Math.cos(a1) * 16), Math.round(b.entity.position.z + Math.sin(a1) * 16))), 14000, 'timeout')
}
let lastEscapeFeet = null
let lastEscapeAt = 0
async function escapeStuck (b) {
  if (escaping) return
  escaping = true
  jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 8000)
  try {
    const feet = b.entity.position.floored()
    const now = Date.now()
    const sameSpot = lastEscapeFeet && feet.distanceTo(lastEscapeFeet) < 2.5 && (now - lastEscapeAt) < 25000
    lastEscapeFeet = feet; lastEscapeAt = now
    if (sameSpot) { log('ESCAPE still stuck -> dig UP at', pos(b)); await digUpAndOut(b, 6); escaping = false; return }
    const enclosed = solidAt(b, feet.offset(1, 0, 0)) && solidAt(b, feet.offset(-1, 0, 0)) && solidAt(b, feet.offset(0, 0, 1)) && solidAt(b, feet.offset(0, 0, -1))
    const headWalls = ESCAPE_DIRS.filter(d => solidAt(b, feet.offset(d[0], 1, d[1]))).length
    const matName = PLACEABLE.find(nm => countItem(b, nm) > 0)
    if (enclosed && headWalls >= 3 && matName) {
      log('ESCAPE pillar up via', matName)
      await pillarUp(b, 3)
    } else {
      let best = null; let bestScore = -1e9
      for (const dir of ESCAPE_DIRS) {
        let score = 0
        for (let depth = 1; depth <= 2; depth++) {
          for (let dy = 0; dy <= 2; dy++) {
            const blk = b.blockAt(feet.offset(dir[0] * depth, dy, dir[1] * depth))
            if (!blk || blk.boundingBox !== 'block') score += 3
            else score += 1 / (1 + (blk.hardness || 1))
          }
        }
        if (score > bestScore) { bestScore = score; best = dir }
      }
      const dir = best || ESCAPE_DIRS[0]
      const yaw = Math.atan2(-dir[0], dir[1])
      for (let depth = 1; depth <= 2; depth++) {
        await digBlock(b, feet.offset(dir[0] * depth, 0, dir[1] * depth))
        await digBlock(b, feet.offset(dir[0] * depth, 1, dir[1] * depth))
        await digBlock(b, feet.offset(dir[0] * depth, 2, dir[1] * depth))
      }
      await ensureHeadroom(b)
      try { await b.look(yaw, 0) } catch (e) {}
      jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 1600)
      b.setControlState('forward', true); b.setControlState('jump', true)
      await sleep(700)
      b.setControlState('forward', false); b.setControlState('jump', false)
    }
  } catch (e) {}
  escaping = false
}

async function autoFree (b) {
  await sleep(600)
  for (let i = 0; i < 12; i++) {
    if (!b.entity || b.health <= 0) return
    const feet = b.entity.position.floored()
    const enclosed = solidAt(b, feet.offset(1, 0, 0)) && solidAt(b, feet.offset(-1, 0, 0)) && solidAt(b, feet.offset(0, 0, 1)) && solidAt(b, feet.offset(0, 0, -1))
    if (!enclosed) { log('AUTOFREE open at', pos(b)); return }
    log('AUTOFREE enclosed -> digging out')
    await ensureHeadroom(b)
    await escapeStuck(b)
    await sleep(700)
  }
  log('AUTOFREE gave up')
}

let reflexOn = true
let manualLockUntil = 0
let lastHeal = 0
function healReconnect (b, why, force) {
  // force = targeted resync when physics is provably desynced (jump rejected x3) -
  // NOT reconnect spam: own 150s cooldown, only fires from stuck-detection
  if (!force && process.env.MC_HEAL !== 'on') return false
  const now = Date.now()
  if (now - lastHeal < (force ? 150000 : 60000)) return false
  lastHeal = now
  log('HEAL_RECONNECT', why)
  stopDrive(b)
  mission = null
  try { b._client.end('heal') } catch (e) { try { b.quit('heal') } catch (e2) {} }
  return true
}
function sendLoaded (b, tag) {
  try {
    if (b.supportFeature && b.supportFeature('sendsPlayerLoadedPacket')) { b._client.write('player_loaded', {}); log('PLAYER_LOADED', tag) }
  } catch (e) { log('LOADED_ERR', e.message) }
}
function announceLoaded (b) {
  sendLoaded(b, 't+0.4')
  setTimeout(() => sendLoaded(b, 't+2'), 2000)
  setTimeout(() => sendLoaded(b, 't+5'), 5000)
  if (b.__loadedTimer) clearInterval(b.__loadedTimer)
  b.__loadedTimer = setInterval(() => { try { sendLoaded(b, 'keep') } catch (e) {} }, 25000)
}
function hop (b) {
  try { b.setControlState('jump', false) } catch (e) {}
  try { b.setControlState('jump', true) } catch (e) {}
}
function hopCycle (b) {
  b.__hopPhase = !b.__hopPhase
  try { b.setControlState('jump', b.__hopPhase) } catch (e) {}
}
function syncInput (b) {
  if (!b || !b._client || b._client.state !== 'play' || !b.entity) return
  let g = n => false
  try { g = n => !!b.getControlState(n) } catch (e) { return }
  const inputs = { forward: g('forward'), backward: g('back'), left: g('left'), right: g('right'), jump: g('jump'), shift: g('sneak'), sprint: g('sprint') }
  const key = Object.keys(inputs).map(k => inputs[k] ? '1' : '0').join('')
  b.__inputKey = key; b.__inputSent = Date.now()
  b.__inputWrites = (b.__inputWrites || 0) + 1
  try { b._client.write('player_input', { inputs }) } catch (e) { b.__inputErr = e.message; log('INPUT_ERR', e.message) }
}
function startInputSync (b) {
  if (b.__inputTimer) clearInterval(b.__inputTimer)
  b.__inputTimer = setInterval(() => { try { syncInput(b) } catch (e) {} }, 50)
}
function collectNear (b, r) {
  return new Promise(resolve => {
    if (!b.entity) return resolve(0)
    let items = []
    try { items = Object.values(b.entities).filter(e => e && e.name === 'item' && e.position && e.position.distanceTo(b.entity.position) <= r) } catch (e) { log('COLLECT_ERR', e.message); return resolve(0) }
    if (!items.length) return resolve(0)
    items.sort((x, y) => x.position.distanceTo(b.entity.position) - y.position.distanceTo(b.entity.position))
    let i = 0
    const next = () => {
      if (i >= items.length || !b.entity || b.health <= 0) return resolve(i)
      const it = items[i++]
      try { b.pathfinder.setGoal(new goals.GoalNear(it.position.x, it.position.y, it.position.z, 0.5)) } catch (e) {}
      let finished = false
      const fin = () => { if (finished) return; finished = true; try { b.pathfinder.setGoal(null) } catch (e) {} ; setTimeout(next, 260) }
      b.once('goal_reached', fin)
      setTimeout(fin, 6000)
    }
    next()
  })
}
function dryCol (b, feet, dx, dz) {
  const v = feet.offset(dx, 0, dz)
  for (let dy = 7; dy >= -4; dy--) {
    const blk = b.blockAt(v.offset(0, dy, 0))
    if (blk && blk.boundingBox === 'block') {
      for (const k of [1, 2]) { const air = b.blockAt(v.offset(0, dy + k, 0)); if (air && /water/.test(air.name)) return null }
      return { x: v.x, y: feet.y + dy + 1, z: v.z, d: Math.hypot(dx, dz) }
    }
  }
  return null
}
function nearestDry (b, r) {
  if (!b.entity) return null
  const feet = b.entity.position.floored()
  let best = null
  for (let dx = -r; dx <= r; dx++) {
    for (let dz = -r; dz <= r; dz++) {
      const d = Math.hypot(dx, dz)
      if (d < 0.9 || d > r) continue
      const c = dryCol(b, feet, dx, dz)
      if (c && (!best || d < best.d)) best = c
    }
  }
  return best
}
function stopDrive (b) {
  if (b.__drive) { clearInterval(b.__drive); b.__drive = null }
  try { b.clearControlStates() } catch (e) {}
}
function walkTo (b, tx, ty, tz, ms) {
  stopDrive(b)
  try { b.pathfinder.setGoal(null) } catch (e) {}
  manualLockUntil = Date.now() + (ms || 45000)
  const tEnd = Date.now() + (ms || 45000)
  let ticks = 0, winDist = null, blocked = 0, episode = 0, slideTicks = 0, side = 1
  const origin = b.entity.position.clone()
  let nextHealCheck = Date.now() + 16000
  b.__drive = setInterval(() => {
    try {
      if (!b.entity || b.health <= 0 || Date.now() > tEnd) { stopDrive(b); log('DRIVE_END', pos(b)); return }
      const p = b.entity.position
      const dh = Math.hypot(tx - p.x, tz - p.z)
      if (dh < 2) { stopDrive(b); log('DRIVE_ARRIVED', pos(b) + ' ydiff=' + (ty - p.y).toFixed(1)); return }
      if (dh < 5 && !isWaterAt(b, Math.round(p.x), Math.round(p.y), Math.round(p.z)) === false) { }
      ticks++
      if (Date.now() > nextHealCheck) {
        nextHealCheck = Date.now() + 16000
        if (Math.hypot(p.x - origin.x, p.z - origin.z) < 1.5) { if (healReconnect(b, 'drive no progress ' + dh.toFixed(0) + ' from spawn-point')) return }
      }
      if (slideTicks > 0) slideTicks--
      if (winDist === null) winDist = dh
      if (ticks % 5 === 0) {
        if (winDist - dh >= 0.5) { blocked = 0; if (episode > 0) { episode--; if (episode === 0) side = 1 } }
        else { blocked++ }
        winDist = dh
        if (blocked >= 2 && slideTicks === 0) {
          episode++
          if (episode >= 6) { stopDrive(b); log('DRIVE_STUCK', pos(b) + ' target ' + tx + ' ' + ty + ' ' + tz); return }
          if (blocked >= 3) { side = -side; blocked = 0 }
          if (episode === 3 && countPlaceable(b) > 0 && !inCollapseZone(b)) { log('DRIVE_BUILD', 'pillaring up with ' + countPlaceable(b) + ' blocks'); pillarUp(b, 2) ; slideTicks = 12 }
          slideTicks = 6
          log('DRIVE_SLIDE', 'no progress, ' + (dh).toFixed(1) + ' left, side ' + side + ' ep ' + episode + ' at ' + pos(b))
        }
      }
      try { b.lookAt(new Vec3(tx, p.y - 1.1, tz), true, false) } catch (e) {}
      const hl = Math.hypot(tx - p.x, tz - p.z) || 1
      const ax = (tx - p.x) / hl; const az = (tz - p.z) / hl
      let wet = false
      const selfWet = isWaterAt(b, Math.round(p.x), Math.round(p.y), Math.round(p.z))
      for (const k of [1, 2, 3, 4]) { if (!selfWet && isWaterAt(b, Math.round(p.x + ax * k), Math.round(p.y), Math.round(p.z + az * k))) { wet = true; break } }
      if (wet && slideTicks === 0) { slideTicks = 6; side = side > 0 ? 1 : -1; log('DRIVE_WATER', 'steer ashore at ' + pos(b)) }
      const sliding = slideTicks > 0
      try {
        b.setControlState('forward', true)
        b.setControlState('sprint', !sliding && dh > 10 && b.food > 10)
        b.setControlState('left', sliding && side > 0)
        b.setControlState('right', sliding && side < 0)
      } catch (e) {}
      if (b.food <= 8) { try { eatFood(b) } catch (e) {} }
    } catch (e) { stopDrive(b); log('DRIVE_ERR', e.message) }
  }, 400)
}
function groundYAt (b, feet, dx, dz, span) {
  const v = feet.offset(dx, 0, dz)
  for (let dy = span; dy >= -span; dy--) { const blk = b.blockAt(v.offset(0, dy, 0)); if (blk && blk.boundingBox === 'block') return feet.y + dy }
  return null
}
function pushInput (b) { syncInput(b) }
// ==================== MOVEMENT CORE (jump + stuck) ====================
let jumpLockUntil = 0
let forceJumpUntil = 0      // bunny-hop while dodging arrows
let lastDigAt = 0
let lastHurtAt = 0
let cautionUntil = 0        // just (re)spawned: don't start missions yet
let hiding = false
// where the bot died recently: mission targets are never picked near these
// (the fixed server spawn is a zombie nest - without this the wood mission
// keeps routing straight back into the place that just killed it)
const deathZones = []
// the server's fixed spawn point: a zombie/drowned/skeleton nest under dark jungle
// canopy (mobs don't burn there). 20+ deaths proved it - treat it as a no-go zone
// for mission targets, permanently.
const NEST = { x: -618, z: -654 }
function noteDeathZone (p) {
  if (!p) return
  deathZones.push({ x: p.x, z: p.z, t: Date.now() })
  if (deathZones.length > 12) deathZones.shift()
}
function pointSegDist (px, pz, ax, az, bx, bz) {
  const dx = bx - ax; const dz = bz - az
  const l2 = dx * dx + dz * dz
  let t = l2 ? ((px - ax) * dx + (pz - az) * dz) / l2 : 0
  t = Math.max(0, Math.min(1, t))
  return Math.hypot(px - (ax + t * dx), pz - (az + t * dz))
}
function inDeathZone (x, z, r) {
  const now = Date.now()
  for (let i = deathZones.length - 1; i >= 0; i--) {
    const dz = deathZones[i]
    if (now - dz.t > 1800000) { deathZones.splice(i, 1); continue }   // 30min TTL: under jungle canopy mobs don't burn
    if (Math.hypot(dz.x - x, dz.z - z) < (r || 40)) return true
  }
  return false
}
// nearest no-go center (nest or recent death zone) within r, as a Vec3 at our y - or null
function worstZone (b, r) {
  if (!b.entity) return null
  const p = b.entity.position
  let best = null; let bd = 1e9
  const cands = [NEST].concat(deathZones)
  for (const z of cands) { const d = Math.hypot(z.x - p.x, z.z - p.z); if (d < (r || 70) && d < bd) { bd = d; best = z } }
  return best ? new Vec3(best.x, p.y, best.z) : null
}
let lastHideAt = 0
const RANGED = new Set(['skeleton', 'stray', 'bogged', 'wither_skeleton', 'pillager', 'blaze', 'witch', 'breeze', 'evoker', 'vex', 'ghast', 'snow_golem', 'shulker'])
function relJump (b) { try { if (b.getControlState('jump')) b.setControlState('jump', false) } catch (e) {} }
function holdJump (b) { try { if (!b.getControlState('jump')) b.setControlState('jump', true) } catch (e) {} }
function faceDir (b) { const y = b.entity.yaw; return { x: -Math.sin(y), z: Math.cos(y) } }
function controlDir (b) {
  const g = n => { try { return !!b.getControlState(n) } catch (e) { return false } }
  let f = 0; let s = 0
  if (g('forward')) f += 1
  if (g('back')) f -= 1
  if (g('right')) s += 1
  if (g('left')) s -= 1
  if (!f && !s) return null
  const y = b.entity.yaw
  const sin = Math.sin(y); const cos = Math.cos(y)
  const x = s * cos - f * sin; const z = f * cos + s * sin
  const l = Math.hypot(x, z) || 1
  return { x: x / l, z: z / l }
}
// direction the bot is trying to travel: real velocity first, then inputs, then look
function intendedDir (b) {
  const v = b.entity.velocity
  const sp = Math.hypot(v.x, v.z)
  if (sp > 0.07) return { x: v.x / sp, z: v.z / sp }
  return controlDir(b) || faceDir(b)
}
function isSolidBlk (b, v) { const k = b.blockAt(v); return !!(k && k.boundingBox === 'block') }
function isFreeBlk (b, v) { const k = b.blockAt(v); return !k || k.boundingBox !== 'block' }
function isLiquidBlk (b, v) { const k = b.blockAt(v); return !!(k && /water|lava/.test(k.name)) }
// Pick the most open dry run about `dist` blocks directly away from `src` (mob or death spot).
// Used for flee goals and post-respawn repositioning in dense terrain.
function escapePointFrom (b, src, dist) {
  if (!b.entity || !src) return null
  const bp = b.entity.position
  let ax = bp.x - src.x; let az = bp.z - src.z
  const l = Math.hypot(ax, az)
  if (l < 0.5) { const a = Math.random() * Math.PI * 2; ax = Math.cos(a); az = Math.sin(a) } else { ax /= l; az /= l }
  dist = dist || 18
  const feet = bp.floored()
  let best = null; let bestScore = -1e9
  for (let i = 0; i < 10; i++) {
    const ang = Math.atan2(az, ax) + (i - 5) * 0.42          // fan of ~+-105 deg around "away"
    const dx = Math.cos(ang); const dz = Math.sin(ang)
    let score = 0
    for (let k = 4; k <= dist; k += 3) {
      const sx = Math.round(bp.x + dx * k); const sz = Math.round(bp.z + dz * k)
      if (isWaterAt(b, sx, sz)) { score -= 6; continue }
      let blocked = 0
      for (const dy of [0, 1, 2]) { const blk = b.blockAt(new Vec3(sx, feet.y + dy, sz)); if (blk && blk.boundingBox === 'block') blocked++ }
      if (blocked >= 2) score -= 4                            // wall: sprint dies here
      else if (blocked === 1) score += 1                      // one step: jumpable
      else score += 3                                         // clear run
    }
    score -= Math.abs(i - 5) * 0.2                            // slight bias to straight away
    if (score > bestScore) { bestScore = score; best = { x: Math.round(bp.x + dx * dist), z: Math.round(bp.z + dz * dist) } }
  }
  return best
}
// null = free, 'step' = climbable by jumping, 'wall' = too high / has ceiling, 'gap' = hole ahead
function frontObstacle (b, dir, reach) {
  const p = b.entity.position
  const r = reach || 0.72
  const fx = Math.floor(p.x + dir.x * r); const fz = Math.floor(p.z + dir.z * r); const fy = Math.floor(p.y)
  const low = isSolidBlk(b, new Vec3(fx, fy, fz))
  const high = isSolidBlk(b, new Vec3(fx, fy + 1, fz))
  if (!low && !high) {
    if (!isSolidBlk(b, new Vec3(fx, fy - 1, fz)) && !isSolidBlk(b, new Vec3(fx, fy - 2, fz))) return 'gap'
    return null
  }
  const topY = fy + (high ? 2 : 1)
  if (isFreeBlk(b, new Vec3(fx, topY, fz)) && isFreeBlk(b, new Vec3(fx, topY + 1, fz))) return 'step'
  return 'wall'
}
// Auto-jump: holds the jump control (mineflayer auto-jumps on every landing while held)
// exactly when there is something to climb, and releases it otherwise.
function startAutoJump (b) {
  if (b.__ajump) clearInterval(b.__ajump)
  b.__ajump = setInterval(() => {
    try {
      if (!b.entity || b.health <= 0 || b.physicsEnabled === false) return
      if (Date.now() < jumpLockUntil) return          // another routine owns the jump key
      let pf = false; try { pf = b.pathfinder.isMoving() } catch (e) {}
      if (pf) return                                  // pathfinder is driving: IT owns the jump key
                                                      // (fighting it cancelled sprint-jumps and towers)
      if (Date.now() < forceJumpUntil) { holdJump(b); return }   // dodging arrows: keep hopping
      const now = Date.now()
      if (now < (b.__jumpHold || 0)) { holdJump(b); return }      // finish the jump we started
      const dir = controlDir(b)
      if (!dir) { relJump(b); b.__jumpHold = 0; return }          // no manual input: nothing to auto-jump for
      const d = dir
      const feet = b.entity.position.floored()
      if (b.entity.isInWater || isLiquidBlk(b, feet.offset(0, 1, 0))) {
        if (!b.entity.onGround) holdJump(b); else relJump(b)   // swim to the surface, don't bob in the shallows
        return
      }
      if (!isFreeBlk(b, feet.offset(0, 2, 0))) { relJump(b); return }   // ceiling: jumping is pointless
      const ob = frontObstacle(b, d)
      // Only hold the jump while there is a real STEP to climb. The old code also held it
      // whenever we merely touched a wall (isCollidedHorizontally) - in a forest that is
      // always, so the bot was permanently airborne, bouncing 1 block up and down forever.
      // The server reads that as flying and answers with a teleport 5x per second.
      if (ob === 'step') {
        if (!b.entity.onGround) { holdJump(b); return }   // mid-jump: keep it down to gain height
        b.__jumpHold = now + 260                            // press and hold long enough to clear it
        holdJump(b)
        return
      }
      relJump(b)
    } catch (e) {}
  }, 80)
}
function wantsToMove (b) {
  try { if (b.pathfinder.isMoving()) return true } catch (e) {}
  const g = n => { try { return !!b.getControlState(n) } catch (e) { return false } }
  if (g('forward') || g('back') || g('left') || g('right')) return true
  if (b.__drive) return true
  return false
}
// ==================== SELF TEST (objective jump/climb proof) ====================
async function selfTest (b) {
  const log2 = (...a) => log('SELFTEST', ...a)
  try {
    if (!b.entity) return log2('no entity')
    const wasMission = mission
    mission = { name: 'selftest' }
    stopDrive(b)
    try { b.pathfinder.setGoal(null) } catch (e) {}
    await sleep(300)
    const p0 = b.entity.position.clone()
    const feet = p0.floored()
    let cand = null
    for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, 1], [1, -1], [-1, -1]]) {
      const step = new Vec3(feet.x + d[0], feet.y, feet.z + d[1])
      if (!isSolidBlk(b, step)) continue
      if (!isFreeBlk(b, step.offset(0, 1, 0)) || !isFreeBlk(b, step.offset(0, 2, 0))) continue
      if (isLiquidBlk(b, step.offset(0, 1, 0))) continue
      if (!isFreeBlk(b, feet.offset(0, 1, 0))) continue
      cand = { d, step }
      break
    }
    if (!cand) { mission = wasMission; return log2('no 1-block step nearby at ' + pos(b) + ' - need flat ground with a ledge') }
    const yaw = Math.atan2(-cand.d[0], cand.d[1])
    log2('step ' + cand.step.x + ' ' + cand.step.y + ' ' + cand.step.z + ' dir=' + cand.d.join(',') + ' startY=' + p0.y.toFixed(2))
    let maxY = p0.y; let jumps = 0; let wasGround = true
    const sampler = setInterval(() => {
      try {
        if (!b.entity) return
        if (b.entity.position.y > maxY) maxY = b.entity.position.y
        if (wasGround && !b.entity.onGround) jumps++
        wasGround = !!b.entity.onGround
      } catch (e) {}
    }, 50)
    await b.look(yaw, 0.05, true)
    b.setControlState('forward', true)
    b.setControlState('sprint', false)
    const t0 = Date.now()
    let climbed = false
    while (Date.now() - t0 < 4000) {
      await sleep(120)
      if (!b.entity) break
      const f = b.entity.position.floored()
      if (f.x === cand.step.x && f.z === cand.step.z && f.y >= cand.step.y) { climbed = true; break }
    }
    b.setControlState('forward', false)
    clearInterval(sampler)
    const gained = maxY - p0.y
    log2('RESULT climbed=' + climbed + ' yGain=' + gained.toFixed(2) + ' airJumps=' + jumps + ' pos=' + pos(b) + ' stuckLevel=' + (b.__stuckLevel || 0))
    log2(climbed && gained > 0.7 ? 'PASS - steps up the ledge' : 'FAIL - did not climb (yGain ' + gained.toFixed(2) + ', jumps ' + jumps + ')')
    mission = wasMission
  } catch (e) { log2('ERR', e && e.message); mission = null }
}
// ==================== UNIVERSAL STUCK GUARD ====================
let unstickBusy = false
let unstickBusyAt = 0
let lastUnstickAt = 0
let stuckCount = 0
let stuckSince = 0
let unstickAnchor = null
function busyDoingSomething (b) {
  if (Date.now() - lastDigAt < 2500) return true                       // mining a block takes seconds
  try { if (b.autoEat && b.autoEat.isEating) return true } catch (e) {}
  try { if (b.currentWindow) return true } catch (e) {}                // crafting / chest
  return false
}
function startStuckGuard (b) {
  if (b.__stuckGuard) clearInterval(b.__stuckGuard)
  let hist = []
  b.__stuckLevel = 0
  b.__stuckGuard = setInterval(() => {
    try {
      if (!b.entity || b.health <= 0) { hist = []; stuckSince = 0; b.__stuckLevel = 0; return }
      const now = Date.now()
      const p = b.entity.position
      hist.push({ t: now, x: p.x, y: p.y, z: p.z })
      while (hist.length && now - hist[0].t > 4200) hist.shift()
      // A narrow shaft is its own kind of stuck: the bot digs one, ends up wedged in it, and
      // the "busy digging" / "pathfinder is moving" resets below keep the clock at zero for
      // ever - so it hops in place for hours and never escalates to the dig-out level.
      // Inside a hole those resets must NOT apply, otherwise nothing ever gets it out.
      // defence in depth: an await that never resolves must not disable the guard for good
      if (unstickBusy && Date.now() - unstickBusyAt > 60000) {
        log('UNSTICK_BUSY_STALE cleared after ' + Math.round((Date.now() - unstickBusyAt) / 1000) + 's')
        unstickBusy = false
      }
      const inHole = inShaft(b)
      const wet = wetNow(b)
      if (!wet.feet && !wet.head && (unstickBusy || b.__fleeing || hiding || diggingUp || tunneling || b.__pillarEscape || deepNearCrater(b) || (!inHole && (!wantsToMove(b) || busyDoingSomething(b))))) {
        hist = []; stuckSince = 0; b.__stuckLevel = 0; return
      }
      if (unstickAnchor && p.distanceTo(unstickAnchor) > 2.2) { unstickAnchor = null; stuckSince = 0; b.__stuckLevel = 0 }
      const h0 = hist[0]
      const flat = Math.hypot(p.x - h0.x, p.z - h0.z)
      const rise = Math.abs(p.y - h0.y)
      if (flat > 0.7 || rise > 1.0) { stuckSince = 0; b.__stuckLevel = 0; b.__detourN = 0; b.__replanN = 0; b.__stepN = 0; return }   // moving again: budgets reset
      if (!stuckSince) { stuckSince = now; return }                     // start the clock, act later
      const wedged = now - stuckSince
      const level = wedged > 12000 ? 4 : wedged > 7000 ? 3 : wedged > 4000 ? 2 : wedged > 2000 ? 1 : 0
      if (!level) return
      if (level === b.__stuckLevel && now - lastUnstickAt < 7000) return
      b.__stuckLevel = level
      stuckCount++; stats.stucks++
      lastUnstickAt = now
      unstickAnchor = p.clone()
      noteStuckSpot(b)
      log('STUCK L' + level, 'wedged ' + (wedged / 1000).toFixed(0) + 's flat=' + flat.toFixed(2) + ' rise=' + rise.toFixed(2) + ' at ' + pos(b) + ' mission=' + (mission ? mission.name : '-'))
      unstick(b, level)
      // Auto-start explore if stuck at L2+ with no active mission
      if (level >= 2 && !mission && !b.__fleeing && !hiding) { try { log("STUCK_AUTO_EXPLORE at", pos(b)); startMission(b, "explore") } catch (e) {} }
    } catch (e) {}
  }, 400)
}
async function unstick (b, level) {
  if (unstickBusy) { if (Date.now() - (b.__dirLog||0) > 10000) { log("DIR_BLOCK unstickBusy"); b.__dirLog = Date.now() } return }
  unstickBusy = true
  unstickBusyAt = Date.now()
  const d0 = intendedDir(b)
  const yaw0 = b.entity.yaw
  try {
   try {
    // A shaft has no sidestep and no step-up. Checked first, because the bot can bob
    // around inside one for hours without ever reaching a higher escalation level.
    if (inShaft(b) && !inCollapseZone(b)) {
      log('UNSTICK dig out of shaft rim=' + rimAbove(b) + ' at', pos(b))
      stopDrive(b)
      if (mission && mission.name !== 'selftest') { missionFail(mission.name); mission = null }
      try { b.clearControlStates() } catch (e) {}
      await withTimeout(digUpAndOut(b, 8), 55000, null)
      return
    }
    if (level <= 1) {
      // cheapest nudge: hop TOWARD the intended direction (in-place hops climb nothing).
      // Do NOT steal the pathfinder goal; if it is driving, forward is already held.
      let pf = false; try { pf = b.pathfinder.isMoving() } catch (e) {}
      // BUG: if the pathfinder is "driving" but we are not moving, its path is dead. Hopping
      // in place next to it (the old behaviour, spammed hundreds of times) achieves nothing -
      // stop the dead path and re-plan, which now goes through the route-around ladder.
      if (pf && b.__lastGoal && !pfOwned(b)) {
        b.__replanN = (b.__replanN || 0) + 1
        noteStuckSpot(b)
        try { b.pathfinder.stop() } catch (e) {}
        if (b.__replanN > 4) {
          const g = b.__lastGoal; b.__lastGoal = null
          log('PF_ABANDON ' + Math.round(g.x) + ',' + Math.round(g.z) + ' unreachable -> pick another way at ' + pos(b))
          try { mission = null } catch (e) {}
          const p = b.entity.position
          const ft = p.floored()
          // The detour ladder has already failed. What is in front of us may be a soft shore
          // lip one block high: making a step out of it (dirt/sand/leaves only, never stone,
          // never our own planks) is cheaper than wandering the coast for ten minutes.
          b.__stepN = b.__stepN || 0
          let carved = 0; let cv = null
          if (b.__stepN > 3) { log('STEP_DIG capped - only walking now at ' + pos(b)) }
          try {
            const dd = intendedDir(b)
            for (const dy of [0, 1]) {
              const v = new Vec3(Math.floor(p.x + dd.x * 1.3), ft.y + dy, Math.floor(p.z + dd.z * 1.3))
              const k = b.blockAt(v)
              if (!k || k.boundingBox !== 'block') continue
              const soft = /dirt|sand|gravel|clay|leaves|grass_block|podzol|moss_block|snow|terracotta|mud/.test(k.name)
              const hd = typeof k.hardness === 'number' ? k.hardness : 1
              if (!soft || hd > 1.6 || STRUCT_RE.test(k.name)) break
              if (b.__stepN > 3) break
              b.__allowDig = true
              try { if (await withTimeout(digBlock(b, v), 9000, false)) { carved++; cv = v; b.__stepN++ } } finally { b.__allowDig = false }
            }
          } catch (e) {}
          if (carved) { stats.stepdug = (stats.stepdug || 0) + carved; log('STEP_DIG carved=' + carved + ' at ' + cv + ' (soft step, ladder already failed)') }
          // BUG: LEASH_RETURN re-issued the same impossible GoalNear every few seconds, so
          // "go around" was overwritten by "go straight at the wall" - PF_ABANDON every 8s and
          // no movement at all. Give the detour some air to breathe.
          homeRunUntil = Math.max(homeRunUntil, Date.now() + 30000)
          b.__abandonN = (b.__abandonN || 0) + 1
          const side = b.__abandonN % 2 === 0 ? 1 : -1
          try { b.pathfinder.setGoal(new goals.GoalXZ(p.x + side * 8, p.z + 6)) } catch (e) {}
          await sleep(700)
          return
        }
        log('UNSTICK replan #' + b.__replanN + ' -> ' + Math.round(b.__lastGoal.x) + ',' + Math.round(b.__lastGoal.z) + ' at ' + pos(b))
        try { b.pathfinder.setGoal(new goals.GoalNear(b.__lastGoal.x, b.__lastGoal.y, b.__lastGoal.z, 4)) } catch (e) {}
        await sleep(500)
        return
      }
      log('UNSTICK step-up' + (pf ? ' (pf driving)' : '') + ' at', pos(b))
      jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 1500)
      if (!pf) {
        try { await b.look(Math.atan2(-d0.x, d0.z), 0, true) } catch (e) {}
        try { b.setControlState('forward', true) } catch (e) {}
      }
      holdJump(b)
      await sleep(620)
      relJump(b)
      if (!pf) { try { b.setControlState('forward', false) } catch (e) {} }
      await sleep(380)
    } else if (level === 2) {
      // A 1x1 shaft has no sidestep and no way up - the only answer is to dig/tower out.
      if (rimAbove(b) >= 2.5 && !inCollapseZone(b)) {
        log('UNSTICK dig out of shaft rim=' + rimAbove(b) + ' at', pos(b))
        stopDrive(b)
        if (mission && mission.name !== 'selftest') { missionFail(mission.name); mission = null }
        try { b.clearControlStates() } catch (e) {}
        await withTimeout(digUpAndOut(b, 8), 55000, null)
        return
      }
      log('UNSTICK sidestep at', pos(b))
      try { b.pathfinder.setGoal(null) } catch (e) {}
      jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 2000)
      try { await b.look(yaw0 + Math.PI / 2, 0, true) } catch (e) {}
      b.setControlState('forward', true); b.setControlState('jump', true); b.setControlState('sprint', true)
      await sleep(430)
      b.setControlState('forward', false); b.setControlState('jump', false); b.setControlState('sprint', false)
      await sleep(140)
      try { await b.look(Math.atan2(-d0.x, d0.z), 0, true) } catch (e) {}
      b.setControlState('forward', true); b.setControlState('jump', true)
      await sleep(650)
      b.setControlState('forward', false); b.setControlState('jump', false)
    } else if (level === 3) {
      jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 6000)
      const feet = b.entity.position.floored()
      const ob = frontObstacle(b, d0, 0.9)
      const aheadBlk = b.blockAt(new Vec3(Math.floor(b.entity.position.x + d0.x), feet.y, Math.floor(b.entity.position.z + d0.z)))
      const soft = aheadBlk && ((aheadBlk.hardness === undefined ? 1 : aheadBlk.hardness) <= 1.5 || hasPickaxe(b))
      b.__detourN = b.__detourN || 0
      // BUG #3 (the owner's words: "ты их ломаешь, даже не зная что их можно обойти").
      // Three cheap detours - sidestep, then sidestep + forward, then a longer arc -
      // are tried before a single block is broken. Only a real dead end gets dug out.
      if (b.__detourN < 3 && ob !== 'none' && !inCollapseZone(b)) {
        b.__detourN++
        stats.detours = (stats.detours || 0) + 1
        const side = (b.__detourN % 2 === 0) ? 1 : -1
        const arc = b.__detourN === 3 ? 1500 : 850
        log('UNSTICK DETOUR #' + b.__detourN + ' ob=' + ob + ' ' + (side > 0 ? 'right' : 'left') + ' at ' + pos(b) + ' (no breaking)')
        try { b.pathfinder.setGoal(null) } catch (e) {}
        try { await b.look(yaw0 + side * Math.PI / 2, 0, true) } catch (e) {}
        b.setControlState('forward', true); b.setControlState('jump', true)
        await sleep(arc)
        b.setControlState('forward', false); b.setControlState('jump', false)
        await sleep(150)
        try { await b.look(Math.atan2(-d0.x, d0.z), 0, true) } catch (e) {}
        b.setControlState('forward', true)
        await sleep(700)
        b.setControlState('forward', false)
        return
      }
      if (ob !== 'wall' || !soft || inCollapseZone(b)) {
        // don't wreck the terrain: sprint-run sideways to get around the obstacle
        const side = (stuckCount % 2 === 0) ? 1 : -1
        log('UNSTICK bypass run ' + (side > 0 ? 'right' : 'left') + ' ob=' + ob + ' at', pos(b))
        try { b.pathfinder.setGoal(null) } catch (e) {}
        try { await b.look(yaw0 + side * Math.PI / 2, 0, true) } catch (e) {}
        b.setControlState('forward', true); b.setControlState('sprint', true); b.setControlState('jump', true)
        await sleep(1300)
        b.setControlState('forward', false); b.setControlState('jump', false); b.setControlState('sprint', false)
        return
      }
      // if the "soft wall" is our own house, the answer is the door, not the pickaxe
      const nearDoor = findDoorNear(b, b.entity.position.floored(), 4)
      if (nearDoor && isStruct(b, nearDoor.v)) {
        log('UNSTICK at own wall -> door at ' + nearDoor.v)
        try { b.pathfinder.setGoal(null) } catch (e) {}
        const oc = doorOutCell(b, nearDoor.v) || nearDoor.v
        await b.pathfinder.goto(new goals.GoalNear(oc.x, oc.y, oc.z, 1.2)).catch(() => {})
        await actDoor(b, nearDoor.v, true)
        await sleep(400)
        return
      }
      log('UNSTICK dig ahead (soft wall) at', pos(b))
      try { b.pathfinder.setGoal(null) } catch (e) {}
      for (let k = 1; k <= 2; k++) {
        for (let dy = 0; dy <= 2; dy++) {
          await withTimeout(digBlock(b, new Vec3(Math.floor(b.entity.position.x + d0.x * k), feet.y + dy, Math.floor(b.entity.position.z + d0.z * k))), 8000, false)
        }
      }
      try { await b.look(Math.atan2(-d0.x, d0.z), 0, true) } catch (e) {}
      b.setControlState('forward', true); b.setControlState('jump', true)
      await sleep(950)
      b.setControlState('forward', false); b.setControlState('jump', false)
    } else {
      log('UNSTICK give up: drop mission, climb out at', pos(b))
      stopDrive(b)
      if (mission && mission.name !== 'selftest') { missionFail(mission.name); mission = null }
      try { b.clearControlStates() } catch (e) {}
      await sleep(400)
      await withTimeout(digUpAndOut(b, 8), 50000, null)
    }
   } catch (e) { log('UNSTICK_ERR', e && e.message ? e.message : String(e)) }
  } finally {
    // REGRESSION of my own (patch11/12): the new detour/replan branches return early, and a
    // return inside try skips the code after it - so unstickBusy latched true forever, the
    // stuck guard went silent and the director just printed DIR_BLOCK. finally covers every
    // return, present and future.
    try { b.clearControlStates() } catch (e) {}
    unstickBusy = false
  }
}
// Dig a 2-deep pocket away from the threat and wait: breaks line of sight, saves us from skeletons.
async function hidePocket (b, threat, ms, seal) {
  if (hiding || !b.entity) return
  // hiding in water = drowning/getting shot: wall-burrow instead (seals + waits + digs out)
  // BUG (owner: "идёшь к воде, сидишь там и задыхаешься"): being wet used to mean "dig a wall
  // pocket at water level and sit in it for up to 2 minutes". The pocket is a sealed coffin -
  // wet inside, hiding set, so every escape routine refused to run. Dry land first, pocket only
  // as a last resort and only for 30s.
  if (botWet(b) && !b.__wallBury && !inCollapseZone(b)) {
    const dry = nearestDry(b, 16)
    if (dry) {
      log('HIDE wet -> shore at ' + dry.x + ' ' + dry.y + ' ' + dry.z + ' (d=' + (dry.d || 0).toFixed(1) + ')')
      try { b.pathfinder.setGoal(null) } catch (e) {}
      b.__dryRunUntil = Date.now() + 20000
      const ok = await b.pathfinder.goto(new goals.GoalNear(dry.x, dry.y, dry.z, 1)).then(() => true).catch(() => false)
      log('HIDE shore reached=' + ok + ' at ' + pos(b))
      return
    }
    log('HIDE wet -> wallBury capped 30s at', pos(b))
    await wallBury(b, 30000)
    return
  }
  if (inCollapseZone(b)) { log('HIDE skip in crater at', pos(b)); return }   // digging here = sinking
  hiding = true
  lastHideAt = Date.now()
  try {
    log('HIDE pocket at', pos(b), 'hp=' + Math.round(b.health), 'threat=' + (threat && threat.name) + (seal ? ' SEAL' : ''))
    try { b.pathfinder.setGoal(null) } catch (e) {}
    stopDrive(b)
    jumpLockUntil = Math.max(jumpLockUntil, Date.now() + Math.min(ms || 22000, 30000))
    manualLockUntil = Math.max(manualLockUntil, Date.now() + Math.min(ms || 22000, 30000))
    const feet = b.entity.position.floored()
    let dir = [1, 0]
    if (threat && threat.position) {
      const ax = b.entity.position.x - threat.position.x; const az = b.entity.position.z - threat.position.z
      const l = Math.hypot(ax, az) || 1
      dir = [Math.round(ax / l), Math.round(az / l)]
      if (!dir[0] && !dir[1]) dir = [1, 0]
    }
    for (let k = 1; k <= 2; k++) {
      await withTimeout(digBlock(b, feet.offset(dir[0] * k, 0, dir[1] * k)), 9000, false)
      await withTimeout(digBlock(b, feet.offset(dir[0] * k, 1, dir[1] * k)), 9000, false)
    }
    try { await b.look(Math.atan2(-dir[0], dir[1]), 0, true) } catch (e) {}
    b.setControlState('forward', true)
    await sleep(1100)
    b.setControlState('forward', false)
    b.setControlState('sneak', true)
    // sealed mode: wall the entrance up with the material we just mined. Zombies can't
    // dig, skeletons have no LOS - this is how a gearless bot survives a spawn-camp night.
    const e1 = feet.offset(dir[0], 0, dir[1]); const e2 = feet.offset(dir[0], 1, dir[1])
    let sealed = false
    // NOTE: threatsNear takes an AGGRO-RADIUS MULTIPLIER, not blocks - with mul=1.6 the gate
    // meant "no mobs within ~10-25 blocks" (never true at the nest), so we never sealed.
    // Only a mob literally inside the tunnel (<2.5b) must block sealing.
    let mobInside = false
    try { for (const th of threatsNear(b, 3)) { if (th.d < 2.5) { mobInside = true; break } } } catch (e) {}
    if (seal && !mobInside) {
      await ensurePlaceable(b, 2)
      const refB = b.blockAt(feet.offset(dir[0], -1, dir[1]))        // ground under the entrance cell
      if (countPlaceable(b) >= 1 && refB && refB.boundingBox === 'block') {
        const r1 = await withTimeout(b.placeBlock(refB, new Vec3(0, 1, 0)), 4000, 'to')
        if (r1 !== 'to') {
          sealed = true
          if (countPlaceable(b) >= 1) {
            const refT = b.blockAt(e1)                               // stack the second seal on the first
            if (refT) await withTimeout(b.placeBlock(refT, new Vec3(0, 1, 0)), 4000, 'to')
          }
          log('HIDE sealed at', pos(b))
        }
      }
    }
    const t0 = Date.now()
    const limit = ms || 22000
    while (Date.now() - t0 < limit) {
      if (!b.entity || b.health <= 0) break
      if (!sealed && Date.now() - t0 > 7000 && !threatsNear(b, 1.2).length) break
      if (!sealed && Date.now() - t0 > 12000 && threatsNear(b, 1.2).length) break  // tunnel breached / they found us: run instead
      // sealed: sleep out the night, leave at dawn when the area is clear
      if (sealed && Date.now() - t0 > 20000 && !isNight(b) && !isDusk(b) && !threatsNear(b, 1.2).length) break
      await sleep(700)
    }
    if (sealed) {
      await withTimeout(digBlock(b, e2), 9000, false)
      await withTimeout(digBlock(b, e1), 9000, false)
    }
    b.setControlState('sneak', false)
    // release OUR long locks immediately - a zombie waiting outside must be flee-able
    manualLockUntil = Math.min(manualLockUntil, Date.now() + 1500)
    jumpLockUntil = Math.min(jumpLockUntil, Date.now() + 1500)
    log('HIDE done at', pos(b), 'hp=' + Math.round(b.health))
  } catch (e) { log('HIDE_ERR', e && e.message) }
  hiding = false
}
// ==================== STATS + PERSISTENCE ====================
const HB_FILE = '/home/agent/bot/heartbeat.json'
const STATE_FILE = '/home/agent/bot/state.json'
const SOCIAL_FILE = '/home/agent/bot/social.json'
let lastDeathCause = ''
let stats = { deaths: 0, stucks: 0, mined: 0, crafted: 0, replies: 0, walked: 0, missions: 0, jumps: 0, kills: 0, born: Date.now() }
try { const s = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); if (s && typeof s === 'object') stats = Object.assign(stats, s) } catch (e) {}
function saveStats () { try { fs.writeFileSync(STATE_FILE, JSON.stringify(stats)) } catch (e) {} }
setInterval(saveStats, 20000)
process.on('exit', saveStats)
let missionBackoff = {}
function missionFail (name) { missionBackoff[name] = Date.now() + 45000 }
function missionAllowed (name) {
  if (leashOn && (name === 'explore')) return false      // no long walks away from home
  return !(missionBackoff[name] && Date.now() < missionBackoff[name])
}
let hbLastPos = null
function startHeartbeat (b) {
  if (b.__hb) clearInterval(b.__hb)
  b.__hb = setInterval(() => {
    try {
      const p = b.entity ? b.entity.position : null
      if (p && hbLastPos) stats.walked += Math.hypot(p.x - hbLastPos.x, p.z - hbLastPos.z)
      if (p) hbLastPos = p.clone()
      const s = {
        t: Date.now(), pid: process.pid, up: Math.round(process.uptime()),
        pos: b.entity ? pos(b) : 'n/a', hp: Math.round(b.health || 0), food: Math.round(b.food || 0),
        dim: (b.game && b.game.dimension) || '?', day: b.time ? Math.floor((b.time.age || 0) / 24000) : 0,
        clock: b.time ? Math.round((b.time.age || 0) % 24000) : 0,
        mission: mission ? mission.name : null, director: directorOn,
        stuckLevel: b.__stuckLevel || 0, stuckTotal: stats.stucks, unstickBusy,
        drive: !!b.__drive, flee: !!b.__fleeing, reconnects, deaths: stats.deaths,
        mined: stats.mined, crafted: stats.crafted, replies: stats.replies, kills: stats.kills || 0, walked: Math.round(stats.walked),
        ground: b.entity ? !!b.entity.onGround : false, collided: b.entity ? !!b.entity.isCollidedHorizontally : false,
        inv: b.inventory ? b.inventory.items().slice(0, 14).map(i => i.name + ':' + i.count) : [],
        chat: chatRing.slice(-3).map(c => (c.u || '?') + ': ' + c.x)
      }
      fs.writeFileSync(HB_FILE, JSON.stringify(s))
    } catch (e) {}
  }, 3000)
}
// ==================== CHAT BRAIN ====================
const MY_NAME = (USERNAME || 'Puff').toLowerCase()
const NAME_RE = new RegExp('^\\s*(' + MY_NAME + '|' + MY_NAME.replace(/f/g, 'ff') + '|пуф+|puf+)([\\s,:!?\\.]|$)', 'i')
const NAME_ANY_RE = new RegExp('(' + MY_NAME + '|пуф+)', 'i')
const OWNERS = (process.env.PUFF_OWNERS || 'MrBaGued').split(',').map(x => x.trim().toLowerCase()).filter(Boolean)
// quick, self-composed answer to a message that addresses Puff (MC_AUTOREPLY=off disables it)
const autoReplyOn = String(process.env.MC_AUTOREPLY || 'on').toLowerCase() !== 'off'
function isOwner (user) { return OWNERS.indexOf(norm(user)) >= 0 }
// NO canned text anywhere: Puff composes every chat line himself.
let chatRing = []
let social = {}
try { social = JSON.parse(fs.readFileSync(SOCIAL_FILE, 'utf8')) || {} } catch (e) { social = {} }
function saveSocial () { try { fs.writeFileSync(SOCIAL_FILE, JSON.stringify(social)) } catch (e) {} }
setInterval(saveSocial, 30000)
let lastSpokeAt = 0
let spokeTimes = []
function canSpeak () {
  const now = Date.now()
  if (now - lastSpokeAt < 2600) return false
  spokeTimes = spokeTimes.filter(t => now - t < 300000)
  if (spokeTimes.length >= 9) return false
  return true
}
function say (b, text) {
  if (!b || !b.entity || !text) return false
  if (!canSpeak()) return false
  lastSpokeAt = Date.now()
  spokeTimes.push(Date.now())
  stats.replies++
  try { b.chat(text.slice(0, 240)); log('SAY', text.slice(0, 120)); return true } catch (e) { log('SAY_ERR', e && e.message); return false }
}
function norm (s) { return String(s || '').toLowerCase().replace(/[«»"'`~]/g, '').replace(/\s+/g, ' ').trim() }
function addressedToMe (text) {
  const t = norm(text)
  if (!t) return false
  if (NAME_RE.test(t)) return true                      // name at the start  <- what the user asked for
  const i = t.search(NAME_ANY_RE)
  return false /* user wants ONLY start match */
}
function stateBlurb (b) {
  const parts = []
  if (mission) parts.push('занят: ' + mission.name)
  else parts.push('свободен')
  parts.push('хп ' + Math.round(b.health || 0))
  const wood = countAny(b, LOG_TYPES); const pick = hasPickaxe(b)
  if (wood) parts.push('дерева ' + wood)
  if (pick) parts.push('кирка есть'); else parts.push('кирки нет')
  if (countFood(b)) parts.push('еды ' + countFood(b))
  return parts.join(', ')
}
function findPlayerByName (b, name) {
  const n = norm(name)
  for (const id in b.entities) {
    const e = b.entities[id]
    if (!e || e.type !== 'player' || !e.username) continue
    if (norm(e.username) === n || norm(e.username).indexOf(n) === 0) return e
  }
  return null
}
// addressed-but-unanswered messages pile up here; the agent (Puff) reads them with
// the 'asks' control command and answers in his own words with 'chat <text>'.
const pendingAsks = []
// ---------- answering in Puff's own words ----------
// There is no fixed greeting and no fixed answer anywhere: a reply is composed from
// what was actually said (the topic), what Puff is doing right now and a closing,
// and the wording is picked by a hash of the message - so the same question never
// gets the same answer twice and nothing reads like a template.
// A bare "привет" that is not addressed to Puff is left alone (the user asked for that).
function hashStr (s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) } return (h >>> 0) }
function pickOf (arr, seed) { return arr[(seed >>> 0) % arr.length] }
const STOPWORDS = new Set(('и в на с не что как ты я он она мы вы это у а то же но бы ли за по из от до для о об да нет мне меня тебя его ее так вот там тут уже еще ещё быть есть надо ну все всё кто где когда хорошо привет здаров ку живой скинь дай кинь напиши сделай зачем почему помнишь помни расскажи расскажите скажи скажите строишь построить строить помоги помогай пропадай пропадаешь хочешь хотим думаешь думать думаем видишь слышишь знаешь знаю будет будут делать делаешь делаю говорю говоришь говорите слушаю слушаешь ответь отвечай спрашивай спроси хто есть были был была было можно тоже очень опять снова сейчас вместе один раз много мало большой маленький новый старый хороший плохой первый второй весь вся моя твой наш ваш свой их умею умеешь пошёл пошли поехали пойдём').split(' '))
function topicOf (text) {
  const words = norm(text).replace(/[^0-9a-zа-яё]+/gi, ' ').split(/\s+/).filter(Boolean)
  const cand = words.filter(w => w.length > 2 && !STOPWORDS.has(w) &&
    !/^пуф+$/.test(w) && !/^puf+$/.test(w) && w !== 'puff')
  if (!cand.length) return null
  // russian is SOV: the topic sits near the END of the sentence ("ты строишь базу" -> базу)
  const t = cand[cand.length - 1]
  return t.length > 14 ? null : t
}
const GREETING_RE = /^(привет|здаров|здарова|хай|хеллоу|hello|hi|ку|йо|салют|приветик|приветики|доброе утро|добрый день|добрый вечер)[\s!.?,]*$/i
const MISSION_RU = { wood: 'дерево', stone: 'камень', food: 'еда', explore: 'разведка', gather: 'сбор', shelter: 'укрытие', home: 'дом' }
function composeReply (b, user, text) {
  const t = norm(text)
  const seed = hashStr(t + '|' + norm(user) + '|' + Math.round(b.health) + '|' + Math.round(b.food) + '|' + (mission ? mission.name : '-'))
  const topic = topicOf(text)
  const doing = mission ? (MISSION_RU[mission.name] || mission.name) : (b.__fleeing ? 'убегаю' : (b.__drive ? 'иду' : 'стою'))
  const parts = []
  parts.push(topic
    ? pickOf([
        'про ' + topic + ' - расскажи',
        topic + ', да?',
        'а ' + topic + ' - уже интересно',
        'про ' + topic + ' - в курсе',
        'ну про ' + topic + ' - что там'
      ], seed)
    : pickOf([
        'да, в курсе',
        'угу, понял',
        'ага, слушаю',
        'так, продолжай',
        'хм, я тут'
      ], seed))
  // a short real status - not the same status readout every single time
  if (seed % 5 !== 0) {
    const cond = b.health < 11
      ? pickOf(['хп ' + Math.round(b.health) + ', надо отдышаться', 'хп всего ' + Math.round(b.health), 'так себе, хп ' + Math.round(b.health)], seed >>> 5)
      : (b.food < 12
          ? pickOf(['еды ' + Math.round(b.food) + ', пора жрать', 'голодный, еды ' + Math.round(b.food)], seed >>> 5)
          : pickOf(['хп ' + Math.round(b.health) + ', норм', 'всё ровно'], seed >>> 5))
    parts.push(pickOf([cond + ', ' + doing, doing + ', ' + cond, cond], seed >>> 3))
  }
  if (seed % 3 !== 0) {
    parts.push(pickOf([
      'ты по чему?',
      'а ты что делаешь?',
      'ты где сейчас?',
      'у тебя как дела?',
      'ты тут надолго?',
      'а сам что думаешь?'
    ], seed >>> 11))
  }
  return parts.join('. ').replace(/\s+/g, ' ').replace(/\.\s*\./g, '.').trim().slice(0, 220)
}
let autoReplyTimes = []
function canAutoReply (b) {
  const now = Date.now()
  autoReplyTimes = autoReplyTimes.filter(t => now - t < 300000)
  if (autoReplyTimes.length >= 6) return false
  if (b.__lastAutoAt && now - b.__lastAutoAt < 9000) return false
  return true
}
function feedChat (b, user, text, whisper) {
  try {
    const t = String(text || '')
    chatRing.push({ t: Date.now(), u: user || '', x: t.slice(0, 200) })
    if (chatRing.length > 60) chatRing.shift()
    if (!user || user === USERNAME) return
    const low = norm(user)
    if (!social[low]) social[low] = { met: Date.now(), talks: 0, last: 0 }
    social[low].seen = Date.now()
    let toMe = whisper || addressedToMe(t)
    if (!toMe && isOwner(user) && t.length > 12) {
      // the owner talking in chat next to me counts - but at most once per 20s
      if (Date.now() - (social[low].ownerAsk || 0) > 20000) { toMe = true; social[low].ownerAsk = Date.now() }
    }
    if (!toMe) return
    social[low].talks++; social[low].last = Date.now()
    pendingAsks.push({ t: Date.now(), u: user, x: t.slice(0, 200), w: !!whisper, auto: false })
    if (pendingAsks.length > 30) pendingAsks.shift()
    log('ASK', (whisper ? '[whisper] ' : '') + user + ': ' + t.slice(0, 140))
    // answer right away - a human takes a moment to type, so wait a beat, but never
    // longer than a couple of seconds. The agent can still follow up with a better
    // answer through 'asks' + 'chat'.
    if (autoReplyOn && canAutoReply(b)) {
      const wait = 1100 + (hashStr(t + norm(user)) % 2300)
      setTimeout(() => {
        try {
          if (!b || !b.entity || b.health <= 0) return
          if (GREETING_RE.test(t) && !addressedToMe(text)) return      // bare greeting -> leave it alone
          const reply = composeReply(b, user, text)
          if (!reply) return
          if (say(b, reply)) {
            b.__lastAutoAt = Date.now(); autoReplyTimes.push(Date.now())
            const a = pendingAsks[pendingAsks.length - 1]
            if (a && a.u === user) a.auto = true
            log('AUTO_REPLY', user + ' -> ' + reply.slice(0, 120))
          }
        } catch (e) { log('AUTO_ERR', e && e.message) }
      }, wait)
    }
  } catch (e) { log('CHATBRAIN_ERR', e && e.message) }
}


// ==================== COMBAT: we fight back and we WIN ====================
// Old defence code swung once per reflex tick (~1.1s) and only at hp>=10 while armed.
// Result: 127 deaths, 0 kills. This is a dedicated 240ms loop: best weapon, swing on the
// item cooldown, jump-crits, circle-strafe vs shooters, hit-and-run vs creepers, and it
// does not let go of a target until it is dead.
const MOB_HP = { zombie: 20, zombie_villager: 20, husk: 20, drowned: 20, skeleton: 20, stray: 20, bogged: 20, wither_skeleton: 20, creeper: 20, spider: 16, cave_spider: 16, silverfish: 8, enderman: 40, slime: 16, phantom: 20, pillager: 24, vindicator: 24, witch: 26, breeze: 20 }
const WEAPON_INFO = { netherite_sword: [8, 600], diamond_sword: [7, 600], iron_sword: [6, 500], stone_sword: [5, 620], golden_sword: [4, 500], wooden_sword: [4, 520], netherite_axe: [10, 1250], diamond_axe: [9, 1150], iron_axe: [9, 1050], stone_axe: [9, 1100], golden_axe: [7, 1000], wooden_axe: [7, 1000] }
const fightState = { lastSwing: 0, strafe: 1, strafeAt: 0, retreatUntil: 0, goalAt: 0 }
function fin3 (p) { return !!p && isFinite(p.x) && isFinite(p.y) && isFinite(p.z) }
function slook (b, p) { try { if (fin3(p)) b.lookAt(p, true, false) } catch (e) {} }
function radiusOf (hp) { return hp >= 10 ? 14 : (hp >= 7 ? 9 : 4.5) }
function bestWeapon (b) {
  let best = null
  try {
    for (const it of b.inventory.items()) {
      const info = WEAPON_INFO[it.name]
      if (!info) continue
      if (!best || info[0] > (WEAPON_INFO[best.name] || [0, 0])[0]) best = it
    }
  } catch (e) {}
  return best
}
function swingMs (wp) { const i = wp && WEAPON_INFO[wp.name]; return i ? i[1] : 640 }
const FOOD_MOBS = new Set(['cow', 'pig', 'sheep', 'chicken', 'rabbit', 'mooshroom', 'goat'])
function huntTarget (b, radius) {
  let best = null; let bd = radius
  if (!b.entity) return null
  for (const id in b.entities) {
    const e = b.entities[id]
    if (!e || !e.position || !e.name || e === b.entity || !fin3(e.position)) continue
    if (!FOOD_MOBS.has(String(e.name).toLowerCase())) continue
    if (e.health !== undefined && e.health <= 0) continue
    const d = e.position.distanceTo(b.entity.position)
    if (d < bd) { bd = d; best = e }
  }
  return best
}
function fightTarget (b, radius) {
  let worst = null; let ws = 1e9
  if (!b.entity) return null
  const hurt = String(b.__lastHurtBy || '')
  for (const id in b.entities) {
    const e = b.entities[id]
    if (!e || !e.position || !e.name || e === b.entity) continue
    const nm = String(e.name).toLowerCase()
    if (!HOSTILE.has(nm)) continue
    if (e.health !== undefined && e.health <= 0) continue
    const d = e.position.distanceTo(b.entity.position)
    if (d > radius) continue
    let s = d / Math.max(1, threatRadius(nm))
    if (hurt && String(e.id) === hurt) s -= 50                     // the one that hit us goes first
    if (nm === 'creeper' && d < 6) s -= 20                          // fuse is the real deadline
    if (s < ws) { ws = s; worst = e }
  }
  return worst
}
function stopFight (b) {
  b.__fighting = false; b.__fightAt = 0; b.__fightId = undefined
  try { b.setControlState('left', false); b.setControlState('right', false); b.setControlState('sprint', false) } catch (e) {}
}
function strafeAround (b, st, now) {
  if (now - st.strafeAt > 700) { st.strafeAt = now; st.strafe = Math.random() < 0.5 ? 1 : -1 }
  const L = st.strafe > 0, R = !L
  try { b.setControlState('left', L); b.setControlState('right', R); b.setControlState('back', false); b.setControlState('forward', false) } catch (e) {}
}
function markHit (b, e) {
  if (!b.__hit) b.__hit = {}
  b.__hit[e.id] = { name: e.name, t: Date.now() }
}
async function combatTick (b) {
  if (b !== bot) { if (b.__combat) { clearInterval(b.__combat); b.__combat = null } ; return }   // ghost client
  if (!b.entity || !b.isAlive || b.health <= 0) { stopFight(b); return }
  const now = Date.now()
  if (!reflexOn || b.__noFight) { if (b.__fighting) stopFight(b); return }
  if (!fin3(b.entity.position) || !isFinite(b.health)) { stopFight(b); return }
  const wp = bestWeapon(b)
  const armed = !!wp
  const hp = b.health
  if (hp < 6) { if (b.__fighting) stopFight(b); return }          // hopeless, let survival logic run
  // burst-damage panic: 6+ hearts lost inside 4s means this fight ends with our death,
  // however good our own dps looks - break off and let the flee/hide logic do its job
  if (!b.__dmgBuf || now - 4000 > (b.__dmgBuf.t0 || 0)) b.__dmgBuf = { t0: now, hp0: hp }
  if (hp < (b.__dmgBuf.hp0 || 20) - 5) {
    if (b.__fighting) { log('FIGHT_PANIC', (b.__fightName || '?') + ' hp=' + Math.round(hp)); stopFight(b) }
    b.__dmgBuf = { t0: now, hp0: hp }
    return
  }
  // a brand new engagement only while healthy; a mob already in our face is fair game
  if (!b.__fighting && hp < 12 && bestWeapon(b) && !fightTarget(b, 3.2)) return
  // swarm rule: three or more hostiles in range and we are not at full strength -> break off
  if (hp < 17 || !bestWeapon(b)) {
    let crowd = 0
    for (const id in b.entities) {
      const e2 = b.entities[id]
      if (!e2 || !e2.position || !e2.name || e2 === b.entity) continue
      if (!HOSTILE.has(String(e2.name).toLowerCase())) continue
      if (e2.health !== undefined && e2.health <= 0) continue
      if (e2.position.distanceTo(b.entity.position) <= radiusOf(hp)) crowd++
    }
    if (crowd >= 3) { if (b.__fighting) { log('FIGHT_SWARM ' + crowd + ' nearby, breaking off'); stopFight(b) }; return }
  }
  const radius = radiusOf(hp)
  // hunger outranks fear: nothing edible in the bag and the bar is low -> hunt, whatever is nearby
  const starving = (b.food || 0) <= 12 && countFood(b) === 0
  const e = fightTarget(b, radius) || (starving && hp >= 6 ? huntTarget(b, 70) : null)
  if (e && FOOD_MOBS.has(String(e.name).toLowerCase())) b.__hunting = true
  else if (e) b.__hunting = false
  if (!e) {
    if (b.__fighting) log('FIGHT_WON_OR_LOST', (b.__fightName || '?') + ' gone at ' + pos(b) + ' hp=' + Math.round(hp))
    stopFight(b)
    return
  }
  if (!fin3(e.position)) return
  b.__fighting = true; b.__fightAt = now; b.__fightId = e.id; b.__fightName = e.name
  const nm = String(e.name).toLowerCase()
  const ranged = RANGED.has(nm)
  const d = e.position.distanceTo(b.entity.position)
  if (!isFinite(d)) { stopFight(b); return }
  // MEASURED, not guessed: AUDIT showed the last deaths as "slain by Drowned" and wateresc=42.
  // In water we cannot sprint, cannot breathe and swing slowly, and drowned drag us under -
  // so an aquatic fight is refused and the answer is dry land, not more courage.
  const cellWet = (p) => { try { const k = b.blockAt(new Vec3(Math.floor(p.x), Math.floor(p.y + 0.2), Math.floor(p.z))); return !!(k && /water/.test(k.name)) } catch (err) { return false } }
  const weWet = botWet(b)
  const enemyWet = okPos(e.position) ? cellWet(e.position) : false
  const aquatic = /drowned|guardian|squid|cod|salmon|pufferfish|tropical_fish/.test(nm)
  if ((aquatic && enemyWet) || weWet) {
    if (now - (b.__waterEvadeAt || 0) > 3000) {
      b.__waterEvadeAt = now
      stats.waterEvade = (stats.waterEvade || 0) + 1
      log('NO_FIGHT_WATER ' + nm + ' d=' + d.toFixed(1) + ' we_wet=' + weWet + ' enemy_wet=' + enemyWet + ' -> dry land')
      const dry = nearestDry(b, 24)
      if (dry) { try { b.pathfinder.setGoal(new goals.GoalNear(dry.x, dry.y, dry.z, 1)) } catch (err) {} }
      else { try { escapeWaterPillar(b) } catch (err) {} }
    }
    stopFight(b)
    return
  }
  if (b.__hunting && now - (b.__huntLogAt || 0) > 5000) { b.__huntLogAt = now; log('HUNTING', nm, 'd=' + d.toFixed(1) + ' food=' + Math.round(b.food)) }
  const look = e.position.offset(0, (e.height || 1.8) * 0.62, 0)
  try { if (armed && (!b.heldItem || b.heldItem.name !== wp.name)) b.equip(wp, 'hand').catch(() => {}) } catch (err) {}

  // ---- creeper: swing, then back off; never die standing next to it
  if (nm === 'creeper' && d < 3.2 && now > fightState.retreatUntil) {
    slook(b, look)
    try { b.attack(e) } catch (err) {}
    markHit(b, e)
    fightState.lastSwing = now
    fightState.retreatUntil = now + 1900
    log('FIGHT_BUMP creeper d=' + d.toFixed(1))
  }
  if (nm === 'creeper' && now < fightState.retreatUntil) {
    try { b.pathfinder.setGoal(null) } catch (err) {}
    fleeFrom(b, e)
    return
  }
  // ---- low on health and unarmed: do not trade, run
  if (!armed && d < 2.2) {
    slook(b, look)
    try { b.attack(e) } catch (err) {}                                  // fist + knockback
    markHit(b, e)
    fightState.lastSwing = now
    if (hp < 12) { stopFight(b); return }                               // survival logic takes over
  }
  // ---- close the distance
  if (d > 2.7) {
    if (now - fightState.goalAt > 900) {
      fightState.goalAt = now
      if (fin3(e.position)) { try { b.pathfinder.setGoal(new goals.GoalNear(e.position.x, e.position.y, e.position.z, 2)) } catch (err) {} }
    }
    let pfMoving = false; try { pfMoving = b.pathfinder.isMoving() } catch (err) {}
    if (!pfMoving) {
      slook(b, look)
      try { b.setControlState('forward', true); b.setControlState('sprint', d > 6); b.setControlState('left', false); b.setControlState('right', false) } catch (err) {}
      hop(b)
    }
    if (ranged && d < 10) strafeAround(b, fightState, now)
    if (d <= 3.4 && now - fightState.lastSwing >= swingMs(wp)) {
      fightState.lastSwing = now
      try { b.attack(e) } catch (err) {}
      markHit(b, e)
    }
    return
  }
  // ---- in swing range: strafe, look, swing on cooldown, jump-crit when grounded
  let pf = false; try { pf = b.pathfinder.isMoving() } catch (err) {}
  if (pf) { try { b.pathfinder.setGoal(null) } catch (err) {} }
  strafeAround(b, fightState, now)
  try { b.look(look, true) } catch (err) {}
  if (now - fightState.lastSwing >= swingMs(wp)) {
    fightState.lastSwing = now
    try { if (b.entity.onGround) { b.setControlState('jump', true); setTimeout(() => { try { b.setControlState('jump', false) } catch (err) {} }, 140) } } catch (err) {}
    try { b.attack(e) } catch (err) {}
    markHit(b, e)
    if (now - (b.__fightLogAt || 0) > 3000) {
      b.__fightLogAt = now
      log('FIGHT', nm, 'd=' + d.toFixed(1) + ' hp=' + Math.round(b.health) + ' wp=' + (wp ? wp.name : 'fist') + ' mobhp=' + (e.health !== undefined ? Math.round(e.health) : '?'))
    }
  }
}

// ==================== THE CASSETTE (custom item, found "in the sea") ====================
// Not a music_disc and not paper by meaning: it is a custom item whose DISPLAY NAME is
// this string, so we match by name, wherever it comes from (nbt components or customName).
// everything a custom name can hide in on 1.21: parsed customName compound, item
// components, legacy nbt - serialized as JSON so we can grep it as text
function itemTextBlob (it) {
  let s = ''
  try { s += String(it.displayName || '') } catch (e) {}
  try { s += '|' + JSON.stringify(it.customName || null) } catch (e) {}
  try { s += '|' + JSON.stringify(it.componentMap || null) } catch (e) {}
  try { s += '|' + JSON.stringify(it.components || null) } catch (e) {}
  try { s += '|' + JSON.stringify(it.nbt || null) } catch (e) {}
  try { s += '|' + it.name } catch (e) {}
  return s.toLowerCase()
}
function prettyName (it) {
  try {
    const c = it.customName
    if (typeof c === 'string') return c
    const v = c && c.value ? c.value : c
    if (v && v.extra && v.extra.value && v.extra.value.length) {
      const first = v.extra.value[0]
      const t = first && first.text ? (first.text.value !== undefined ? first.text.value : first.text) : JSON.stringify(first)
      return String(t)
    }
    if (v && v.text) return String(v.text.value !== undefined ? v.text.value : v.text)
  } catch (e) {}
  return String(it.displayName || it.name || '')
}

const CASSETTE = (process.env.PUFF_CASSETTE || 'наши проекты #4').toLowerCase()
function findCassette (b) {
  try {
    for (const it of b.inventory.items()) {
      if (itemTextBlob(it).indexOf(CASSETTE) >= 0) return it
    }
  } catch (e) {}
  return null
}
function startCassette (b) {
  if (b.__cassette) clearInterval(b.__cassette)
  b.__cassette = setInterval(() => {
    try {
      if (b !== bot) { if (b.__cassette) { clearInterval(b.__cassette); b.__cassette = null }; return }   // ghost client
      if (!b.entity || !b.isAlive) return
      const it = findCassette(b)
      if (!it) { b.__cassetteSaid = false; b.__cassetteGiven = false; return }
      if (!b.__cassetteSaid) {
        b.__cassetteSaid = true
        try { b.chat('Ребят, я нашёл какую-то кассету'); log('CASSETTE_ANNOUNCE') } catch (e) {}
      }
      const pl = nearestPlayerEntity(b, 7)
      if (!pl) return                                    // only to players, into their hands
      if (b.__cassetteGiven) return
      b.__cassetteGiven = true
      try { b.equip(it, 'hand').catch(() => {}) } catch (e) {}
      slook(b, pl.position.offset(0, 1.1, 0))
      setTimeout(() => {
        try { const cur = findCassette(b) || it; b.tossStack(cur); log('CASSETTE_GIVEN', pl.username || pl.name) } catch (e) { log('CASSETTE_TOSS_ERR', e && e.message) }
      }, 500)
    } catch (e) { log('CASSETTE_ERR', e && e.message) }
  }, 4000)
  log('CASSETTE watch on ("' + CASSETTE + '")')
}

function wrapLook (b) {
  if (b.__lookWrapped) return
  b.__lookWrapped = true
  const _lookAt = b.lookAt.bind(b)
  b.lookAt = (p, force, animate) => {
    if (!fin3(p)) { log('LOOKAT_REJECT non-finite target'); return Promise.resolve() }
    return _lookAt(p, force, animate)
  }
  const _look = b.look.bind(b)
  b.look = (yaw, pitch, force) => {
    if (!isFinite(yaw) || !isFinite(pitch)) { log('LOOK_REJECT non-finite angles'); return Promise.resolve() }
    return _look(yaw, pitch, force)
  }
  log('LOOK wrapped (NaN look = server kick: invalid_player_movement)')
}
function startNaNProbe (b) {
  if (b.__nanProbe) clearInterval(b.__nanProbe)
  b.__nanProbe = setInterval(() => {
    try {
      const e = b.entity
      if (!e) return
      const v = e.velocity
      if (v && (!isFinite(v.x) || !isFinite(v.y) || !isFinite(v.z))) {
        e.velocity = new Vec3(0, v && isFinite(v.y) ? v.y : 0, 0)
      }
      if (!isFinite(e.yaw)) e.yaw = 0
      if (!isFinite(e.pitch)) e.pitch = 0
      if (!fin3(e.position)) {
        const s = b.__srvPos
        if (s && fin3(s) && Date.now() - s.t < 60000) {
          e.position = new Vec3(s.x, s.y, s.z)
          e.velocity = new Vec3(0, -0.08, 0)
          e.yaw = 0; e.pitch = 0
          if (Date.now() - (globalNaNFixAt || 0) > 8000) { globalNaNFixAt = Date.now(); log('NAN_SNAP -> srv ' + s.x.toFixed(1) + ',' + s.y.toFixed(1) + ',' + s.z.toFixed(1)) }
        }
      }
    } catch (err) {}
  }, 300)
}

function startCombat (b) {
  if (b.__combat) clearInterval(b.__combat)
  b.__combat = setInterval(() => { combatTick(b).catch(e => log('COMBAT_ERR', e && e.message)) }, 240)
  try {
    b.on('entityGone', e => {
      try {
        if (!e || !e.name || !HOSTILE.has(String(e.name).toLowerCase())) return
        if (!b.__hit || !b.__hit[e.id] || Date.now() - b.__hit[e.id].t > 15000) return
        stats.kills = (stats.kills || 0) + 1
        log('KILL', e.name, 'at', pos(b), 'total=' + stats.kills)
        delete b.__hit[e.id]
        b.__lootAt = Date.now()
        if (FOOD_MOBS.has(String(e.name).toLowerCase())) { setTimeout(() => { try { collectNear(b, 16) } catch (err2) {} }, 900) }
      } catch (err) {}
    })
    b.on('entityHealth', e => {
      try {
        if (!e || !e.name || e.health === undefined || e.health > 0) return
        if (!HOSTILE.has(String(e.name).toLowerCase())) return
        if (!b.__hit || !b.__hit[e.id] || Date.now() - b.__hit[e.id].t > 15000) return
        stats.kills = (stats.kills || 0) + 1
        log('KILL', e.name, 'at', pos(b), 'total=' + stats.kills)
        delete b.__hit[e.id]
        b.__lootAt = Date.now()
        if (FOOD_MOBS.has(String(e.name).toLowerCase())) { setTimeout(() => { try { collectNear(b, 16) } catch (err2) {} }, 900) }
      } catch (err) {}
    })
    b.on('entityHurt', (e, dmg, src) => { try {
      if (b.__hit && e) b.__hit[e.id] = { name: e.name, t: Date.now() }
      if (b.entity && e && e.id === b.entity.id && src && src.name) { b.__lastHurtBy = src.name; b.__lastHurtAt = Date.now() }
    } catch (err) {} })
  } catch (err) { log('COMBAT_EV_ERR', err && err.message) }
  log('COMBAT on (240ms autoretaliate, jump-crit, strafe, creeper bump)')
}

// ==================== WATER SAFETY: never sit in water until we drown ====================
// Puff used to walk into water, then get "owned" by a routine (hiding / wallBury / fleeing)
// that disabled the stuck guard AND the dry-out logic, so he bobbed there until he drowned -
// dozens of deaths with hp going 20 -> 0 while the log showed nothing but silence.
let waterSafeAt = 0
function wetNow (b) {
  try {
    if (!b.entity) return { feet: false, head: false }
    const ft = b.entity.position.floored()
    const f = b.blockAt(ft), h = b.blockAt(ft.offset(0, 1, 0))
    return { feet: !!(b.entity.isInWater || (f && /water/.test(f.name))), head: !!(h && /water/.test(h.name)) }
  } catch (e) { return { feet: false, head: false } }
}
function startWaterSafety (b) {
  if (b.__waterSafe) clearInterval(b.__waterSafe)
  b.__waterSafe = setInterval(() => {
    try {
      if (b !== bot) { if (b.__waterSafe) { clearInterval(b.__waterSafe); b.__waterSafe = null }; return }
      if (!b.entity || !b.isAlive || b.health <= 0) return
      const now = Date.now()
      const w = wetNow(b)
      if (w.feet || w.head) { if (!b.__wetSince) b.__wetSince = now } else { b.__wetSince = 0; return }
      const wetFor = now - b.__wetSince
      let air = null
      try { if (typeof b.oxygenLevel === 'number' && isFinite(b.oxygenLevel)) air = b.oxygenLevel } catch (e) {}
      // head under water, or 7s of bobbing, or the air bar running out = act NOW
      // with a mob on our tail, "wet" is not a nuisance but a death sentence (drowned kills)
      let chaseNear = false
      try { chaseNear = threatsNear(b, 1).length > 0 } catch (e) {}
      const panic = w.head || wetFor > 7000 || (air !== null && air < 9) || (chaseNear && wetFor > 1500)
      if (!panic) return
      // crossing a cove on purpose is fine - unless our head is under (then air wins)
      try {
        const g = b.__lastGoal
        if (g && !w.head && Math.hypot(g.x - b.entity.position.x, g.z - b.entity.position.z) < 10) {
          const gb = b.blockAt(new Vec3(Math.floor(g.x), Math.floor(g.y), Math.floor(g.z)))
          if (gb && /water/.test(gb.name)) return
        }
      } catch (e) {}
      // Re-issueing the shore order every 4s interrupts our own escape (path stop, controls
      // cleared, new goal). Only nag again if we are not actually getting out.
      if (now - waterSafeAt < 9000) return
      const moved = b.__wetMoved ? Math.hypot(b.entity.position.x - b.__wetMoved.x, b.entity.position.z - b.__wetMoved.z) : 99
      if (moved > 1.5) { waterSafeAt = now - 6000 }        // making progress: give it longer
      b.__wetMoved = { x: b.entity.position.x, z: b.entity.position.z }
      waterSafeAt = now
      stats.waterEscapes = (stats.waterEscapes || 0) + 1
      log('WATER_SAFETY wet=' + (wetFor / 1000).toFixed(0) + 's head=' + (w.head ? 1 : 0) + ' air=' + air +
        ' hiding=' + hiding + ' bury=' + !!b.__wallBury + ' flee=' + !!b.__fleeing + ' at ' + pos(b))
      // drop every routine that owns us: being "hidden" is worthless if we are drowning
      try { hiding = false } catch (e) {}
      b.__buryAbort = true
      b.__wallBury = false
      b.__burying = false
      b.__fleeing = false
      try { b.pathfinder.setGoal(null) } catch (e) {}
      manualLockUntil = Math.min(manualLockUntil, now)
      jumpLockUntil = Math.min(jumpLockUntil, now)
      const dry = nearestDry(b, 22)
      if (dry) {
        log('WATER_SAFETY -> shore ' + dry.x + ' ' + dry.y + ' ' + dry.z + ' d=' + (dry.d || 0).toFixed(1))
        b.__lastGoal = { x: dry.x, y: dry.y, z: dry.z }
        try {
          const yaw = Math.atan2(-(dry.x + 0.5 - b.entity.position.x), dry.z + 0.5 - b.entity.position.z)
          b.look(yaw, w.head ? -0.5 : 0, true).catch(() => {})
        } catch (e) {}
        // swim/stride for the shore immediately, pathing follows
        try { b.setControlState('forward', true); b.setControlState('jump', true); b.setControlState('sprint', true) } catch (e) {}
        // a shore ledge one block up is climbed, not swum against: hold the jump longer
        const up = (dry.y - b.entity.position.y)
        setTimeout(() => { try { b.setControlState('forward', false); b.setControlState('jump', false); b.setControlState('sprint', false) } catch (e) {} }, up >= 0.9 ? 4200 : 2600)
        try { b.pathfinder.setGoal(new goals.GoalNear(dry.x, dry.y, dry.z, 1)) } catch (e) {}
      } else {
        log('WATER_SAFETY no shore -> pillar out at ' + pos(b))
        try { escapeWaterPillar(b) } catch (e) {}
      }
      // flags that never clear leave us standing still while mobs chew on us
      if (hiding && now - lastHideAt > 45000) { hiding = false; log('WATCHDOG hiding cleared ' + Math.round((now - lastHideAt) / 1000) + 's') }
      if (b.__fleeing && b.__fleeStart && now - b.__fleeStart > 25000) { b.__fleeing = false; log('WATCHDOG fleeing cleared ' + Math.round((now - b.__fleeStart) / 1000) + 's') }
    } catch (e) {}
  }, 400)
}

// ==================== AUDIT: a survival report card, every 4 minutes ====================
// "Learn to survive" means measurable: how often we get stuck, how many blocks we break,
// how many detours replaced a broken block, how we died. Without the numbers there is no
// way to know which habit to fix next.
function startAudit (b) {
  if (b.__audit) clearInterval(b.__audit)
  b.__audit = setInterval(() => {
    try {
      if (b !== bot) { if (b.__audit) { clearInterval(b.__audit); b.__audit = null }; return }
      const d = lastDeathCause || '-'
      log('AUDIT hp=' + Math.round(b.health) + ' food=' + Math.round(b.food) +
        ' kills=' + stats.kills + ' deaths=' + stats.deaths + ' lastdeath=' + d +
        ' stucks=' + stats.stucks + ' dug=' + (stats.dug || 0) + ' detours=' + (stats.detours || 0) +
        ' pffail=' + (stats.pfFail || 0) + ' pfdetour=' + (stats.pfDetour || 0) + ' wateresc=' + (stats.waterEscapes || 0) +
        ' mined=' + stats.mined + ' crafted=' + stats.crafted +
        ' leash=' + (leashOn ? 'on' : 'off') + ' home=' + (anchor ? Math.round(anchor.x) + ',' + Math.round(anchor.z) + ' d=' + distAnchor(b).toFixed(0) : '-') +
        ' inv=' + b.inventory.items().length)
    } catch (e) {}
  }, 240000)
}

// ==================== LEASH: stay inside 2 chunks of where we appeared ====================
const ANCHOR_FILE = '/home/agent/bot/anchor.json'
const ANCHOR_BAK = '/home/agent/bot/anchor.bak.json'
// BUG #4, the big one: reanchorIfFar() happily moved "home" to wherever we respawned.
// We respawn at world spawn, which IS the zombie nest, so the leash dragged us back into
// it, we died there, re-anchored there... 500+ deaths and the empty inventory came from
// that loop. Home = the 2-chunk circle where Puff appeared; nothing casual moves it.
const SPAWN = { x: -618, z: -654 }
const APPEARED = { x: -574, y: 67, z: 87 }
function nearBadXZ (x, z) {
  if (!isFinite(x) || !isFinite(z)) return true
  return Math.hypot(x - NEST.x, z - NEST.z) < 70 || Math.hypot(x - SPAWN.x, z - SPAWN.z) < 70
}
let anchor = null
let anchorBak = null
let globalNaNRescueAt = 0
let globalNaNFixAt = 0
let globalNaNFixN = 0
let globalNaNFixT0 = 0
let leashR = 32
let leashOn = true
try { const a = JSON.parse(fs.readFileSync(ANCHOR_FILE, 'utf8')); if (a && isFinite(a.x)) anchor = a } catch (e) {}
try { const a = JSON.parse(fs.readFileSync(ANCHOR_BAK, 'utf8')); if (a && isFinite(a.x)) anchorBak = a } catch (e) {}
function saveAnchor () {
  try {
    // keep the previous good home in a backup instead of overwriting history
    if (anchorBak && isFinite(anchorBak.x) && !nearBadXZ(anchorBak.x, anchorBak.z)) fs.writeFileSync(ANCHOR_BAK, JSON.stringify(anchorBak))
    if (anchor && isFinite(anchor.x)) {
      if (!nearBadXZ(anchor.x, anchor.z)) {
        if (!anchorBak || anchorBak.x !== anchor.x || anchorBak.z !== anchor.z) fs.writeFileSync(ANCHOR_BAK, JSON.stringify(anchor))
      }
    }
    fs.writeFileSync(ANCHOR_FILE, JSON.stringify(anchor || {}))
  } catch (e) {}
}
// self-heal a poisoned anchor file: death-nest centre -> last good home -> house -> circle
// where Puff appeared. Runs at load, so a bad write can never re-imprison us.
function healAnchor () {
  const hm = (typeof HOME !== 'undefined' && HOME && isFinite(HOME.x)) ? { x: HOME.x, y: HOME.y, z: HOME.z, t: Date.now(), home: true } : null
  const good = (a) => a && isFinite(a.x) && isFinite(a.z) && !nearBadXZ(a.x, a.z)
  if (good(anchor)) return
  const from = anchor ? (Math.round(anchor.x) + ',' + Math.round(anchor.z)) : 'null'
  if (good(anchorBak)) { anchor = anchorBak } else if (hm) { anchor = hm } else { anchor = { x: APPEARED.x, y: APPEARED.y, z: APPEARED.z, t: Date.now(), home: true } }
  log('ANCHOR_HEAL was ' + from + ' (death zone) -> ' + Math.round(anchor.x) + ',' + Math.round(anchor.z))
  saveAnchor()
}
function anchorOf (b) {
  if (!anchor && b && b.entity && fin3(b.entity.position)) {
    const p = b.entity.position
    if (nearBadXZ(p.x, p.z)) return null          // never adopt the nest as the centre
    anchor = { x: p.x, y: p.y, z: p.z, t: Date.now() }
    saveAnchor()
    log('ANCHOR set at ' + Math.round(p.x) + ' ' + Math.round(p.y) + ' ' + Math.round(p.z) + ' (leash ' + leashR + ')')
  }
  return anchor
}
// The anchor is the centre of the leash circle - it is where "home" is. When the bot dies
// and respawns at the world spawn, the old anchor can be hundreds of blocks away, and then
// the leash drags it straight back into the mob nest it just escaped (524 deaths that way).
// Re-anchor whenever we end up far outside the circle.
function reanchorIfFar (b) {
  if (!b || !b.entity || !fin3(b.entity.position)) return
  if (!anchor) { anchorOf(b); return }
  const p = b.entity.position
  const d = Math.hypot(p.x - anchor.x, p.z - anchor.z)
  if (d > Math.max(leashR * 3, 80)) {
    if (nearBadXZ(p.x, p.z) || anchor.home || (typeof HOME !== 'undefined' && HOME)) {
      // We are far from home and either standing in the grinder or we already HAVE a home:
      // walking back is the answer, moving the circle is the trap that killed us 500 times.
      log('ANCHOR_REFUSE ' + Math.round(p.x) + ',' + Math.round(p.z) + ' kept home at ' +
          Math.round(anchor.x) + ',' + Math.round(anchor.z) + ' (d=' + d.toFixed(0) + ')')
      try { walkHomeLong(b) } catch (e) { log('HOME_HOP_ERR', e && e.message) }
      return
    }
    anchorBak = anchor
    log('ANCHOR re-set at ' + Math.round(p.x) + ' ' + Math.round(p.y) + ' ' + Math.round(p.z) + ' (old anchor ' + d.toFixed(0) + 'b away)')
    anchor = { x: p.x, y: p.y, z: p.z, t: Date.now() }
    saveAnchor()
  }
}
let homeRunUntil = 0
let homeWalkUntil = 0
// Hops the long way back to the home circle with the clamp lifted (otherwise every goal is
// pinned onto the rim and we mill around 700 blocks away forever).
async function walkHomeLong (b) {
  if (!b.entity || !anchor || !b.isAlive) return
  if (Date.now() < homeWalkUntil) return
  homeWalkUntil = Date.now() + 180000
  const wasOn = leashOn
  leashOn = false
  let hops = 0
  try {
    while (b.entity && b.isAlive && hops < 10) {
      const p = b.entity.position
      const d = Math.hypot(p.x - anchor.x, p.z - anchor.z)
      if (d < leashR) break
      hops++
      const ux = (anchor.x - p.x) / d, uz = (anchor.z - p.z) / d
      const step = Math.min(44, d)
      const qx = -uz, qz = ux                    // perpendicular: the way around a ridge
      log('HOME_HOP #' + hops + ' d=' + d.toFixed(0) + ' -> ' + Math.round(p.x + ux * step) + ',' + Math.round(p.z + uz * step))
      try { b.pathfinder.setGoal(null) } catch (e) {}
      // BUG #5: goto() throwing "No path to the goal!" used to end the walk and leave us
      // standing in the open. Now each hop is tried shorter, then sideways around whatever
      // blocks it, and only then do we hand control back to the director.
      const tries = []
      for (const frac of [1, 0.6, 0.3]) tries.push([ux * step * frac, uz * step * frac, 5])
      for (const side of [1, -1]) for (const off of [10, 20]) tries.push([ux * step * 0.6 + qx * off * side, uz * step * 0.6 + qz * off * side, 4])
      let ok = false
      for (const t of tries) {
        if (!b.entity || !b.isAlive || Date.now() > homeWalkUntil) break
        const g = new goals.GoalNear(p.x + t[0], anchor.y, p.z + t[1], t[2])
        ok = await b.pathfinder.goto(g).then(() => true).catch(() => false)
        if (ok) break
      }
      if (!ok) { log('HOME_HOP blocked at ' + pos(b) + ' d=' + d.toFixed(0) + ' - director takes over'); break }
    }
  } catch (e) { log('HOME_HOP_ERR', e && e.message) } finally {
    leashOn = wasOn
    homeWalkUntil = 0
    log('HOME_HOP end at ' + pos(b) + ' d=' + (anchor ? distAnchor(b).toFixed(1) : '?'))
  }
}

function distAnchor (b) {
  const a = anchorOf(b)
  if (!a || !b.entity) return 0
  return Math.hypot(b.entity.position.x - a.x, b.entity.position.z - a.z)
}
function startLeash (b) {
  if (b.__leash) clearInterval(b.__leash)
  b.__leash = setInterval(() => {
    try {
      if (b !== bot) { if (b.__leash) { clearInterval(b.__leash); b.__leash = null }; return }   // ghost client
      if (b.entity && !fin3(b.entity.position)) {
        // cheap heal first: the server still knows where we are, so snap the client entity
        // back to the last server position and keep playing. Reconnect only if it keeps
        // happening (6 times in a minute) - a relog costs us the whole fight.
        const s = b.__srvPos
        if (s && fin3(s) && Date.now() - s.t < 25000 && Date.now() - globalNaNFixAt > 1200) {
          globalNaNFixAt = Date.now()
          if (Date.now() - globalNaNFixT0 > 60000) { globalNaNFixN = 0; globalNaNFixT0 = Date.now() }
          globalNaNFixN++
          try {
            b.entity.position = new Vec3(s.x, s.y, s.z)
            b.entity.velocity = new Vec3(0, -0.08, 0)
            b.entity.yaw = 0; b.entity.pitch = 0
          } catch (e) { log('NAN_FIX_ERR', e && e.message) }
          log('NAN_POS_FIX #' + globalNaNFixN + ' -> ' + s.x.toFixed(1) + ',' + s.y.toFixed(1) + ',' + s.z.toFixed(1))
          if (globalNaNFixN >= 6 && Date.now() - globalNaNRescueAt > 90000) {
            globalNaNRescueAt = Date.now()
            log('NAN_POS_RESCUE after ' + globalNaNFixN + ' fixes -> reconnect')
            saveStats()
            try { b.end('nan-pos-rescue') } catch (e) {}
          }
          return
        }
        // the client entity position went NaN (a poisoned look/GoalNear): movement is dead,
        // only a clean reconnect brings the chunks and physics back. One relog per 90s max.
        if (Date.now() - (globalNaNRescueAt || 0) > 90000) {
          globalNaNRescueAt = Date.now()
          log('NAN_POS_RESCUE at srv=' + (b.__srvPos ? (b.__srvPos.x.toFixed(1) + ',' + b.__srvPos.y.toFixed(1) + ',' + b.__srvPos.z.toFixed(1)) : '?') + ' -> reconnect')
          saveStats()
          try { b.end('nan-pos-rescue') } catch (e) {}
        }
        return
      }
      if (!leashOn || !b.entity || !b.isAlive) return
      if (Date.now() < homeWalkUntil || Date.now() < homeRunUntil) return   // escape run owns us
      // BUG #6: the client entity drifted 15-20 blocks from where the server actually has
      // us, so the leash computed a 700-block distance and hammered an impossible
      // GoalNear every 5s (LEASH_RETURN spam + UNSTICK step-up spam, nothing else running).
      if (b.__srvPos && fin3(b.__srvPos) && Date.now() - b.__srvPos.t < 15000) {
        const dd = Math.hypot(b.entity.position.x - b.__srvPos.x, b.entity.position.z - b.__srvPos.z)
        if (dd > 14) {
          log('LEASH_DESYNC local ' + pos(b) + ' vs srv ' + b.__srvPos.x.toFixed(1) + ',' + b.__srvPos.z.toFixed(1) + ' = ' + dd.toFixed(0) + 'b -> snap')
          try { b.entity.position = new Vec3(b.__srvPos.x, b.__srvPos.y, b.__srvPos.z) } catch (e) {}
          try { mission = null } catch (e) {}
          try { b.pathfinder.setGoal(null) } catch (e) {}
          return
        }
      }
      const now2 = Date.now()
      const a = anchorOf(b)
      if (!a) return
      const d = distAnchor(b)
      if (isFinite(d) && d > leashR + 6 && Date.now() > manualLockUntil && now2 - lastUnstickAt > 12000) {
        log('LEASH_RETURN from ' + pos(b) + ' d=' + d.toFixed(1) + ' -> anchor')
        try { mission = null } catch (e) {}
        try { b.pathfinder.setGoal(new goals.GoalNear(a.x, a.y, a.z, 3)) } catch (e) {}
      }
    } catch (e) { log('LEASH_ERR', e && e.message) }
  }, 5000)
}


// ---- DOORS (players use doors; so must we) ----
// Blocks that belong to a BUILDING. Digging one of these is wrecking our own house.
const STRUCT_RE = /(_planks|_log|_wood|_stripped_|_stairs|_slab|_fence|_door|_trapdoor|_sign|glass|glass_pane|iron_bars|bookshelf|crafting_table|furnace|chest|anvil|lantern|campfire|bed|_button|lever)$/
const isStruct = (b, v) => { const k = b.blockAt(v); return !!(k && STRUCT_RE.test(k.name)) }
const isDoor = (b, v) => { const k = b.blockAt(v); return !!(k && /door/.test(k.name)) }
// 4.39 exposes states only through getProperties(); the raw .properties field is empty
function doorOpen (k) {
  try {
    const p = (k.getProperties && k.getProperties()) || {}
    if (p.open === true || p.open === 'true') return true
    if (p.open === false || p.open === 'false') return false
  } catch (e) {}
  return k.boundingBox !== 'block'      // an open door no longer fills its cell
}

function findDoorNear (b, center, r) {
  const c = center.floored()
  let best = null, bd = 1e9
  for (let dx = -r; dx <= r; dx++) {
    for (let dz = -r; dz <= r; dz++) {
      for (let dy = -1; dy <= 2; dy++) {
        const v = new Vec3(c.x + dx, c.y + dy, c.z + dz)
        const k = b.blockAt(v)
        if (!k || !/door/.test(k.name)) continue
        const d = Math.abs(dx) + Math.abs(dz)
        if (d < bd) { bd = d; best = { v, k, dist: d } }
      }
    }
  }
  return best
}

// walkable cell: air, or a plant we can stand in (fern/flowers/snow-like are 'empty' too)
const isFreeCell = (b, p) => {
  const a = b.blockAt(p), h = b.blockAt(p.offset(0, 1, 0))
  return !!(a && (a.boundingBox === 'empty' || a.boundingBox === 'none' || /^water|lava/.test(a.name))) &&
    !!(h && (h.boundingBox === 'empty' || h.boundingBox === 'none'))
}
// the free cell on the outside of a door (air at feet AND head)
function doorOutCell (b, v) {
  for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
    const p = new Vec3(v.x + d[0], v.y, v.z + d[1])
    if (isFreeCell(b, p)) return p
  }
  // door blocked by a block we placed ourselves? say so instead of failing silently
  return null
}

async function actDoor (b, v, wantOpen) {
  const k = b.blockAt(v)
  if (!k || !/door/.test(k.name)) return false
  if (doorOpen(k) === wantOpen) return true
  if (!b.entity) return false
  const p = b.entity.position
  // knock on the face that points at us, that is the face the client activates
  const dir = new Vec3(Math.round(p.x - (v.x + 0.5)), 1, Math.round(p.z - (v.z + 0.5)))
  if (dir.x === 0 && dir.z === 0) dir.x = 1
  try { await b.lookAt(v.offset(0.5, 0.5, 0.5)) } catch (e) {}
  try {
    await b.activateBlock(k, dir)
    log('DOOR ' + (wantOpen ? 'open' : 'close') + ' ' + v)
    await sleep(280)
    const now = b.blockAt(v)
    return now ? doorOpen(now) === wantOpen : true
  } catch (e) {
    log('DOOR_ERR ' + (e && e.message ? e.message : e)); return false
  }
}

// walk to a door, open it, step through, then on to (tx,ty,tz). closes it behind us.
async function pfTo (b, gx, gy, gz, range) {          // goto resolves null on success
  try { await withTimeout(b.pathfinder.goto(new goals.GoalNear(gx, gy, gz, range)), 30000, 'timeout'); return true } catch (e) { return false }
}

async function enterThroughDoor (b, tx, ty, tz) {
  if (!b.entity) return 'no entity'
  const tgt = new Vec3(tx, ty, tz)
  let d = findDoorNear(b, tgt, 7)
  if (!d) d = findDoorNear(b, b.entity.position.floored(), 7)     // stand next to the house and try again
  if (!d) return 'no door within 7 of target or of me'
  const out = doorOutCell(b, d.v)
  if (!out) return 'no free cell beside the door ' + d.v
  log('ENTER via door ' + d.v + ' outside cell ' + out)
  if (!await pfTo(b, out.x, out.y, out.z, 1.5) && Math.abs(b.entity.position.x - out.x) + Math.abs(b.entity.position.z - out.z) > 2.5) return 'could not reach the doorway at ' + out
  if (!await actDoor(b, d.v, true)) return 'door at ' + d.v + ' would not open'
  await sleep(350)
  const ok = await pfTo(b, tgt.x, tgt.y, tgt.z, 1.5)
  setTimeout(() => { actDoor(b, d.v, false).catch(() => {}) }, 1500)   // shut it behind us like a person
  log('ENTER ' + (ok ? 'inside at ' + pos(b) : 'inside failed, door left open'))
  return ok ? 'inside' : 'inside failed'
}


// ---- structure take-down and blueprints ----
async function demolish (b, a, bb, placed) {
  const [x1, y1, z1, x2, y2, z2] = a.map(v => Math.round(v))
  let dug = 0, fail = 0
  for (let y = y2; y >= y1; y--) {                       // top down: nothing falls on us
    for (let x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) {
      for (let z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
        const v = new Vec3(x, y, z)
        const k = b.blockAt(v)
        if (!k || !STRUCT_RE.test(k.name)) continue
        if (/crafting_table|furnace|chest/.test(k.name)) { log('DEMOLISH leaving ' + k.name + ' at ' + v); continue }
        // stand close enough to reach and to suck the drop
        try {
          b.__allowDig = true
          const ok = await withTimeout(digBlock(b, v), 12000, false)
          if (ok) dug++; else fail++
        } finally { b.__allowDig = false }
        await sleep(60)
      }
    }
  }
  log('DEMOLISH done dug=' + dug + ' failed=' + fail)
  return dug + '/' + fail
}

// one blueprint cell: clear whatever is there that we do not want, then place item
async function standNear (b, v) {                    // within reach, on ground we can path to
  const p = b.entity ? b.entity.position : null
  if (!p) return false
  if (Math.hypot(p.x - (v.x + 0.5), p.z - (v.z + 0.5)) < 3.6 && Math.abs(p.y - v.y) < 3.6) return true
  const spots = []
  for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1], [2, 0], [-2, 0], [0, 2], [0, -2], [2, 2], [-2, -2], [2, -2], [-2, 2]]) spots.push([v.x + d[0], v.z + d[1]])
  for (const s of spots) {
    for (let y = v.y; y >= v.y - 5; y--) {
      const c = new Vec3(Math.round(s[0]), y, Math.round(s[1]))
      const g = b.blockAt(c), a1 = b.blockAt(c.offset(0, 1, 0)), a2 = b.blockAt(c.offset(0, 2, 0))
      if (g && g.boundingBox === 'block' && a1 && a1.name === 'air' && a2 && a2.name === 'air') {
        if (await pfTo(b, c.x, c.y + 1, c.z, 0.7)) return true
      }
    }
  }
  return Math.hypot(b.entity.position.x - (v.x + 0.5), b.entity.position.z - (v.z + 0.5)) < 4.2
}

async function buildCell (b, x, y, z, item, tries) {
  const v = new Vec3(x, y, z)
  await standNear(b, v)
  let k = b.blockAt(v)
  if (k && k.name === item) return 'have'
  if (k && k.boundingBox === 'block') {
    try { b.__allowDig = true; await withTimeout(digBlock(b, v), 12000, false) } finally { b.__allowDig = false }
    k = b.blockAt(v)
  }
  if (k && k.boundingBox !== 'empty' && k.boundingBox !== 'none') return 'busy'
  for (let t = 0; t < (tries || 3); t++) {
    if (await placeBlockAt(b, x, y, z, item)) return 'placed'
    await sleep(220)
  }
  return 'failed'
}

async function runBlueprint (b, cells) {
  const res = { placed: 0, have: 0, failed: 0, list: [] }
  const sorted = cells.slice().sort((p, q) => (p[1] - q[1]) || (p[2] - q[2]) || (p[0] - q[0]))
  for (const c of sorted) {
    const item = c[3]
    if (countItem(b, item) < 1) {
      const plank = /_planks$/.test(item) ? item : null
      if (plank) { await ensurePlanks(b, countItem(b, plank) + 8) }
      if (countItem(b, item) < 1 && /slab|stairs|fence|sign|chest|button|door/.test(item)) {
        const base = item.replace(/_slab.*/, '_planks').replace(/_stairs.*/, '_planks').replace(/_fence$/, '_planks').replace(/_sign$/, '_planks').replace(/^chest$/, 'birch_planks').replace(/_door$/, '_planks')
        try { await craftItem(b, item, 3) } catch (e) {}
        if (countItem(b, item) < 1) { try { await craftItem(b, item, 1) } catch (e) {} }
      }
    }
    if (countItem(b, item) < 1) { res.failed++; res.list.push(c.join(',') + ' no ' + item); continue }
    const r = await buildCell(b, c[0], c[1], c[2], item)
    if (r === 'placed') res.placed++
    else if (r === 'have') res.have++
    else { res.failed++; res.list.push(c.join(',') + ' ' + r) }
  }
  log('BLUEPRINT placed=' + res.placed + ' have=' + res.have + ' failed=' + res.failed)
  return res
}


// Escape a water basin the way a player would: build a step next to you, climb it,
// repeat toward dry land. Placing into your own cell is refused by the server, so the
// step always goes in the NEIGHBOUR column and never higher than feet+1.
async function stairOut (b, tx, tz, tries) {
  if (!b.entity) return 'no entity'
  const src = b.inventory.items().find(i => /_planks$|dirt|grass_block|cobblestone|sand|gravel|cobble/.test(i.name))
  if (!src) return 'no placeable block'
  try { await b.equip(src, 'hand') } catch (e) { return 'equip failed' }
  const up = b.entity.position.floored().offset(0, 1, 0).minus(b.entity.position.floored())
  const rep = []
  for (let k = 0; k < (tries || 8); k++) {
    const p = b.entity.position
    const f = p.floored()
    const head = b.blockAt(f.offset(0, 1, 0))
    if (b.blockAt(f).name === 'air' && p.y >= f.y + 0.4 && Math.abs(f.x - tx) + Math.abs(f.z - tz) <= 2) return 'dry at ' + f
    let dx = Math.sign(tx - f.x), dz = Math.sign(tz - f.z)
    if (Math.abs(tx - f.x) >= Math.abs(tz - f.z)) dz = 0; else dx = 0
    if (!dx && !dz) dz = 1
    const col = f.offset(dx, 0, dz)
    let top = null
    for (let y = f.y - 4; y <= f.y + 1; y++) { const kk = b.blockAt(new Vec3(col.x, y, col.z)); if (kk && kk.boundingBox === 'block') top = kk }
    if (!top) { rep.push('no floor in ' + col); break }
    let ty = top.position.y + 1
    if (ty > f.y + 1) ty = f.y + 1                       // never build a wall we cannot climb
    for (let s = 0; s < 3 && ty <= f.y + 1; s++) {
      try { await b.placeBlock(top, up); rep.push('step@' + col.x + ',' + (top.position.y + 1) + ',' + col.z) } catch (e) { rep.push('E ' + e.message.slice(0, 26)); break }
      await sleep(600)
      const re = b.blockAt(new Vec3(col.x, ty, col.z))
      if (!re || re.boundingBox !== 'block') break
      top = re; ty = top.position.y + 1
    }
    const yaw = Math.atan2(-(col.x + 0.5 - p.x), col.z + 0.5 - p.z)
    for (let t = 0; t < 3; t++) {
      try { await b.look(yaw, 0.35, true) } catch (e) {}
      try { b.setControlState('forward', true); b.setControlState('sprint', true); b.setControlState('jump', true) } catch (e) {}
      await sleep(1300)
      try { b.setControlState('sprint', false); b.setControlState('jump', false) } catch (e) {}
      await sleep(300)
      if (b.entity && b.entity.position.y >= f.y + 1.2) break
    }
    try { b.clearControlStates() } catch (e) {}
    rep.push('now ' + (b.entity ? Math.round(b.entity.position.x) + ',' + b.entity.position.y.toFixed(1) + ',' + Math.round(b.entity.position.z) : '-'))
  }
  return (b.entity ? 'at ' + pos(b) : 'gone') + ' :: ' + rep.slice(0, 18).join(' ')
}


// ---- the leash circle, enforced on the pathfinder itself ----
let HOME = null                       // the interior cell of our house, from home.json
try { HOME = JSON.parse(require('fs').readFileSync(__dirname + '/home.json', 'utf8')) } catch (e) {}
function saveHome () { try { require('fs').writeFileSync(__dirname + '/home.json', JSON.stringify(HOME)) } catch (e) {} }
const okPos = (p) => !!(p && isFinite(p.x) && isFinite(p.y) && isFinite(p.z))

// Where we recently failed to move. Two uses: the detour search skips these sides, and the
// stuck guard escalates faster if we come back to the same wall twice.
let stuckSpots = []
function noteStuckSpot (b) {
  try {
    if (!b.entity || !fin3(b.entity.position)) return
    const p = b.entity.position
    stuckSpots.push({ x: p.x, z: p.z, t: Date.now() })
    const cut = Date.now() - 600000
    stuckSpots = stuckSpots.filter(s => s.t > cut)
    while (stuckSpots.length > 80) stuckSpots.shift()
  } catch (e) {}
}
function stuckSpotNear (b, x, z, r) {
  const cut = Date.now() - 600000
  for (const s of stuckSpots) { if (s.t > cut && Math.hypot(s.x - x, s.z - z) < (r || 4)) return true }
  return false
}

function clampXZ (x, z) {
  if (!leashOn || !anchor || !isFinite(x) || !isFinite(z)) return null
  // during the run out of the nest, clamping goals onto a circle 700 blocks away only
  // pins us there - the escape routine is already aimed at home
  if (Date.now() < homeRunUntil) return null
  try { if (bot && bot.__dropRun) return null } catch (e) {}   // fetching our own gear - no leash
  const a = anchor
  const dx = x - a.x, dz = z - a.z
  const d = Math.hypot(dx, dz)
  const lim = leashR - 1
  if (d <= lim || d < 0.01) return null
  return [a.x + dx / d * lim, a.z + dz / d * lim]
}

// ---- adaptive path planning ----
// "No path to the goal!" used to be a dead end: we stood still, the stuck guard hopped in
// place, and the only remaining trick was to dig. Now a failed path is retried around the
// obstacle: wider arrival radius first, then a perpendicular detour, then we give up cleanly
// and let the director pick something reachable. Budget per attempt grows with distance and
// shrinks after repeated failures, so short walks stay snappy.
function pfTune (b, dist) {
  try {
    const pf = b.pathfinder
    pf.thinkTimeout = dist > 90 ? 8000 : dist > 40 ? 5500 : dist > 16 ? 4000 : 2500
    if (!b.__pfSearch) b.__pfSearch = pf.searchRadius || 100
    pf.tickTimeout = 45
  } catch (e) {}
}
function pfAdapt (b, ok) {
  try {
    const pf = b.pathfinder
    if (ok) {
      if (b.__pfFailStreak) log('PF_RECOVERED after ' + b.__pfFailStreak + ' fails')
      b.__pfFailStreak = 0
      if (pf.searchRadius !== 100) { pf.searchRadius = 100; log('PF_TUNE searchRadius=100 (path found)') }
    } else {
      b.__pfFailStreak = (b.__pfFailStreak || 0) + 1
      // 48 is the floor: below that A* cannot even see a route around a hill, and every
      // failure would then look like "unreachable" when it is only "not searched far enough"
      const ns = Math.max(48, Math.round((pf.searchRadius || 100) * 0.75))
      if (pf.searchRadius !== ns) { pf.searchRadius = ns; log('PF_TUNE searchRadius=' + ns + ' after ' + b.__pfFailStreak + ' fails') }
    }
  } catch (e) {}
}
function pfOwned (b) {
  // while an escape routine drives us, planning must not fight it
  return !!(b.__wallBury || b.__burying || b.__wetPillar || b.__pillarEscape || hiding || tunneling || diggingUp)
}
// One path attempt with a hard clock. Without it a single A* search on a 6-block hop could
// eat 16 seconds (thinkTimeout only bounds one search, not the retries inside the plugin),
// which is exactly the "stands there doing nothing" the owner keeps seeing.
async function pfTry (b, orig, goal, ms) {
  let to = null
  const pr = orig.call(b.pathfinder, goal)
  try {
    const raced = await Promise.race([
      pr.then(() => 'ok').catch(() => 'fail'),
      new Promise(res => { to = setTimeout(() => res('to'), ms || 4000) })
    ])
    if (raced === 'to') {
      try { b.pathfinder.stop() } catch (e) {}
      try { b.clearControlStates() } catch (e) {}
      stats.pfTimeout = (stats.pfTimeout || 0) + 1
    }
    return raced
  } catch (e) { return 'fail' } finally { if (to) clearTimeout(to) }
}

async function smartGoto (b, orig, goal) {
  const p0 = b.entity ? b.entity.position : null
  if (!p0 || !fin3(p0) || !goal || typeof goal.x !== 'number') return orig.call(b.pathfinder, goal)
  if (b.__pfRaw) return orig.call(b.pathfinder, goal)
  const gx = goal.x, gy = goal.y, gz = goal.z
  const dist = Math.hypot(gx - p0.x, gz - p0.z)
  b.__lastGoal = { x: gx, y: gy, z: gz }
  if (dist < 2 || dist > 240 || pfOwned(b)) return orig.call(b.pathfinder, goal)
  const t0 = Date.now()
  // the whole retry ladder has to fit in a budget that scales with the hop: standing still
  // for 22s while mobs close in is exactly the "does nothing" behaviour the owner called out.
  const budget = Math.min(11000, 1600 + dist * 80)
  pfTune(b, dist)
  // long hops get a longer single search (the travel routine owns them); short ones must
  // answer in a couple of seconds or we move on to the route-around ladder
  const attemptMs = dist > 60 ? 12000 : Math.max(2500, Math.min(6000, Math.round(dist * 120)))
  try {
    const r0 = await pfTry(b, orig, goal, attemptMs)
    if (r0 !== 'ok') { if (r0 === 'to' && dist > 60) { log('PF_LONG_TIMEOUT d=' + dist.toFixed(0) + ' - travel owns this'); throw new Error('long path timeout') } throw new Error('path ' + r0 + ' in ' + attemptMs + 'ms') }
    pfAdapt(b, true)
    return
  } catch (e) {
    pfAdapt(b, false)
    stats.pfFail = (stats.pfFail || 0) + 1
    // 1) relax the arrival radius: rough jungle terrain is often 3 blocks off "exactly here"
    for (const r of [6, 12]) {
      if (!b.entity || !b.isAlive || Date.now() - t0 > budget) break
      const ok = (await pfTry(b, orig, new goals.GoalNear(gx, gy, gz, r), 4000)) === 'ok'
      if (ok) { pfAdapt(b, true); stats.pfRadius = (stats.pfRadius || 0) + 1; log('PF_RADIUS ' + r + ' ' + Math.round(gx) + ',' + Math.round(gz) + ' from ' + pos(b)); return }
    }
    // 2) route around: step sideways off the straight line, then aim at the goal again
    const dx = gx - p0.x, dz = gz - p0.z
    const L = Math.hypot(dx, dz) || 1
    const px = -dz / L, pz = dx / L
    for (const side of [1, -1]) {
      for (const off of [8, 18]) {
        if (!b.entity || !b.isAlive || Date.now() - t0 > budget || pfOwned(b)) break
        const wx = gx + px * off * side, wz = gz + pz * off * side
        if (stuckSpotNear(b, wx, wz, 3)) continue
        const okw = (await pfTry(b, orig, new goals.GoalNear(wx, gy, wz, 3), 4000)) === 'ok'
        if (!okw) continue
        const ok2 = (await pfTry(b, orig, new goals.GoalNear(gx, gy, gz, 4), 4500)) === 'ok'
        if (ok2) { pfAdapt(b, true); stats.pfDetour = (stats.pfDetour || 0) + 1; log('PF_DETOUR ' + (side > 0 ? 'R' : 'L') + off + ' -> ' + Math.round(gx) + ',' + Math.round(gz)); return }
        const ok3 = (await pfTry(b, orig, new goals.GoalNear(gx, gy, gz, 12), 4500)) === 'ok'
        if (ok3) { stats.pfDetour = (stats.pfDetour || 0) + 1; log('PF_DETOUR_PART ' + (side > 0 ? 'R' : 'L') + off + ' -> ' + Math.round(gx) + ',' + Math.round(gz) + ' at ' + pos(b)); return }
      }
    }
    noteStuckSpot(b)
    log('PF_GIVEUP(to=' + (stats.pfTimeout || 0) + ') ' + Math.round(gx) + ',' + Math.round(gz) + ' d=' + dist.toFixed(0) + ' after ' + ((Date.now() - t0) / 1000).toFixed(0) + 's at ' + pos(b))
    throw e
  }
}

function wrapLeashGoals (b) {
  const pf = b.pathfinder
  if (!pf || pf.__leashWrapped) return
  pf.__leashWrapped = true
  const fixGoal = (g) => {
    try {
      if (g && typeof g === 'object' && typeof g.x === 'number' && typeof g.z === 'number' && Number.isFinite(g.x)) {
        const c = clampXZ(g.x, g.z)
        if (c) { log('LEASH_CLAMP goal ' + Math.round(g.x) + ',' + Math.round(g.z) + ' -> ' + Math.round(c[0]) + ',' + Math.round(c[1])); g.x = c[0]; g.z = c[1] }
      }
    } catch (e) {}
  }
  for (const fn of ['goto', 'setGoal', 'start']) {
    const orig = pf[fn]
    if (typeof orig !== 'function') continue
    pf[fn] = function () {
      const a0 = arguments[0]
      if (typeof a0 === 'number' && arguments.length >= 3 && fn === 'goto') {
        const c = clampXZ(a0, arguments[2])
        if (c) { log('LEASH_CLAMP goto ' + Math.round(a0) + ',' + Math.round(arguments[2]) + ' -> ' + Math.round(c[0]) + ',' + Math.round(c[1])); arguments[0] = c[0]; arguments[2] = c[1] }
        const gx = arguments[0], gz = arguments[2]
        const gyy = arguments.length > 1 && isFinite(arguments[1]) ? arguments[1] : (b.entity ? b.entity.position.y : 64)
        return smartGoto(b, orig, new goals.GoalBlock(Math.floor(gx), Math.floor(gyy), Math.floor(gz)))
      } else fixGoal(a0)
      if (fn === 'goto' && a0 && typeof a0 === 'object' && isFinite(a0.x)) return smartGoto(b, orig, a0)
      if (a0 && typeof a0 === 'object' && isFinite(a0.x)) b.__lastGoal = { x: a0.x, y: a0.y, z: a0.z }
      return orig.apply(this, arguments)
    }
  }
}

// go home and shut the door behind us: the cheapest real shelter there is
async function hideAtHome (b) {
  if (!b.entity) return 'no entity'
  const p = b.entity.position
  const target = HOME ? new Vec3(Math.round(HOME.x), Math.round(HOME.y), Math.round(HOME.z)) : (anchor ? anchorOf(b) : null)
  if (!target) return 'no home cell set'
  if (Math.hypot(p.x - target.x, p.z - target.z) < 1.6) return 'already home'
  const r = await enterThroughDoor(b, target.x, target.y, target.z)
  return 'home: ' + r
}

// ==================== WOODEN HUT ====================
const PLANK_LIST = ['pale_oak_planks', 'oak_planks', 'birch_planks', 'spruce_planks', 'jungle_planks', 'acacia_planks', 'dark_oak_planks', 'mangrove_planks', 'cherry_planks', 'crimson_planks', 'warped_planks']
function plankCount (b) { return countAny(b, PLANK_LIST) }
async function ensurePlanks (b, want) {
  let have = plankCount(b)
  let guard = 0
  while (have < want && guard++ < 12) {
    const logName = LOG_TYPES.find(n => countItem(b, n) > 0)
    if (!logName) break
    const plankName = logName.replace('_log', '_planks')
    if (!mcData.itemsByName[plankName]) break
    await craftItem(b, plankName, Math.min(16, countItem(b, logName) * 4))
    const nh = plankCount(b)
    if (nh <= have) break
    have = nh
  }
  return have
}
function pickBuildSite (b) {
  const a = anchorOf(b)
  if (!a || !b.entity) return null
  const p = b.entity.position
  const dirs = []
  for (let r = 0; r <= 24; r += 3) {
    for (let k = 0; k < 12; k++) {
      const ang = k * Math.PI / 6
      dirs.push({ x: Math.round(a.x + Math.cos(ang) * r), z: Math.round(a.z + Math.sin(ang) * r) })
    }
  }
  for (const c of dirs) {
    let gy = null
    let ok = true
    for (let dx = -2; dx <= 2 && ok; dx++) {
      for (let dz = -2; dz <= 2 && ok; dz++) {
        const gx = c.x + dx; const gz = c.z + dz
        if (Math.hypot(gx - a.x, gz - a.z) > leashR - 2) { ok = false; break }
        let found = null
        for (let dy = -2; dy <= 3; dy++) {
          const y = Math.round(p.y) + dy
          const bl = b.blockAt(new Vec3(gx, y, gz))
          const up1 = b.blockAt(new Vec3(gx, y + 1, gz))
          const up2 = b.blockAt(new Vec3(gx, y + 2, gz))
          if (bl && bl.boundingBox === 'block' && bl.name !== 'crafting_table' &&
              (!up1 || up1.boundingBox !== 'block' || up1.name === 'short_grass' || up1.name === 'grass' || up1.name === 'fire') &&
              (!up2 || up2.boundingBox !== 'block')) { found = y; break }
        }
        if (found === null) ok = false
        else if (gy === null) gy = found
        else if (found !== gy) ok = false
      }
    }
    if (ok && gy !== null) return { x: c.x, y: gy, z: c.z }
  }
  return null
}
// Sleeping in a bed is the only op-free way to move a respawn point on vanilla servers.
async function bedInsideHut (b, site, y0) {
  try {
    const bed = b.inventory.items().find(i => /_bed$/.test(i.name))
    if (!bed) { log('BED none carried - ask the players for 3 wool (3 wool + 3 planks = bed)'); return false }
    const cx = Math.floor(site.x), cy = Math.floor(y0), cz = Math.floor(site.z)
    const reached = await b.pathfinder.goto(new goals.GoalNear(cx + 1.5, cy, cz + 0.5, 1)).then(() => true).catch(() => false)
    await sleep(400)
    if (!b.entity) return false
    const f = b.entity.position.floored()
    let ref = b.blockAt(f.offset(0, -1, 0))
    if (!ref || ref.boundingBox !== 'block') ref = b.blockAt(f.offset(0, -2, 0))
    if (!ref || ref.boundingBox !== 'block') { log('BED no floor under us at ' + f + ' reached=' + reached); return false }
    try { await b.equip(bed, 'hand') } catch (e) {}
    let ok = await withTimeout(b.placeBlock(ref, new Vec3(0, 1, 0)), 6000, false)
    if (!ok) {
      for (const fv of [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]]) {
        const side = b.blockAt(f.offset(fv[0], -1, fv[2]))
        if (!side || side.boundingBox !== 'block') continue
        ok = await withTimeout(b.placeBlock(side, new Vec3(-fv[0], 1, -fv[2])), 5000, false)
        if (ok) break
      }
    }
    const ids = Object.keys(mcData.blocksByName).filter(n => /_bed$/.test(n)).map(n => mcData.blocksByName[n].id)
    const ps = b.findBlocks({ matching: ids, maxDistance: 10, count: 2 })
    log('BED placed=' + !!ok + ' found=' + (ps.length ? String(ps[0]) : 'none') + ' reached=' + reached + ' at ' + pos(b))
    if (!ps.length) return false
    const bp = ps[0]
    if (!fin3(bp)) { log('BED bad position'); return false }
    try { await b.lookAt(new Vec3(bp.x + 0.5, bp.y + 0.5, bp.z + 0.5), true) } catch (e) {}
    await sleep(300)
    let slept = false
    try {
      await withTimeout(b.useBlock(bp, { faces: [new Vec3(0, 0, 1), new Vec3(0, 0, -1), new Vec3(1, 0, 0), new Vec3(-1, 0, 0)] }), 6000, false)
      slept = true
    } catch (e) { log('BED_USE_ERR', e && e.message) }
    HOME = { x: cx, y: cy, z: cz }
    try { saveHome() } catch (e) {}
    log('BED slept=' + slept + ' respawn should now be home at ' + cx + ' ' + cy + ' ' + cz)
    try {
      const tool = b.inventory.items().find(i => /sword|axe|pickaxe/.test(i.name))
      if (tool) await b.equip(tool, 'hand')
    } catch (e) {}
    return slept
  } catch (e) { log('BED_ERR', e && e.message); return false }
}

async function buildHut (b) {
  const site = pickBuildSite(b)
  if (!site) { log('BUILD no flat 5x5 inside the leash circle near anchor'); return false }
  log('BUILD site ' + site.x + ' ' + site.y + ' ' + site.z + ' planks=' + plankCount(b))
  if (!(await ensureCraftingTable(b))) { /* placing still works without a table */ }
  if (plankCount(b) < 20) await ensurePlanks(b, 48)
  if (plankCount(b) < 20) { log('BUILD need ~20 planks, have ' + plankCount(b) + ' - gather wood first'); return false }
  manualLockUntil = Math.max(manualLockUntil, Date.now() + 300000)
  b.__building = true
  const y0 = site.y + 1
  let placed = 0; let failed = 0
  const mat = () => PLANK_LIST.find(n => countItem(b, n) > 0)
  // 2 wall layers of the 5x5 ring (30 blocks), doorway kept open at +z, then a 3x3 roof (9)
  for (let layer = 0; layer < 2; layer++) {
    for (let dx = -2; dx <= 2; dx++) {
      for (let dz = -2; dz <= 2; dz++) {
        if (Math.abs(dx) !== 2 && Math.abs(dz) !== 2) continue
        if (dx === 0 && dz === 2) continue                           // doorway
        if (!b.entity || b.health < 7 || !b.isAlive) { log('BUILD abort hp=' + Math.round(b.health)); b.__building = false; return false }
        const m = mat()
        if (!m) { failed++; continue }
        const okp = await placeBlockAt(b, site.x + dx, y0 + layer, site.z + dz, m)
        if (okp) placed++; else failed++
        if (b.__fighting) { await sleep(1200); }                      // let the combat loop shoot first
      }
    }
    log('BUILD walls layer ' + layer + ' placed=' + placed + ' failed=' + failed)
  }
  for (let dx = -1; dx <= 1; dx++) {
    for (let dz = -1; dz <= 1; dz++) {
      if (!b.entity || !b.isAlive || b.health < 7) { b.__building = false; return false }
      const m = mat()
      if (!m) { failed++; continue }
      const okp = await placeBlockAt(b, site.x + dx, y0 + 2, site.z + dz, m)
      if (okp) placed++; else failed++
    }
  }
  log('BUILD roof placed=' + placed + ' failed=' + failed)
  // door, if we can craft one from the same planks
  try {
    const m = PLANK_LIST.find(n => countItem(b, n) >= 6)
    if (m) {
      const dn = m.replace('_planks', '_door')
      if (mcData.itemsByName[dn]) {
        if (await craftItem(b, dn, 1)) {
          if (await placeBlockAt(b, site.x, y0, site.z + 2, dn)) { log('BUILD door set'); placed++ }
        }
      }
    }
  } catch (e) { log('BUILD_DOOR_ERR', e && e.message) }
  b.__building = false
  manualLockUntil = Date.now() + 8000
  anchor = { x: site.x + 0.5, y: site.y, z: site.z + 0.5, t: Date.now(), home: true }
  saveAnchor()
  log('BUILD hut done placed=' + placed + ' failed=' + failed + ' home=' + site.x + ' ' + site.y + ' ' + site.z)
  // finish the house = make it the place we come back to after a death
  if (placed >= 18) { try { await bedInsideHut(b, site, y0) } catch (e) { log('BED_ERR', e && e.message) } }
  return placed >= 18
}

function startReflexes (b) {
  let lastStuckPos = null; let lastStuckTime = Date.now();
  let lastPos = null; let lastMove = Date.now(); let lastEscape = 0; let lastDefLog = 0
  if (b.__reflex) clearInterval(b.__reflex)
  b.__reflex = setInterval(() => {
    try {
      // STUCK JUMP: if trying to move but not actually moving for 1.5s, force a jump
      try {
        const isMovingCtrl = b.controlState && (b.controlState.forward || b.controlState.back || b.controlState.left || b.controlState.right);
        const pfMoving = b.pathfinder && b.pathfinder.isMoving ? b.pathfinder.isMoving() : false;
        if (isMovingCtrl || pfMoving) {
          const p = b.entity ? b.entity.position : null;
          if (p && lastStuckPos && p.distanceTo(lastStuckPos) < 0.5 && Date.now() - lastStuckTime > 1500) {
            if (Date.now() > jumpLockUntil) {
              b.setControlState('jump', true);
              setTimeout(() => { try { b.setControlState('jump', false) } catch(e){} }, 300);
              lastStuckTime = Date.now();
            }
          }
          if (!lastStuckPos || (p && p.distanceTo(lastStuckPos) > 0.5)) {
            lastStuckPos = p ? p.clone() : null;
            lastStuckTime = Date.now();
          }
        } else {
          lastStuckPos = null;
          lastStuckTime = Date.now();
        }
      } catch (e) {}

      if (!reflexOn) { lastPos = null; return }
      if (!b.entity || b.health <= 0) { lastPos = null; return }
      const now = Date.now()
      // fleeing / respawn-sprinting: NEVER dig - digging while chased = death spiral.
      // toggled centrally here so canDig always restores itself afterwards
      try {
        // the reflex loop used to hand digging back every time we were not fleeing, which
        // quietly re-enabled the tunnel-through-everything habit. Path planning never digs.
        const wantDig = !!b.__softDig       // walking never digs; harvest sets __softDig (patch16)
        if (b.__movements && b.__movements.canDig !== wantDig) b.__movements.canDig = wantDig
        if (b.collectBlock && b.collectBlock.movements && b.collectBlock.movements.canDig !== wantDig) b.collectBlock.movements.canDig = wantDig
      } catch (e) {}
      // anti-starvation: directorTick is blocked while missions run, but food keeps dropping -
      // eat here instead (junk food only as a last resort, never while fleeing/hiding)
      if (!b.__fleeing && !hiding && b.food <= 7 && now - (b.__lastStarveEat || 0) > 15000) {
        try {
          const junk = b.food <= 5 ? b.inventory.items().find(i => i.name === 'rotten_flesh' || i.name === 'spider_eye' || i.name === 'poisonous_potato') : null
          if (countFood(b) > 0) { b.__lastStarveEat = now; eatFood(b).catch(() => {}) } else if (junk) {
            b.__lastStarveEat = now
            b.equip(junk, 'hand').then(() => b.consume()).then(() => log('ATE emergency', junk.name, 'food=' + Math.round(b.food))).catch(() => {})
          }
        } catch (e) {}
      }
      // starving with empty hands: abort whatever mission is running so director picks food
      if (b.food <= 4 && countFood(b) === 0 && mission && mission.name !== 'food' && !isNight(b) && now - (b.__lastStarveAbort || 0) > 30000) {
        b.__lastStarveAbort = now
        log('STARVE_ABORT food=' + Math.round(b.food) + ' mission=' + mission.name)
        try { b.pathfinder.setGoal(null) } catch (e) {}
        mission = null
      }
      if (b.isAlive === false && b.health > 0) { b.isAlive = true; log('ISALIVE_RESTORED', 'hp=' + Math.round(b.health)) }
      if (b.__srvPos && Date.now() - b.__srvPos.t > 12000 && b.__inWater) {
        if (Date.now() - (b.__helpAsked || 0) > 90000) { b.__helpAsked = Date.now(); log('WATER_PIN', 'no server updates, stuck at ' + pos(b)) }
      }
      if (b.game && b.game.gameMode === 'creative') { log('MODE_FIX'); try { b.game.gameMode = 'survival' } catch (e) {} }
      const fp = b.entity.position.floored()
      const hb = b.blockAt(fp.offset(0, 1, 0))
      const inWater = !!(hb && /water|lava/.test(hb.name))
      const feetWet = !!(b.blockAt(fp) && /water|lava/.test(b.blockAt(fp).name))
      if (!inWater && !feetWet && b.entity.onGround) b.__lastDry = { x: fp.x, y: fp.y, z: fp.z, t: now }
      if ((inWater || feetWet) && !(b.__drive && Date.now() < manualLockUntil) && !b.__wallBury && !b.__burying && !hiding && !inCollapseZone(b) && !tunneling && !diggingUp && !deepNearCrater(b)) {
        if (!b.__inWater) { b.__inWater = true; try { b.pathfinder.setGoal(null) } catch (e) {} }
        // being shot at while swimming = death spiral (50 deaths in 10 min): wall-burrow NOW
        if (now - (b.__lastWallBury || 0) > 45000) {
          let wt = null
          try { wt = threatsNear(b, 1.0)[0] } catch (e) {}
          if (wt && wt.d < 14) {
            b.__fleeing = false
            b.__lastWallBury = now
            log('WATER_THREAT ' + (wt.e.name || '?') + ' d=' + wt.d.toFixed(1) + ' -> wallBury')
            wallBury(b, 90000)
            return
          }
        }
        if (now - (b.__dryRun || 0) > 6000) {
          b.__dryRun = now
          const dry = nearestDry(b, 16)
          if (dry && dry.d < 4) {
            const key = Math.round(b.entity.position.x) + ',' + Math.round(b.entity.position.z)
            if (b.__wetKey === key) b.__wetFails = (b.__wetFails || 0) + 1
            else { b.__wetKey = key; b.__wetFails = 1 }
            if (b.__wetFails >= 2 && b.__wetFails < 5 && !b.__stairing) {   // pillar-in-water never worked
              const T = dry || { x: anchor ? anchor.x : b.entity.position.x, z: anchor ? anchor.z : b.entity.position.z }
              b.__stairing = true
              stairOut(b, Math.round(T.x), Math.round(T.z), 8).then(r => log('STAIR_OUT ' + r)).finally(() => { b.__stairing = false })
            }
            if (b.__wetFails >= 5 && dry.d < 3.5 && !b.__wetBurst) {
              b.__wetBurst = true
              log('WATER_BURST at dry shore d=' + dry.d.toFixed(1) + ' at', pos(b))
              try { b.lookAt(new Vec3(dry.x + 0.5, dry.y + 0.5, dry.z + 0.5), true) } catch (e) {}
              try { b.setControlState('forward', true); b.setControlState('sprint', true); b.setControlState('jump', true) } catch (e) {}
              setTimeout(() => { try { b.setControlState('forward', false); b.setControlState('sprint', false); b.setControlState('jump', false) } catch (e) {}; b.__wetBurst = false; b.__wetFails = 0 }, 2200)
            }
          } else if (dry) { b.__wetFails = 0 }
          if (dry) {
            log('WATER_OUT', 'to ' + Math.round(dry.x) + ' ' + dry.y + ' ' + Math.round(dry.z) + ' d=' + dry.d.toFixed(1))
            try { b.lookAt(new Vec3(dry.x + 0.5, dry.y, dry.z + 0.5), true, false) } catch (e) {}
            try { b.setControlState('forward', true); b.setControlState('sprint', false) } catch (e) {}
            hop(b)
            const hb = setInterval(() => hop(b), 400)
            setTimeout(() => { clearInterval(hb); try { b.setControlState('jump', false) } catch (e) {} }, 1400)
            setTimeout(() => { try { b.setControlState('forward', false) } catch (e) {} }, 2600)
          } else {
            const ld = (b.__lastDry && now - b.__lastDry.t < 300000) ? b.__lastDry : null
            if (ld) {
              log('WATER_OUT', 'swim to last dry ' + ld.x + ' ' + ld.z + ' at', pos(b))
              try { b.look(Math.atan2(-(ld.x + 0.5 - b.entity.position.x), ld.z + 0.5 - b.entity.position.z), -0.1, true) } catch (e) {}
              try { b.setControlState('forward', true); b.setControlState('sprint', true) } catch (e) {}
              setTimeout(() => { try { b.setControlState('forward', false); b.setControlState('sprint', false) } catch (e) {} }, 5000)
            } else {
              log('WATER_OUT', 'no dry ground near ' + pos(b))
              try { b.setControlState('jump', true) } catch (e) {}
              setTimeout(() => { try { b.setControlState('jump', false) } catch (e) {} }, 800)
            }
          }
        }
        lastPos = b.entity.position.clone()
        return
      } else if (b.__inWater) {
        b.__inWater = false
        try { b.setControlState('jump', false); b.setControlState('forward', false); b.setControlState('sprint', false) } catch (e) {}
      }
      const hsMul = hasWeapon(b) && b.health >= 14 ? 0.6 : 1.0
      let hs = threatsNear(b, hsMul)
      // dropped campers: a ranged follower that keeps its distance and never lands a hit
      // is ignored for a while, otherwise missions never resume (it aggroed for 3+ min straight)
      if (b.__ignore && now < b.__ignore.until) {
        hs = hs.filter(x => !(x.e.id === b.__ignore.id && x.d > x.r * 0.7 && now - lastHurtAt > 8000))
      }
      // hysteresis: while fleeing, keep fleeing while the chaser is anywhere inside 1.4x radius,
      // so a threat hovering at the boundary cannot flip-flop the state (goal ping-pong)
      if (!hs.length && b.__fleeing) {
        let wide = threatsNear(b, hsMul * 1.4)
        if (b.__ignore && now < b.__ignore.until) wide = wide.filter(x => x.e.id !== b.__ignore.id)
        if (wide.length) hs = wide
      }
      if (hs.length) { b.__fleeClearAt = 0 }
      if (hs.length) {
        const t = hs[0]
        const armed = hasWeapon(b)
        // combat owns this fight: no flee/hide/tower ping-pong on top of it
        if (b.__fighting && now - (b.__fightAt || 0) < 1600) { lastPos = b.entity.position.clone(); return }
        const ranged = RANGED.has(String(t.e.name || '').toLowerCase())
        // cornered by MELEE (zombie walked into the trench / caught us at pocket exit):
        // raw sprint barely outpaces it - tower up 4 instead, they cannot pillar after us
        if (!ranged && !armed && t.d < 4.5 && b.health <= 16 && now - (b.__towerCd || 0) > 40000 && !botWet(b) && !b.__burying && !b.__wallBury && !hiding && !inCollapseZone(b)) {
          if (b.__pillarEscape) { lastPos = b.entity.position.clone(); return }
          b.__towerCd = now
          log('TOWER_ESCAPE ' + t.e.name + ' d=' + t.d.toFixed(1) + ' hp=' + Math.round(b.health))
          ;(async () => {
            b.__pillarEscape = true
            try {
              try { b.pathfinder.setGoal(null) } catch (e) {}
              b.__fleeing = false
              manualLockUntil = Math.max(manualLockUntil, Date.now() + 12000)
              if (countPlaceable(b) < 4) await ensurePlaceable(b, 4)
              if (countPlaceable(b) >= 1) await pillarUp(b, 4)
            } catch (e) {}
            b.__pillarEscape = false
          })()
          lastPos = b.entity.position.clone()
          return
        }
        if (b.__pillarEscape) { lastPos = b.entity.position.clone(); return }
        // night + gearless + mob within 14: don't run around the jungle all night -
        // flee-escaping kept dying (water/undergrowth slow us, canopy keeps mobs spawning).
        // Seal into a pocket and sleep out the night instead.
        if ((b.entity.isInWater || feetWet) && t.d < 16 && !hiding && !b.__wallBury && now - (b.__lastWallBury || 0) > 45000) {
          b.__fleeing = false
          b.__lastWallBury = now
          log('WATER_THREAT flee ' + t.e.name + ' d=' + t.d.toFixed(1) + ' -> wallBury')
          wallBury(b, 90000)
          return
        }
        if (!armed && (isNight(b) || isDusk(b)) && t.d < 22 && b.health > 10 && now - lastHideAt > 70000) {
          b.__fleeing = false
          lastPos = b.entity.position.clone()
          log('HIDE_TRIGGER night ' + t.e.name + ' d=' + t.d.toFixed(1) + ' hp=' + Math.round(b.health))
          const hd = findDoorNear(b, b.entity.position.floored(), 10)
          if (hd && b.health > 8) {                 // we own a door now - use it as a shield
            lastHideAt = now
            hideAtHome(b).then(r => log('HIDE_HOME ' + r)).catch(() => {})
            return
          }
          hidePocket(b, t.e, 240000, true)
          return
        }
        if (ranged && !armed && b.health <= 13 && b.health > 4 && now - lastHideAt > 70000) {
          b.__fleeing = false
          if (now - lastDefLog > 4000) { lastDefLog = now; log('HIDE_TRIGGER', t.e.name + ' hp=' + Math.round(b.health) + ' d=' + t.d.toFixed(1)) }
          lastPos = b.entity.position.clone()
          hidePocket(b, t.e, 26000, true)
          return
        }
        if (armed && b.health >= 10 && now > manualLockUntil) {
          b.__fleeing = false
          equipBestWeapon(b)
          if (okPos(t.e.position)) { try { b.lookAt(t.e.position.offset(0, (t.e.height || 1.8) * 0.6, 0)) } catch (e) {} }
          if (t.d > 3.0) { try { b.pathfinder.setGoal(new goals.GoalNear(t.e.position.x, t.e.position.y, t.e.position.z, 2)) } catch (e) {} }
          try { b.attack(t.e) } catch (e) {}
          if (now - lastDefLog > 4000) { lastDefLog = now; log('DEFEND', t.e.name, 'd=' + t.d.toFixed(1)) }
        } else if (now > manualLockUntil || (b.__drive && t.d < 8)) {
          if (!b.__fleeing) { b.__fleeing = true; b.__fleeGoalAt = 0; b.__fleeStart = now; try { b.pathfinder.setGoal(null) } catch (e) {} }
          if (b.__drive && Date.now() < manualLockUntil) { log('DRIVE_ABORT', 'flee ' + t.e.name); stopDrive(b) }
          if (ranged && !armed && b.health >= 14 && now - (b.__fleeStart || now) > 20000 && t.d > t.r * 0.7 && now - lastHurtAt > 10000) {
            // anti-camp: it just follows at range and never hits - drop aggro, resume living
            b.__ignore = { id: t.e.id, until: now + 30000 }
            b.__fleeing = false
            log('FLEE_DROP', t.e.name + ' keeps distance d=' + t.d.toFixed(1) + ' - ignoring for 30s')
            try { b.pathfinder.setGoal(null) } catch (e) {}
            try { b.clearControlStates() } catch (e) {}
          } else {
            // in dense terrain raw sprinting runs face-first into trees and the chaser catches up;
            // let the pathfinder route the escape around obstacles, raw sprint only while it thinks.
            // commit to each escape vector for 4s: re-picking every 2.2s made the bot zigzag in
            // place while zombies kept contact distance (d=4-8 forever) and eventually killed it
            if (now - (b.__fleeGoalAt || 0) > 4000 && !hiding) {
              b.__fleeGoalAt = now
              const ep = escapePointFrom(b, t.e.position, ranged ? 28 : 32)
              if (ep) { try { b.pathfinder.setGoal(new goals.GoalXZ(ep.x, ep.z)) } catch (e) {} }
            }
            let pfMoving = false; try { pfMoving = b.pathfinder.isMoving() } catch (e) {}
            if (!pfMoving) fleeFrom(b, t.e)
            if (now - lastDefLog > 4000) { lastDefLog = now; log('FLEE', t.e.name, 'd=' + t.d.toFixed(1), 'hp=' + Math.round(b.health) + ((ranged ? ' zigzag ' : ' ') + (pfMoving ? 'pf' : 'raw'))) }
          }
        }
      } else if (b.__fleeing) {
        // coast for 2.5s before standing down (kills boundary flip-flop for good)
        if (!b.__fleeClearAt) b.__fleeClearAt = now
        if (now - b.__fleeClearAt >= 2500) {
          b.__fleeing = false; b.__fleeClearAt = 0
          if (Date.now() > manualLockUntil && !b.__drive) {
            try { b.setControlState('forward', false); b.setControlState('sprint', false); b.setControlState('left', false); b.setControlState('right', false); b.setControlState('jump', false) } catch (e) {}
          }
        }
      }
      const p = b.entity.position
      if (lastPos && p.distanceTo(lastPos) < 0.2) { if (now - lastMove > 8000) lastMove = now } else { lastMove = now }
      lastPos = p.clone()
    } catch (e) {}
  }, 500)
}

let mission = null
function missionActive () { return !!mission }

function countItem (b, name) {
  let n = 0
  for (const it of b.inventory.items()) if (it.name === name) n += it.count
  return n
}

async function placeBlockAt (b, x, y, z, itemName) {
  if (!b.entity) return false
  const targetPos = new Vec3(x, y, z)
  const cur = b.blockAt(targetPos)
  if (cur && cur.boundingBox === 'block') return true
  const inv = b.inventory.items().find(i => i.name === itemName)
  if (!inv) return false
  try { await b.equip(inv, 'hand') } catch (e) { return false }
  if (b.entity.position.distanceTo(targetPos) > 4) {
    try { b.pathfinder.setGoal(new goals.GoalNear(x, y, z, 3)); await once(b, 'goal_reached', 12000) } catch (e) {}
    try { b.pathfinder.setGoal(null) } catch (e) {}
  }
  const dirs = [new Vec3(0, -1, 0), new Vec3(1, 0, 0), new Vec3(-1, 0, 0), new Vec3(0, 0, 1), new Vec3(0, 0, -1), new Vec3(0, 1, 0)]
  for (const d of dirs) {
    const ref = b.blockAt(targetPos.plus(d))
    if (ref && ref.boundingBox === 'block') {
      const r = await withTimeout(b.placeBlock(ref, d.scaled(-1)), 4000, 'to')
      if (r !== 'to') return true
    }
  }
  return false
}

async function gatherBlocks (b, findNames, countName, target) {
  const ids = findNames.map(n => mcData.blocksByName[n]).filter(Boolean).map(bt => bt.id)
  let guard = 0
  let stalls = 0
  let last = countItem(b, countName)
  while (countItem(b, countName) < target && b.entity && b.health > 0 && mission && guard++ < 150) {
    if (b.entity && /log/.test(countName)) {
      // If we are standing ON or IN a tree (leaves under/around us) there is no path and no
      // clever plan - the way down is to chop the block under our feet and fall one block,
      // which also harvests the trunk on the way. That is how a player fells a tree.
      const ft = b.entity.position.floored()
      const under = b.blockAt(ft.offset(0, -1, 0))
      const inside = b.blockAt(ft)
      const onTree = under && (LOG_TYPES.indexOf(under.name) >= 0 || /leaves/.test(under.name))
      const inCrown = inside && /leaves/.test(inside.name)
      if (onTree || inCrown) {
        b.__allowDig = true
        try {
          if (onTree) await withTimeout(digBlock(b, ft.offset(0, -1, 0)), 15000, false)
          if (inCrown) await withTimeout(digBlock(b, ft), 12000, false)
        } finally { b.__allowDig = false }
        await sleep(500)
        try { await collectNear(b, 7) } catch (e) {}
        log('TREE_DESCEND chopped under=' + (under ? under.name : '-') + ' now=' + pos(b))
      }
    }
    let positions = b.findBlocks({ matching: ids, maxDistance: 28, count: 8 })
    if (!positions.length) { log('GATHER none nearby'); await suckDrops(b, 12); break }
    if (/log/.test(countName)) {
      // base of the trunk only: a log with another log under it is mid-trunk and needs a
      // ladder, and the crown is 6-10 up. Bases are on the ground, at our own height.
      const bases = positions.filter(p => { const bel = b.blockAt(p.offset(0, -1, 0)); return !(bel && LOG_TYPES.indexOf(bel.name) >= 0) })
      if (bases.length) positions = bases
      const feetY = b.entity ? b.entity.position.y : 64
      const low = positions.filter(p => p.y <= feetY + 3)
      if (low.length) positions = low
    }
    const blocks = positions.map(p => b.blockAt(p)).filter(Boolean)
    const need = target - countItem(b, countName)
    if (/log|wood|plank/.test(countName)) { for (const p of positions) await clearFoliage(b, p) }
    const job = withSoftDig(b, () => b.collectBlock.collect(blocks, { iterations: Math.max(1, Math.min(8, need)), range: 4 }))
    let r = await withTimeout(job, 25000, 'timeout')
    if (r === 'timeout') {
      log('GATHER timeout - waiting for the collect that is already running')
      r = await withTimeout(job.then(() => 'late-ok').catch(() => 'late-fail'), 40000, 'late-timeout')
      try { b.pathfinder.stop() } catch (e) {}
    }
    const now = countItem(b, countName)
    if (now <= last) {
      stalls++
      await suckDrops(b, 8)
      if (stalls >= 2 && /log/.test(countName)) await chopOne(b, positions)
      if (stalls >= 5) { log('GATHER stalled at', now, '- proceeding to build'); break }
    } else { stalls = 0; last = now }
  }
  log('GATHER have', countItem(b, countName), countName)
}

// Collector gave up twice? Then chop the trunk by hand: walk to it, break exactly that
// one block, pick up the drop. It is the difference between "no wood for 20 minutes" and
// one log every few seconds - and it still breaks ONE block, not a tunnel.
async function chopOne (b, positions) {
  try {
    if (!b.entity) return false
    const g = b.entity.position
    const near = positions.map(p => ({ p, d: g.distanceTo(p) })).sort((a, c) => a.d - c.d)
    for (const c of near.slice(0, 3)) {
      const k = b.blockAt(c.p)
      if (!k || LOG_TYPES.indexOf(k.name) < 0) continue
      if (c.d > 4.5) {
        const ok = await b.pathfinder.goto(new goals.GoalNear(c.p.x, c.p.y, c.p.z, 2)).then(() => true).catch(() => false)
        if (!ok) continue
      }
      const now = b.blockAt(c.p)
      if (!now || LOG_TYPES.indexOf(now.name) < 0) continue
      b.__allowDig = true
      try { await withTimeout(digBlock(b, c.p), 20000, false) } finally { b.__allowDig = false }
      await sleep(700)
      try { await collectNear(b, 7) } catch (e) {}
      log('CHOP_ONE ' + k.name + ' at ' + c.p + ' have=' + countItem(b, k.name))
      if (countItem(b, k.name) > 0) return true
    }
    return false
  } catch (e) { log('CHOP_ERR', e && e.message); return false }
}

// walk over item entities we dropped/mined but never picked up (pickup range is tiny)
async function suckDrops (b, r) {
  try {
    if (!b.entity) return
    const p = b.entity.position
    const near = []
    // cylindrical search: trunk drops tumble off cliffs and land 15+ blocks BELOW
    for (const id in b.entities) {
      const e = b.entities[id]
      if (e && e.name === 'item' && e.position) {
        const dh = Math.hypot(e.position.x - p.x, e.position.z - p.z)
        if (dh < (r || 8) && Math.abs(e.position.y - p.y) < 24) near.push(e)
      }
    }
    if (!near.length) return
    near.sort((x, y) => x.position.distanceTo(p) - y.position.distanceTo(p))
    log('SUCK drops x' + Math.min(8, near.length))
    for (const e of near.slice(0, 8)) {
      if (!b.entity || !mission || b.__fleeing || hiding) break
      await gotoT(b, new goals.GoalNear(e.position.x, e.position.y, e.position.z, 1), 4000)
      await sleep(450)
    }
  } catch (e2) {}
}

async function buildShelter (b, mat) {
  const o = b.entity.position.floored()
  log('BUILD origin', o.x, o.y, o.z, 'mat', mat)
  const cells = []
  for (let dx = -2; dx <= 2; dx++) {
    for (let dz = -2; dz <= 2; dz++) {
      const perim = (Math.abs(dx) === 2 || Math.abs(dz) === 2)
      if (perim) {
        for (let dy = 0; dy <= 1; dy++) {
          if (dx === 2 && dz === 0) continue
          cells.push([dx, dy, dz])
        }
      }
    }
  }
  for (let dx = -2; dx <= 2; dx++) { for (let dz = -2; dz <= 2; dz++) cells.push([dx, 2, dz]) }
  let placed = 0
  for (const c of cells) {
    if (!mission) break
    if (await placeBlockAt(b, o.x + c[0], o.y + c[1], o.z + c[2], mat)) placed++
    await sleep(50)
  }
  log('BUILD placed', placed, '/', cells.length)
}

async function missionShelter (b) {
  log('MISSION shelter START at', pos(b))
  try {
    await autoFree(b)
    if (!hasWeapon(b) && (isNight(b) || isDusk(b))) {
      // gearless at night: gathering 55 dirt in the open is suicide - seal into a
      // pocket and sleep out the night instead (zombies can't dig, arrows need LOS)
      let rounds = 0
      while (mission && b.entity && b.health > 0 && (isNight(b) || isDusk(b)) && rounds++ < 8) {
        if (botWet(b)) await wallBury(b, 120000)
        else await hidePocket(b, nearestHostile(b, 20), 240000, true)
        if (mission && (isNight(b) || isDusk(b))) await sleep(3000)
      }
      log('MISSION shelter: dawn at', pos(b))
    } else {
      await gatherBlocks(b, ['dirt', 'grass_block'], 'dirt', 55)
      if (mission) await buildShelter(b, 'dirt')
    }
  } catch (e) { log('MISSION_ERR', e && e.message ? e.message : String(e)) }
  log('MISSION shelter END')
  mission = null
}

async function missionGather (b, blockName, n) {
  log('MISSION gather START', blockName, n)
  try {
    await autoFree(b)
    await gatherBlocks(b, [blockName], blockName, n)
  } catch (e) { log('MISSION_ERR', e && e.message ? e.message : String(e)) }
  log('MISSION gather END')
  mission = null
}

// Craft+place a crafting table when 3x3 recipes need one and none is in reach.
// Returns the table Block, or null. (Fixes the stone-mission hot loop: cobble was
// banked but stone_pickaxe silently failed to craft with no table anywhere.)
async function ensureCraftingTable (b) {
  try {
    const ct = mcData.blocksByName.crafting_table
    if (!ct) return null
    let tb = b.findBlock({ matching: ct.id, maxDistance: 5 })
    if (tb) return tb
    if (countItem(b, 'crafting_table') < 1) {
      const pl = PLANKS_ANY.find(n => countItem(b, n) >= 4)
      if (!pl) return null
      if (!await craftItem(b, 'crafting_table', 1)) return null
    }
    const ctItem = b.inventory.items().find(i => i.name === 'crafting_table')
    if (!ctItem) return null
    const feet = b.entity.position.floored()
    for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]]) {
      const ground = b.blockAt(feet.offset(d[0], -1, d[1]))
      const cell = b.blockAt(feet.offset(d[0], 0, d[1]))
      const head = b.blockAt(feet.offset(d[0], 1, d[1]))
      if (!ground || ground.boundingBox !== 'block') continue
      if (!cell || cell.boundingBox === 'block') continue
      if (head && head.boundingBox === 'block') continue
      try {
        await b.equip(ctItem, 'hand')
        const r = await withTimeout(b.placeBlock(ground, new Vec3(0, 1, 0)), 4000, 'to')
        if (r === 'to') continue
        tb = b.findBlock({ matching: ct.id, maxDistance: 5 })
        if (tb) { log('TABLE placed at', tb.position.x + ' ' + tb.position.y + ' ' + tb.position.z); return tb }
      } catch (e) { log('TABLE_PLACE_ERR', e && e.message) }
    }
    return null
  } catch (e) { log('TABLE_ERR', e && e.message); return null }
}
async function craftItem (b, name, count) {
  const item = mcData.itemsByName[name]
  if (!item) return false
  let table = null
  const ct = mcData.blocksByName.crafting_table
  if (ct) { const tb = b.findBlock({ matching: ct.id, maxDistance: 5 }); if (tb) table = tb }
  let recipes = b.recipesFor(item.id, null, 1, table)
  if (!recipes.length && table) recipes = b.recipesFor(item.id, null, 1, null)
  if (!recipes.length && name !== 'crafting_table') {
    // 3x3 recipe with no table in reach: make one, place it, retry once
    table = await ensureCraftingTable(b)
    if (table) { recipes = b.recipesFor(item.id, null, 1, table); if (!recipes.length) recipes = b.recipesFor(item.id, null, 1, null) }
  }
  if (!recipes.length) return false
  try { await b.craft(recipes[0], count || 1, table); stats.crafted += (count || 1); log('CRAFT', name, 'x' + (count || 1)); return true } catch (e) { log('CRAFT_FAIL', name, e && e.message); return false }
}

const LOG_TYPES = ['pale_oak_log', 'oak_log', 'birch_log', 'spruce_log', 'jungle_log', 'acacia_log', 'dark_oak_log', 'mangrove_log', 'cherry_log']
// walk down a trunk to its base: the bottom log is reachable, the canopy is not
function trunkBase (b, p) {
  let base = p.clone()
  for (let dy = 1; dy <= 30; dy++) {
    const below = b.blockAt(new Vec3(p.x, p.y - dy, p.z))
    if (below && LOG_TYPES.indexOf(below.name) >= 0) base = below.position.clone()
    else break
  }
  return base
}
function findNearestLog (b, r, exclude, relaxed) {
  const ids = LOG_TYPES.map(n => mcData.blocksByName[n]).filter(Boolean).map(bt => bt.id)
  if (!ids.length) return null
  let positions = []
  try { positions = b.findBlocks({ matching: ids, maxDistance: r, count: 250 }) } catch (e) {}
  if (!positions.length) return null
  const feet = b.entity.position
  const bases = new Map()
  for (const p of positions) {
    const key = p.x + ',' + p.z
    if (!bases.has(key)) bases.set(key, trunkBase(b, p))
  }
  let best = null; let bestD = 1e9
  for (const base of bases.values()) {
    if (exclude && exclude.has(base.x + ',' + base.y + ',' + base.z)) continue
    if (inDeathZone(base.x, base.z, 40)) continue                    // died by this tree recently - pick another area
    if (relaxed) {
      // the whole jungle sits in the "corridor": strict pass found nothing, so only
      // keep the nest core excluded - death zones still guard the actually lethal spots
      if (Math.hypot(base.x - NEST.x, base.z - NEST.z) < 35) continue
    } else {
      if (Math.hypot(base.x - NEST.x, base.z - NEST.z) < 60) continue  // spawn-nest corridor: never route wood through it
      if (pointSegDist(NEST.x, NEST.z, feet.x, feet.z, base.x, base.z) < 45) continue  // straight route would cross the nest
    }
    if (base.y - feet.y > 30 || feet.y - base.y > 20) continue     // unreachable cliff/canopy
    const d = Math.hypot(base.x - feet.x, base.z - feet.z)
    // slope/cliff-top trunk: no longer hard-skipped (we can dig + pillar toward it now),
    // but heavily penalized so level-ground trunks are always attempted first.
    const up = Math.max(0, base.y - feet.y)
    const score = d + (up > 2 ? up * 2.5 : 0) + (up > 6 && up > d * 0.6 ? 25 : 0)
    if (score < bestD) { bestD = score; best = base }
  }
  if (best) log('WOOD trunk base', best.x + ' ' + best.y + ' ' + best.z, 'score=' + Math.round(bestD))
  return best
}
// goto with a hard deadline; resolves to 'reached' | 'timeout' | 'fail:<reason>' and always
// leaves the pathfinder idle afterwards, so callers can chain strategies without overlap
async function gotoT (b, goal, ms) {
  let res
  try {
    res = await Promise.race([
      b.pathfinder.goto(goal).then(() => 'reached').catch(e => 'fail:' + ((e && e.name) || 'err')),
      sleep(ms).then(() => 'timeout')
    ])
  } catch (e) { res = 'fail:err' }
  // library quirk: when A* finds no path at all, 'path_update' arrives with an empty
  // path and goto RESOLVES as success. Verify we actually satisfy the goal.
  if (res === 'reached' && b.entity) {
    try {
      const p = b.entity.position.floored()
      if (!goal.isEnd(p) && !goal.isEnd(p.offset(0, 1, 0))) res = 'fail:noPath'
    } catch (e) {}
  }
  if (res !== 'reached') {
    try { b.pathfinder.stop() } catch (e) {}
    await sleep(120)
    try { b.pathfinder.setGoal(null) } catch (e) {}
    await sleep(580)                                   // hard pacing: never spin goto loops
  }
  return res
}
// No paths anywhere = tiny island / water pocket / walled niche. Swim or walk to dry land.
// Underwater pillarUp() can't work: one hop lifts <1 block in water, floored() never
// changes and every place lands into the block we stand on. Swim up deliberately
// (+1.25b), then place into the cell we just left, against the block below it.
async function waterPillarOnce (b) {
  if (!b.entity) return false
  const matName = PLACEABLE.find(nm => countItem(b, nm) > 0)
  if (!matName) return false
  const mat = b.inventory.items().find(it => it.name === matName)
  try { await b.equip(mat, 'hand') } catch (e) {}
  const start = b.entity.position.clone()
  const baseCell = start.floored()                        // the water cell we will fill
  const baseBlk = b.blockAt(baseCell)
  if (baseBlk && baseBlk.boundingBox === 'block') return true
  // swim-jump up until our FEET clear the cell, then place into the cell we left.
  // (old version computed target=feet-1 AFTER the wait: in a puddle that was the
  // solid floor -> "already solid, return true" short-circuit = infinite no-op)
  b.setControlState('jump', true)
  const t0 = Date.now()
  while (Date.now() - t0 < 1800 && b.entity && b.entity.position.y < start.y + 1.15) await sleep(70)
  b.setControlState('jump', false)
  if (!b.entity) return false
  if (b.entity.position.y - start.y < 0.55) return false  // puddle/pinned: caller handles
  const ref = b.blockAt(baseCell.offset(0, -1, 0))
  if (!ref || ref.boundingBox !== 'block') return false
  const still = b.blockAt(baseCell)
  if (still && still.boundingBox === 'block') return true
  const r = await withTimeout(b.placeBlock(ref, new Vec3(0, 1, 0)), 3500, 'to')
  return r !== 'to'
}
// wet = submerged OR standing in a puddle (feet cell water). hidePocket in a puddle
// dug+sealed the trench floor and WASTED our pillar sand - always wallBury when wet.
function botWet (b) {
  try {
    if (!b.entity) return false
    if (b.entity.isInWater) return true
    const fb = b.blockAt(b.entity.position.floored())
    return !!(fb && /water/.test(fb.name))
  } catch (e) { return false }
}
// stuck in water with an unreachable 1-block shore (the spawn cove is exactly that):
// pillar straight up through the water column - placing blocks underwater works,
// and from the surface the shore is a trivial walk
async function escapeWaterPillar (b) {
  if (b.__wetPillar || !b.entity) return
  b.__wetPillar = true
  try {
    log('WATER_PILLAR up from water at', pos(b))
    manualLockUntil = Math.max(manualLockUntil, Date.now() + 20000)
    for (let k = 0; k < 10 && b.entity && b.health > 0; k++) {
      const ft = b.entity.position.floored()
      const here = b.blockAt(ft)
      const inW = b.entity.isInWater || !!(here && /water/.test(here.name))
      if (!inW) break
      if (countPlaceable(b) < 1) await ensurePlaceable(b, 3, false)
      if (countPlaceable(b) < 1) break
      const y0 = b.entity.position.y
      const ok = await waterPillarOnce(b)
      if (!ok && b.entity && b.entity.position.y - y0 < 0.3) {
        // pinned in the cove (server rejects every move): carve horizontally toward
        // dry land, free our own cells, then tower up with digUpAndOut
        const dry = nearestDry(b, 16)
        if (dry) {
          log('WATER_CARVE toward ' + Math.round(dry.x) + ' ' + Math.round(dry.z) + ' at', pos(b))
          const ft = b.entity.position.floored()
          await withTimeout(digBlock(b, ft), 6000, false)
          await withTimeout(digBlock(b, ft.offset(0, 1, 0)), 6000, false)
          const dx = dry.x + 0.5 - b.entity.position.x; const dz = dry.z + 0.5 - b.entity.position.z
          const l = Math.hypot(dx, dz) || 1
          const ux = Math.round(dx / l); const uz = Math.round(dz / l)
          for (let step = 1; step <= 3; step++) {
            for (const dy of [0, 1]) await withTimeout(digBlock(b, ft.offset(ux * step, dy, uz * step)), 6000, false)
          }
          try { await b.look(Math.atan2(-dx, dz), 0, true) } catch (e) {}
          b.setControlState('forward', true); b.setControlState('sprint', true)
          await sleep(1400)
          b.setControlState('forward', false); b.setControlState('sprint', false)
          await digUpAndOut(b, 8)
        }
        break
      }
      await sleep(300)
    }
    log('WATER_PILLAR done at', pos(b), 'placeable=' + countPlaceable(b))
  } catch (e) { log('WPILLAR_ERR', e && e.message) }
  b.__wetPillar = false
}
// dig without suckDrop: underwater suckDrop swims up after floating drops and drags
// the bot out of the niche mid-work. Retries once on "Digging aborted" (arrow knockback).
async function digRaw (b, v) {
  if (NO_DIG) return false
  for (let att = 0; att < 2; att++) {
    const blk = b.blockAt(v)
    if (!blk || blk.boundingBox !== 'block') return true          // already open = fine
    const hard = blk.hardness === undefined ? 1 : blk.hardness
    if (hard < 0) return false
    try { await b.lookAt(blk.position.offset(0.5, 0.5, 0.5)); await b.dig(blk); stats.mined++; return true } catch (e) { await sleep(200) }
  }
  return false
}
// niche chosen in a PREVIOUS life (same process): terrain edits persist through death,
// so every respawn CONTINUES the same hole instead of restarting a fresh scan
let wallNiche = null
// WATER-TRENCH KILLBOX escape: respawning in water with a skeleton on the rim killed us
// 280+ times - swim/flee/hidePocket all fail while wet. Burrow into the nearest SAND wall
// at water level (cover in ~6s), THEN deepen + seal from inside, sleep out the night,
// digUpAndOut surfaces ON THE SHORE above the wall.
async function wallBury (b, waitMs) {
  if (!b.entity || b.__wallBury || hiding) return false
  if (inCollapseZone(b)) { log('WALL_BURY skip in crater at', pos(b)); return false }
  b.__wallBury = true
  b.__buryAbort = false
  lastHideAt = Date.now()
  try {
    try { b.pathfinder.setGoal(null) } catch (e) {}
    try { b.clearControlStates() } catch (e) {}
    b.__fleeing = false
    manualLockUntil = Math.max(manualLockUntil, Date.now() + 60000)
    jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 60000)
    const GR = /dirt|grass_block|podzol|sand|gravel|stone|cobble|deepslate|granite|diorite|andesite|tuff|calcite|mud|terracotta|moss_block|netherrack|blackstone|basalt|mossy/
    // reuse the niche from a previous life if it is still near
    let best = null
    if (wallNiche && Date.now() - wallNiche.t < 900000 && b.entity.position.distanceTo(new Vec3(wallNiche.x, wallNiche.y, wallNiche.z)) < 10) {
      best = { v: new Vec3(wallNiche.x, wallNiche.y, wallNiche.z), d: wallNiche.d, name: 'cached' }
    }
    if (!best) {
      for (let t = 0; t < 20 && !best; t++) {
        if (!b.entity || b.health <= 0) return false
        const feet0 = b.entity.position.floored()
        // pass 1: SOFT only (sand/dirt/gravel/mud ~2.5s underwater); pass 2: anything diggable
        for (const maxHard of [0.9, 1.6]) {
          for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1], [2, 0], [-2, 0], [0, 2], [0, -2]]) {
            for (const dy of [0, 1]) {
              const v = feet0.offset(d[0], dy, d[1])
              const blk = b.blockAt(v)
              if (!blk || blk.boundingBox !== 'block' || !GR.test(blk.name)) continue
              const hard = blk.hardness === undefined ? 1 : blk.hardness
              if (hard < 0 || hard > maxHard) continue
              const head = b.blockAt(v.offset(0, 1, 0))
              if (head && head.boundingBox === 'block' && (head.hardness === undefined ? 1 : head.hardness) > maxHard) continue
              const score = hard * 3 + Math.hypot(d[0], d[1])
              if (!best || score < best.score) best = { v, d, score, name: blk.name }
            }
          }
          if (best) break
        }
        if (!best) await sleep(400)
      }
    }
    if (!best) { log('WALL_BURY no wall near', pos(b)); return false }
    wallNiche = { x: best.v.x, y: best.v.y, z: best.v.z, d: best.d, t: Date.now() }
    log('WALL_BURY into ' + best.name + ' ' + best.v.x + ' ' + best.v.y + ' ' + best.v.z + ' from', pos(b), 'hp=' + Math.round(b.health))
    // PHASE 1 - get under cover FAST (2 sand cells ~5s): low + head, then move in
    if (!(await withTimeout(digRaw(b, best.v), 12000, false))) { log('WALL_BURY dig failed'); return false }
    if (!b.entity || b.health <= 0) return true
    await withTimeout(digRaw(b, best.v.offset(0, 1, 0)), 7000, false)
    if (!b.entity || b.health <= 0) return true
    try { await b.look(Math.atan2(-best.d[0], best.d[1]), -0.1, true) } catch (e) {}
    b.setControlState('forward', true); b.setControlState('jump', true)
    await sleep(900)
    b.setControlState('forward', false); b.setControlState('jump', false)
    if (!b.entity || b.health <= 0) return true
    // PHASE 2 - from inside: deepen (drops land INSIDE the niche = seal material), collect, seal
    const deep = best.v.offset(best.d[0], 0, best.d[1])
    await withTimeout(digRaw(b, deep), 8000, false)
    await withTimeout(digRaw(b, deep.offset(0, 1, 0)), 6000, false)
    try { await b.look(Math.atan2(-best.d[0], best.d[1]), -0.1, true) } catch (e) {}
    b.setControlState('forward', true)
    await sleep(700)
    b.setControlState('forward', false)
    await sleep(400)
    try { await collectNear(b, 3) } catch (e) {}
    if (!b.entity || b.health <= 0) return true
    const feet2 = b.entity.position.floored()
    const inCell = feet2.distanceTo(deep) === 0 || feet2.distanceTo(best.v) === 0
    let sealed = false
    const ent = best.v                                        // first cell = entrance from the trench
    const entBlk = b.blockAt(ent)
    if (inCell && countPlaceable(b) >= 1 && entBlk && entBlk.boundingBox !== 'block') {
      for (const dd of [[0, -1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, 1, 0]]) {
        const ref = b.blockAt(ent.offset(dd[0], dd[1], dd[2]))
        if (!ref || ref.boundingBox !== 'block') continue
        const r = await withTimeout(b.placeBlock(ref, new Vec3(-dd[0], -dd[1], -dd[2])), 4000, 'to')
        if (r !== 'to') { sealed = true; break }
      }
    }
    log('WALL_BURY in=' + inCell + ' sealed=' + sealed + ' placeable=' + countPlaceable(b) + ' at', pos(b), 'hp=' + Math.round(b.health))
    if (!inCell && !sealed) return false
    const t0 = Date.now()
    const lim = Math.min(30000, Math.max(20000, waitMs || 60000))
    while (Date.now() - t0 < lim && b.entity && b.health > 0) {
      // dawn: skeletons burn, leave even if night budget remains
      if (Date.now() - t0 > 15000 && !isNight(b) && !isDusk(b)) break
      // a pocket that fills with water, or low health, ends the wait immediately
      if (b.__buryAbort || botWet(b) || b.health < 12) { log('WALL_BURY abort wet/lowhp hp=' + Math.round(b.health) + ' at ' + pos(b)); break }
      await sleep(800)
    }
    if (!b.entity || b.health <= 0) return true
    await digUpAndOut(b, 10)
    wallNiche = null
    manualLockUntil = Math.min(manualLockUntil, Date.now() + 1500)
    jumpLockUntil = Math.min(jumpLockUntil, Date.now() + 1500)
    return true
  } catch (e) { log('WALL_BURY_ERR', e && e.message); return false }
  finally { b.__wallBury = false }
}
// SAND HOURGLASS around world spawn (the drained cove trench + bowl we dug):
// ANY dig triggers sand collapse that swallows the bot (hp 20->6 suffocating, floor
// y56->51, then rising fill). No digging, no pillaring inside - the stable ground
// starts at x >= -612 (walked fine at y61-63): just travel east.
const COLLAPSE_ZONE = { x1: -636, x2: -610, z1: -668, z2: -640 }
function inCollapseZone (b) {
  try { const p = b.entity.position; return p.x >= COLLAPSE_ZONE.x1 && p.x <= COLLAPSE_ZONE.x2 && p.z >= COLLAPSE_ZONE.z1 && p.z <= COLLAPSE_ZONE.z2 } catch (e) { return false }
}
// deep underground near the crater (tunnel/pocket/shaft): water reflexes, unstick and
// forced heal-reconnects are all pointless-to-harmful here (the pocket is flooded; a wet
// jump "no-rise" there once triggered a heal -> reconnect -> pillar -> heal LOOP)
function deepNearCrater (b) {
  try { const p = b.entity.position; return p.y < 50 && rimAbove(b) >= 10 && Math.abs(p.x + 612) < 40 && Math.abs(p.z + 654) < 40 } catch (e) { return false }
}
// only cells with OPEN SKY above are safe to dig in the hourglass: a buried cell
// releases the whole column above it (that cascade entombed us at y52, hp 20->6).
// Surface cells of the talus piles yield sand with only a local 1-2 cell slide.
function diggableSurface (b, v) {
  const blk = b.blockAt(v)
  if (!blk || blk.boundingBox !== 'block') return false
  if (!GROUND_RE.test(blk.name)) return false
  if ((blk.hardness === undefined ? 1 : blk.hardness) < 0) return false
  const up = b.blockAt(v.offset(0, 1, 0))
  return !(up && up.boundingBox === 'block')
}
async function harvestSurface (b, need) {
  const feet = b.entity.position.floored()
  for (let r = 1; r <= 4 && countPlaceable(b) < need; r++) {
    for (const d of [[r, 0], [-r, 0], [0, r], [0, -r], [r, r], [r, -r], [-r, r], [-r, -r]]) {
      for (let dy = -1; dy <= 6 && countPlaceable(b) < need; dy++) {
        const v = feet.offset(d[0], dy, d[1])
        if (!diggableSurface(b, v)) continue
        if (b.entity.position.distanceTo(new Vec3(v.x + 0.5, v.y + 0.5, v.z + 0.5)) > 4.6) continue
        await withTimeout(digBlock(b, v), 9000, false)
      }
    }
  }
  return countPlaceable(b)
}
let zoneRunning = false
async function zoneRunEast (b) {
  if (!b.entity || zoneRunning) return
  zoneRunning = true
  try {
    log('ZONE_RUN east from', pos(b), 'hp=' + Math.round(b.health))
    jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 34000)
    const z0 = Math.round(b.entity.position.z) + 0.5
    walkTo(b, -604.5, 63, z0, 25000)
    const t0 = Date.now()
    while (Date.now() - t0 < 25000 && b.entity && b.health > 0 && b.entity.position.x < -612) await sleep(500)
    if (!b.entity || b.health <= 0) return
    if (b.entity.position.x >= -612) { log('ZONE_RUN out at', pos(b)); return }
    // drive stalled in the fill: raw sprint east, hop the soft slopes
    stopDrive(b)
    manualLockUntil = Math.max(manualLockUntil, Date.now() + 9000)
    try { b.pathfinder.setGoal(null) } catch (e) {}
    try { await b.look(-Math.PI / 2, -0.15, true) } catch (e) {}
    b.setControlState('forward', true); b.setControlState('sprint', true); b.setControlState('jump', true)
    const t1 = Date.now()
    while (Date.now() - t1 < 7000 && b.entity && b.health > 0 && b.entity.position.x < -611) await sleep(250)
    try { b.clearControlStates() } catch (e) {}
    log('ZONE_RUN raw end at', pos(b))
  } catch (e) { log('ZONE_RUN_ERR', e && e.message) }
  finally { zoneRunning = false }
}
// IN THE CRATER: digging AND placing both trigger collapses (floor y52->44 over an hour
// of escape attempts). Standing still is stable. Hold position, try server teleport
// commands, ask passing players to drop blocks; pillar out only when material arrives
// (a placed tower on settled floor is the one safe build - one-off updates only).
async function craterHold (b) {
  if (!b.entity || tunneling) return
  const rim = rimAbove(b)
  const inCrater = inCollapseZone(b)
  if (inCrater && rim >= 3 && countPlaceable(b) >= rim + 3) {
    log('CRATER material=' + countPlaceable(b) + ' rim=' + rim + ' -> climbing out at', pos(b))
    jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 45000)
    manualLockUntil = Math.max(manualLockUntil, Date.now() + 45000)
    await pillarClimb(b, rim + 2)
    if (b.entity && rimAbove(b) < 3) {
      log('CRATER OUT at', pos(b))
      wallNiche = null
      try { b.pathfinder.setGoal(new goals.GoalXZ(-598, Math.round(b.entity.position.z))) } catch (e) {}
    }
    return
  }
  const nowC = Date.now()
  // no /spawn-style command spam and no pre-written pleas: if we are genuinely stuck it
  // lands in the log and Puff decides himself whether and how to ask for help.
  if (nowC - (b.__craterNotifiedAt || 0) > 120000) {
    b.__craterNotifiedAt = nowC
    log('CRATER_STUCK at ' + pos(b) + ' rim=' + rim + ' placeable=' + countPlaceable(b))
  }
  // no teleport commands and no helper in sight? dig our way out through the bedrock
  try {
    const mate2 = nearestPlayerEntity(b, 48)
    const playerNear = mate2 && mate2.name && String(mate2.name) !== USERNAME
    const resumable = !inCrater && rim >= 5            // mid-tunnel east of the zone: always continue
    if (rim >= 5 && (resumable || countPlaceable(b) < rim + 3) && (!inCrater || !playerNear) && nowC - (b.__tunnelTriedAt || 0) > (resumable ? 90000 : 600000)) {
      b.__tunnelTriedAt = nowC
      await tunnelEast(b)
    }
  } catch (e) { log('CRATER tunnel err', e && e.message) }
}

// ===== TUNNEL_EAST (deploy 50): dig OUT of the sand crater =====
// The crater floor is STONE (y40-42): below the sand bowl lies stable bedrock that
// does not collapse. East wall at floor level = stone to x=-611, gravel pockets at
// y44+, a DIRT pocket at (-609, y35-37). Plan: mine a safe tunnel east at y~40-42
// (never touch sand/gravel - they flow), drop into the dirt pocket for pillar
// material, tunnel on east past the gravel to x=-602, then climb a 1-wide shaft
// through stable ground to the surface (rim ~y61). Hand-mining stone drops nothing,
// hence the dirt pocket detour.
const SAFE_TUNNEL = new Set(['stone', 'deepslate', 'dirt', 'grass_block', 'cobblestone', 'mossy_cobblestone', 'andesite', 'granite', 'diorite', 'tuff', 'calcite', 'sandstone', 'smooth_sandstone', 'red_sandstone', 'clay', 'mud', 'packed_mud', 'mud_bricks', 'stone_bricks', 'deepslate_bricks', 'cobbled_deepslate', 'iron_ore', 'coal_ore', 'copper_ore', 'gold_ore', 'lapis_ore', 'deepslate_iron_ore', 'deepslate_coal_ore', 'deepslate_copper_ore', 'deepslate_gold_ore', 'deepslate_lapis_ore', 'coarse_dirt', 'rooted_dirt', 'podzol', 'dirt_path', 'terracotta', 'white_terracotta', 'orange_terracotta', 'brown_terracotta'])
const FLOWY = new Set(['sand', 'red_sand', 'gravel', 'suspicious_sand', 'suspicious_gravel'])
let tunneling = false
function cellSafeTunnel (b, v) {
  const blk = b.blockAt(v)
  if (!blk) return false                       // unloaded chunk: treat as unsafe
  if (/lava/.test(blk.name)) return false
  if (blk.boundingBox !== 'block') return true // air / water: passable
  return SAFE_TUNNEL.has(blk.name)
}
function cellFlowy (b, v) { const blk = b.blockAt(v); return !!(blk && FLOWY.has(blk.name)) }
function rowSafeLen (b, x0, x1, y, z) {
  let n = 0; let holes = 0
  for (let x = x0; x <= x1; x++) {
    if (!cellSafeTunnel(b, new Vec3(x, y, z)) || !cellSafeTunnel(b, new Vec3(x, y + 1, z))) break
    const headBlk = b.blockAt(new Vec3(x, y + 1, z))
    const headSolid = !!(headBlk && headBlk.boundingBox === 'block')
    // flowy block over the head cell would bury us WHEN WE MINE that cell; if the head
    // cell is already open, the flowy block above has been resting fine - leave it be
    if (headSolid && cellFlowy(b, new Vec3(x, y + 2, z))) break
    // a row needs a walkable floor, but small dips are fine (stepTo hop-jumps over them);
    // the old-tunnel CEILING row y+1 has a hole every column - rejected by the hole cap
    if (!solidAt(b, new Vec3(x, y - 1, z))) { holes++; if (holes > 4) break }
    n++
  }
  return n
}
async function stepTo (b, dx, dz, ms) {
  if (!b.entity) return
  try { await b.lookAt(b.entity.position.offset(dx * 3, 0, dz * 3)) } catch (e) {}
  let wet = botWet(b)
  try { const fb = b.blockAt(b.entity.position.floored()); if (fb && fb.name === 'water') wet = true } catch (e) {}
  // wading/swimming is ~3x slower and currents push us back: sprint + pulse-jump = swim stroke
  b.setControlState('forward', true)
  if (wet) b.setControlState('sprint', true)
  const t0 = Date.now(); const p0 = b.entity.position.clone()
  const lim = ms || (wet ? 3600 : 1200)
  let lastJump = 0
  while (b.entity && Date.now() - t0 < lim && b.entity.position.distanceTo(p0) < (wet ? 0.6 : 0.75)) {
    // jump ONLY when actually stuck: pulse-jumping in shallow water throws us into the air
    // (no control there) and the current walks us back - bottom-walking wins
    const blocked = Date.now() - t0 > 500 && b.entity.position.distanceTo(p0) < 0.2
    if (blocked && Date.now() - lastJump > 650) {
      lastJump = Date.now()
      b.setControlState('jump', true)
      setTimeout(() => { try { b.setControlState('jump', false) } catch (e) {} }, 280)
    }
    await sleep(50)
  }
  b.setControlState('forward', false)
  try { b.setControlState('jump', false); b.setControlState('sprint', false) } catch (e) {}
  await sleep(120)
}
async function digDownTo (b, targetY) {
  let guard = 0
  while (b.entity && b.health > 0 && b.entity.position.floored().y > targetY && guard++ < 14) {
    const below = b.entity.position.floored().offset(0, -1, 0)
    const blk = b.blockAt(below)
    if (!blk) return false
    if (blk.boundingBox !== 'block') { await sleep(350); continue }   // open/water: sink or wait
    if (FLOWY.has(blk.name) || /lava/.test(blk.name)) { log('DIGDOWN unsafe ' + blk.name, pos(b)); return false }
    if (!await withTimeout(digBlock(b, below), 14000, false)) return false
    await sleep(420)
  }
  return !!(b.entity && b.entity.position.floored().y <= targetY)
}
async function minePocket (b, want) {
  const c0 = b.entity.position.floored()
  const cells = []
  for (let dx = -2; dx <= 2; dx++) for (let dy = -2; dy <= 3; dy++) for (let dz = -3; dz <= 3; dz++) cells.push(c0.offset(dx, dy, dz))
  cells.sort((a, c) => a.distanceTo(c0) - c.distanceTo(c0))
  for (const v of cells) {
    if (!b.entity || countPlaceable(b) >= want) break
    const blk = b.blockAt(v)
    if (!blk || blk.name !== 'dirt' || blk.boundingBox !== 'block') continue
    if (!b.entity || v.distanceTo(b.entity.position) > 4.2) continue
    await withTimeout(digBlock(b, v), 6000, false)
    await sleep(100)
  }
}
async function tunnelEastLeg (b, xEnd) {
  const p0 = b.entity.position.floored()
  const need = xEnd - p0.x + 1
  let rowY = null; let rowZ = null; let bestLen = -1
  outer:
  for (let y = p0.y; y >= p0.y - 3; y--) {
    for (const dz of [0, -1, 1, -2, 2]) {
      const len = rowSafeLen(b, p0.x, xEnd, y, p0.z + dz)
      if (len > bestLen) { bestLen = len; rowY = y; rowZ = p0.z + dz }
      if (len >= need) break outer
    }
  }
  if (rowY === null || bestLen < need) { log('TUNNEL no safe row: best=' + bestLen + '/' + need + ' at y=' + rowY + ' z=' + rowZ); return false }
  log('TUNNEL row y=' + rowY + ' z=' + rowZ + ' -> x=' + xEnd)
  if (!(await digDownTo(b, rowY))) return false
  let guard = 0
  while (b.entity && b.entity.position.floored().z !== rowZ && guard++ < 4) {
    const ft = b.entity.position.floored()
    const dzs = Math.sign(rowZ - ft.z)
    const a = new Vec3(ft.x, ft.y, ft.z + dzs); const c = new Vec3(ft.x, ft.y + 1, ft.z + dzs)
    if (!cellSafeTunnel(b, a) || !cellSafeTunnel(b, c)) { log('TUNNEL z-align blocked at', pos(b)); return false }
    if (b.blockAt(c) && b.blockAt(c).boundingBox === 'block') await digBlock(b, c)
    if (b.blockAt(a) && b.blockAt(a).boundingBox === 'block') await digBlock(b, a)
    await stepTo(b, 0, dzs, 1300)
  }
  if (!b.entity || b.entity.position.floored().z !== rowZ) return false
  // NOTE: face column = first solid column at/after the bot's LEADING EDGE (x+0.31), not
  // floor(x)+1: straddling the border (x=-602.08 -> floor -603) made the old logic re-dig
  // an already-open column forever while the real wall one cell east went untouched.
  while (b.entity && b.health > 0 && b.entity.position.x < xEnd) {
    const ft = b.entity.position.floored()
    if (ft.y > rowY) { if (!(await digDownTo(b, rowY))) return false; continue }
    if (ft.y < rowY - 1) {
      log('TUNNEL fell to y' + ft.y + ', climbing back to row y' + rowY, pos(b))
      for (let k = 0; k < 4 && b.entity && b.entity.position.floored().y < rowY; k++) { await pillarUp(b, 1); await sleep(250) }
      if (!b.entity || b.entity.position.floored().y < rowY) return false
      continue
    }
    let faceX = Math.floor(b.entity.position.x + 0.31)
    while (faceX <= xEnd + 1) {
      const f0 = b.blockAt(new Vec3(faceX, rowY, rowZ))
      const h0 = b.blockAt(new Vec3(faceX, rowY + 1, rowZ))
      if ((f0 && f0.boundingBox === 'block') || (h0 && h0.boundingBox === 'block')) break
      faceX++
    }
    if (faceX > xEnd + 1) {
      // corridor already open ahead: walk/swim to the end (currents make this slow)
      let walkTries = 0
      while (b.entity && b.health > 0 && b.entity.position.x < xEnd - 0.3 && walkTries++ < 60) {
        await stepTo(b, 1, 0)
        if (Date.now() - (b.__tunLogAt || 0) > 60000) { b.__tunLogAt = Date.now(); log('TUNNEL walk progress', pos(b)) }
      }
      break
    }
    let tries = 0
    let xBefore = b.entity.position.x
    while (b.entity && b.health > 0 && tries++ < 8) {
      const feetV = new Vec3(faceX, rowY, rowZ)
      const headV = new Vec3(faceX, rowY + 1, rowZ)
      const abvV = new Vec3(faceX, rowY + 2, rowZ)
      if (!cellSafeTunnel(b, feetV) || !cellSafeTunnel(b, headV) || cellFlowy(b, abvV)) {
        const hb = b.blockAt(headV); const fb = b.blockAt(feetV)
        log('TUNNEL face unsafe at ' + faceX + ' ' + rowY + ' ' + rowZ + ': feet=' + String(fb && fb.name) + ' head=' + String(hb && hb.name))
        return false
      }
      let dugOk = true
      for (const v of [headV, feetV]) {
        const blk = b.blockAt(v)
        if (!blk || blk.boundingBox !== 'block') continue
        await withTimeout(digBlock(b, v), 16000, false)
        const after = b.blockAt(v)
        if (after && after.boundingBox === 'block') {
          dugOk = false
          log('TUNNEL dig fail at ' + v.x + ' ' + v.y + ' ' + v.z + ' (' + after.name + ') try=' + tries)
          break
        }
      }
      if (!dugOk) { await sleep(500); continue }
      await stepTo(b, 1, 0)
      if (!b.entity) break
      if (b.entity.position.x - xBefore > 0.15) break   // made progress toward/past the face
      xBefore = b.entity.position.x
    }
    const fAfter = b.blockAt(new Vec3(faceX, rowY, rowZ))
    const hAfter = b.blockAt(new Vec3(faceX, rowY + 1, rowZ))
    if ((fAfter && fAfter.boundingBox === 'block') || (hAfter && hAfter.boundingBox === 'block')) {
      log('TUNNEL face wont clear at ' + faceX + ' (server-side protected?) at', pos(b))
      return false
    }
    if (b.entity && b.entity.position.x - xBefore <= 0.15 && b.entity.position.x < faceX - 0.69) { log('TUNNEL column stall at', pos(b), 'face=' + faceX); return false }
    if (Date.now() - (b.__tunLogAt || 0) > 60000) { b.__tunLogAt = Date.now(); log('TUNNEL progress', pos(b)) }
  }
  return !!(b.entity && b.entity.position.x >= xEnd - 0.4)
}
async function climbShaft (b, levels) {
  jumpLockUntil = Math.max(jumpLockUntil, Date.now() + levels * 3200 + 20000)
  manualLockUntil = Math.max(manualLockUntil, Date.now() + levels * 3200 + 20000)
  let noRise = 0
  for (let i = 0; i < levels && b.entity && b.health > 0; i++) {
    if (rimAbove(b) < 2) { log('SHAFT surfaced at', pos(b)); return }
    const ft = b.entity.position.floored()
    let ok = true
    for (const dy of [1, 2]) {
      const v = ft.offset(0, dy, 0)
      const cb = b.blockAt(v)
      if (!cb) { ok = false; break }
      if (cb.boundingBox === 'block') {
        // gravel lenses are diggable (fast, drop material, brief burial is survivable at hp20);
        // sand would flow en masse and suffocate - still a hard abort
        if (!SAFE_TUNNEL.has(cb.name) && cb.name !== 'gravel') { log('SHAFT unsafe above: ' + cb.name, pos(b)); ok = false; break }
        if (!await withTimeout(digBlock(b, v), 14000, false)) { ok = false; break }
        const settled = b.blockAt(v)
        if (settled && settled.boundingBox === 'block' && settled.name === 'gravel') await withTimeout(digBlock(b, v), 8000, false)
      }
    }
    if (!ok) return
    if (countPlaceable(b) < 1) { log('SHAFT no material at', pos(b)); return }
    const yBefore = b.entity.position.y
    await pillarUp(b, 1)
    await sleep(150)
    if (b.entity && b.entity.position.y - yBefore < 0.5) {
      noRise++
      log('SHAFT no rise n=' + noRise, pos(b))
      if (noRise >= 3) return
      await sleep(500)
      i--
      continue
    }
    noRise = 0
    if (Date.now() - (b.__shaftLogAt || 0) > 60000) { b.__shaftLogAt = Date.now(); log('SHAFT climb', pos(b), 'material=' + countPlaceable(b)) }
  }
}
async function pfGoto (b, x, y, z, ms) {
  const tEnd = Date.now() + (ms || 300000)
  const arrived = () => !!(b.entity && Math.abs(b.entity.position.x - x) < 1.4 && Math.abs(b.entity.position.z - z) < 1.4 && b.entity.position.y < y + 1.2 && b.entity.position.y > y - 8)
  let fails = 0
  while (b.entity && b.health > 0 && Date.now() < tEnd && !arrived()) {
    const t0 = Date.now()
    try { await withTimeout(b.pathfinder.goto(new goals.GoalBlock(x, y, z)), Math.min(45000, Math.max(5000, tEnd - Date.now())), 'to') } catch (e) {}
    if (!b.entity || arrived()) break
    const took = Date.now() - t0
    fails = took < 3000 ? fails + 1 : 0
    if (fails > 6) { log('PF_GOTO no-path giving up at', pos(b)); break }
    log('PF_GOTO partial at', pos(b))
    await sleep(took < 3000 ? 3000 : 400)
  }
  try { b.pathfinder.setGoal(null) } catch (e) {}
  return arrived()
}
async function tunnelEast (b) {
  if (NO_DIG) { log('TUNNEL skipped: digging disabled by owner'); return }
  if (tunneling || diggingUp || !b.entity) return
  const POCKET = { x: -609, y: 36, z: -654 }
  const EXIT_X = -601
  if (Math.hypot(b.entity.position.x - POCKET.x, b.entity.position.z - POCKET.z) > 40) { log('TUNNEL too far from pocket at', pos(b)); return }
  tunneling = true; diggingUp = true
  try { b.pathfinder.setGoal(null) } catch (e) {}
  stopDrive(b)
  const lockMs = () => { jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 900000); manualLockUntil = Math.max(manualLockUntil, Date.now() + 900000) }
  lockMs()
  try {
    log('TUNNEL start at', pos(b), 'rim=' + rimAbove(b) + ' material=' + countPlaceable(b))
    // AuthMe freezes movement until login completes (the early tunnel stalls were pre-login
    // freeze): wait for the auth confirm.
    let authWait = 0
    while (b.entity && !b.__authOk && authWait++ < 24) await sleep(5000)
    if (!b.entity) return
    if (!b.__authOk) { log('TUNNEL abort: no auth confirm at', pos(b)); return }
    await sleep(3000)
    if (!b.entity) return
    lockMs()
    // PHASE 1 - pillar material.
    // In the crater: harvest open-sky sand first (fast, no travel).
    if (countPlaceable(b) < 12 && inCollapseZone(b)) {
      await harvestSurface(b, 16)
      log('TUNNEL sand harvest material=' + countPlaceable(b), pos(b))
      lockMs()
    }
    // Otherwise (or not enough): the dirt pockets under the stable step (-606..-609, y34-38).
    if (countPlaceable(b) < 12) {
      if (!b.entity) return
      // line up on the pocket z-lane before any leg/digdown so we descend ONTO the pockets
      if (Math.abs(b.entity.position.z + 654) > 3) {
        await pfGoto(b, Math.round(b.entity.position.x), Math.round(b.entity.position.y), -654, 90000)
        if (!b.entity) return
      }
      if (b.entity.position.x < -609.5) {
        if (!(await tunnelEastLeg(b, -609))) { log('TUNNEL abort leg1 at', pos(b)); return }
      } else if (b.entity.position.x > -605.5) {
        if (!(await pfGoto(b, -609, 36, -654, 300000))) { log('TUNNEL abort: walk west at', pos(b)); return }
      }
      lockMs()
      if (!b.entity) return
      if (b.entity.position.floored().y > 36) {
        if (!(await digDownTo(b, 36))) { log('TUNNEL abort digdown at', pos(b)); return }
      }
      await minePocket(b, 16)
      log('TUNNEL pocket material=' + countPlaceable(b), pos(b))
      if (countPlaceable(b) < 6) { log('TUNNEL abort: pocket too poor'); return }
      lockMs()
    } else {
      log('TUNNEL material rich (' + countPlaceable(b) + ') at', pos(b))
    }
    if (!b.entity) return
    // surfacing at night = endermen/skeletons on the rim: wait it out underground
    let nightWait = 0
    while (b.entity && (isNight(b) || isDusk(b)) && nightWait++ < 60) {
      if (nightWait === 1) log('TUNNEL night - waiting underground before surfacing')
      // a player may have teleported us out mid-run (happened: MrCeldou /tp to -402 108)
      if (!deepNearCrater(b) && !inCollapseZone(b) && rimAbove(b) < 5) { log('TUNNEL relocated (teleport?), aborting at', pos(b)); wallNiche = null; return }
      await sleep(20000); lockMs()
    }
    if (!b.entity) return
    if (!deepNearCrater(b) && !inCollapseZone(b) && rimAbove(b) < 5) { log('TUNNEL relocated before climb at', pos(b)); wallNiche = null; return }
    // PHASE 2 - climb straight up from the pocket (x=-609, dx=9 from spawn: server accepts
    // digs here again; the flooded east corridor to -601 was unwalkable against the current).
    // Stone y36-49 eats ~14 placements, the dirt layer y50+ resupplies (2 drops per level).
    for (let attempt = 0; attempt < 3 && b.entity && b.health > 0; attempt++) {
      const need = Math.max(rimAbove(b) + 2, 64 - Math.round(b.entity.position.y))
      log('TUNNEL climb attempt=' + attempt + ' need=' + need + ' material=' + countPlaceable(b), pos(b))
      await climbShaft(b, need)
      lockMs()
      if (!b.entity || rimAbove(b) < 3) break
      if (attempt < 2) {
        log('TUNNEL climb blocked, shifting east at', pos(b))
        if (!(await tunnelEastLeg(b, Math.round(b.entity.position.x) + 2))) break
        lockMs()
      }
    }
    if (b.entity && rimAbove(b) < 3) { log('TUNNEL OUT at', pos(b)); wallNiche = null }
    else log('TUNNEL incomplete rim=' + rimAbove(b), pos(b))
  } catch (e) { log('TUNNEL_ERR', e && e.message) }
  finally { tunneling = false; diggingUp = false }
}
// Respawned at/near the mob nest: RUNNING through the den is a proven death spiral
// (10+ deaths a night). Dig 2 down, seal overhead, let the mobs lose interest (~30s
// without LOS), regen, then dig out. Zombies can't dig, skeletons need LOS.
async function buryAtSpawn (b) {
  if (!b.entity) return false
  // digging at spawn = digging into the hourglass: skip bury, let RESPAWN_RUN sprint east
  if (inCollapseZone(b)) { log('BURY skip: collapse zone at', pos(b)); return false }
  b.__burying = true
  try {
    manualLockUntil = Math.max(manualLockUntil, Date.now() + 90000)
    jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 90000)
    try { b.pathfinder.setGoal(null) } catch (e) {}
    try { b.clearControlStates() } catch (e) {}
    // bury owns movement from here on: reflex may have set __fleeing pre-respawn,
    // and escapeIsland breaks instantly on that flag - do our own forced swim
    b.__fleeing = false
    // chunks may not be loaded yet at respawn: blockAt() returns null everywhere,
    // dryCol/nearestDry find "no dry land" and we drown on a shore we can't see.
    // wait for the world before digging or swimming.
    for (let w = 0; w < 30; w++) {
      if (!b.entity || b.health <= 0) return false
      if (b.blockAt(b.entity.position.floored().offset(0, -1, 0))) break
      await sleep(200)
    }
    let feet = b.entity.position.floored()
    let below = b.blockAt(feet.offset(0, -1, 0))
    if (!below || below.boundingBox !== 'block' || b.entity.isInWater) {
      // spawn point sits in shallow water - can't dig liquid: swim ashore first
      let dry = null; try { dry = nearestDry(b, 24) } catch (e) {}
      log('BURY wet spawn -> swim ashore at', pos(b), dry ? ('dry=' + Math.round(dry.x) + ' ' + Math.round(dry.z)) : 'no dry near')
      // being shot at while swimming = death spiral: skip the swim, wall-burrow immediately
      let shotAt = false
      try { const wt = threatsNear(b, 1.0)[0]; shotAt = !!(wt && wt.d < 14) } catch (e) {}
      if (shotAt) { log('BURY under fire -> wallBury now'); if (await wallBury(b, 70000)) return true }
      if (dry && !shotAt) {
        const t0 = Date.now()
        try { b.setControlState('forward', true); b.setControlState('jump', true) } catch (e) {}
        while (Date.now() - t0 < 5000 && b.entity && b.health > 0) {
          if (b.__wallBury) break                          // wallBury took over: don't fight its controls
          try { await b.look(Math.atan2(-(dry.x + 0.5 - b.entity.position.x), dry.z + 0.5 - b.entity.position.z), -0.15, true) } catch (e) {}
          await sleep(300)
          const ft = b.entity.position.floored()
          const bl = b.blockAt(ft.offset(0, -1, 0))
          if (b.entity.onGround && bl && bl.boundingBox === 'block' && !b.entity.isInWater) break
        }
        try { b.setControlState('forward', false); b.setControlState('jump', false) } catch (e) {}
      }
      if (!b.entity || b.health <= 0) return false
      feet = b.entity.position.floored()
      below = b.blockAt(feet.offset(0, -1, 0))
      if (!below || below.boundingBox !== 'block' || b.entity.isInWater) {
        // trench killbox: wall-burrow FIRST (swimming ashore gets us shot to death),
        // pillar escape only if no soft wall is reachable
        if (b.__wallBury) { await sleep(2000); return true }
        if (await wallBury(b, 70000)) return true
        await escapeWaterPillar(b)                      // cove shore is often a 1b ledge we can't climb
        if (!b.entity || b.health <= 0) return false
        feet = b.entity.position.floored()
        below = b.blockAt(feet.offset(0, -1, 0))
        if (!below || below.boundingBox !== 'block' || b.entity.isInWater) { log('BURY still wet, sprint fallback'); return false }
      }
    }
    const ok1 = await withTimeout(digBlock(b, feet.offset(0, -1, 0)), 10000, false)
    if (!ok1 || !b.entity) {
      // trench floor is STONE (slow, dig times out) but the walls are SAND:
      // burrow sideways, seal, sleep out the night - sprinting above ground at night got us endermaned
      log('BURY dig failed -> wallBury')
      if (b.entity && b.health > 0 && await wallBury(b, 90000)) return true
      log('BURY wallBury failed, falling back to sprint')
      return false
    }
    await sleep(280)
    await withTimeout(digBlock(b, feet.offset(0, -2, 0)), 10000, false)
    await sleep(280)
    // seal the cell above our head (the original feet cell) against a side wall
    let sealed = false
    for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const wall = b.blockAt(new Vec3(feet.x + d[0], feet.y, feet.z + d[1]))
      if (wall && wall.boundingBox === 'block' && countPlaceable(b) >= 1) {
        const r = await withTimeout(b.placeBlock(wall, new Vec3(-d[0], 0, -d[1])), 4000, 'to')
        if (r !== 'to') { sealed = true; break }
      }
    }
    log('BURY sealed=' + sealed + ' at', pos(b), 'hp=' + Math.round(b.health))
    const t0 = Date.now()
    while (Date.now() - t0 < 70000 && b.entity && b.health > 0) await sleep(1000)
    if (!b.entity || b.health <= 0) return true            // died waiting: next respawn cycle takes over
    await digUpAndOut(b, 6)
    manualLockUntil = Math.min(manualLockUntil, Date.now() + 1500)
    jumpLockUntil = Math.min(jumpLockUntil, Date.now() + 1500)
    return true
  } catch (e) { log('BURY_ERR', e && e.message); return false }
  finally { b.__burying = false }
}
async function escapeIsland (b) {
  if (!b.entity) return
  log('ISLAND_ESCAPE at', pos(b))
  try { b.pathfinder.setGoal(null) } catch (e) {}
  jumpLockUntil = Math.max(jumpLockUntil, Date.now() + 9000)
  let dry = null
  try { dry = nearestDry(b, 20) } catch (e) {}
  if (!dry && b.__lastDry && Date.now() - b.__lastDry.t < 300000) dry = { x: b.__lastDry.x, y: b.__lastDry.y, z: b.__lastDry.z }
  let yaw
  if (dry) yaw = Math.atan2(-(dry.x + 0.5 - b.entity.position.x), dry.z + 0.5 - b.entity.position.z)
  else { const a = Math.random() * Math.PI * 2; yaw = Math.atan2(-Math.cos(a), Math.sin(a)) }
  log('ISLAND_ESCAPE heading ' + (dry ? ('to dry ' + dry.x + ' ' + dry.y + ' ' + dry.z) : 'random swim'))
  try { b.look(yaw, dry ? -0.15 : 0.1, true) } catch (e) {}
  try { b.setControlState('forward', true); b.setControlState('sprint', true); b.setControlState('jump', true) } catch (e) {}
  const t0 = Date.now()
  while (Date.now() - t0 < 8000 && b.entity && b.health > 0 && !b.__fleeing) {
    await sleep(300)
    if (dry && b.entity) {
      const d = Math.hypot(dry.x + 0.5 - b.entity.position.x, dry.z + 0.5 - b.entity.position.z)
      if (d < 1.3) break
    }
    // keep looking straight ahead while swimming; re-aim at dry land periodically
    if (dry && b.entity && (Date.now() - t0) % 1500 < 300) { try { b.look(Math.atan2(-(dry.x + 0.5 - b.entity.position.x), dry.z + 0.5 - b.entity.position.z), -0.15, true) } catch (e) {} }
  }
  try { b.setControlState('forward', false); b.setControlState('sprint', false); b.setControlState('jump', false) } catch (e) {}
}
function enclosedHere (b) {
  if (!b.entity) return false
  const feet = b.entity.position.floored()
  return solidAt(b, feet.offset(1, 0, 0)) && solidAt(b, feet.offset(-1, 0, 0)) &&
         solidAt(b, feet.offset(0, 0, 1)) && solidAt(b, feet.offset(0, 0, -1))
}
// Travel WITHOUT wrecking the terrain: greedy stepping-stones -> XZ-only retry -> side
// bypasses. Digging happens only when physically enclosed (and is capped).
async function travelTo (b, target, tries) {
  tries = tries || 40
  // cliff-top target (plateau wall): the gentle side is elsewhere - fail fast and let
  // the blacklist/explore drift relocate us instead of burning the full budget here
  let dy0 = 0; try { dy0 = target.y - b.entity.position.y } catch (e) {}
  const tEnd = Date.now() + (dy0 > 10 ? 50000 : 90000)
  let failStreak = 0
  let zeroStreak = 0
  let digs = 0
  let fleeWaits = 0
  let climbed = false
  for (let i = 0; i < tries && mission && b.entity && b.health > 0 && Date.now() < tEnd; i++) {
    if (b.__fleeing || hiding) {                       // under attack: survival first, don't fight the flee goal
      if (++fleeWaits > 75) { log('TRAVEL abort: under attack at', pos(b)); return false }
      await sleep(400)
      i--
      continue
    }
    fleeWaits = 0
    const p = b.entity.position
    if (p.distanceTo(target) < 4) return true
    const dx = target.x - p.x; const dz = target.z - p.z
    const flat = Math.hypot(dx, dz) || 1
    let goal
    if (flat <= 14) goal = new goals.GoalNear(target.x, target.y, target.z, 2)
    else { const s = Math.min(12, flat * 0.6); goal = new goals.GoalXZ(Math.round(p.x + dx / flat * s), Math.round(p.z + dz / flat * s)) }
    const r = await gotoT(b, goal, 16000)
    if (!b.entity) break
    if (b.entity.position.distanceTo(target) < 4.5) return true
    const moved = p.distanceTo(b.entity.position)
    if (moved > 1.5) { failStreak = 0; zeroStreak = 0; continue }
    failStreak++
    if (moved < 0.5) zeroStreak++; else zeroStreak = 0
    log('TRAVEL ' + r + ' moved=' + moved.toFixed(1) + ' failStreak=' + failStreak + ' at', pos(b))
    if (zeroStreak >= 3) { zeroStreak = 0; failStreak = 0; await escapeIsland(b); continue }
    if (enclosedHere(b) || rimAbove(b) >= 3) {
      if (digs++ >= 3) { log('TRAVEL give up: walled in at', pos(b)); return false }
      log('TRAVEL enclosed -> dig out at', pos(b))
      await withTimeout(digUpAndOut(b, 6), 40000, null)
      failStreak = 0
      continue
    }
    if (failStreak === 1) {
      // maybe only the target's Y is unreachable - walk to its column and look around
      const r2 = await gotoT(b, new goals.GoalXZ(Math.round(target.x), Math.round(target.z)), 12000)
      if (b.entity && b.entity.position.distanceTo(target) < 6) return true
      if (r2 === 'reached' && failStreak === 1) failStreak = 2
      continue
    }
    // target sits up a slope/cliff and pathing keeps failing: do what a player does -
    // dig scaffold material and pillar up toward it (once per travelTo, budget-capped)
    if (failStreak >= 2 && !climbed && target.y - p.y >= 3 && target.y - p.y <= 14) {
      climbed = true
      const need = Math.min(12, Math.ceil(target.y - p.y) + 2)
      log('TRAVEL climb: target ' + Math.round(target.y - p.y) + 'b above at', pos(b))
      await ensurePlaceable(b, need)
      if (countPlaceable(b) < 1) { log('TRAVEL climb: no material at', pos(b)); failStreak = 0; zeroStreak = 0; continue }
      try { await b.look(Math.atan2(-(target.x - p.x), target.z - p.z), 0, true) } catch (e) {}
      const y0 = b.entity ? b.entity.position.y : 0
      for (let k = 0; k < need && mission && b.entity && b.health > 0 && !b.__fleeing && b.entity.position.y < target.y - 1.5; k++) {
        await pillarUp(b, 1)
        await sleep(250)
      }
      log('TRAVEL climb done: +' + (b.entity ? (b.entity.position.y - y0).toFixed(1) : '?') + 'b at', pos(b))
      failStreak = 0; zeroStreak = 0
      continue
    }
    // bypass: waypoint 10 blocks to the side of the direct line, alternate sides
    const side = (failStreak % 2 === 0) ? 1 : -1
    const px = -dz / flat; const pz = dx / flat
    const wx = Math.round(p.x + dx / flat * 3 + px * 10 * side)
    const wz = Math.round(p.z + dz / flat * 3 + pz * 10 * side)
    log('TRAVEL blocked -> bypass ' + (side > 0 ? 'right' : 'left') + ' via ' + wx + ' ' + wz + ' at', pos(b))
    await gotoT(b, new goals.GoalXZ(wx, wz), 12000)
    if (failStreak >= 4) failStreak = 2   // keep alternating bypasses, never escalate to digging
  }
  return b.entity ? b.entity.position.distanceTo(target) < 6 : false
}
async function wander (b, far) {
  let angle
  if (far) { if (b.__heading === undefined || Math.random() < 0.12) b.__heading = Math.random() * Math.PI * 2; angle = b.__heading } else { angle = Math.random() * Math.PI * 2 }
  for (let attempt = 0; attempt < 3; attempt++) {
    let fw = 0
    while ((b.__fleeing || hiding) && fw++ < 75 && b.entity && b.health > 0) await sleep(400)
    if (!b.entity || b.health <= 0) return false
    const dist = far ? (30 + Math.random() * 16) : (12 + Math.random() * 8)
    let gx = 0; let gz = 0; let ok = false
    for (let t = 0; t < 8; t++) {
      gx = Math.round(b.entity.position.x + Math.cos(angle) * dist)
      gz = Math.round(b.entity.position.z + Math.sin(angle) * dist)
      if (!isWaterAt(b, gx, gz)) { ok = true; break }
      angle += Math.PI / 3
    }
    if (!ok) { angle += 2.1; continue }
    // NOTE: no manualLockUntil here - it used to suppress the flee/defend reflexes
    // for the whole wander, and the bot ate arrows face-first while "exploring".
    try { b.pathfinder.setGoal(null) } catch (e) {}
    const before = b.entity ? b.entity.position.clone() : null
    const r = await gotoT(b, new goals.GoalXZ(gx, gz), far ? 22000 : 15000)
    const moved = (before && b.entity) ? before.distanceTo(b.entity.position) : 99
    if (moved > 2.5) { if (far) b.__heading = angle; return true }
    log('WANDER ' + r + ' moved=' + moved.toFixed(1) + ' -> turn, at', pos(b))
    angle += 2.1                       // walked into something: pick a new direction
    if (far) b.__heading = angle
  }
  await escapeIsland(b)                // every direction failed: swim out of wherever we are
  return false
}
async function missionWood (b) {
  if (NO_DIG) return
  log('MISSION wood START at', pos(b))
  try {
    await autoFree(b)
    let target = null
    let guard = 0
    let unreachable = 0
    const skipped = new Set()
    while (mission && guard++ < 24) {
      target = findNearestLog(b, 64, skipped)
      if (!target) target = findNearestLog(b, 64, skipped, true)
      if (target) {
        const key = target.x + ',' + target.y + ',' + target.z
        log('WOOD logs at', target.x, target.y, target.z, 'dist', Math.round(b.entity.position.distanceTo(target)))
        const reached = await travelTo(b, target)
        log('WOOD reached', reached, 'at', pos(b))
        if (reached) break
        // could not walk there: blacklist this trunk and look for another one instead of digging
        skipped.add(key); unreachable++
        log('WOOD trunk unreachable (' + unreachable + ' skipped), looking for another')
        if (unreachable >= 4) { log('WOOD no reachable trunk around'); missionFail('wood'); mission = null; return }
        target = null
        continue
      }
      const far = guard > 4
      if (!far && worstZone(b, 60)) {
        // standing in the nest corridor: relocate before scanning for trunks again
        const ep = escapePointFrom(b, worstZone(b, 60), 70)
        if (ep) { log('WOOD leaving death zone via ' + ep.x + ' ' + ep.z, 'at', pos(b)); await travelTo(b, new Vec3(ep.x, b.entity.position.y, ep.z), 10); continue }
      }
      log('WOOD exploring' + (far ? ' far' : '') + ' at', pos(b))
      const before = b.entity.position.clone()
      const moved = await wander(b, far)
      if (!moved && enclosedHere(b)) { log('WOOD enclosed -> escape'); await escapeStuck(b) }
      try { await autoFree(b) } catch (e) {}
    }
    if (!target) { log('WOOD no logs found after exploring'); missionFail('wood'); mission = null; return }
    const blk = b.blockAt(target)
    const logType = (blk && blk.name) || 'oak_log'
    // we stand within 4b of the base log now: break it DIRECTLY first - gatherBlocks'
    // findBlocks reported "none nearby" while literally on the trunk (lost the whole trip)
    if (blk && LOG_TYPES.indexOf(blk.name) >= 0) { await digBlock(b, target); await sleep(400) }
    await gatherBlocks(b, [logType], logType, 8)
    log('WOOD logs gathered', countItem(b, logType), logType)
    const plankType = logType.endsWith('_stem') ? logType.replace('_stem', '_planks') : logType.replace('_log', '_planks')
    // craft(recipe, N) runs the recipe N TIMES (planks: 1 log -> 4 per run), so
    // N must be grounded in what we actually hold, else 'missing ingredient'
    const nl = countItem(b, logType)
    if (nl > 0) await craftItem(b, plankType, nl)
    let pl = countAny(b, PLANKS_ANY)
    // only if we literally do not carry a table: crafting a second one burns 4 wall planks
    if (pl >= 4 && countItem(b, 'crafting_table') < 1) await craftItem(b, 'crafting_table', 1)
    pl = countAny(b, PLANKS_ANY)
    // sticks are only needed for tool recipes (2 per tool). Keeping a small budget and never
    // below the 20 planks the hut needs - this was eating the house.
    if (pl >= 8 && countItem(b, 'stick') < 4) await craftItem(b, 'stick', 2)
    const o = b.entity.position.floored()
    let placed = false
    for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1]]) {
      if (await placeBlockAt(b, o.x + d[0], o.y, o.z + d[1], 'crafting_table')) { placed = true; break }
    }
    // placeBlockAt returns true when the cell was ALREADY solid - verify the table really exists
    try {
      const ct = mcData.blocksByName.crafting_table
      if (ct) placed = !!b.findBlock({ matching: ct.id, maxDistance: 6 })
    } catch (e) {}
    log('WOOD table placed', placed)
    if (placed) {
      await craftItem(b, 'wooden_pickaxe', 1)
      await craftItem(b, 'wooden_axe', 1)
      await craftItem(b, 'wooden_sword', 1)
    }
    log('WOOD DONE pickaxe', countItem(b, 'wooden_pickaxe'), 'axe', countItem(b, 'wooden_axe'), 'sword', countItem(b, 'wooden_sword'), 'at', pos(b))
  } catch (e) { log('WOOD_ERR', e && e.message ? e.message : String(e)) }
  mission = null
}

const PASSIVE = new Set(['cow', 'pig', 'sheep', 'chicken', 'rabbit', 'mooshroom', 'goat'])
const PICKS = ['netherite_pickaxe', 'diamond_pickaxe', 'iron_pickaxe', 'stone_pickaxe', 'golden_pickaxe', 'wooden_pickaxe']
const PLANKS_ANY = ['pale_oak_planks', 'oak_planks', 'birch_planks', 'spruce_planks', 'jungle_planks', 'acacia_planks', 'dark_oak_planks', 'mangrove_planks', 'cherry_planks']
function countAny (b, names) { let n = 0; for (const nm of names) n += countItem(b, nm); return n }
function hasPickaxe (b) { return countAny(b, PICKS) > 0 }
function hasStonePick (b) { return countAny(b, ['stone_pickaxe', 'iron_pickaxe', 'diamond_pickaxe', 'netherite_pickaxe']) > 0 }
function countFood (b) { return countAny(b, FOODS) }
// NOTE: b.time.day is the DAY COUNTER (0,1,2,...851), b.time.age is total ticks.
// Using .day here made isNight() always false (851 % 24000 = 851 = "morning") -
// the bot never knew it was night and ran wood missions straight into the dark.
function timeOfDay (b) { try { const a = Math.floor(b.time.age); return ((a % 24000) + 24000) % 24000 } catch (e) { return 6000 } }
function isNight (b) { const t = timeOfDay(b); return t >= 13000 && t < 23500 }
function isDusk (b) { const t = timeOfDay(b); return t >= 11500 && t < 13000 }
function nearestPassive (b, r) {
  let best = null; let bd = r
  for (const id in b.entities) {
    const e = b.entities[id]
    if (!e || !e.position || !e.name || e === b.entity) continue
    if (!PASSIVE.has(String(e.name).toLowerCase())) continue
    if (e.health !== undefined && e.health <= 0) continue
    const d = e.position.distanceTo(b.entity.position)
    if (d < bd) { bd = d; best = e }
  }
  return best
}
function findNearestBlock (b, names, r) {
  const ids = names.map(n => mcData.blocksByName[n]).filter(Boolean).map(x => x.id)
  if (!ids.length) return null
  let positions = []
  try { positions = b.findBlocks({ matching: ids, maxDistance: r, count: 24 }) } catch (e) {}
  if (!positions || !positions.length) return null
  const feet = b.entity.position
  positions.sort((p, q) => feet.distanceTo(p) - feet.distanceTo(q))
  return positions[0]
}
async function missionStone (b) {
  log('MISSION stone START at', pos(b))
  try {
    await autoFree(b)
    if (!hasPickaxe(b)) { log('STONE need pickaxe first'); mission = null; return }
    if (countItem(b, 'stick') < 2 && countAny(b, PLANKS_ANY) >= 10) await craftItem(b, 'stick', 4)
    let target = null; let guard = 0
    while (mission && guard++ < 20) {
      target = findNearestBlock(b, ['stone', 'cobblestone', 'deepslate', 'cobbled_deepslate', 'andesite', 'diorite', 'granite'], 48)
      if (target) break
      const far = guard > 4
      log('STONE exploring' + (far ? ' far' : '') + ' at', pos(b))
      const moved = await wander(b, far)
      if (!moved && enclosedHere(b)) await escapeStuck(b)
      try { await autoFree(b) } catch (e) {}
    }
    if (!target) { log('STONE no stone found'); mission = null; return }
    await travelTo(b, target)
    await gatherBlocks(b, ['stone', 'cobblestone', 'deepslate', 'cobbled_deepslate', 'andesite', 'diorite', 'granite'], 'cobblestone', 12)
    const cob = countItem(b, 'cobblestone')
    if (cob >= 2) {
      if (countItem(b, 'stick') < 2) { const pl = PLANKS_ANY.find(n => countItem(b, n) > 1); if (pl) await craftItem(b, 'stick', 4) }
      await ensureCraftingTable(b)
      await craftItem(b, 'stone_pickaxe', 1)
      await craftItem(b, 'stone_sword', 1)
      await craftItem(b, 'stone_axe', 1)
    }
    log('MISSION stone DONE cob', cob, 'pick', countItem(b, 'stone_pickaxe'), 'at', pos(b))
    if (countItem(b, 'stone_pickaxe') === 0) { missionFail('stone'); log('STONE pick missing - backoff 45s') }
  } catch (e) { log('STONE_ERR', e && e.message ? e.message : String(e)) }
  mission = null
}
async function missionFood (b) {
  log('MISSION food START at', pos(b))
  try {
    await autoFree(b)
    const bush = findNearestBlock(b, ['sweet_berry_bush'], 40)
    if (bush && mission) { const rb = await travelTo(b, bush); if (rb) await gatherBlocks(b, ['sweet_berry_bush'], 'sweet_berries', 8) }
    if (countFood(b) >= 6) { log('MISSION food DONE berries', countFood(b)); mission = null; return }
    let guard = 0
    while (mission && guard++ < 20) {
      const a = nearestPassive(b, 40)
      if (!a) { const moved = await wander(b, guard > 3); if (!moved && enclosedHere(b)) await escapeStuck(b); continue }
      await travelTo(b, a.position)
      let tries = 0
      while (mission && tries++ < 30 && a.position && a.isValid !== false) {
        if (a.health !== undefined && a.health <= 0) break
        try { b.lookAt(a.position.offset(0, 0.6, 0)) } catch (e) {}
        try { b.attack(a) } catch (e) {}
        if (a.position.distanceTo(b.entity.position) > 2.6) { try { b.pathfinder.setGoal(new goals.GoalNear(a.position.x, a.position.y, a.position.z, 2)) } catch (e) {} }
        await sleep(340)
      }
      try { b.pathfinder.setGoal(null) } catch (e) {}
      await sleep(1200)
      if (countFood(b) >= 6) break
    }
    log('MISSION food DONE', countFood(b))
  } catch (e) { log('FOOD_ERR', e && e.message ? e.message : String(e)) }
  mission = null
}
async function missionExplore (b) {
  log('MISSION explore START at', pos(b))
  try {
    await autoFree(b)
    // standing in a death zone (nest corridor / recent deaths)? leave it FIRST -
    // aimless wandering inside the zone is how we racked up 15+ deaths a night
    const zc = worstZone(b, 70)
    if (zc && mission && b.entity) {
      const ep = escapePointFrom(b, zc, 75)
      if (ep) {
        log('EXPLORE leaving death zone via ' + ep.x + ' ' + ep.z, 'at', pos(b))
        await travelTo(b, new Vec3(ep.x, b.entity.position.y, ep.z), 10)
      }
    }
    for (let i = 0; i < 3 && mission; i++) { await wander(b); try { await autoFree(b) } catch (e) {} }
  } catch (e) {}
  log('MISSION explore END')
  mission = null
}
let directorOn = true
if (process.env.MC_DIRECTOR === 'off') directorOn = false
async function directorTick (b) {
  try {
    if (!directorOn) return
    if (!b.entity || b.health <= 0) return
    // survival override: critically low hp with nothing to eat -> drop whatever we are doing
    // and go hunting. Being stuck on a "stone" run at 4 hp is how the bot died 202 times.
    if (mission && b.health < 7 && countFood(b) === 0 && mission.name !== 'food' && !isNight(b) && !isDusk(b)) {
      log('DIRECTOR abort ' + mission.name + ' - hp=' + Math.round(b.health) + ' and nothing to eat')
      try { missionFail(mission.name) } catch (e) {}
      mission = null
      try { b.pathfinder.setGoal(null) } catch (e) {}
    }
    if (mission) { if (Date.now() - (b.__dirLog||0) > 10000) { log("DIR_BLOCK mission=" + mission.name); b.__dirLog = Date.now() } return }
    if (b.__fleeing || hiding) { if (Date.now() - (b.__dirLog||0) > 10000) { log("DIR_BLOCK fleeing=" + !!b.__fleeing + " hiding=" + !!hiding); b.__dirLog = Date.now() } return }
    if (Date.now() < cautionUntil) { if (Date.now() - (b.__dirLog||0) > 10000) { log("DIR_BLOCK caution=" + Math.round((cautionUntil - Date.now())/1000) + "s"); b.__dirLog = Date.now() } return }
    if (Date.now() < manualLockUntil) { if (Date.now() - (b.__dirLog||0) > 10000) { log("DIR_BLOCK lock=" + Math.round((manualLockUntil - Date.now())/1000) + "s"); b.__dirLog = Date.now() } return }
    let moving = false; try { moving = b.pathfinder.isMoving() } catch (e) {}
    // the owner wants us to live inside the leash circle: if we drifted out, that IS the
    // mission - no food/explore grind 40 blocks away from home, just walk back first
    if (leashOn && anchor && b.entity && fin3(b.entity.position) && distAnchor(b) > leashR - 8) {
      if (Date.now() - (b.__leashWalkAt || 0) > 6000) {
        b.__leashWalkAt = Date.now()
        log('DIR_HOME_WALK d=' + distAnchor(b).toFixed(1) + ' -> anchor')
        try { b.pathfinder.setGoal(new goals.GoalNear(anchor.x, anchor.y, anchor.z, 4)) } catch (e) {}
      }
      return
    }
    if (moving) return
    if (unstickBusy) { if (Date.now() - (b.__dirLog||0) > 10000) { log("DIR_BLOCK unstickBusy"); b.__dirLog = Date.now() } return }
    if (threatsNear(b, 0.7).length) { if (Date.now() - (b.__dirLog||0) > 10000) { log("DIR_BLOCK threats=" + threatsNear(b,0.7).length); b.__dirLog = Date.now() } return }                      // no new missions with a real threat on us
    if (b.health < 18 && b.food < 20 && countFood(b) > 0) { await eatFood(b); return }
    // --- anti-starvation outranks tool-making ---
    // wheat is not edible raw, but 3 wheat = 1 bread (needs a crafting table within 5b)
    if (b.food < 17 && countItem(b, 'wheat') >= 3) await craftItem(b, 'bread', Math.min(Math.floor(countItem(b, 'wheat') / 3), 3))
    if (b.food < 16 && countFood(b) > 0) { await eatFood(b); return }
    if (b.food <= 6 && countFood(b) === 0) {
      // last resort: junk food beats starving to death in a loop
      const junk = b.inventory.items().find(i => i.name === 'rotten_flesh' || i.name === 'spider_eye' || i.name === 'poisonous_potato')
      if (junk) {
        try { await b.equip(junk, 'hand'); await b.consume(); log('ATE emergency', junk.name, 'food=' + Math.round(b.food)); return } catch (e) {}
      }
      if (missionAllowed('food') && !isNight(b) && !isDusk(b)) { startMission(b, 'food'); return }
    }
    // near-death or critically hungry with nothing edible in inv: food mission beats tools
    if ((b.health < 8 || b.food < 10) && countFood(b) === 0 && !isNight(b) && !isDusk(b)) {
      if (missionAllowed('food')) { startMission(b, 'food'); return }
      if (missionAllowed('explore')) { startMission(b, 'explore'); return }
      return
    }
    equipArmor(b)
    if (rimAbove(b) >= 3) {
      if (inCollapseZone(b) || deepNearCrater(b)) { if (Date.now() - (b.__craterLogAt || 0) > 120000) { b.__craterLogAt = Date.now(); log('CRATER hold at', pos(b), 'rim=' + rimAbove(b) + ' material=' + countPlaceable(b)) } await craterHold(b); return }
      log('DIRECTOR in hole -> escape at', pos(b)); await digUpAndOut(b, 8); return
    }
    // 0) gearless at night: sealed pocket till dawn FIRST - the tool grind can wait,
    //    the wood mission kept routing back through the spawn nest after dark
    if ((isNight(b) || isDusk(b)) && !hasWeapon(b)) { startMission(b, 'shelter'); return }
    // 1) tools first - a wooden pickaxe+sword unlocks everything else
    if (!hasPickaxe(b) || !hasWeapon(b)) {
      if (missionAllowed('wood')) { startMission(b, 'wood'); return }
      if (missionAllowed('explore')) { startMission(b, 'explore'); return }
      return
    }
    // 2) stone upgrade
    if (!hasStonePick(b)) {
      if (missionAllowed('stone')) { startMission(b, 'stone'); return }
      if (missionAllowed('wood')) { startMission(b, 'wood'); return }
      return
    }
    // 3) night -> shelter
    const day = Math.floor((b.time && b.time.age ? b.time.age : 0) / 24000)
    if ((isNight(b) || isDusk(b)) && b.__shelterDay !== day) { b.__shelterDay = day; startMission(b, 'shelter'); return }
    // 4) hungry -> food
    if (b.food < 15 || (b.health < 16 && countFood(b) === 0)) {
      if (missionAllowed('food')) { startMission(b, 'food'); return }
      if (missionAllowed('explore')) { startMission(b, 'explore'); return }
      return
    }
    // 5) otherwise explore / develop
    startMission(b, missionAllowed('explore') ? 'explore' : (missionAllowed('shelter') ? 'shelter' : 'gather'))
  } catch (e) { log('DIRECTOR_ERR', e && e.message ? e.message : String(e)) }
}
function startDirector (b) {
  if (b.__director) { clearInterval(b.__director); b.__director = null }
  if (!directorOn) { log('DIRECTOR off'); return }
  b.__director = setInterval(() => { directorTick(b) }, 4000)
  log('DIRECTOR on')
}
async function missionHome (b) {
  // 'shelter' = build an actual wooden hut inside the leash circle. Digging a sealed pocket
  // is what kept us dying (and NaN-bricked the client once), so it is the LAST option, only
  // when there is nothing to build with.
  const planks = plankCount(b)
  const logs = countAny(b, LOG_TYPES)
  if (planks >= 20 || logs >= 6) {
    const ok = await buildHut(b)
    mission = null
    if (ok) { log('HOME built, hp=' + Math.round(b.health)); return }
    log('HOME build failed, falling back')
  }
  if (!hasWeapon(b) && logs === 0 && missionAllowed('wood')) { startMission(b, 'wood'); return }
  missionShelter(b)
}

function startMission (b, name, arg1, arg2) {
  mission = { name }
  stats.missions++
  log('DIRECTOR picked', name, 'hp=' + Math.round(b.health), 'food=' + Math.round(b.food))
  if (name === 'shelter') { missionHome(b); return 'home' }
  if (name === 'wood') { missionWood(b); return 'wood' }
  if (name === 'stone') { missionStone(b); return 'stone' }
  if (name === 'food') { missionFood(b); return 'food' }
  if (name === 'explore') { missionExplore(b); return 'explore' }
  if (name === 'gather') { missionGather(b, arg1 || 'dirt', parseInt(arg2 || '32', 10)); return 'gather ' + arg1 }
  mission = null
  return null
}

async function handle (raw, sock) {
  const parts = raw.split(/\s+/)
  const cmd = (parts[0] || '').toLowerCase()
  const args = parts.slice(1)
  const b = bot
  try {
    if (cmd === 'help') {
      return respond(sock, 'commands: mission <shelter|wood|gather <block> <n>|stop> status pos goto <x y z> follow <player> break <x y z> collect <name> [n] craft <item> [n] placeat <x y z> [item] find <block> [r] [n] fight [secs] [radius] mobs [r] eat lookat <name> look <yaw> <pitch> chat <msg> reflex <on|off> free stop window click <slot> [left|right] [mode] clickitem <name> inventory equip <item> drop <item> [n] quit')
    }
    if (!b || !b.entity) return respond(sock, 'ERR bot not spawned yet')

    if (cmd === 'status' || cmd === 'pos') {
      return respond(sock, 'pos=' + pos(b) + ' alive=' + b.isAlive + ' hp=' + Math.round(b.health) + ' food=' + Math.round(b.food) + ' yaw=' + b.entity.yaw.toFixed(2) + ' time=' + (b.time ? b.time.day : '?') + ' dim=' + (b.game ? b.game.dimension : '?') + ' kills=' + (stats.kills || 0) + ' leash=' + Math.round(distAnchor(b)) + 'r' + (leashOn ? leashR : 0) + ' srv=' + (b.__srvPos ? (b.__srvPos.x.toFixed(1) + ',' + b.__srvPos.y.toFixed(1) + ',' + b.__srvPos.z.toFixed(1) + '@' + Math.round((Date.now() - b.__srvPos.t) / 1000) + 's') : '?') + ' drive=' + (b.__drive ? 'on' : 'off') + ' lock=' + Math.max(0, Math.round((manualLockUntil - Date.now()) / 1000)) + 's' + ' sync=' + (b.__syncKeep || 0) + '/' + (b.__syncReal || 0) + ' stucks=' + stuckCount)
    }
    if (cmd === 'goto') {
      let x = parseFloat(args[0]); let y = parseFloat(args[1]); let z = parseFloat(args[2])
      if (isNaN(x) || isNaN(y) || isNaN(z)) return respond(sock, 'ERR goto <x y z>')
      if (leashOn && anchor) {
        const dxg = x - anchor.x; const dzg = z - anchor.z
        const dg = Math.hypot(dxg, dzg)
        if (dg > leashR) { x = anchor.x + dxg * leashR / dg; z = anchor.z + dzg * leashR / dg; log('GOTO_CLAMP', 'target was ' + dg.toFixed(0) + ' from anchor') }
      }
      stopDrive(b)
      b.pathfinder.setGoal(new goals.GoalNear(x, y, z, 1))
      respond(sock, 'OK pathfinding to ' + x + ' ' + y + ' ' + z)
      b.once('goal_reached', () => log('ARRIVED', pos(b)))
      return
    }
    if (cmd === 'follow') {
      const name = args[0]
      const target = b.players[name] && b.players[name].entity
      if (!target) return respond(sock, 'ERR no player ' + name)
      b.pathfinder.setGoal(new goals.GoalFollow(target, 2), true)
      return respond(sock, 'OK following ' + name)
    }
    if (cmd === 'break' || cmd === 'breakhere') {
      let target
      if (cmd === 'breakhere') {
        target = b.blockAtCursor ? b.blockAtCursor() : null
        if (!target) {
          const ray = b.raycast ? b.raycast({ maxDistance: 5 }) : null
          target = ray ? ray.block : null
        }
      } else {
        const x = parseInt(args[0], 10); const y = parseInt(args[1], 10); const z = parseInt(args[2], 10)
        if (isNaN(x) || isNaN(y) || isNaN(z)) return respond(sock, 'ERR break <x y z>')
        target = b.blockAt(new Vec3(x, y, z))
      }
      if (!target || target.type === 0) return respond(sock, 'ERR no block there')
      respond(sock, 'OK breaking ' + target.name + ' at ' + target.position)
      try {
        await b.lookAt(target.position.offset(0.5, 0.5, 0.5))
        if (b.entity.position.distanceTo(target.position) > 4) {
          b.pathfinder.setGoal(new goals.GoalNear(target.position.x, target.position.y, target.position.z, 3))
          await once(b, 'goal_reached', 20000).catch(() => {})
        }
        b.__allowDig = true
        try { await b.dig(target) } finally { b.__allowDig = false }
        log('DUG', target.name)
        collectNear(b, 6).then(n => { if (n) log('DROPS collected', n) })
      } catch (e) { log('DIG_FAIL', e && e.message ? e.message : String(e)) }
      return
    }
    if (cmd === 'collect') {
      const name = args[0]
      const count = parseInt(args[1] || '1', 10)
      if (!name) return respond(sock, 'ERR collect <name> [n]')
      const bt = mcData.blocksByName[name]
      if (!bt) return respond(sock, 'ERR unknown block ' + name)
      if (!b.collectBlock) return respond(sock, 'ERR collectblock plugin missing')
      const positions = b.findBlocks({ matching: bt.id, maxDistance: 48, count: count * 4 })
      const targets = positions.map(p => b.blockAt(p)).filter(Boolean)
      if (!targets.length) return respond(sock, 'ERR no ' + name + ' within 48 blocks')
      manualLockUntil = Date.now() + Math.min(180000, 20000 + count * 6000)
      respond(sock, 'OK collecting up to ' + count + ' ' + name + ' (' + targets.length + ' found)')
      withSoftDig(b, () => b.collectBlock.collect(targets, { iterations: count, range: 4 }))
        .then(() => log('COLLECT_DONE', name))
        .catch(e => log('COLLECT_ERR', e && e.message ? e.message : String(e)))
      return
    }
    if (cmd === 'placebed') {
      // Respawning at world spawn means respawning inside the zombie nest. The only legal,
      // op-free way to move the respawn point on a vanilla server is SLEEPING IN A BED,
      // and a bed needs a floor: so place it in our own hut and sleep there every night.
      const it = b.inventory.items().find(i => /_bed$/.test(i.name))
      if (!it) return respond(sock, 'ERR no bed in inventory (need 3 wool + 3 planks)')
      const f = b.entity.position.floored()
      let ref = b.blockAt(f.offset(0, -1, 0))
      if (!ref || ref.boundingBox !== 'block') ref = b.blockAt(f.offset(0, -2, 0))
      if (!ref || ref.boundingBox !== 'block') return respond(sock, 'ERR no floor below at ' + f)
      try { await b.equip(it, 'hand') } catch (e) {}
      let ok = await withTimeout(b.placeBlock(ref, new Vec3(0, 1, 0)), 6000, false)
      if (!ok) {
        // beds need air above the floor: clear the cell we are standing in is a no-go, so
        // try facing sideways instead
        for (const fv of [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]]) {
          const side = b.blockAt(f.offset(fv[0], -1, fv[2]))
          if (!side || side.boundingBox !== 'block') continue
          ok = await withTimeout(b.placeBlock(side, new Vec3(-fv[0], 1, -fv[2])), 5000, false)
          if (ok) break
        }
      }
      log('PLACE_BED ' + it.name + ' ref=' + ref.position + ' ok=' + !!ok + ' at ' + pos(b))
      return respond(sock, (ok ? 'OK' : 'ERR') + ' bed at ' + f)
    }
    if (cmd === 'sleep') {
      const bedIds = Object.keys(mcData.blocksByName).filter(n => /_bed$/.test(n)).map(n => mcData.blocksByName[n].id)
      let ps = b.findBlocks({ matching: bedIds, maxDistance: 20, count: 6 })
      if (!ps.length) return respond(sock, 'ERR no bed within 20 blocks (placebed first)')
      const p = ps[0]
      const reached = await b.pathfinder.goto(new goals.GoalNear(p.x, p.y, p.z, 2)).then(() => true).catch(() => false)
      const k = b.blockAt(p)
      if (!k) return respond(sock, 'ERR bed gone at ' + p)
      try { await b.lookAt(new Vec3(p.x + 0.5, p.y + 0.5, p.z + 0.5), true) } catch (e) {}
      let used = false
      try {
        await withTimeout(b.useBlock(p, { faces: [new Vec3(0, 0, 1), new Vec3(0, 0, -1), new Vec3(1, 0, 0), new Vec3(-1, 0, 0)] }), 6000, false)
        used = true
      } catch (e) { log('SLEEP_ERR', e && e.message) }
      b.__sleptAt = Date.now()
      log('SLEEP ' + k.name + ' at ' + p + ' reached=' + reached + ' used=' + used + ' time=' + (b.time ? b.time.day : '?'))
      return respond(sock, 'OK sleep reached=' + reached + ' used=' + used)
    }
    if (cmd === 'craft') {
      const name = args[0]
      const count = parseInt(args[1] || '1', 10)
      if (!name) return respond(sock, 'ERR craft <item> [n]')
      const item = mcData.itemsByName[name]
      if (!item) return respond(sock, 'ERR unknown item ' + name)
      let table = null
      const ct = mcData.blocksByName.crafting_table
      if (ct) {
        const tb = b.findBlock({ matching: ct.id, maxDistance: 5 })
        if (tb) table = tb
      }
      let recipes = b.recipesFor(item.id, null, 1, table)
      if (!recipes.length && table) recipes = b.recipesFor(item.id, null, 1, null)
      if (!recipes.length) return respond(sock, 'ERR no recipe for ' + name + ' (missing materials or need table)')
      try {
        await b.craft(recipes[0], count, table)
      } catch (e) {
        return respond(sock, 'ERR craft failed: ' + (e && e.message ? e.message : e))
      }
      return respond(sock, 'OK crafted ' + count + ' ' + name + (table ? ' (used table)' : ''))
    }
    if (cmd === 'place') {
      const name = args[0]
      const item = mcData.itemsByName[name]
      if (!item) return respond(sock, 'ERR unknown item ' + name)
      const inv = b.inventory.items().find(i2 => i2.name === name)
      if (!inv) return respond(sock, 'ERR no ' + name + ' in inventory')
      try { await b.equip(inv, 'hand') } catch (e) {}
      const feet = b.entity.position.floored()
      let target
      const x = parseFloat(args[1]); const y = parseFloat(args[2]); const z = parseFloat(args[3])
      if (!isNaN(x) && !isNaN(y) && !isNaN(z)) target = new Vec3(x, y, z)
      else {
        const yaw = b.entity.yaw
        const fx = Math.round(-Math.sin(yaw)); const fz = Math.round(-Math.cos(yaw))
        target = feet.offset(fx, 0, fz)
      }
      const FACES = [new Vec3(0, 1, 0), new Vec3(0, -1, 0), new Vec3(1, 0, 0), new Vec3(-1, 0, 0), new Vec3(0, 0, 1), new Vec3(0, 0, -1)]
      let done = false
      for (const f of FACES) {
        const refPos = target.plus(f.scaled(-1))
        const ref = b.blockAt(refPos)
        if (ref && ref.boundingBox === 'block' && b.entity.position.distanceTo(refPos) < 4.5) {
          const r = await withTimeout(b.placeBlock(ref, f), 3500, 'to')
          if (r !== 'to') { done = true; break }
        }
      }
      return respond(sock, done ? 'OK placed ' + name + ' at ' + target.toString() : 'ERR place failed at ' + target.toString())
    }
    if (cmd === 'look') {
      const yaw = parseFloat(args[0]); const pitch = parseFloat(args[1] || '0')
      await b.look(yaw, pitch)
      return respond(sock, 'OK looked')
    }
    if (cmd === 'hb') {
      try { return respond(sock, fs.readFileSync(HB_FILE, 'utf8')) } catch (e) { return respond(sock, 'ERR no heartbeat yet') }
    }
    if (cmd === 'stats') {
      return respond(sock, JSON.stringify(stats) + ' lastUnstick=' + Math.round((Date.now() - lastUnstickAt) / 1000) + 's ago')
    }
    if (cmd === 'social') {
      const rows = Object.keys(social).map(k => k + '(talks=' + social[k].talks + ',last=' + Math.round((Date.now() - (social[k].last || 0)) / 1000) + 's)')
      return respond(sock, rows.length ? rows.join(' ') : 'nobody yet')
    }
    if (cmd === 'lastchat') {
      return respond(sock, chatRing.length ? chatRing.slice(-10).map(c => (c.u || '?') + ': ' + c.x).join(' | ') : 'empty')
    }
    if (cmd === 'asks') {
      const n = parseInt(args[0] || '10', 10)
      if (!pendingAsks.length) return respond(sock, 'no one waiting on an answer')
      return respond(sock, pendingAsks.slice(-n).map(a => new Date(a.t).toISOString().slice(11, 19) + ' ' + (a.w ? '*w ' : '') + (a.auto ? '[auto] ' : '') + a.u + ': ' + a.x).join(' || '))
    }
    if (cmd === 'clearasks') { pendingAsks.length = 0; return respond(sock, 'OK asks cleared') }
    if (cmd === 'sayto') {
      return respond(sock, 'ERR removed - no canned replies; answer yourself with: chat <text>')
    }
    if (cmd === 'rawsay') {
      const msg = args.join(' ')
      if (!msg) return respond(sock, 'ERR rawsay <text>')
      try { b.chat(msg); respond(sock, 'OK rawsaid: ' + msg.slice(0, 80)) } catch (e) { respond(sock, 'ERR ' + (e && e.message)) }
      return
    }
    if (cmd === 'testchat') {
      const u = args[0] || 'Tester'
      const t = args.slice(1).join(' ')
      const before = pendingAsks.length
      feedChat(b, u, t, false)
      await sleep(200)
      return respond(sock, 'addressed=' + addressedToMe(t) + ' queued=' + (pendingAsks.length > before ? 'yes' : 'no') + ' (bot never auto-answers)')
    }
    if (cmd === 'selftest') {
      respond(sock, 'OK selftest started, see log')
      selfTest(b)
      return
    }
    if (cmd === 'chat') {
      b.chat(args.join(' '))
      return respond(sock, 'OK said')
    }
    if (cmd === 'jump') {
      if (args[0] === 'on' || args[0] === 'off') { b.setControlState('jump', args[0] === 'on'); syncInput(b); return respond(sock, 'OK jump held ' + (args[0] === 'on')) }
      b.setControlState('jump', true); setTimeout(() => b.setControlState('jump', false), 300); syncInput(b); return respond(sock, 'OK jumped')
    }
    if (cmd === 'sneak') { const on = args[0] !== 'off'; b.setControlState('sneak', on); return respond(sock, 'OK sneak ' + on) }
    if (cmd === 'sprint') { const on = args[0] !== 'off'; b.setControlState('sprint', on); return respond(sock, 'OK sprint ' + on) }
    if (cmd === 'forward') { const on = args[0] !== 'off'; b.setControlState('forward', on); return respond(sock, 'OK forward ' + on) }
    if (cmd === 'inventory') {
      const items = b.inventory.items().map(i => i.name + ' x' + i.count)
      return respond(sock, items.length ? items.join(', ') : 'empty')
    }
    if (cmd === 'window') {
      const w = b.currentWindow
      if (!w) return respond(sock, 'no window open')
      dumpWindow(w)
      let title = ''; try { title = chatText(w.title) } catch (e) {}
      const parts = []
      for (let i = 0; i < w.slots.length; i++) { const it = w.slots[i]; if (it) { let dn = ''; try { dn = chatText(it.displayName) || '' } catch (e) {} parts.push(i + '=' + it.name + (dn && dn !== it.name ? '("' + dn + '")' : '') + 'x' + it.count) } }
      return respond(sock, 'title="' + title + '" type=' + w.type + ' slots=' + w.slots.length + ' | ' + (parts.join(' | ') || 'empty'))
    }
    if (cmd === 'click') {
      const w = b.currentWindow
      if (!w) return respond(sock, 'ERR no window open')
      const slot = parseInt(args[0], 10)
      if (isNaN(slot)) return respond(sock, 'ERR click <slot> [left|right] [mode]')
      const mouseButton = args[1] === 'right' ? 1 : 0
      const mode = parseInt(args[2] || '0', 10)
      try { w.click(slot, mouseButton, mode); return respond(sock, 'OK clicked slot ' + slot) } catch (e) { return respond(sock, 'ERR click ' + (e && e.message ? e.message : e)) }
    }
    if (cmd === 'clickitem') {
      const w = b.currentWindow
      if (!w) return respond(sock, 'ERR no window open')
      const name = args.join(' ').toLowerCase()
      for (let i = 0; i < w.slots.length; i++) {
        const it = w.slots[i]
        if (!it) continue
        let dn = ''; try { dn = (chatText(it.displayName) || '').toLowerCase() } catch (e) {}
        const nm = (it.name || '').toLowerCase()
        if (name && (dn.includes(name) || nm.includes(name))) {
          try { w.click(i, 0, 0); return respond(sock, 'OK clicked slot ' + i + ' ' + it.name + '("' + (chatText(it.displayName) || '') + '")') } catch (e) { return respond(sock, 'ERR click ' + (e && e.message ? e.message : e)) }
        }
      }
      return respond(sock, 'ERR no slot matching "' + name + '"')
    }
    if (cmd === 'equip') {
      const name = args[0]
      const inv = b.inventory.items().find(i => i.name === name)
      if (!inv) return respond(sock, 'ERR no ' + name)
      await b.equip(inv, 'hand')
      return respond(sock, 'OK equipped ' + name)
    }
    if (cmd === 'drop') {
      const name = args[0]; const count = parseInt(args[1] || '1', 10)
      const inv = b.inventory.items().find(i => i.name === name)
      if (!inv) return respond(sock, 'ERR no ' + name)
      await b.toss(name === 'air' ? null : inv.type, null, Math.min(count, inv.count))
      return respond(sock, 'OK dropped ' + name)
    }
    if (cmd === 'fight') {
      const secs = Math.min(parseFloat(args[0] || '6'), 60)
      const radius = parseFloat(args[1] || '6')
      const end = Date.now() + secs * 1000
      let hits = 0
      manualLockUntil = Date.now() + secs * 1000
      respond(sock, 'OK fighting up to ' + secs + 's radius ' + radius)
      ;(async () => {
        let last = ''
        while (Date.now() < end && b.entity && b.health > 0) {
          const h = nearestHostile(b, radius)
          if (!h) break
          equipBestWeapon(b)
          try { await b.lookAt(h.position.offset(0, h.height ? h.height * 0.6 : 0.9, 0)) } catch (e) {}
          const d = h.position.distanceTo(b.entity.position)
          try {
            if (d > 3.3) b.pathfinder.setGoal(new goals.GoalNear(h.position.x, h.position.y, h.position.z, 2))
            else b.pathfinder.setGoal(null)
          } catch (e) {}
          try { b.attack(h); hits++ } catch (e) {}
          if (h.name !== last) { log('FIGHT', h.name, 'd=' + d.toFixed(1), 'hp=' + (h.health !== undefined ? Math.round(h.health) : '?')); last = h.name }
          await sleep(340)
        }
        try { b.pathfinder.setGoal(null) } catch (e) {}
        log('FIGHT_END hits=' + hits)
      })()
      return
    }
    if (cmd === 'mobs') {
      const radius = parseFloat(args[0] || '16')
      const out = []
      for (const id in b.entities) {
        const e = b.entities[id]
        if (!e || !e.position || !e.name || e === b.entity) continue
        const d = e.position.distanceTo(b.entity.position)
        if (d > radius) continue
        const hostile = HOSTILE.has(String(e.name).toLowerCase())
        if (!hostile && args[1] !== 'all') continue
        out.push((hostile ? '!' : ' ') + e.name + ' d=' + d.toFixed(1) + (e.health !== undefined ? ' hp=' + Math.round(e.health) : ''))
      }
      return respond(sock, out.length ? out.join(' | ') : 'none')
    }
    if (cmd === 'find') {
      const name = args[0]
      const radius = parseFloat(args[1] || '32')
      const cnt = parseInt(args[2] || '5', 10)
      if (!name) return respond(sock, 'ERR find <block> [radius] [count]')
      const bt = mcData.blocksByName[name]
      if (!bt) return respond(sock, 'ERR unknown block ' + name)
      const positions = b.findBlocks({ matching: bt.id, maxDistance: radius, count: cnt })
      if (!positions.length) return respond(sock, 'no ' + name + ' within ' + radius)
      const out = positions.map(p => p.x + ' ' + p.y + ' ' + p.z)
      return respond(sock, name + '(' + positions.length + '): ' + out.join(' | '))
    }
    if (cmd === 'eat') {
      const food = findFood(b)
      if (!food) return respond(sock, 'ERR no food in inventory')
      try { await b.equip(food, 'hand'); await b.consume(); return respond(sock, 'OK ate ' + food.name + ' food=' + Math.round(b.food)) } catch (e) { return respond(sock, 'ERR eat ' + (e && e.message ? e.message : e)) }
    }
    if (cmd === 'lookat') {
      const name = (args[0] || '').toLowerCase()
      let target = null; let bd = 1e9
      for (const id in b.entities) {
        const e = b.entities[id]
        if (!e || !e.position || e === b.entity) continue
        const nm = String(e.name || '').toLowerCase()
        const un = String(e.username || '').toLowerCase()
        if (name && nm !== name && un !== name) continue
        if (!name && e.type !== 'player' && un === '') continue
        const d = e.position.distanceTo(b.entity.position)
        if (d < bd) { bd = d; target = e }
      }
      if (!target) return respond(sock, 'ERR no target ' + (name || ''))
      try { await b.lookAt(target.position.offset(0, 1.4, 0)) } catch (e) {}
      return respond(sock, 'OK looking at ' + (target.username || target.name) + ' d=' + bd.toFixed(1))
    }
    if (cmd === 'placeat') {
      const x = parseInt(args[0], 10); const y = parseInt(args[1], 10); const z = parseInt(args[2], 10)
      if (isNaN(x) || isNaN(y) || isNaN(z)) return respond(sock, 'ERR placeat <x y z> [item]')
      let inv
      if (args[3]) inv = b.inventory.items().find(i => i.name === args[3])
      else inv = b.heldItem
      if (!inv) return respond(sock, 'ERR no block item to place')
      await b.equip(inv, 'hand')
      const targetPos = new Vec3(x, y, z)
      const dirs = [new Vec3(0, -1, 0), new Vec3(1, 0, 0), new Vec3(-1, 0, 0), new Vec3(0, 0, 1), new Vec3(0, 0, -1), new Vec3(0, 1, 0)]
      if (b.entity.position.distanceTo(targetPos) > 4.5) {
        b.pathfinder.setGoal(new goals.GoalNear(x, y, z, 3))
        await once(b, 'goal_reached', 15000).catch(() => {})
      }
      for (const d of dirs) {
        const ref = b.blockAt(targetPos.plus(d))
        if (ref && ref.type !== 0) {
          try { await b.placeBlock(ref, d.scaled(-1)); return respond(sock, 'OK placed ' + inv.name + ' at ' + x + ' ' + y + ' ' + z) } catch (e) { return respond(sock, 'ERR place ' + (e && e.message ? e.message : e)) }
        }
      }
      return respond(sock, 'ERR no adjacent solid block at ' + x + ' ' + y + ' ' + z)
    }
    if (cmd === 'demolish') {
      const a = args.slice(0, 6).map(v => parseFloat(v))
      if (a.some(isNaN)) return respond(sock, 'ERR demolish <x1 y1 z1 x2 y2 z2>')
      const r = await demolish(b, a, 0, 0)
      return respond(sock, 'OK demolished dug/failed=' + r + ' planks=' + plankCount(b))
    }
    if (cmd === 'bp') {          // blueprint from a file on the server: "x y z item" per line
      const fs = require('fs')
      let txt = ''
      try { txt = fs.readFileSync('/home/agent/bot/' + (args[0] || 'blueprint.txt'), 'utf8') } catch (e) { return respond(sock, 'ERR no blueprint file: ' + (e && e.message)) }
      const cells = txt.split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('#')).map(l => { const p = l.split(/\s+/); return [parseInt(p[0], 10), parseInt(p[1], 10), parseInt(p[2], 10), p.slice(3).join('_')] })
      if (!cells.length) return respond(sock, 'ERR blueprint empty')
      const r = await runBlueprint(b, cells)
      return respond(sock, 'OK blueprint placed=' + r.placed + ' have=' + r.have + ' failed=' + r.failed + (r.list.length ? ' :: ' + r.list.slice(0, 12).join(' | ') : ''))
    }
    if (cmd === 'home') {
      const x = parseFloat(args[0]); const y = parseFloat(args[1]); const z = parseFloat(args[2])
      if (!isNaN(x) && !isNaN(z)) { HOME = { x, y: isNaN(y) ? Math.round(b.entity.position.y) : y, z }; saveHome(); return respond(sock, 'OK home=' + HOME.x + ' ' + HOME.y + ' ' + HOME.z) }
      if (args[0] === 'here') { const p = b.entity.position; HOME = { x: Math.round(p.x), y: Math.round(p.y), z: Math.round(p.z) }; saveHome(); return respond(sock, 'OK home=' + pos(b)) }
      return respond(sock, HOME ? 'home=' + HOME.x + ' ' + HOME.y + ' ' + HOME.z : 'no home set')
    }
    if (cmd === 'door') {
      const d = findDoorNear(b, b.entity.position.floored(), 8)
      if (!d) return respond(sock, 'ERR no door within 8')
      const ok = await actDoor(b, d.v, args[0] !== 'close')
      return respond(sock, (ok ? 'OK door ' + (args[0] === 'close' ? 'closed' : 'opened') + ' at ' + d.v : 'ERR door at ' + d.v + ' not reached'))
    }
    if (cmd === 'use') {
      const x = parseInt(args[0], 10); const y = parseInt(args[1], 10); const z = parseInt(args[2], 10)
      if ([x, y, z].some(isNaN)) return respond(sock, 'ERR use <x y z>')
      const v = new Vec3(x, y, z); const k = b.blockAt(v)
      if (!k) return respond(sock, 'ERR no block there')
      try { await b.lookAt(v.offset(0.5, 0.5, 0.5)) } catch (e) {}
      const dir = new Vec3(Math.round(b.entity.position.x - (x + 0.5)) || 0, 1, Math.round(b.entity.position.z - (z + 0.5)) || 0)
      try { await b.activateBlock(k, dir); return respond(sock, 'OK used ' + k.name + ' ' + x + ' ' + y + ' ' + z) } catch (e) { return respond(sock, 'ERR ' + (e && e.message ? e.message : e)) }
    }
    if (cmd === 'enter') {
      const x = parseInt(args[0], 10); const y = parseInt(args[1], 10); const z = parseInt(args[2], 10)
      if ([x, y, z].some(isNaN)) return respond(sock, 'ERR enter <x y z>  (inside target; we go in through the door)')
      const r = await enterThroughDoor(b, x, y, z)
      return respond(sock, r === 'inside' ? 'OK in through the door to ' + x + ' ' + y + ' ' + z : 'ERR ' + r)
    }
    if (cmd === 'out') {          // leave the house the same way: find the door from inside
      const d = findDoorNear(b, b.entity.position.floored(), 8)
      if (!d) return respond(sock, 'ERR no door near me')
      if (!await actDoor(b, d.v, true)) return respond(sock, 'ERR door ' + d.v + ' stuck')
      const out = doorOutCell(b, d.v)
      const ok = out ? await pfTo(b, out.x, out.y, out.z, 1.5) : false
      return respond(sock, ok ? 'OK out through the door at ' + d.v : 'ERR opened door ' + d.v + ' but could not step out')
    }
    if (cmd === 'mission') {
      const name = (args[0] || '').toLowerCase()
      if (name === 'stop' || name === 'none') { mission = null; try { b.pathfinder.setGoal(null) } catch (e) {}; try { b.clearControlStates() } catch (e) {}; return respond(sock, 'OK mission stopped') }
      if (!name) return respond(sock, 'ERR mission <shelter|wood|gather <block> <n>|stop>')
      if (mission) return respond(sock, 'ERR mission already running: ' + mission.name)
      const started = startMission(b, name, args[1], args[2])
      if (!started) return respond(sock, 'ERR unknown mission ' + name)
      return respond(sock, 'OK mission ' + started + ' running')
    }
    if (cmd === 'anchor') {
      if (args[0] === 'here' || args[0] === 'set') { const p = b.entity.position; anchor = { x: p.x, y: p.y, z: p.z, t: Date.now() }; saveAnchor(); return respond(sock, 'OK anchor=' + pos(b)) }
      const x = parseFloat(args[0]); const y = parseFloat(args[1]); const z = parseFloat(args[2])
      if (!isNaN(x) && !isNaN(y) && !isNaN(z)) { anchor = { x, y, z, t: Date.now() }; saveAnchor(); return respond(sock, 'OK anchor=' + x + ' ' + y + ' ' + z) }
      const a = anchorOf(b)
      return respond(sock, a ? 'anchor=' + Math.round(a.x) + ' ' + Math.round(a.y) + ' ' + Math.round(a.z) + ' (home=' + !!a.home + ') dist=' + distAnchor(b).toFixed(1) + ' leash=' + (leashOn ? leashR + 'r' : 'off') : 'no anchor yet')
    }
    if (cmd === 'leash') {
      if (args[0] === 'off') { leashOn = false; return respond(sock, 'OK leash off') }
      if (args[0] === 'on') { leashOn = true; return respond(sock, 'OK leash on r=' + leashR) }
      const r = parseFloat(args[0])
      if (!isNaN(r) && r > 4) { leashR = r; leashOn = true; return respond(sock, 'OK leash r=' + leashR) }
      return respond(sock, 'leash ' + (leashOn ? 'on' : 'off') + ' r=' + leashR + ' (2 chunks = 32)')
    }
    if (cmd === 'build') {
      respond(sock, 'OK building hut, see log')
      buildHut(b).then(ok => { if (!ok) log('BUILD failed') })
      return
    }
    if (cmd === 'site') {
      const s = pickBuildSite(b)
      return respond(sock, s ? 'flat 5x5 at ' + s.x + ' ' + s.y + ' ' + s.z + ' dist=' + Math.hypot(s.x - anchorOf(b).x, s.z - anchorOf(b).z).toFixed(1) : 'no flat 5x5 inside the circle')
    }
    if (cmd === 'named') {
      const q = args.join(' ').toLowerCase()
      if (!q) return respond(sock, 'ERR named <substring>')
      const out = []
      for (const it of b.inventory.items()) {
        if (itemTextBlob(it).indexOf(q) >= 0) out.push('slot' + it.index + ' ' + it.name + ' x' + it.count + ' name=' + prettyName(it).slice(0, 60))
      }
      return respond(sock, out.length ? 'FOUND ' + out.join(' , ') : 'nothing named like "' + args.join(' ') + '"')
    }
    if (cmd === 'toss') {
      const q = args.join(' ').toLowerCase()
      if (!q) return respond(sock, 'ERR toss <name substring> [player]')
      let it = null
      for (const i2 of b.inventory.items()) {
        if (itemTextBlob(i2).indexOf(q) >= 0 || i2.name === args[0]) { it = i2; break }
      }
      if (!it) return respond(sock, 'ERR nothing named like "' + args.join(' ') + '" in inventory')
      const want = args[args.length - 1]
      let pl = null
      if (want && b.players[want] && b.players[want].entity) pl = b.players[want].entity
      else pl = nearestPlayerEntity(b, 14)
      if (!pl) return respond(sock, 'REFUSED: no player within 14 - the cassette goes ONLY to players, wait for them')
      const dd = pl.position.distanceTo(b.entity.position)
      if (dd > 14) return respond(sock, 'REFUSED: nearest player ' + dd.toFixed(1) + ' away')
      try { await b.equip(it, 'hand') } catch (e) {}
      slook(b, pl.position.offset(0, 1.1, 0))
      await sleep(260)
      try { b.tossStack(it); log('TOSS', prettyName(it).slice(0, 40) + ' -> ' + (pl.username || pl.name) + ' d=' + dd.toFixed(1)); return respond(sock, 'OK threw "' + prettyName(it).slice(0, 40) + '" to ' + (pl.username || pl.name)) } catch (e) { return respond(sock, 'ERR toss ' + (e && e.message)) }
    }
    if (cmd === 'cassette') {
      const it = findCassette(b)
      if (!it) return respond(sock, 'no cassette in inventory (looking for "' + CASSETTE + '")')
      const pl = nearestPlayerEntity(b, 14)
      return respond(sock, 'have it: slot' + it.index + ' ' + it.name + ' x' + it.count + ' | nearest player ' + (pl ? (pl.username || pl.name) + ' d=' + pl.position.distanceTo(b.entity.position).toFixed(1) : 'none') + (b.__cassetteGiven ? ' ALREADY GIVEN' : ''))
    }
    if (cmd === 'fighton') { b.__noFight = args[0] === 'off'; return respond(sock, 'OK combat ' + (b.__noFight ? 'off' : 'on')) }
    if (cmd === 'reflex') {
      reflexOn = args[0] !== 'off'
      return respond(sock, 'OK reflex ' + (reflexOn ? 'on' : 'off'))
    }
    if (cmd === 'director') {
      directorOn = args[0] !== 'off'
      if (directorOn) startDirector(b); else if (b.__director) { clearInterval(b.__director); b.__director = null }
      return respond(sock, 'OK director ' + (directorOn ? 'on' : 'off'))
    }
    if (cmd === 'free') {
      respond(sock, 'OK freeing')
      autoFree(b)
      return
    }
    if (cmd === 'pillar') {
      const steps = parseInt(args[0] || '4', 10)
      ;(async () => {
        for (let i = 0; i < steps; i++) {
          if (!b.entity || b.health <= 0) break
          const ok = await ensurePlaceable(b, 1)
          if (!ok && countPlaceable(b) < 1) { log('PILLAR', 'no blocks'); break }
          const feet = b.entity.position.floored()
          const ref = b.blockAt(feet.offset(0, -1, 0))
          if (!ref || ref.boundingBox !== 'block') { log('PILLAR', 'no reference at ' + feet.toString()); break }
          try { b.setControlState('jump', true) } catch (e) {}
          await sleep(220)
          const it = b.inventory.items().find(x => PLACEABLE.includes(x.name))
          let placed = false
          if (it) { const r = await withTimeout(b.placeBlock(ref, new Vec3(0, 1, 0)), 3000, 'to'); placed = (r !== 'to') }
          await sleep(280)
          try { b.setControlState('jump', false) } catch (e) {}
          log('PILLAR', i + ' placed=' + placed + ' y=' + pos(b))
        }
      })()
      return respond(sock, 'OK pillaring ' + steps + ' steps')
    }
    if (cmd === 'escapeup') {
      respond(sock, 'OK digging up')
      digUpAndOut(b, parseInt(args[0] || '6', 10))
      return
    }
    if (cmd === 'evaljs') {
      // live diagnostics: evaluate an async expression with bot/b in scope
      const expr = args.join(' ')
      try {
        const fn = new Function('bot', 'b', 'mcData', 'sleep', 'return (async () => (' + expr + '))()')
        const r = await fn(b, b, mcData, sleep)
        const s = typeof r === 'string' ? r : JSON.stringify(r)
        return respond(sock, 'EVAL ' + String(s).slice(0, 1800))
      } catch (e) { return respond(sock, 'EVAL_ERR ' + (e && e.message ? e.message : String(e))) }
    }
    if (cmd === 'probe') {
      if (!b || !b.entity) return respond(sock, 'ERR no entity')
      const feet = b.entity.position.floored()
      let out = 'PROBE y=' + feet.y + ' pos=' + pos(b)
      for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1], [2, 0], [-2, 0], [0, 2], [0, -2], [4, 0], [-4, 0], [0, 4], [0, -4]]) {
        let h = '?'
        for (let dy = 8; dy >= -5; dy--) { const blk = b.blockAt(feet.offset(d[0], dy, d[1])); if (blk && blk.boundingBox === 'block') { h = feet.y + dy; break } }
        out += ' [' + d[0] + ',' + d[1] + ']=' + h
      }
      return respond(sock, out)
    }
    if (cmd === 'stackup') { const n = parseInt(args[0] || '2', 10); manualLockUntil = Date.now() + n * 4000 + 6000; pillarUp(b, n); return respond(sock, 'OK pillaring ' + n) }
    if (cmd === 'pickup') {
      const r = parseInt(args[0] || '24', 10)
      const n = Object.values(b.entities).filter(e => e && e.name === 'item' && e.position && e.position.distanceTo(b.entity.position) <= r).length
      if (!n) return respond(sock, 'no items within ' + r)
      collectNear(b, r).then(k => log('PICKUP done', k + ' items, ' + pos(b)))
      return respond(sock, 'OK picking up ' + n + ' items')
    }
    if (cmd === 'dryout') {
      const dry = nearestDry(b, 16)
      if (!dry) return respond(sock, 'no dry ground within 16')
      walkTo(b, dry.x + 0.5, dry.y, dry.z + 0.5, 40000)
      return respond(sock, 'OK to dry ' + Math.round(dry.x) + ' ' + dry.y + ' ' + Math.round(dry.z) + ' d=' + dry.d.toFixed(1))
    }
    if (cmd === 'walk') {
      const x = parseFloat(args[0]); const y = parseFloat(args[1]); const z = parseFloat(args[2])
      if (isNaN(x) || isNaN(z)) return respond(sock, 'ERR walk <x y z> [secs]')
      const secs = parseInt(args[3] || '45', 10)
      walkTo(b, x, isNaN(y) ? b.entity.position.y : y, z, secs * 1000)
      return respond(sock, 'OK walking to ' + x + ' ' + (isNaN(y) ? '?' : y) + ' ' + z + ' for ' + secs + 's')
    }
    if (cmd === 'near') {
      const feet = b.entity.position.floored()
      let out = 'NEAR y=' + feet.y
      for (const d of [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1], [2, 0], [-2, 0], [0, 2], [0, -2]]) {
        const col = []
        for (let dy = -1; dy <= 4; dy++) { const blk = b.blockAt(feet.offset(d[0], dy, d[1])); col.push(dy + ':' + (blk ? blk.name.replace(/_block$/, '') : '-')) }
        out += ' [' + d[0] + ',' + d[1] + '] ' + col.join(' ')
      }
      const below = []
      for (let dy = -1; dy >= -4; dy--) { const blk = b.blockAt(feet.offset(0, dy, 0)); below.push(dy + ':' + (blk ? blk.name.replace(/_block$/, '') : '-')) }
      out += ' BELOW ' + below.join(' ')
      return respond(sock, out)
    }
    if (cmd === 'scan') {
      const feet = b.entity.position.floored()
      const span = parseInt(args[0] || '10', 10)
      let out = 'SCAN y=' + feet.y
      const dirs = [[1, 0, 'E'], [-1, 0, 'W'], [0, 1, 'S'], [0, -1, 'N'], [1, 1, 'SE'], [-1, -1, 'NW'], [1, -1, 'NE'], [-1, 1, 'SW']]
      for (const d of dirs) {
        const seq = []
        for (let dist = 3; dist <= 33; dist += 3) {
          const c = dryCol(b, feet, d[0] * dist, d[1] * dist)
          const g = c ? (feet.y + 0 + (c.y - feet.y - 1)) : null
          seq.push(dist + ':' + (c ? c.y + 'd' : (groundYAt(b, feet, d[0] * dist, d[1] * dist, span) === null ? '?' : 'W')))
        }
        out += ' ' + d[2] + '[' + seq.join(' ') + ']'
      }
      return respond(sock, out)
    }
    if (cmd === 'phys') { b.physicsEnabled = args[0] !== 'off'; return respond(sock, 'OK physics=' + b.physicsEnabled) }
    if (cmd === 'loaded') { sendLoaded(b, 'manual'); return respond(sock, 'OK player_loaded sent') }
    if (cmd === 'input') {
      const names = ['forward', 'back', 'left', 'right', 'jump', 'sneak', 'sprint']
      const errs = []
      const c = n => { try { return !!b.getControlState(n) } catch (e) { errs.push('get:' + n + ':' + e.message); return false } }
      if (args[0] === 'send') { syncInput(b); b.__inputKey = '' ; syncInput(b) }
      if (args.length >= 3) { try { b.setControlState(args[1], args[2] === 'on') } catch (e) { errs.push('set:' + e.message) } ; b.__inputKey = ''; syncInput(b) }
      const st = names.map(n => n + ':' + (c(n) ? 1 : 0)).join(' ')
      let err = 'none'
      try { b._client.write('player_input', { inputs: { forward: c('forward'), backward: c('back'), left: c('left'), right: c('right'), jump: c('jump'), shift: c('sneak'), sprint: c('sprint') } }) } catch (e) { err = e.message }
      return respond(sock, 'errs=' + (errs.join('|') || 'none') + ' raw=' + (() => { try { return JSON.stringify(b.controlState) } catch (e) { return 'throw ' + e.message } })() + ' INPUTS writes=' + (b.__inputWrites || 0) + ' err=' + err + ' state=' + st + ' feature=' + (b.supportFeature ? b.supportFeature('newPlayerInputPacket') : '?') + ' pos=' + pos(b))
    }
    if (cmd === 'diag') {
      const e = b.entity
      const cs = JSON.stringify(b.controlState)
      const out = 'DIAG pos=' + e.position.x.toFixed(2) + ',' + e.position.y.toFixed(2) + ',' + e.position.z.toFixed(2) + ' vel=' + JSON.stringify({ x: +e.velocity.x.toFixed(3), y: +e.velocity.y.toFixed(3), z: +e.velocity.z.toFixed(3) }) +
        ' onGround=' + b.onGround + ' yaw=' + e.yaw.toFixed(2) + ' pitch=' + e.pitch.toFixed(2) +
        ' ctrl=' + cs + ' alive=' + e.isPlayer + ' state=' + (b._client && b._client.state) + ' phys=' + (b.physics ? b.physics.gravity + '/' + b.physics.airDamping : '?')
      const names = ['position', 'flying', 'player_input', 'player_loaded', 'arm_animation']
      const snap = () => names.map(n => n + ':' + (b.__outPk[n] || 0) + '/' + (b.__inPk[n] || 0)).join(' ')
      const s0 = snap()
      const p0 = e.position.clone()
      try { b.setControlState('forward', true) } catch (er) {}
      await sleep(2000)
      try { b.setControlState('forward', false) } catch (er) {}
      const p1 = b.entity.position
      const s1 = snap()
      return respond(sock, out + ' | pk_out/in_before ' + s0 + ' | pk_after ' + s1 + ' | moved=' + Math.hypot(p1.x - p0.x, p1.z - p0.z).toFixed(3) + ' dy=' + (p1.y - p0.y).toFixed(3))
    }
    if (cmd === 'stop') {
      // 'stop' must also drop the mission: a gather loop in the wrong biome used to spin
      // forever (GATHER timeout x N) because nothing else cleared `mission`
      mission = null
      try { hiding = false } catch (e) {}
      stopDrive(b)
      try { b.pathfinder.setGoal(null) } catch (e) {}
      try { b.clearControlStates() } catch (e) {}
      manualLockUntil = 0
      return respond(sock, 'OK stopped, mission cleared')
    }
    if (cmd === 'quit') {
      respond(sock, 'OK quitting')
      stopped = true
      setTimeout(() => { try { b.quit() } catch (e) {}; process.exit(0) }, 300)
      return
    }
    respond(sock, 'ERR unknown command: ' + cmd)
  } catch (e) {
    log('CMD_ERR', cmd, e && e.message ? e.message : String(e))
    respond(sock, 'ERR ' + (e && e.message ? e.message : String(e)))
  }
}

function once (emitter, event, timeout) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => { emitter.removeListener(event, onOk); reject(new Error('timeout')) }, timeout)
    function onOk () { clearTimeout(t); resolve() }
    emitter.once(event, onOk)
  })
}

function startControl () {
  const server = net.createServer(sock => {
    clients.add(sock)
    let buf = ''
    sock.on('data', d => {
      buf += d.toString()
      let idx
      while ((idx = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, idx).trim()
        buf = buf.slice(idx + 1)
        if (line) handle(line, sock)
      }
    })
    sock.on('close', () => clients.delete(sock))
    sock.on('error', () => clients.delete(sock))
  })
  server.listen(CONTROL_PORT, '127.0.0.1', () => log('control on 127.0.0.1:' + CONTROL_PORT))
}

startControl()
log('connecting to', HOST + ':' + PORT, 'version', VERSION, 'auth', AUTH, 'as', USERNAME)
bot = makeBot()
