#!/usr/bin/env python3
# patch21: stop eating our own building material. The wood prep crafted a crafting table and
# sticks on every run, so 17 sticks + 2 tables were made out of the planks the hut needs
# (BUILD then says "need ~20 planks, have 2"). Planks are wall material first.
import sys

F = 'bot.js'
s = open(F, encoding='utf8').read()
done = []

def sub(name, old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        print('!! %-16s found %d (expected %d)' % (name, n, count)); sys.exit(1)
    s = s.replace(old, new, count); done.append(name)

sub('table-waste', """    if (pl >= 4) await craftItem(b, 'crafting_table', 1)""",
    """    // only if we literally do not carry a table: crafting a second one burns 4 wall planks
    if (pl >= 4 && countItem(b, 'crafting_table') < 1) await craftItem(b, 'crafting_table', 1)""")

sub('stick-waste', """    if (pl >= 2) await craftItem(b, 'stick', Math.min(2, Math.floor(pl / 2)))""",
    """    // sticks are only needed for tool recipes (2 per tool). Keeping a small budget and never
    // below the 20 planks the hut needs - this was eating the house.
    if (pl >= 8 && countItem(b, 'stick') < 4) await craftItem(b, 'stick', 2)""")

sub('stone-sticks', """    if (countItem(b, 'stick') < 2 && countAny(b, PLANKS_ANY) >= 2) await craftItem(b, 'stick', 4)""",
    """    if (countItem(b, 'stick') < 2 && countAny(b, PLANKS_ANY) >= 10) await craftItem(b, 'stick', 4)""")

open(F, 'w', encoding='utf8').write(s)
print('OK patch21 applied:', len(done), 'edits:', ', '.join(done))
