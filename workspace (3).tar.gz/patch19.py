#!/usr/bin/env python3
# patch19: my own regression - patch18 REPLACED "let homeWalkUntil" instead of adding next to
# it, so the leash interval threw ReferenceError every 5s (LEASH_ERR homeWalkUntil is not
# defined) and leash protection silently stopped working.
import sys

F = 'bot.js'
s = open(F, encoding='utf8').read()
old = """let homeRunUntil = 0"""
new = """let homeRunUntil = 0
let homeWalkUntil = 0"""
if s.count(old) != 1:
    print('!! homeRunUntil decl found', s.count(old)); sys.exit(1)
s = s.replace(old, new, 1)

# and make sure the walk-home flag is declared only once
if s.count("let homeWalkUntil = 0") != 1:
    print('!! duplicate homeWalkUntil declaration:', s.count("let homeWalkUntil = 0")); sys.exit(1)

open(F, 'w', encoding='utf8').write(s)
print('OK patch19 applied')
