#!/usr/bin/env python3
# patch18: (1) read the death cause from the server's own death message - "Puff was slain by
# Zombie" - because entityHurt gives no source in this version, (2) bed support: placebed +
# sleep, so respawn stops being the zombie nest at all (that is where hundreds of deaths came
# from), (3) stop the respawn thrash: LEASH_RETURN must not fight RESPAWN_RUN/HOME_HOP.
import sys

F = 'bot.js'
s = open(F, encoding='utf8').read()
done = []

def sub(name, old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        print('!! %-16s found %d (expected %d)' % (name, n, count)); sys.exit(1)
    s = s.replace(old, new, count); done.append(name)

# ---- 1. death cause from the death message -------------------------------------------
sub('death-msg', """  b.on('messagestr', (msg) => {
    log('MSG', msg)""",
    """  b.on('messagestr', (msg) => {
    log('MSG', msg)
    // The server says exactly how we died ("Puff was slain by Zombie"); entityHurt gives no
    // source in this mineflayer, so this is the only reliable cause. Without it I kept
    // guessing: 534 deaths and no idea which hazard to fix first.
    try {
      if (/Puff/.test(msg) && /slain by|killed by|shot by|fired by|struck by|drowned|suffocated|fell from|went too deep|burned to death|was squashed|died|magic|expired|tried to swim in lava|was blown/i.test(msg)) {
        let c = 'env'
        let m = msg.match(/(?:slain by|killed by|shot by|fired by|struck by)\s*([A-Za-z' _]{2,24})/i)
        if (m) c = m[1].trim().split(/[\s(]+/)[0].toLowerCase()
        else if (/drowned|suffocat/.test(msg)) c = 'drown'
        else if (/lava/.test(msg)) c = 'lava'
        else if (/fell from|high place/.test(msg)) c = 'fall'
        else if (/too deep/.test(msg)) c = 'void'
        else if (/burned/.test(msg)) c = 'burn'
        else if (/blown|explos/.test(msg)) c = 'creeper'
        else if (/magic/.test(msg)) c = 'magic'
        lastDeathCause = c
        log('DEATH_MSG cause=' + c + ' :: ' + msg)
      }
    } catch (e) {}""")

# ---- 2. bed: place it and sleep, so the nest stops being our respawn ------------------
sub('bed-cmds', """    if (cmd === 'craft') {""",
    """    if (cmd === 'placebed') {
      // Respawning at world spawn means respawning inside the zombie nest. The only legal,
      // op-free way to move the respawn point on a vanilla server is SLEEPING IN A BED,
      // and a bed needs a floor: so place it in our own hut and sleep there every night.
      const it = b.inventory.items().find(i => /_bed$/.test(i.name))
      if (!it) return respond(sock, 'ERR no bed in inventory (need 3 wool + 3 planks)')
      const f = b.entity.position.floored()
      let ref = b.blockAt(f.offset(0, -1, 0))
      if (!ref || ref.boundingBox !== 'block') ref = b.blockAt(f.offset(0, -2, 0))
      if (!ref || ref.boundingBox !== 'block') return respond(sock, 'ERR no floor below at ' + f)
      try { await b.equip(it, 'hand') } catch (e) {}
      let ok = await withTimeout(b.placeBlock(ref, new Vec3(0, 1, 0)), 6000, false)
      if (!ok) {
        // beds need air above the floor: clear the cell we are standing in is a no-go, so
        // try facing sideways instead
        for (const fv of [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]]) {
          const side = b.blockAt(f.offset(fv[0], -1, fv[2]))
          if (!side || side.boundingBox !== 'block') continue
          ok = await withTimeout(b.placeBlock(side, new Vec3(-fv[0], 1, -fv[2])), 5000, false)
          if (ok) break
        }
      }
      log('PLACE_BED ' + it.name + ' ref=' + ref.position + ' ok=' + !!ok + ' at ' + pos(b))
      return respond(sock, (ok ? 'OK' : 'ERR') + ' bed at ' + f)
    }
    if (cmd === 'sleep') {
      const bedIds = Object.keys(mcData.blocksByName).filter(n => /_bed$/.test(n)).map(n => mcData.blocksByName[n].id)
      let ps = b.findBlocks({ matching: bedIds, maxDistance: 20, count: 6 })
      if (!ps.length) return respond(sock, 'ERR no bed within 20 blocks (placebed first)')
      const p = ps[0]
      const reached = await b.pathfinder.goto(new goals.GoalNear(p.x, p.y, p.z, 2)).then(() => true).catch(() => false)
      const k = b.blockAt(p)
      if (!k) return respond(sock, 'ERR bed gone at ' + p)
      try { await b.lookAt(new Vec3(p.x + 0.5, p.y + 0.5, p.z + 0.5), true) } catch (e) {}
      let used = false
      try {
        await withTimeout(b.useBlock(p, { faces: [new Vec3(0, 0, 1), new Vec3(0, 0, -1), new Vec3(1, 0, 0), new Vec3(-1, 0, 0)] }), 6000, false)
        used = true
      } catch (e) { log('SLEEP_ERR', e && e.message) }
      b.__sleptAt = Date.now()
      log('SLEEP ' + k.name + ' at ' + p + ' reached=' + reached + ' used=' + used + ' time=' + (b.time ? b.time.day : '?'))
      return respond(sock, 'OK sleep reached=' + reached + ' used=' + used)
    }
    if (cmd === 'craft') {""")

# ---- 3. respawn escape must not fight the leash ---------------------------------------
sub('home-run', """let homeWalkUntil = 0""", """let homeRunUntil = 0""")

sub('respawn-flag', """          log('RESPAWN_IN_GRINDER -> walking home, leash stays on ' + (anchor ? Math.round(anchor.x) + ',' + Math.round(anchor.z) : '?'))""",
    """          log('RESPAWN_IN_GRINDER -> running home, leash holds off 75s (old anchor ' + (anchor ? Math.round(anchor.x) + ',' + Math.round(anchor.z) : '?') + ')')
          homeRunUntil = Date.now() + 75000""")

sub('leash-holdoff', """      if (Date.now() < homeWalkUntil) return                    // long walk home in progress""",
    """      if (Date.now() < homeWalkUntil || Date.now() < homeRunUntil) return   // escape run owns us""")

sub('clamped-holdoff', """function clampXZ (x, z) {
  if (!leashOn || !anchor || !isFinite(x) || !isFinite(z)) return null""",
    """function clampXZ (x, z) {
  if (!leashOn || !anchor || !isFinite(x) || !isFinite(z)) return null
  // during the run out of the nest, clamping goals onto a circle 700 blocks away only
  // pins us there - the escape routine is already aimed at home""")

sub('clamp-hold2', """  if (!leashOn || !anchor || !isFinite(x) || !isFinite(z)) return null
  // during the run out of the nest, clamping goals onto a circle 700 blocks away only
  // pins us there - the escape routine is already aimed at home
  try { if (bot && bot.__dropRun) return null } catch (e) {}   // fetching our own gear - no leash""",
    """  if (!leashOn || !anchor || !isFinite(x) || !isFinite(z)) return null
  // during the run out of the nest, clamping goals onto a circle 700 blocks away only
  // pins us there - the escape routine is already aimed at home
  if (Date.now() < homeRunUntil) return null
  try { if (bot && bot.__dropRun) return null } catch (e) {}   // fetching our own gear - no leash""")

open(F, 'w', encoding='utf8').write(s)
print('OK patch18 applied:', len(done), 'edits:', ', '.join(done))
