# -*- coding: utf-8 -*-
# NaN guards + watchdog for the combat module (client position went NaN mid-fight).
import io, sys
src = io.open('bot.js', encoding='utf-8').read()

def rep(old, new, tag='', cnt=1):
    global src
    n = src.count(old)
    if n == 0:
        print('MISS  %s' % tag); sys.exit(1)
    src = src.replace(old, new, cnt)
    print('ok    %s (%d)' % (tag, n))

# helpers, inserted with the combat module
rep("const fightState = { lastSwing: 0, strafe: 1, strafeAt: 0, retreatUntil: 0, goalAt: 0 }",
"""const fightState = { lastSwing: 0, strafe: 1, strafeAt: 0, retreatUntil: 0, goalAt: 0 }
function fin3 (p) { return !!p && isFinite(p.x) && isFinite(p.y) && isFinite(p.z) }
function slook (b, p) { try { if (fin3(p)) b.lookAt(p, true, false) } catch (e) {} }""",
    tag='helpers')

# combat: refuse non-finite targets/positions, guarded looks
rep("""  const wp = bestWeapon(b)
  const armed = !!wp
  const hp = b.health""",
"""  if (!fin3(b.entity.position) || !isFinite(b.health)) { stopFight(b); return }
  const wp = bestWeapon(b)
  const armed = !!wp
  const hp = b.health""", tag='guard self')

rep("""  b.__fighting = true; b.__fightAt = now; b.__fightId = e.id; b.__fightName = e.name
  const nm = String(e.name).toLowerCase()
  const ranged = RANGED.has(nm)
  const d = e.position.distanceTo(b.entity.position)""",
"""  if (!fin3(e.position)) return
  b.__fighting = true; b.__fightAt = now; b.__fightId = e.id; b.__fightName = e.name
  const nm = String(e.name).toLowerCase()
  const ranged = RANGED.has(nm)
  const d = e.position.distanceTo(b.entity.position)
  if (!isFinite(d)) { stopFight(b); return }""", tag='guard target')

for i in range(3):
    src = src.replace("try { b.look(look, true) } catch (err) {}", "slook(b, look)", 1)
print('ok    b.look(look,true) -> slook x%d' % src.count('slook(b, look)'))

# GoalNear with a NaN target is what bricks the pathfinder: validate first
rep("""      try { b.pathfinder.setGoal(new goals.GoalNear(e.position.x, e.position.y, e.position.z, 2)) } catch (err) {}""",
"""      if (fin3(e.position)) { try { b.pathfinder.setGoal(new goals.GoalNear(e.position.x, e.position.y, e.position.z, 2)) } catch (err) {} }""",
    tag='GoalNear guard')

# toss: guarded look
rep("""      try { b.lookAt(pl.position.offset(0, 1.1, 0), true, false) } catch (e) {}""",
"""      slook(b, pl.position.offset(0, 1.1, 0))""", tag='toss look')

# leash tick doubles as the NaN watchdog: one targeted relog, never a loop
rep("""  b.__leash = setInterval(() => {
    try {
      if (!leashOn || !b.entity || !b.isAlive) return""",
"""  b.__leash = setInterval(() => {
    try {
      if (b.entity && !fin3(b.entity.position)) {
        // the client entity position went NaN (a poisoned look/GoalNear): movement is dead,
        // only a clean reconnect brings the chunks and physics back. One relog per 90s max.
        if (Date.now() - (globalNaNRescueAt || 0) > 90000) {
          globalNaNRescueAt = Date.now()
          log('NAN_POS_RESCUE at srv=' + (b.__srvPos ? (b.__srvPos.x.toFixed(1) + ',' + b.__srvPos.y.toFixed(1) + ',' + b.__srvPos.z.toFixed(1)) : '?') + ' -> reconnect')
          saveStats()
          try { b.end('nan-pos-rescue') } catch (e) {}
        }
        return
      }
      if (!leashOn || !b.entity || !b.isAlive) return""", tag='NaN watchdog')

rep("""let anchor = null
let leashR = 32""",
"""let anchor = null
let globalNaNRescueAt = 0
let leashR = 32""", tag='watchdog var')

# anchor must never be NaN
rep("""  if (!anchor && b && b.entity) {
    const p = b.entity.position""",
"""  if (!anchor && b && b.entity && fin3(b.entity.position)) {
    const p = b.entity.position""", tag='anchor guard')
rep("""      const d = distAnchor(b)
      if (d > leashR + 6""",
"""      const d = distAnchor(b)
      if (isFinite(d) && d > leashR + 6""", tag='leash dist guard')

io.open('bot.js', 'w', encoding='utf-8').write(src)
print('done')
