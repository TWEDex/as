# -*- coding: utf-8 -*-
# Cassette watcher: the custom item "Наши проекты #4" must be announced once and thrown
# ONLY into a player's hands - never dropped on the ground, never for mobs.
import io, sys
src = io.open('bot.js', encoding='utf-8').read()

def rep(old, new, tag=''):
    global src
    if src.count(old) != 1:
        print('MISS/DUP %s (%d)' % (tag, src.count(old))); sys.exit(1)
    src = src.replace(old, new, 1)
    print('ok    %s' % tag)

MOD = """
// ==================== THE CASSETTE (custom item, found "in the sea") ====================
// Not a music_disc and not paper by meaning: it is a custom item whose DISPLAY NAME is
// this string, so we match by name, wherever it comes from (nbt components or customName).
const CASSETTE = (process.env.PUFF_CASSETTE || 'наши проекты #4').toLowerCase()
function findCassette (b) {
  try {
    for (const it of b.inventory.items()) {
      let s = ''
      try { s = String(it.customName || '') } catch (e) {}
      try { s += '|' + JSON.stringify(it.nbt || {}) } catch (e) {}
      if (s.toLowerCase().indexOf(CASSETTE) >= 0) return it
    }
  } catch (e) {}
  return null
}
function startCassette (b) {
  if (b.__cassette) clearInterval(b.__cassette)
  b.__cassette = setInterval(() => {
    try {
      if (!b.entity || !b.isAlive) return
      const it = findCassette(b)
      if (!it) { b.__cassetteSaid = false; b.__cassetteGiven = false; return }
      if (!b.__cassetteSaid) {
        b.__cassetteSaid = true
        try { b.chat('Ребят, я нашёл какую-то кассету'); log('CASSETTE_ANNOUNCE') } catch (e) {}
      }
      const pl = nearestPlayerEntity(b, 7)
      if (!pl) return                                    // only to players, into their hands
      if (b.__cassetteGiven) return
      b.__cassetteGiven = true
      try { b.equip(it, 'hand').catch(() => {}) } catch (e) {}
      slook(b, pl.position.offset(0, 1.1, 0))
      setTimeout(() => {
        try { b.tossItem(findCassette(b) || it, 1); log('CASSETTE_GIVEN', pl.username || pl.name) } catch (e) { log('CASSETTE_TOSS_ERR', e && e.message) }
      }, 500)
    } catch (e) { log('CASSETTE_ERR', e && e.message) }
  }, 4000)
  log('CASSETTE watch on ("' + CASSETTE + '")')
}
"""
rep("function startCombat (b) {", MOD + "\nfunction startCombat (b) {", tag='cassette module')
rep("    try { startCombat(b) } catch (e) { log('COMBAT_ERR', e && e.message) }",
    "    try { startCombat(b) } catch (e) { log('COMBAT_ERR', e && e.message) }\n    try { startCassette(b) } catch (e) { log('CASSETTE_HOOK_ERR', e && e.message) }",
    tag='cassette hook')
rep("    if (cmd === 'fighton') {",
"""    if (cmd === 'cassette') {
      const it = findCassette(b)
      if (!it) return respond(sock, 'no cassette in inventory (looking for "' + CASSETTE + '")')
      const pl = nearestPlayerEntity(b, 14)
      return respond(sock, 'have it: slot' + it.index + ' ' + it.name + ' x' + it.count + ' | nearest player ' + (pl ? (pl.username || pl.name) + ' d=' + pl.position.distanceTo(b.entity.position).toFixed(1) : 'none') + (b.__cassetteGiven ? ' ALREADY GIVEN' : ''))
    }
    if (cmd === 'fighton') {""", tag='cassette command')

io.open('bot.js', 'w', encoding='utf-8').write(src)
print('done')
