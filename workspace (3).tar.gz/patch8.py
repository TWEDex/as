# -*- coding: utf-8 -*-
import io, sys
src = io.open('bot.js', encoding='utf-8').read()
def rep(old, new, tag=''):
    global src
    if src.count(old) != 1:
        print('MISS/DUP %s (%d)' % (tag, src.count(old))); sys.exit(1)
    src = src.replace(old, new, 1); print('ok    %s' % tag)

# A1: the reconnect path never cleared my own intervals -> ghost clients kept fighting
rep("""    try { if (b.__inputTimer) clearInterval(b.__inputTimer) } catch (e) {}
    try { if (b.__loadedTimer) clearInterval(b.__loadedTimer) } catch (e) {}""",
"""    try { if (b.__inputTimer) clearInterval(b.__inputTimer) } catch (e) {}
    try { if (b.__loadedTimer) clearInterval(b.__loadedTimer) } catch (e) {}
    // COMBAT/LEASH/CASSETTE were missing here: a dead client kept swinging and dragging
    // goals around for hours (two "Puffs" inside one process, phantom positions in the log)
    try { if (b.__combat) clearInterval(b.__combat); b.__combat = null } catch (e) {}
    try { if (b.__leash) clearInterval(b.__leash); b.__leash = null } catch (e) {}
    try { if (b.__cassette) clearInterval(b.__cassette); b.__cassette = null } catch (e) {}
    try { if (b.__reflex) { clearInterval(b.__reflex); b.__reflex = null } } catch (e) {}""", tag='end clears my intervals')

# A2: stale-bot guard in every autonomous loop
rep("""async function combatTick (b) {
  if (!b.entity || !b.isAlive || b.health <= 0) { stopFight(b); return }""",
"""async function combatTick (b) {
  if (b !== bot) { if (b.__combat) { clearInterval(b.__combat); b.__combat = null } ; return }   // ghost client
  if (!b.entity || !b.isAlive || b.health <= 0) { stopFight(b); return }""", tag='combat ghost guard')
rep("""      if (b.entity && !fin3(b.entity.position)) {""",
"""      if (b !== bot) { if (b.__leash) { clearInterval(b.__leash); b.__leash = null }; return }   // ghost client
      if (b.entity && !fin3(b.entity.position)) {""", tag='leash ghost guard')
rep("""      if (!b.entity || !b.isAlive) return
      const it = findCassette(b)""",
"""      if (b !== bot) { if (b.__cassette) { clearInterval(b.__cassette); b.__cassette = null }; return }   // ghost client
      if (!b.entity || !b.isAlive) return
      const it = findCassette(b)""", tag='cassette ghost guard')

# B: do not solo-hero a swarm - that is how 500 deaths happen
rep("""  if (hp < 6) { if (b.__fighting) stopFight(b); return }          // hopeless, let survival logic run""",
"""  if (hp < 6) { if (b.__fighting) stopFight(b); return }          // hopeless, let survival logic run
  // swarm rule: three or more hostiles in range and we are not at full strength -> break off
  if (hp < 17 || !bestWeapon(b)) {
    let crowd = 0
    for (const id in b.entities) {
      const e2 = b.entities[id]
      if (!e2 || !e2.position || !e2.name || e2 === b.entity) continue
      if (!HOSTILE.has(String(e2.name).toLowerCase())) continue
      if (e2.health !== undefined && e2.health <= 0) continue
      if (e2.position.distanceTo(b.entity.position) <= radiusOf(hp)) crowd++
    }
    if (crowd >= 3) { if (b.__fighting) { log('FIGHT_SWARM ' + crowd + ' nearby, breaking off'); stopFight(b) }; return }
  }""", tag='swarm retreat')
rep("""  const radius = armed ? (hp >= 10 ? 14 : 9) : 4.5
  const e = fightTarget(b, radius)""",
"""  const radius = radiusOf(hp)
  const e = fightTarget(b, radius)""", tag='radius helper use')
rep("""function bestWeapon (b) {""",
"""function radiusOf (hp) { return hp >= 10 ? 14 : (hp >= 7 ? 9 : 4.5) }
function bestWeapon (b) {""", tag='radius helper')

# C: home is inside the leash circle - exploring breaks that
rep("""function missionAllowed (name) { return !(missionBackoff[name] && Date.now() < missionBackoff[name]) }""",
"""function missionAllowed (name) {
  if (leashOn && (name === 'explore')) return false      // no long walks away from home
  return !(missionBackoff[name] && Date.now() < missionBackoff[name])
}""", tag='explore off while leashed')
io.open('bot.js', 'w', encoding='utf-8').write(src)
print('done')
