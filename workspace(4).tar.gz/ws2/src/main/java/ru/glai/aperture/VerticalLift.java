package ru.glai.aperture;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.io.File;
import java.io.IOException;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.MultipleFacing;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

public final class VerticalLift {

    public enum State {
        IDLE,
        WAIT_TOP,
        HOLD_TOP,
        STORE,
        MOVE_DOWN,
        WAIT_EXIT,
        GATE_CLOSE,
        WAIT_BOTTOM,
        GATE_SHUT,
        MOVE_UP
    }

    private final ApertureScience plugin;
    private final ItemStorage storage;
    private final String id;
    private final String owner;
    private final String worldName;

    private final int[] topBox = new int[6];
    private final int[] stepVec = new int[3];
    private int totalSteps;
    private final int[] gateBox = new int[6];
    private final List<int[]> gateCellsClose = new ArrayList<>();
    private final List<int[]> gateCellsOpen = new ArrayList<>();

    private final int movePeriod;
    private final int boardCheck;
    private final int boardHold;
    private final int storeTime;
    private final int exitCheck;
    private final int gateCloseDelay;
    private final int upWait;

    private final String storeSound;
    private final float storeVolume;
    private final float storePitch;
    private final String windSound;
    private final SoundCategory windCategory;
    private final float windVolume;
    private final float windPitch;
    private final int windPeriod;
    private final boolean moveSoundEnabled;
    private final String moveSound;
    private final float moveVolume;
    private final float movePitch;
    private final int moveSoundPeriod;
    private final String gateOpenSound;
    private final String gateCloseSound;
    private final float gateVolume;
    private final float gatePitch;
    private final boolean smokeEnabled;
    private final String smokeParticle;
    private final int smokeCount;
    private final int smokeStorePeriod;
    private final int smokeMovePeriod;
    private final double smokeSpread;

    private State state = State.IDLE;
    private int progress;
    private int timer;
    private int moveTicks;
    private int windClock;
    private int smokeClock;

    private boolean gateOpen;
    private boolean skipBoard;
    private boolean gateAnimating;
    private boolean gateAnimOpening;
    private int gateIndex;
    private List<int[]> gateOrder = new ArrayList<>();

    public VerticalLift(ApertureScience plugin, ItemStorage storage, String id, FileConfiguration cfg, String path, String owner) {
        this.plugin = plugin;
        this.storage = storage;
        this.id = id;
        this.owner = owner;
        this.worldName = cfg.getString(path + ".world", "world");
        World world = world();
        if (world == null) {
            throw new IllegalArgumentException("World not found: " + worldName);
        }
        Location topA = parse(cfg.getString(path + ".cabin-top-a"), world);
        Location topB = parse(cfg.getString(path + ".cabin-top-b"), world);
        Location botA = parse(cfg.getString(path + ".cabin-bottom-a"), world);
        normalize(topA, topB, topBox);
        int dy = botA.getBlockY() - topA.getBlockY();
        int dx = botA.getBlockX() - topA.getBlockX();
        int dz = botA.getBlockZ() - topA.getBlockZ();
        stepVec[0] = Integer.signum(dx);
        stepVec[1] = Integer.signum(dy);
        stepVec[2] = Integer.signum(dz);
        totalSteps = Math.max(Math.abs(dx), Math.max(Math.abs(dy), Math.abs(dz)));
        Location gateA = parse(cfg.getString(path + ".gate-a"), world);
        Location gateB = parse(cfg.getString(path + ".gate-b"), world);
        normalize(gateA, gateB, gateBox);
        buildGateCells();

        this.movePeriod = Math.max(1, cfg.getInt(path + ".move-period", 6));
        this.boardCheck = Math.max(1, cfg.getInt(path + ".board-check", 5));
        this.boardHold = cfg.getInt(path + ".board-hold", 40);
        this.storeTime = cfg.getInt(path + ".store-time", 60);
        this.exitCheck = Math.max(1, cfg.getInt(path + ".exit-check", 5));
        this.gateCloseDelay = cfg.getInt(path + ".gate-close-delay", 10);
        this.upWait = cfg.getInt(path + ".up-wait", 60);

        this.storeSound = cfg.getString(path + ".store-sound.sound", "block.respawn_anchor.charge");
        this.storeVolume = (float) cfg.getDouble(path + ".store-sound.volume", 1.0D);
        this.storePitch = (float) cfg.getDouble(path + ".store-sound.pitch", 1.0D);
        this.windSound = cfg.getString(path + ".wind-sound.sound", "tropicalberry:ambience.wind");
        this.windCategory = category(cfg.getString(path + ".wind-sound.category", "master"));
        this.windVolume = (float) Math.min(cfg.getDouble(path + ".wind-sound.volume", 10.0D), 3.0D);
        this.windPitch = (float) cfg.getDouble(path + ".wind-sound.pitch", 0.1D);
        this.windPeriod = Math.max(20, cfg.getInt(path + ".wind-sound.period", 140));
        this.moveSoundEnabled = cfg.getBoolean(path + ".move-sound.enabled", true);
        this.moveSound = cfg.getString(path + ".move-sound.sound", "entity.minecart.riding");
        this.moveVolume = (float) cfg.getDouble(path + ".move-sound.volume", 0.5D);
        this.movePitch = (float) cfg.getDouble(path + ".move-sound.pitch", 0.7D);
        this.moveSoundPeriod = Math.max(1, cfg.getInt(path + ".move-sound.period", 4));
        this.gateOpenSound = cfg.getString(path + ".gate-sound.open", "block.iron_door.open");
        this.gateCloseSound = cfg.getString(path + ".gate-sound.close", "block.iron_door.close");
        this.gateVolume = (float) cfg.getDouble(path + ".gate-sound.volume", 1.0D);
        this.gatePitch = (float) cfg.getDouble(path + ".gate-sound.pitch", 0.8D);
        this.smokeEnabled = cfg.getBoolean(path + ".smoke.enabled", true);
        this.smokeParticle = cfg.getString(path + ".smoke.particle", "SMOKE");
        this.smokeCount = Math.max(1, cfg.getInt(path + ".smoke.count", 4));
        this.smokeStorePeriod = Math.max(1, cfg.getInt(path + ".smoke.store-period", 2));
        this.smokeMovePeriod = Math.max(1, cfg.getInt(path + ".smoke.move-period", 2));
        this.smokeSpread = cfg.getDouble(path + ".smoke.spread", 0.5D);
        this.gateOpen = false;
        loadPosition();
    }

    private void buildGateCells() {
        List<List<int[]>> cols = new ArrayList<>();
        for (int x = gateBox[0]; x <= gateBox[3]; x++) {
            List<int[]> col = new ArrayList<>();
            for (int y = gateBox[1]; y <= gateBox[4]; y++) {
                for (int z = gateBox[2]; z <= gateBox[5]; z++) {
                    col.add(new int[]{x, y, z});
                }
            }
            cols.add(col);
        }
        List<int[]> edge = new ArrayList<>();
        List<int[]> mid = new ArrayList<>();
        int last = cols.size() - 1;
        for (int i = 0; i < cols.size(); i++) {
            if (i == 0 || i == last) {
                edge.addAll(cols.get(i));
            } else {
                mid.addAll(cols.get(i));
            }
        }
        gateCellsClose.clear();
        gateCellsClose.addAll(edge);
        gateCellsClose.addAll(mid);
        gateCellsOpen.clear();
        gateCellsOpen.addAll(mid);
        gateCellsOpen.addAll(edge);
    }

    public String id() {
        return id;
    }

    public boolean isBusy() {
        return state != State.IDLE;
    }

    public boolean isAtTop() {
        return progress <= 0;
    }

    public boolean isAtBottom() {
        return progress >= totalSteps;
    }

    public World world() {
        return Worlds.resolve(worldName);
    }

    public void commandDown() {
        commandDown(false);
    }

    public void commandDown(boolean fast) {
        if (state != State.IDLE || !isAtTop()) {
            return;
        }
        skipBoard = fast;
        state = State.WAIT_TOP;
        timer = 0;
    }

    public void commandUp() {
        commandUp(false);
    }

    public void commandUp(boolean fast) {
        if (state != State.IDLE || !isAtBottom()) {
            return;
        }
        skipBoard = fast;
        openGate();
        state = State.WAIT_BOTTOM;
        timer = upWait;
    }

    public void tick() {
        World world = world();
        if (world == null) {
            return;
        }
        gateTick();
        switch (state) {
            case WAIT_TOP:
                if (skipBoard) {
                    state = State.HOLD_TOP;
                    timer = boardHold;
                    break;
                }
                timer++;
                if (timer % boardCheck == 0 && !playersOnPlatform().isEmpty()) {
                    state = State.HOLD_TOP;
                    timer = boardHold;
                }
                break;
            case HOLD_TOP:
                timer--;
                if (timer <= 0) {
                    storeItems();
                    state = State.STORE;
                    timer = storeTime;
                    smokeClock = 0;
                }
                break;
            case STORE:
                timer--;
                smokeClock++;
                if (smokeEnabled && smokeClock % smokeStorePeriod == 0) {
                    spawnSmoke(cabinCenter());
                }
                if (timer <= 0) {
                    state = State.MOVE_DOWN;
                    moveTicks = 0;
                    windClock = 0;
                    playWind();
                }
                break;
            case MOVE_DOWN:
                windClock++;
                if (windClock % windPeriod == 0) {
                    playWind();
                }
                smokeClock++;
                if (smokeEnabled && smokeClock % smokeMovePeriod == 0) {
                    spawnSmoke(cabinTop());
                }
                moveTicks++;
                if (moveTicks >= movePeriod) {
                    moveTicks = 0;
                    if (progress < totalSteps) {
                        doStep(1);
                    }
                    if (progress >= totalSteps) {
                        stopWind();
                        arriveBottom();
                    }
                }
                break;
            case WAIT_EXIT:
                timer++;
                if (timer % exitCheck == 0 && playersOnPlatform().isEmpty() && gateZoneClear()) {
                    state = State.GATE_CLOSE;
                    timer = gateCloseDelay;
                }
                break;
            case GATE_CLOSE:
                timer--;
                if (timer <= 0) {
                    if (gateZoneClear()) {
                        closeGate();
                        state = State.IDLE;
                        savePosition();
                    } else {
                        state = State.WAIT_EXIT;
                        timer = 0;
                    }
                }
                break;
            case WAIT_BOTTOM:
                if (!skipBoard && playersOnPlatform().isEmpty()) {
                    timer = upWait;
                    break;
                }
                if (timer > 0) {
                    timer--;
                } else if (gateZoneClear()) {
                    closeGate();
                    state = State.GATE_SHUT;
                }
                break;
            case GATE_SHUT:
                if (gateShut()) {
                    state = State.MOVE_UP;
                    moveTicks = 0;
                    windClock = 0;
                    smokeClock = 0;
                    playWind();
                }
                break;
            case MOVE_UP:
                windClock++;
                if (windClock % windPeriod == 0) {
                    playWind();
                }
                smokeClock++;
                if (smokeEnabled && smokeClock % smokeMovePeriod == 0) {
                    spawnSmoke(cabinTop());
                }
                moveTicks++;
                if (moveTicks >= movePeriod) {
                    moveTicks = 0;
                    if (progress > 0) {
                        doStep(-1);
                    }
                    if (progress <= 0) {
                        stopWind();
                        state = State.IDLE;
                        savePosition();
                    }
                }
                break;
            case IDLE:
            default:
                break;
        }
    }

    private void arriveBottom() {
        openGate();
        state = State.WAIT_EXIT;
        timer = 0;
    }

    private void doStep(int sign) {
        World world = world();
        if (world == null) {
            return;
        }
        int[] box = currentBox();
        Vector delta = new Vector(stepVec[0] * sign, stepVec[1] * sign, stepVec[2] * sign);
        int wx = box[3] - box[0] + 1;
        int wy = box[4] - box[1] + 1;
        int wz = box[5] - box[2] + 1;
        BlockData[][][] snapshot = new BlockData[wx][wy][wz];
        for (int x = 0; x < wx; x++) {
            for (int y = 0; y < wy; y++) {
                for (int z = 0; z < wz; z++) {
                    snapshot[x][y][z] = world.getBlockAt(box[0] + x, box[1] + y, box[2] + z).getBlockData();
                }
            }
        }
        List<Entity> riders = collectEntities(box);
        for (int x = 0; x < wx; x++) {
            for (int y = 0; y < wy; y++) {
                for (int z = 0; z < wz; z++) {
                    Block b = world.getBlockAt(box[0] + x, box[1] + y, box[2] + z);
                    if (b.getType() != Material.AIR) {
                        b.setType(Material.AIR, false);
                    }
                }
            }
        }
        progress += sign;
        int[] newBox = currentBox();
        for (int x = 0; x < wx; x++) {
            for (int y = 0; y < wy; y++) {
                for (int z = 0; z < wz; z++) {
                    BlockData data = snapshot[x][y][z];
                    if (data != null && data.getMaterial() != Material.AIR) {
                        world.getBlockAt(newBox[0] + x, newBox[1] + y, newBox[2] + z).setBlockData(data, false);
                    }
                }
            }
        }
        teleportEntities(riders, delta);
        if (moveSoundEnabled && Math.abs(progress) % moveSoundPeriod == 0) {
            world.playSound(cabinCenter(), moveSound, SoundCategory.BLOCKS, moveVolume, movePitch);
        }
    }

    private void storeItems() {
        World world = world();
        if (world == null) {
            return;
        }
        for (Player player : playersOnPlatform()) {
            if (player.getName().equalsIgnoreCase(owner)) {
                continue;
            }
            try {
                PlayerInventory inv = player.getInventory();
                ItemStack[] contents = inv.getContents().clone();
                storage.save(player.getUniqueId(), player.getName(), contents);
                if (storage.has(player.getUniqueId())) {
                    inv.setStorageContents(new ItemStack[36]);
                    inv.setArmorContents(new ItemStack[4]);
                    inv.setExtraContents(new ItemStack[1]);
                }
            } catch (RuntimeException ex) {
                ex.printStackTrace();
            }
        }
        world.playSound(cabinCenter(), storeSound, SoundCategory.MASTER, storeVolume, storePitch);
    }

    private List<Player> playersOnPlatform() {
        List<Player> result = new ArrayList<>();
        World world = world();
        if (world == null) {
            return result;
        }
        int[] box = currentBox();
        for (Entity entity : world.getNearbyEntities(riderBox(box))) {
            if (entity instanceof Player && inRiderArea(entity, box)) {
                result.add((Player) entity);
            }
        }
        return result;
    }

    private boolean gateZoneClear() {
        World world = world();
        if (world == null) {
            return true;
        }
        BoundingBox zone = gateZone();
        for (Entity entity : world.getNearbyEntities(zone)) {
            if (entity instanceof Player && entity.getBoundingBox().overlaps(zone)) {
                return false;
            }
        }
        return true;
    }

    private BoundingBox gateZone() {
        return new BoundingBox(gateBox[0] - 0.5D, gateBox[1] - 0.5D, gateBox[2] - 1.0D,
                gateBox[3] + 1.5D, gateBox[4] + 1.5D, gateBox[5] + 0.5D);
    }

    private void gateTick() {
        if (!gateAnimating) {
            return;
        }
        World world = world();
        if (world == null) {
            gateAnimating = false;
            return;
        }
        if (!gateAnimOpening && !gateZoneClear()) {
            gateOrder = gateCellsOpen;
            gateIndex = 0;
            gateAnimOpening = true;
            if (state == State.IDLE || state == State.GATE_CLOSE) {
                state = State.WAIT_EXIT;
                timer = 0;
            }
            world.playSound(gateCenter(), gateOpenSound, SoundCategory.BLOCKS, gateVolume, gatePitch);
            return;
        }
        if (gateIndex >= gateOrder.size()) {
            gateAnimating = false;
            gateOpen = gateAnimOpening;
            return;
        }
        int[] cell = gateOrder.get(gateIndex);
        Block b = world.getBlockAt(cell[0], cell[1], cell[2]);
        if (gateAnimOpening) {
            if (b.getType() != Material.AIR) {
                b.setType(Material.AIR, false);
            }
        } else {
            placeBars(world, cell[0], cell[1], cell[2]);
        }
        gateIndex++;
    }

    private void placeBars(World world, int x, int y, int z) {
        Block b = world.getBlockAt(x, y, z);
        if (b.getType() != Material.IRON_BARS) {
            b.setType(Material.IRON_BARS, false);
        }
        refreshBars(world, x, y, z);
        refreshBars(world, x + 1, y, z);
        refreshBars(world, x - 1, y, z);
        refreshBars(world, x, y, z + 1);
        refreshBars(world, x, y, z - 1);
    }

    private void refreshBars(World world, int x, int y, int z) {
        Block b = world.getBlockAt(x, y, z);
        if (b.getType() != Material.IRON_BARS) {
            return;
        }
        BlockData data = b.getBlockData();
        if (!(data instanceof MultipleFacing)) {
            return;
        }
        MultipleFacing facing = (MultipleFacing) data;
        for (BlockFace face : facing.getAllowedFaces()) {
            Block n = b.getRelative(face);
            Material m = n.getType();
            boolean connect = m == Material.IRON_BARS || m.isSolid();
            facing.setFace(face, connect);
        }
        b.setBlockData(facing, false);
    }

    private void openGate() {
        World world = world();
        if (world == null) {
            return;
        }
        gateOrder = gateCellsOpen;
        gateIndex = 0;
        gateAnimating = true;
        gateAnimOpening = true;
        world.playSound(gateCenter(), gateOpenSound, SoundCategory.BLOCKS, gateVolume, gatePitch);
    }

    private void closeGate() {
        World world = world();
        if (world == null) {
            return;
        }
        gateOrder = gateCellsClose;
        gateIndex = 0;
        gateAnimating = true;
        gateAnimOpening = false;
        world.playSound(gateCenter(), gateCloseSound, SoundCategory.BLOCKS, gateVolume, gatePitch);
    }

    private boolean gateShut() {
        return !gateAnimating && !gateOpen;
    }

    private List<Entity> collectEntities(int[] box) {
        List<Entity> result = new ArrayList<>();
        World world = world();
        if (world == null) {
            return result;
        }
        for (Entity entity : world.getNearbyEntities(riderBox(box))) {
            if (entity.isInsideVehicle()) {
                continue;
            }
            if (inRiderArea(entity, box)) {
                result.add(entity);
            }
        }
        return result;
    }

    private void teleportEntities(List<Entity> entities, Vector delta) {
        for (Entity entity : entities) {
            if (!entity.isValid() || entity.isDead()) {
                continue;
            }
            entity.teleport(entity.getLocation().add(delta));
            entity.setFallDistance(0.0F);
        }
    }

    private boolean inRiderArea(Entity entity, int[] box) {
        Location l = entity.getLocation();
        double x = l.getX();
        double y = l.getY();
        double z = l.getZ();
        return x >= box[0] && x <= box[3] + 1 && z >= box[2] && z <= box[5] + 1
                && y >= box[4] + 0.4D && y <= box[4] + 3.0D;
    }

    private void playWind() {
        World world = world();
        if (world == null) {
            return;
        }
        world.playSound(cabinCenter(), windSound, windCategory, windVolume, windPitch);
    }

    private void stopWind() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.stopSound(windSound, windCategory);
        }
    }

    private void spawnSmoke(Location at) {
        World world = world();
        if (world == null) {
            return;
        }
        Particle particle;
        try {
            particle = Particle.valueOf(smokeParticle.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            particle = Particle.SMOKE;
        }
        double s = smokeSpread;
        world.spawnParticle(particle, at, smokeCount, s, s, s, 0.01D);
    }

    private int[] currentBox() {
        return new int[]{
                topBox[0] + stepVec[0] * progress, topBox[1] + stepVec[1] * progress, topBox[2] + stepVec[2] * progress,
                topBox[3] + stepVec[0] * progress, topBox[4] + stepVec[1] * progress, topBox[5] + stepVec[2] * progress
        };
    }

    private BoundingBox riderBox(int[] box) {
        return new BoundingBox(box[0], box[1], box[2], box[3] + 1, box[4] + 3, box[5] + 1);
    }

    private Location cabinCenter() {
        int[] box = currentBox();
        return new Location(world(), (box[0] + box[3] + 1) / 2.0D, box[4] + 1.0D, (box[2] + box[5] + 1) / 2.0D);
    }

    private Location cabinTop() {
        int[] box = currentBox();
        return new Location(world(), (box[0] + box[3] + 1) / 2.0D, box[4] + 1.0D, (box[2] + box[5] + 1) / 2.0D);
    }

    private Location gateCenter() {
        return new Location(world(), (gateBox[0] + gateBox[3] + 1) / 2.0D, (gateBox[1] + gateBox[4] + 1) / 2.0D, (gateBox[2] + gateBox[5] + 1) / 2.0D);
    }

    public void restore() {
        World world = world();
        if (world == null) {
            return;
        }
        state = State.IDLE;
        gateAnimating = false;
        for (int[] cell : gateCellsClose) {
            placeBars(world, cell[0], cell[1], cell[2]);
        }
        gateOpen = false;
    }

    public void stop() {
        stopWind();
        state = State.IDLE;
        savePosition();
    }

    private void loadPosition() {
        File file = new File(plugin.getDataFolder(), "liftstate.yml");
        if (file.exists()) {
            YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
            progress = cfg.getInt("lifts." + id + ".progress", 0);
        }
        if (progress < 0) {
            progress = 0;
        }
        if (progress > totalSteps) {
            progress = totalSteps;
        }
    }

    private void savePosition() {
        File file = new File(plugin.getDataFolder(), "liftstate.yml");
        YamlConfiguration cfg = file.exists() ? YamlConfiguration.loadConfiguration(file) : new YamlConfiguration();
        cfg.set("lifts." + id + ".progress", progress);
        try {
            cfg.save(file);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public String statusLine() {
        String pos = isAtTop() ? "top" : (isAtBottom() ? "bottom" : "moving");
        return "lift " + id + ": " + pos + ", " + state.name().toLowerCase(Locale.ROOT);
    }

    private static void normalize(Location a, Location b, int[] out) {
        out[0] = Math.min(a.getBlockX(), b.getBlockX());
        out[1] = Math.min(a.getBlockY(), b.getBlockY());
        out[2] = Math.min(a.getBlockZ(), b.getBlockZ());
        out[3] = Math.max(a.getBlockX(), b.getBlockX());
        out[4] = Math.max(a.getBlockY(), b.getBlockY());
        out[5] = Math.max(a.getBlockZ(), b.getBlockZ());
    }

    private static Location parse(String raw, World world) {
        if (raw == null || raw.trim().isEmpty()) {
            throw new IllegalArgumentException("Missing position");
        }
        String[] parts = raw.trim().split("\\s+");
        if (parts.length < 3) {
            throw new IllegalArgumentException("Bad position: " + raw);
        }
        return new Location(world, Double.parseDouble(parts[0]), Double.parseDouble(parts[1]), Double.parseDouble(parts[2]));
    }

    private static SoundCategory category(String raw) {
        if (raw == null) {
            return SoundCategory.MASTER;
        }
        try {
            return SoundCategory.valueOf(raw.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return SoundCategory.MASTER;
        }
    }
}
