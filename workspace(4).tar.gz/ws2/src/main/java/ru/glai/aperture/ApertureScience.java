package ru.glai.aperture;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Openable;
import org.bukkit.block.data.type.Switch;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.BoundingBox;

public final class ApertureScience extends JavaPlugin implements Listener, TabExecutor {

    private static final String PERMISSION = "aperturescience.admin";

    private final Map<String, Elevator> elevators = new LinkedHashMap<>();
    private final Map<String, VerticalLift> verticalLifts = new LinkedHashMap<>();
    private final Map<String, Location> doors = new LinkedHashMap<>();
    private final Set<UUID> flagged = new HashSet<>();

    private ItemStorage storage;
    private Items items;
    private ButtonManager buttonManager;
    private FluidSystem fluids;
    private CubeManager cubes;
    private PortalManager portals;
    private String owner = "MrBaGued";
    private boolean adventureEnabled;
    private BoundingBox adventureRegion;
    private String adventureWorld;
    private boolean active;
    private int tickerId = -1;
    private int regionClock;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        storage = new ItemStorage(this);
        items = new Items(this);
        buttonManager = new ButtonManager(this, items);
        buttonManager.load();
        fluids = new FluidSystem(this, items);
        fluids.load();
        cubes = new CubeManager(this);
        cubes.load();
        portals = new PortalManager(this, cubes);
        owner = getConfig().getString("owner", "MrBaGued");
        loadElevators();
        loadVerticalLifts();
        loadDoors();
        loadAdventure();
        loadFlagged();
        PluginCommand command = getCommand("aps");
        if (command != null) {
            command.setExecutor(this);
            command.setTabCompleter(this);
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getPluginManager().registerEvents(new ButtonListener(this, buttonManager, items), this);
        Bukkit.getPluginManager().registerEvents(new FluidListener(fluids, items), this);
        active = true;
        tickerId = Bukkit.getScheduler().runTaskTimer(this, this::tickAll, 1L, 1L).getTaskId();
        Bukkit.getScheduler().runTaskLater(this, this::restoreAll, 5L);
    }

    @Override
    public void onDisable() {
        if (tickerId != -1) {
            Bukkit.getScheduler().cancelTask(tickerId);
            tickerId = -1;
        }
        Bukkit.getScheduler().cancelTasks(this);
        for (Elevator elevator : elevators.values()) {
            elevator.stop();
        }
        for (VerticalLift lift : verticalLifts.values()) {
            lift.stop();
        }
        if (buttonManager != null) {
            buttonManager.shutdown();
        }
        saveFlagged();
        active = false;
    }

    private void loadElevators() {
        elevators.clear();
        ConfigurationSection section = getConfig().getConfigurationSection("elevators");
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            try {
                ElevatorConfig config = new ElevatorConfig(key, getConfig(), "elevators." + key);
                elevators.put(key.toLowerCase(Locale.ROOT), new Elevator(this, config, section.getBoolean(key + ".enabled", true)));
            } catch (RuntimeException ex) {
                getLogger().warning("Lift " + key + " not loaded: " + ex.getMessage());
            }
        }
    }

    private void loadVerticalLifts() {
        verticalLifts.clear();
        ConfigurationSection section = getConfig().getConfigurationSection("vertical-lifts");
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            try {
                verticalLifts.put(key.toLowerCase(Locale.ROOT), new VerticalLift(this, storage, key, getConfig(), "vertical-lifts." + key, owner));
            } catch (RuntimeException ex) {
                getLogger().warning("Vertical lift " + key + " not loaded: " + ex.getMessage());
            }
        }
    }

    private void loadDoors() {
        doors.clear();
        ConfigurationSection section = getConfig().getConfigurationSection("doors");
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            String worldName = section.getString(key + ".world", "world");
            String raw = section.getString(key + ".location");
            World world = Worlds.resolve(worldName);
            if (world == null || raw == null) {
                continue;
            }
            try {
                doors.put(key.toLowerCase(Locale.ROOT), parseLocation(raw, world));
            } catch (RuntimeException ex) {
                getLogger().warning("Door " + key + " not loaded: " + ex.getMessage());
            }
        }
    }

    private void loadAdventure() {
        adventureEnabled = getConfig().getBoolean("adventure.enabled", true);
        adventureWorld = getConfig().getString("adventure.world", "world");
        String a = getConfig().getString("adventure.region-a");
        String b = getConfig().getString("adventure.region-b");
        World world = Worlds.resolve(adventureWorld);
        if (world == null || a == null || b == null) {
            adventureRegion = null;
            return;
        }
        try {
            Location pa = parseLocation(a, world);
            Location pb = parseLocation(b, world);
            double minX = Math.min(pa.getX(), pb.getX());
            double minY = Math.min(pa.getY(), pb.getY());
            double minZ = Math.min(pa.getZ(), pb.getZ());
            double maxX = Math.max(pa.getX(), pb.getX()) + 1.0D;
            double maxY = Math.max(pa.getY(), pb.getY()) + 1.0D;
            double maxZ = Math.max(pa.getZ(), pb.getZ()) + 1.0D;
            adventureRegion = new BoundingBox(minX, minY, minZ, maxX, maxY, maxZ);
        } catch (RuntimeException ex) {
            adventureRegion = null;
        }
    }

    private void loadFlagged() {
        flagged.clear();
        File file = new File(getDataFolder(), "adventure.yml");
        if (!file.exists()) {
            return;
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        for (String line : cfg.getStringList("flagged")) {
            try {
                flagged.add(UUID.fromString(line));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void saveFlagged() {
        File file = new File(getDataFolder(), "adventure.yml");
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        List<String> list = new ArrayList<>();
        for (UUID id : flagged) {
            list.add(id.toString());
        }
        cfg.set("flagged", list);
        try {
            cfg.save(file);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void tickAll() {
        for (Elevator elevator : elevators.values()) {
            elevator.tick();
        }
        for (VerticalLift lift : verticalLifts.values()) {
            lift.tick();
        }
        if (buttonManager != null) {
            buttonManager.tick();
        }
        if (fluids != null) {
            fluids.tick();
        }
        regionClock++;
        if (regionClock >= 10) {
            regionClock = 0;
            checkAdventure();
        }
    }

    private void checkAdventure() {
        if (!adventureEnabled || adventureRegion == null) {
            return;
        }
        World world = Worlds.resolve(adventureWorld);
        if (world == null) {
            return;
        }
        for (Player player : world.getPlayers()) {
            if (player.getName().equalsIgnoreCase(owner)) {
                continue;
            }
            if (flagged.contains(player.getUniqueId())) {
                continue;
            }
            if (player.getBoundingBox().overlaps(adventureRegion)) {
                player.setGameMode(GameMode.ADVENTURE);
                flagged.add(player.getUniqueId());
                saveFlagged();
            }
        }
    }

    private void restoreAll() {
        for (Elevator elevator : elevators.values()) {
            elevator.restore();
        }
        for (VerticalLift lift : verticalLifts.values()) {
            lift.restore();
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission(PERMISSION)) {
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage("usage /" + label + " on off status itemsback <lift> <...> <door> <open close>");
            return true;
        }
        String first = args[0].toLowerCase(Locale.ROOT);
        if (first.equals("on")) {
            active = true;
            if (tickerId == -1) {
                tickerId = Bukkit.getScheduler().runTaskTimer(this, this::tickAll, 1L, 1L).getTaskId();
            }
            sender.sendMessage("plugin on");
            return true;
        }
        if (first.equals("off")) {
            active = false;
            sender.sendMessage("plugin off, running actions will finish");
            return true;
        }
        if (first.equals("status")) {
            sender.sendMessage("plugin: " + (active ? "on" : "off"));
            for (Elevator elevator : elevators.values()) {
                sender.sendMessage(elevator.statusLine());
            }
            for (VerticalLift lift : verticalLifts.values()) {
                sender.sendMessage(lift.statusLine());
            }
            return true;
        }
        if (first.equals("itemsback")) {
            handleItemsBack(sender, args);
            return true;
        }
        if (first.equals("item")) {
            handleItem(sender, label, args);
            return true;
        }
        if (first.equals("button")) {
            handleButtonCommand(sender, label, args);
            return true;
        }
        if (first.equals("create")) {
            handleCreate(sender, label, args);
            return true;
        }
        if (first.equals("pump")) {
            handlePumpCommand(sender, label, args);
            return true;
        }
        if (first.equals("pipe")) {
            handlePipeCommand(sender, label, args);
            return true;
        }
        Elevator elevator = elevators.get(first);
        if (elevator != null) {
            handleElevator(sender, label, elevator, args);
            return true;
        }
        VerticalLift lift = verticalLifts.get(first);
        if (lift != null) {
            handleVertical(sender, lift, args);
            return true;
        }
        Location door = doors.get(first);
        if (door != null) {
            handleDoor(sender, door, args);
            return true;
        }
        sender.sendMessage("device " + first + " not found");
        return true;
    }

    private void handleElevator(CommandSender sender, String label, Elevator elevator, String[] args) {
        String second = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "";
        if (second.equals("on")) {
            elevator.setEnabled(true);
            sender.sendMessage("lift " + elevator.id() + " on");
            return;
        }
        if (second.equals("off")) {
            elevator.setEnabled(false);
            sender.sendMessage("lift " + elevator.id() + " off");
            return;
        }
        if (second.equals("start")) {
            if (!active) {
                sender.sendMessage("plugin is off");
                return;
            }
            if (elevator.isRunning()) {
                sender.sendMessage("lift " + elevator.id() + " is busy");
                return;
            }
            String mod = args.length > 2 ? args[2].toLowerCase(Locale.ROOT) : "";
            boolean waitHome = true;
            boolean waitFar = true;
            if (mod.equals("fast")) {
                waitHome = false;
                waitFar = false;
            } else if (mod.equals("nohome")) {
                waitHome = false;
            } else if (mod.equals("nofar")) {
                waitFar = false;
            } else if (!mod.isEmpty()) {
                sender.sendMessage("usage /" + label + " " + elevator.id() + " start <fast nohome nofar>");
                return;
            }
            elevator.remoteStart(waitHome, waitFar);
            sender.sendMessage("lift " + elevator.id() + " started");
            return;
        }
        sender.sendMessage("usage /" + label + " " + elevator.id() + " <on off start>");
    }

    private void handleVertical(CommandSender sender, VerticalLift lift, String[] args) {
        String second = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "";
        boolean fast = args.length > 2 && args[2].equalsIgnoreCase("fast");
        if (!active) {
            sender.sendMessage("plugin is off");
            return;
        }
        if (second.equals("down")) {
            if (lift.isBusy()) {
                sender.sendMessage("lift " + lift.id() + " is busy");
                return;
            }
            if (!lift.isAtTop()) {
                sender.sendMessage("lift " + lift.id() + " is not at top");
                return;
            }
            lift.commandDown(fast);
            sender.sendMessage("lift " + lift.id() + " going down");
            return;
        }
        if (second.equals("up")) {
            if (lift.isBusy()) {
                sender.sendMessage("lift " + lift.id() + " is busy");
                return;
            }
            if (!lift.isAtBottom()) {
                sender.sendMessage("lift " + lift.id() + " is not at bottom");
                return;
            }
            lift.commandUp(fast);
            sender.sendMessage("lift " + lift.id() + " going up");
            return;
        }
        sender.sendMessage("usage /asm " + lift.id() + " <up down> [fast]");
    }

    private void handleDoor(CommandSender sender, Location door, String[] args) {
        String second = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "";
        if (second.equals("open")) {
            setDoor(door, true);
            sender.sendMessage("door open");
            return;
        }
        if (second.equals("close")) {
            setDoor(door, false);
            sender.sendMessage("door close");
            return;
        }
        sender.sendMessage("usage /asm <door> <open close>");
    }

    private void handleItemsBack(CommandSender sender, String[] args) {
        Player target;
        if (args.length > 1) {
            target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage("player offline");
                return;
            }
        } else if (sender instanceof Player) {
            target = (Player) sender;
        } else {
            sender.sendMessage("specify a player");
            return;
        }
        if (!storage.has(target.getUniqueId())) {
            sender.sendMessage("у игрока не забирали вещи");
            return;
        }
        ItemStack[] items = storage.load(target.getUniqueId());
        if (items == null) {
            sender.sendMessage("у игрока не забирали вещи");
            return;
        }
        giveItems(target, items);
        storage.remove(target.getUniqueId());
        sender.sendMessage("items returned to " + target.getName());
    }

    private void handleItem(CommandSender sender, String label, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("usage /" + label + " item <button wrench detector portal_gun> [player]");
            return;
        }
        String kind = args[1].toLowerCase(Locale.ROOT);
        if (!items.kinds().contains(kind)) {
            sender.sendMessage("unknown item " + kind);
            return;
        }
        Player target;
        if (args.length > 2) {
            target = Bukkit.getPlayerExact(args[2]);
            if (target == null) {
                sender.sendMessage("player offline");
                return;
            }
        } else if (sender instanceof Player) {
            target = (Player) sender;
        } else {
            sender.sendMessage("specify a player");
            return;
        }
        ItemStack item = items.create(kind);
        if (item == null) {
            sender.sendMessage("cannot create item");
            return;
        }
        for (ItemStack rest : target.getInventory().addItem(item).values()) {
            target.getWorld().dropItemNaturally(target.getLocation(), rest);
        }
        sender.sendMessage("item " + kind + " given to " + target.getName());
    }

    private void handleButtonCommand(CommandSender sender, String label, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("usage /" + label + " button <number> <delete rename enable disable options>");
            return;
        }
        int number;
        try {
            number = Integer.parseInt(args[1]);
        } catch (NumberFormatException ex) {
            sender.sendMessage("number required");
            return;
        }
        WirelessButton button = buttonManager.button(number);
        if (button == null) {
            sender.sendMessage("button " + number + " not found");
            return;
        }
        String action = args[2].toLowerCase(Locale.ROOT);
        if (action.equals("delete")) {
            buttonManager.deleteButton(number);
            sender.sendMessage("button " + number + " deleted");
            return;
        }
        if (action.equals("rename")) {
            if (args.length < 4) {
                sender.sendMessage("usage /" + label + " button " + number + " rename <name>");
                return;
            }
            StringBuilder sb = new StringBuilder();
            for (int i = 3; i < args.length; i++) {
                if (i > 3) {
                    sb.append(' ');
                }
                sb.append(args[i]);
            }
            button.name = sb.toString();
            buttonManager.save();
            sender.sendMessage("button " + number + " renamed");
            return;
        }
        if (action.equals("enable")) {
            button.enabled = true;
            buttonManager.save();
            sender.sendMessage("button " + number + " enabled");
            return;
        }
        if (action.equals("disable")) {
            button.enabled = false;
            buttonManager.setActive(button, false, -1L);
            buttonManager.save();
            sender.sendMessage("button " + number + " disabled");
            return;
        }
        if (action.equals("options")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("player only");
                return;
            }
            WrenchMenu menu = new WrenchMenu(buttonManager, button, null);
            ((Player) sender).openInventory(menu.getInventory());
            return;
        }
        sender.sendMessage("usage /" + label + " button <number> <delete rename enable disable options>");
    }

    private void handleCreate(CommandSender sender, String label, String[] args) {
        if (args.length < 7 || !args[1].equalsIgnoreCase("button")) {
            sender.sendMessage("usage /" + label + " create button <number> <x y z> <+x -x +z -z>");
            return;
        }
        int number;
        int x;
        int y;
        int z;
        try {
            number = Integer.parseInt(args[2]);
            x = (int) Math.floor(Double.parseDouble(args[3]));
            y = (int) Math.floor(Double.parseDouble(args[4]));
            z = (int) Math.floor(Double.parseDouble(args[5]));
        } catch (NumberFormatException ex) {
            sender.sendMessage("bad number or coordinates");
            return;
        }
        if (buttonManager.button(number) != null) {
            sender.sendMessage("number " + number + " already used");
            return;
        }
        float yaw;
        String facing = args[6].toLowerCase(Locale.ROOT);
        if (facing.equals("+x")) {
            yaw = 270.0F;
        } else if (facing.equals("-x")) {
            yaw = 90.0F;
        } else if (facing.equals("-z")) {
            yaw = 180.0F;
        } else if (facing.equals("+z")) {
            yaw = 0.0F;
        } else {
            sender.sendMessage("facing must be +x -x +z -z");
            return;
        }
        World world;
        if (sender instanceof Player) {
            world = ((Player) sender).getWorld();
        } else {
            world = Bukkit.getWorlds().isEmpty() ? null : Bukkit.getWorlds().get(0);
        }
        if (world == null) {
            sender.sendMessage("world not found");
            return;
        }
        WirelessButton button = buttonManager.createButton(number, "button " + number, world, x, y, z, yaw);
        if (button == null) {
            sender.sendMessage("cannot create button");
            return;
        }
        sender.sendMessage("button " + number + " created at " + x + " " + y + " " + z);
    }

    private void handlePumpCommand(CommandSender sender, String label, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("usage /" + label + " pump <number> <options enable disable group mode> | group <name> <on off start stop>");
            return;
        }
        if (args[1].equalsIgnoreCase("group")) {
            handlePumpGroup(sender, label, args);
            return;
        }
        int number;
        try {
            number = Integer.parseInt(args[1]);
        } catch (NumberFormatException ex) {
            sender.sendMessage("number required");
            return;
        }
        FluidSystem.Pump pump = fluids.pump(number);
        if (pump == null) {
            sender.sendMessage("pump " + number + " not found");
            return;
        }
        if (args.length < 3) {
            sender.sendMessage("pump " + number + ": mode " + pump.mode.name().toLowerCase()
                + ", " + (pump.enabled ? "enabled" : "disabled")
                + ", group " + (pump.group.isEmpty() ? "none" : pump.group));
            return;
        }
        String action = args[2].toLowerCase(Locale.ROOT);
        if (action.equals("options")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("player only");
                return;
            }
            ((Player) sender).openInventory(new PumpMenu(fluids, pump).getInventory());
            return;
        }
        if (action.equals("enable")) {
            pump.enabled = true;
            fluids.save();
            sender.sendMessage("pump " + number + " enabled");
            return;
        }
        if (action.equals("disable")) {
            pump.enabled = false;
            fluids.save();
            sender.sendMessage("pump " + number + " disabled");
            return;
        }
        if (action.equals("mode")) {
            if (args.length < 4) {
                sender.sendMessage("usage /" + label + " pump " + number + " mode <push suck off>");
                return;
            }
            String m = args[3].toLowerCase(Locale.ROOT);
            if (m.equals("push")) {
                pump.mode = FluidSystem.Mode.PUSH;
            } else if (m.equals("suck") || m.equals("pull")) {
                pump.mode = FluidSystem.Mode.SUCK;
            } else if (m.equals("off")) {
                pump.mode = FluidSystem.Mode.OFF;
            } else {
                sender.sendMessage("mode must be push suck off");
                return;
            }
            fluids.save();
            sender.sendMessage("pump " + number + " mode " + pump.mode.name().toLowerCase());
            return;
        }
        if (action.equals("group")) {
            if (args.length < 4) {
                sender.sendMessage("pump " + number + " group: " + (pump.group.isEmpty() ? "none" : pump.group));
                return;
            }
            String sub = args[3].toLowerCase(Locale.ROOT);
            if (sub.equals("delete") || sub.equals("remove") || sub.equals("none") || sub.equals("clear")) {
                pump.group = "";
                fluids.save();
                sender.sendMessage("pump " + number + " removed from group");
                return;
            }
            String name;
            if (sub.equals("add") || sub.equals("set")) {
                if (args.length < 5) {
                    sender.sendMessage("usage /" + label + " pump " + number + " group add <name>");
                    return;
                }
                name = args[4];
            } else {
                name = args[3];
            }
            pump.group = name;
            if (!fluids.groupNames().contains(name.toLowerCase(Locale.ROOT))) {
                fluids.groupSetRunning(name, false);
            }
            fluids.save();
            sender.sendMessage("pump " + number + " group " + name);
            return;
        }
        sender.sendMessage("usage /" + label + " pump " + number + " <options enable disable group mode>");
    }

    private void handlePumpGroup(CommandSender sender, String label, String[] args) {
        if (args.length < 4) {
            sender.sendMessage("usage /" + label + " pump group <name> <on off start [seconds] stop list>");
            return;
        }
        String name = args[2];
        String lower = name.toLowerCase(Locale.ROOT);
        String action = args[3].toLowerCase(Locale.ROOT);
        if (action.equals("list")) {
            List<FluidSystem.Pump> members = fluids.groupMembers(name);
            if (members.isEmpty()) {
                sender.sendMessage("group " + name + " has no pumps");
            } else {
                StringBuilder sb = new StringBuilder("group " + name + " (" + (fluids.groupRunning(name) ? "running" : "stopped") + "):");
                for (FluidSystem.Pump p : members) {
                    sb.append(' ').append(p.number);
                }
                sender.sendMessage(sb.toString());
            }
            return;
        }
        if (!fluids.groupNames().contains(lower)) {
            fluids.groupSetRunning(name, false);
        }
        if (action.equals("on") || action.equals("start")) {
            fluids.groupSetRunning(name, true);
            sender.sendMessage("group " + name + " started");
            if (action.equals("start") && args.length >= 5) {
                int seconds;
                try {
                    seconds = Integer.parseInt(args[4]);
                } catch (NumberFormatException ex) {
                    sender.sendMessage("seconds must be a number");
                    return;
                }
                if (seconds > 0) {
                    final String fname = name;
                    Bukkit.getScheduler().runTaskLater(this, () -> {
                        fluids.groupSetRunning(fname, false);
                        Bukkit.getConsoleSender().sendMessage("group " + fname + " stopped");
                    }, seconds * 20L);
                }
            }
            return;
        }
        if (action.equals("off") || action.equals("stop")) {
            fluids.groupSetRunning(name, false);
            sender.sendMessage("group " + name + " stopped");
            return;
        }
        sender.sendMessage("usage /" + label + " pump group " + name + " <on off start [seconds] stop list>");
    }

    private void handlePipeCommand(CommandSender sender, String label, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("usage /" + label + " pipe <number> <delete>");
            return;
        }
        int number;
        try {
            number = Integer.parseInt(args[1]);
        } catch (NumberFormatException ex) {
            sender.sendMessage("number required");
            return;
        }
        String action = args[2].toLowerCase(Locale.ROOT);
        if (action.equals("delete")) {
            if (fluids.deletePipe(number)) {
                sender.sendMessage("pipe " + number + " deleted");
            } else {
                sender.sendMessage("pipe " + number + " not found");
            }
            return;
        }
        sender.sendMessage("usage /" + label + " pipe " + number + " <delete>");
    }

    private void giveItems(Player player, ItemStack[] items) {
        org.bukkit.inventory.PlayerInventory inv = player.getInventory();
        ItemStack[] current = inv.getContents();
        boolean empty = true;
        for (ItemStack it : current) {
            if (it != null && it.getType() != Material.AIR) {
                empty = false;
                break;
            }
        }
        if (empty && items.length == current.length) {
            inv.setContents(items);
            return;
        }
        for (ItemStack item : items) {
            if (item == null || item.getType() == Material.AIR) {
                continue;
            }
            Map<Integer, ItemStack> left = inv.addItem(item);
            for (ItemStack remainder : left.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), remainder);
            }
        }
    }

    private void setDoor(Location location, boolean open) {
        World world = location.getWorld();
        if (world == null) {
            return;
        }
        Block bottom = world.getBlockAt(location.getBlockX(), location.getBlockY(), location.getBlockZ());
        BlockData data = bottom.getBlockData();
        if (data instanceof Openable) {
            Openable openable = (Openable) data;
            if (openable.isOpen() != open) {
                openable.setOpen(open);
                bottom.setBlockData(openable, false);
                world.playSound(bottom.getLocation(), open ? Sound.BLOCK_IRON_DOOR_OPEN : Sound.BLOCK_IRON_DOOR_CLOSE, SoundCategory.BLOCKS, 1.0F, 1.0F);
            }
            Block top = world.getBlockAt(location.getBlockX(), location.getBlockY() + 1, location.getBlockZ());
            BlockData topData = top.getBlockData();
            if (topData instanceof Openable) {
                Openable topOpenable = (Openable) topData;
                if (topOpenable.isOpen() != open) {
                    topOpenable.setOpen(open);
                    top.setBlockData(topOpenable, false);
                }
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission(PERMISSION)) {
            return new ArrayList<>();
        }
        if (args.length == 1) {
            List<String> base = new ArrayList<>(Arrays.asList("on", "off", "status", "itemsback", "item", "button", "create"));
            base.addAll(elevators.keySet());
            base.addAll(verticalLifts.keySet());
            base.addAll(doors.keySet());
            return filter(base, args[0]);
        }
        if (args.length == 2) {
            String name = args[0].toLowerCase(Locale.ROOT);
            if (name.equals("item")) {
                return filter(items.kinds(), args[1]);
            }
            if (name.equals("create")) {
                return filter(Arrays.asList("button"), args[1]);
            }
            if (name.equals("button")) {
                List<String> numbers = new ArrayList<>();
                for (Integer n : buttonManager.buttons().keySet()) {
                    numbers.add(String.valueOf(n));
                }
                return filter(numbers, args[1]);
            }
            if (elevators.containsKey(name)) {
                return filter(Arrays.asList("on", "off", "start"), args[1]);
            }
            if (verticalLifts.containsKey(name)) {
                return filter(Arrays.asList("up", "down"), args[1]);
            }
            if (doors.containsKey(name)) {
                return filter(Arrays.asList("open", "close"), args[1]);
            }
        }
        if (args.length == 3) {
            String name = args[0].toLowerCase(Locale.ROOT);
            String action = args[1].toLowerCase(Locale.ROOT);
            if (name.equals("button")) {
                return filter(Arrays.asList("delete", "rename", "enable", "disable", "options"), args[2]);
            }
            if (elevators.containsKey(name) && action.equals("start")) {
                return filter(Arrays.asList("fast", "nohome", "nofar"), args[2]);
            }
            if (verticalLifts.containsKey(name) && (action.equals("up") || action.equals("down"))) {
                return filter(Arrays.asList("fast"), args[2]);
            }
        }
        if (args.length == 7 && args[1].equalsIgnoreCase("button")) {
            return filter(Arrays.asList("+x", "-x", "+z", "-z"), args[6]);
        }
        return new ArrayList<>();
    }

    private List<String> filter(List<String> source, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        List<String> result = new ArrayList<>();
        for (String value : source) {
            if (value.toLowerCase(Locale.ROOT).startsWith(lower)) {
                result.add(value);
            }
        }
        return result;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_BLOCK && action != Action.LEFT_CLICK_BLOCK) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null || !(block.getBlockData() instanceof Switch)) {
            return;
        }
        for (Elevator elevator : elevators.values()) {
            if (!elevator.isButton(block.getLocation())) {
                continue;
            }
            event.setCancelled(true);
            if (action == Action.RIGHT_CLICK_BLOCK) {
                playClick(block);
                if (active) {
                    elevator.pressButton();
                }
            }
            return;
        }
    }

    private void playClick(Block block) {
        Material material = block.getType();
        Sound sound = material == Material.STONE_BUTTON || material == Material.POLISHED_BLACKSTONE_BUTTON
                ? Sound.BLOCK_STONE_BUTTON_CLICK_ON
                : Sound.BLOCK_WOODEN_BUTTON_CLICK_ON;
        block.getWorld().playSound(block.getLocation(), sound, SoundCategory.BLOCKS, 0.6F, 1.0F);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        for (Elevator elevator : elevators.values()) {
            elevator.playerJoined(player);
        }
    }

    private static Location parseLocation(String raw, World world) {
        String[] parts = raw.trim().split("\\s+");
        if (parts.length < 3) {
            throw new IllegalArgumentException("Bad position: " + raw);
        }
        return new Location(world, Double.parseDouble(parts[0]), Double.parseDouble(parts[1]), Double.parseDouble(parts[2]));
    }
}
