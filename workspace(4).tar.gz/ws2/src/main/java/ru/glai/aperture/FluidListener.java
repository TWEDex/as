package ru.glai.aperture;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public final class FluidListener implements Listener {

    private final FluidSystem fluids;
    private final Items items;

    public FluidListener(FluidSystem fluids, Items items) {
        this.fluids = fluids;
        this.items = items;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null) {
            return;
        }
        Player player = event.getPlayer();
        ItemStack hand = player.getInventory().getItemInMainHand();
        String kind = items.kindOf(hand);

        if (Items.KIND_PUMP.equals(kind)) {
            Block target = block.getRelative(event.getBlockFace());
            if (!target.getType().isAir() && !isReplaceable(target.getType())) {
                player.sendMessage("место занято");
                event.setCancelled(true);
                return;
            }
            event.setCancelled(true);
            FluidSystem.Pump pump = fluids.placePump(player, target);
            consume(hand, player);
            player.sendMessage("насос " + pump.number + " установлен");
            return;
        }
        if (Items.KIND_ACID.equals(kind)) {
            Block target = block.getRelative(event.getBlockFace());
            if (!target.getType().isAir() && !isReplaceable(target.getType())) {
                player.sendMessage("место занято");
                event.setCancelled(true);
                return;
            }
            event.setCancelled(true);
            fluids.placeAcid(target);
            consume(hand, player);
            player.sendMessage("кислота вылита");
            return;
        }

        FluidSystem.Pump placed = fluids.pumpAt(block.getLocation());
        if (placed != null) {
            event.setCancelled(true);
            if (Items.KIND_WRENCH.equals(kind)) {
                player.openInventory(new PumpMenu(fluids, placed).getInventory());
            }
        }
    }

    private static boolean isReplaceable(Material m) {
        return m == Material.WATER || m == Material.LAVA || m == Material.TALL_GRASS
            || m == Material.SHORT_GRASS || m == Material.SNOW;
    }

    private void consume(ItemStack hand, Player player) {
        if (hand.getAmount() <= 1) {
            player.getInventory().setItemInMainHand(null);
        } else {
            hand.setAmount(hand.getAmount() - 1);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        Material type = block.getType();
        Player player = event.getPlayer();
        boolean admin = player.hasPermission("aperturescience.admin");

        if (type == Material.DISPENSER) {
            FluidSystem.Pump pump = fluids.pumpAt(block.getLocation());
            if (pump != null) {
                event.setCancelled(true);
                if (admin) {
                    fluids.deletePump(pump.number);
                    player.sendMessage("насос " + pump.number + " удален");
                }
                return;
            }
        }
        if (type == Material.WATER) {
            String key = FluidSystem.blockKey(block.getLocation());
            if (fluids.isAcid(key)) {
                fluids.removeAcid(key);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onFlow(BlockFromToEvent event) {
        if (fluids.isAcid(event.getBlock().getLocation())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpread(BlockSpreadEvent event) {
        if (fluids.isAcid(event.getSource().getLocation())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof PumpMenu)) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        event.setCancelled(true);
        ((PumpMenu) holder).handleClick((Player) event.getWhoClicked(), event.getRawSlot(), event.isShiftClick());
    }
}
