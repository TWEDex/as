package ru.glai.aperture;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.Powerable;
import org.bukkit.block.data.type.Switch;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class ButtonManager {

    private final JavaPlugin plugin;
    private final Items items;
    private final Map<Integer, WirelessButton> buttons = new LinkedHashMap<>();
    private final List<DetectorData> detectors = new ArrayList<>();

    private String pressSound = "block.wooden_button.click_on";
    private String tickSound = "block.note_block.hat";
    private float soundVolume = 0.8F;
    private float soundPitch = 1.0F;

    private long clock;

    public ButtonManager(JavaPlugin plugin, Items items) {
        this.plugin = plugin;
        this.items = items;
        readSettings();
    }

    private void readSettings() {
        pressSound = plugin.getConfig().getString("wireless.press-sound", pressSound);
        tickSound = plugin.getConfig().getString("wireless.tick-sound", tickSound);
        soundVolume = (float) plugin.getConfig().getDouble("wireless.sound-volume", soundVolume);
        soundPitch = (float) plugin.getConfig().getDouble("wireless.sound-pitch", soundPitch);
    }

    public void load() {
        buttons.clear();
        detectors.clear();
        File file = new File(plugin.getDataFolder(), "buttons.yml");
        if (!file.exists()) {
            return;
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection bs = cfg.getConfigurationSection("buttons");
        if (bs != null) {
            for (String key : bs.getKeys(false)) {
                int number;
                try {
                    number = Integer.parseInt(key);
                } catch (NumberFormatException ex) {
                    continue;
                }
                String worldName = bs.getString(key + ".world", "world");
                int x = bs.getInt(key + ".x");
                int y = bs.getInt(key + ".y");
                int z = bs.getInt(key + ".z");
                float yaw = (float) bs.getDouble(key + ".yaw", 0.0D);
                WirelessButton button = new WirelessButton(number, bs.getString(key + ".name", "button " + number),
                        new Location(Worlds.resolve(worldName), x, y, z), yaw);
                button.world = worldName;
                button.setCodeNames(bs.getStringList(key + ".code"));
                button.modeLever = bs.getBoolean(key + ".mode-lever", false);
                button.leverOffNoWrench = bs.getBoolean(key + ".lever-off-no-wrench", false);
                button.holdSeconds = bs.getInt(key + ".hold-seconds", 1);
                button.enabled = bs.getBoolean(key + ".enabled", true);
                buttons.put(number, button);
            }
        }
        for (Map<?, ?> entry : cfg.getMapList("detectors")) {
            Object worldName = entry.get("world");
            if (worldName == null) {
                continue;
            }
            Location loc = new Location(Worlds.resolve(worldName.toString()),
                    toInt(entry.get("x")), toInt(entry.get("y")), toInt(entry.get("z")));
            DetectorData detector = new DetectorData(loc);
            detector.world = worldName.toString();
            List<String> code = new ArrayList<>();
            Object codeObj = entry.get("code");
            if (codeObj instanceof List) {
                for (Object o : (List<?>) codeObj) {
                    code.add(String.valueOf(o));
                }
            }
            detector.setCodeNames(code);
            detectors.add(detector);
        }
        resetDetectorBlocks();
    }

    private void resetDetectorBlocks() {
        for (DetectorData detector : detectors) {
            World world = Worlds.resolve(detector.world);
            if (world == null) {
                continue;
            }
            Block b = world.getBlockAt(detector.x, detector.y, detector.z);
            if (b.getType() == Material.REDSTONE_BLOCK) {
                b.setType(Material.DAYLIGHT_DETECTOR, false);
            }
        }
    }

    private static int toInt(Object o) {
        if (o instanceof Number) {
            return ((Number) o).intValue();
        }
        try {
            return Integer.parseInt(String.valueOf(o));
        } catch (NumberFormatException ex) {
            return 0;
        }
    }

    public void save() {
        File file = new File(plugin.getDataFolder(), "buttons.yml");
        YamlConfiguration cfg = new YamlConfiguration();
        for (WirelessButton button : buttons.values()) {
            String base = "buttons." + button.number + ".";
            cfg.set(base + "name", button.name);
            cfg.set(base + "world", button.world);
            cfg.set(base + "x", button.x);
            cfg.set(base + "y", button.y);
            cfg.set(base + "z", button.z);
            cfg.set(base + "yaw", button.yaw);
            cfg.set(base + "code", button.codeNames());
            cfg.set(base + "mode-lever", button.modeLever);
            cfg.set(base + "lever-off-no-wrench", button.leverOffNoWrench);
            cfg.set(base + "hold-seconds", button.holdSeconds);
            cfg.set(base + "enabled", button.enabled);
        }
        List<Map<String, Object>> list = new ArrayList<>();
        for (DetectorData detector : detectors) {
            Map<String, Object> map = new HashMap<>();
            map.put("world", detector.world);
            map.put("x", detector.x);
            map.put("y", detector.y);
            map.put("z", detector.z);
            map.put("code", detector.codeNames());
            list.add(map);
        }
        cfg.set("detectors", list);
        try {
            cfg.save(file);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void shutdown() {
        for (DetectorData detector : detectors) {
            setPower(detector, false);
        }
        save();
    }

    public int lowestFreeNumber() {
        Set<Integer> used = new TreeSet<>(buttons.keySet());
        int n = 1;
        while (used.contains(n)) {
            n++;
        }
        return n;
    }

    public WirelessButton button(int number) {
        return buttons.get(number);
    }

    public Map<Integer, WirelessButton> buttons() {
        return buttons;
    }

    public WirelessButton placeButton(Player player, Block target) {
        World world = target.getWorld();
        return createButton(lowestFreeNumber(), "button " + lowestFreeNumber(), world,
                target.getX(), target.getY(), target.getZ(), player.getLocation().getYaw());
    }

    public WirelessButton createButton(int number, String name, World world, int x, int y, int z, float yaw) {
        if (buttons.containsKey(number) || world == null) {
            return null;
        }
        world.getBlockAt(x, y, z).setType(Material.DIORITE_WALL);
        world.getBlockAt(x, y + 1, z).setBlockData(crimsonData(yaw, false), false);
        WirelessButton button = new WirelessButton(number, name, new Location(world, x, y, z), yaw);
        buttons.put(number, button);
        save();
        return button;
    }

    public boolean deleteButton(int number) {
        WirelessButton button = buttons.remove(number);
        if (button == null) {
            return false;
        }
        World world = Worlds.resolve(button.world);
        if (world != null) {
            Block top = world.getBlockAt(button.x, button.y + 1, button.z);
            if (top.getType() == Material.CRIMSON_BUTTON) {
                top.setType(Material.AIR, false);
            }
            Block base = world.getBlockAt(button.x, button.y, button.z);
            if (base.getType() == Material.DIORITE_WALL) {
                base.setType(Material.AIR, false);
            }
        }
        save();
        return true;
    }

    private BlockData crimsonData(float yaw, boolean powered) {
        BlockData data = Material.CRIMSON_BUTTON.createBlockData();
        if (data instanceof Switch) {
            ((Switch) data).setFace(Switch.Face.FLOOR);
        }
        if (data instanceof Directional) {
            Directional dir = (Directional) data;
            BlockFace face = yawToFace(yaw);
            if (dir.getFaces().contains(face)) {
                dir.setFacing(face);
            }
        }
        if (data instanceof Powerable) {
            ((Powerable) data).setPowered(powered);
        }
        return data;
    }

    private static BlockFace yawToFace(float yaw) {
        float y = (yaw % 360.0F + 360.0F) % 360.0F;
        if (y >= 315.0F || y < 45.0F) {
            return BlockFace.SOUTH;
        }
        if (y < 135.0F) {
            return BlockFace.WEST;
        }
        if (y < 225.0F) {
            return BlockFace.NORTH;
        }
        return BlockFace.EAST;
    }

    private void setCrimsonPowered(WirelessButton button, boolean on) {
        World world = Worlds.resolve(button.world);
        if (world == null) {
            return;
        }
        Block top = world.getBlockAt(button.x, button.y + 1, button.z);
        if (top.getType() != Material.CRIMSON_BUTTON) {
            return;
        }
        BlockData data = top.getBlockData();
        if (data instanceof Powerable) {
            Powerable p = (Powerable) data;
            if (p.isPowered() != on) {
                p.setPowered(on);
                top.setBlockData(data, false);
            }
        }
    }

    public WirelessButton buttonByBlock(Location loc) {
        if (loc == null || loc.getWorld() == null) {
            return null;
        }
        String wn = loc.getWorld().getName();
        int bx = loc.getBlockX();
        int by = loc.getBlockY();
        int bz = loc.getBlockZ();
        for (WirelessButton button : buttons.values()) {
            if (!button.world.equals(wn) || button.x != bx || button.z != bz) {
                continue;
            }
            if (button.y == by || button.y + 1 == by) {
                return button;
            }
        }
        return null;
    }

    public DetectorData detectorAt(Location loc) {
        if (loc == null || loc.getWorld() == null) {
            return null;
        }
        String wn = loc.getWorld().getName();
        for (DetectorData detector : detectors) {
            if (detector.world.equals(wn) && detector.x == loc.getBlockX()
                    && detector.y == loc.getBlockY() && detector.z == loc.getBlockZ()) {
                return detector;
            }
        }
        return null;
    }

    public DetectorData placeDetector(Block target) {
        target.setType(Material.DAYLIGHT_DETECTOR);
        DetectorData detector = new DetectorData(target.getLocation());
        detectors.add(detector);
        save();
        return detector;
    }

    public boolean removeDetector(DetectorData detector) {
        if (detectors.remove(detector)) {
            setPower(detector, false);
            save();
            return true;
        }
        return false;
    }

    public void press(Player player, WirelessButton button) {
        if (!button.enabled) {
            return;
        }
        if (button.modeLever) {
            if (!button.active) {
                setActive(button, true, -1L);
                click(button);
            } else if (button.leverOffNoWrench) {
                setActive(button, false, -1L);
                click(button);
            }
            return;
        }
        int hold = Math.max(1, Math.min(15, button.holdSeconds));
        setActive(button, true, clock + (long) hold * 20L);
        click(button);
    }

    private void click(WirelessButton button) {
        World world = Worlds.resolve(button.world);
        if (world != null) {
            world.playSound(button.center(world), pressSound, SoundCategory.BLOCKS, soundVolume, soundPitch);
        }
    }

    public void setActive(WirelessButton button, boolean active, long until) {
        button.active = active;
        button.activeUntil = active ? until : -1L;
        setCrimsonPowered(button, active);
    }

    public void tick() {
        clock++;
        for (WirelessButton button : buttons.values()) {
            if (!button.active) {
                continue;
            }
            if (button.activeUntil > 0 && clock >= button.activeUntil) {
                setActive(button, false, -1L);
                continue;
            }
            World world = Worlds.resolve(button.world);
            if (world == null) {
                continue;
            }
            Location above = button.topCenter(world);
            Particle.DustOptions dust = new Particle.DustOptions(Color.RED, 1.2F);
            world.spawnParticle(Particle.DUST, above, 4, 0.25D, 0.2D, 0.25D, dust);
            if (button.holdSeconds > 1 && button.activeUntil > 0 && clock % 20L == 0L) {
                world.playSound(above, tickSound, SoundCategory.BLOCKS, soundVolume, soundPitch);
            }
        }
        updateDetectors();
    }

    private void updateDetectors() {
        for (DetectorData detector : detectors) {
            boolean desired = false;
            for (WirelessButton button : buttons.values()) {
                if (button.enabled && button.active && button.codeMatches(detector.code)) {
                    desired = true;
                    break;
                }
            }
            if (desired != detector.active) {
                detector.active = desired;
                setPower(detector, desired);
            }
            if (detector.active) {
                World world = Worlds.resolve(detector.world);
                if (world != null) {
                    Location at = new Location(world, detector.x + 0.5D, detector.y + 1.0D, detector.z + 0.5D);
                    Particle.DustOptions dust = new Particle.DustOptions(Color.RED, 1.0F);
                    world.spawnParticle(Particle.DUST, at, 3, 0.25D, 0.2D, 0.25D, dust);
                }
            }
        }
    }

    private void setPower(DetectorData detector, boolean on) {
        World world = Worlds.resolve(detector.world);
        if (world == null) {
            return;
        }
        Block b = world.getBlockAt(detector.x, detector.y, detector.z);
        Material target = on ? Material.REDSTONE_BLOCK : Material.DAYLIGHT_DETECTOR;
        if (b.getType() != target) {
            b.setType(target, true);
        }
    }

    public Items items() {
        return items;
    }

    public JavaPlugin plugin() {
        return plugin;
    }
}
