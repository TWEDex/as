package ru.glai.aperture;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.World;

public final class Worlds {

    private static final Set<String> warned = new HashSet<>();

    private Worlds() {
    }

    public static World exact(String name) {
        if (name == null) {
            return null;
        }
        return Bukkit.getWorld(name);
    }

    public static World resolve(String name) {
        World world = exact(name);
        if (world != null) {
            return world;
        }
        List<World> worlds = Bukkit.getWorlds();
        World fallback = worlds.isEmpty() ? null : worlds.get(0);
        if (fallback != null && warned.add(String.valueOf(name))) {
            Bukkit.getLogger().warning("[ApertureScience] world '" + name + "' not found, using '" + fallback.getName() + "' instead");
        }
        return fallback;
    }
}
