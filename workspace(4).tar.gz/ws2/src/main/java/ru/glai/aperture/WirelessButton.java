package ru.glai.aperture;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

public final class WirelessButton {

    public int number;
    public String name;
    public String world;
    public int x;
    public int y;
    public int z;
    public float yaw;
    public final List<Material> code = new ArrayList<>();
    public boolean modeLever;
    public boolean leverOffNoWrench;
    public int holdSeconds = 1;
    public boolean enabled = true;
    public boolean active;
    public long activeUntil = -1L;

    public WirelessButton(int number, String name, Location loc, float yaw) {
        this.number = number;
        this.name = name;
        World w = loc.getWorld();
        this.world = w == null ? "world" : w.getName();
        this.x = loc.getBlockX();
        this.y = loc.getBlockY();
        this.z = loc.getBlockZ();
        this.yaw = yaw;
        this.modeLever = false;
        this.leverOffNoWrench = false;
    }

    public Location location(World w) {
        return new Location(w, x, y, z);
    }

    public Location center(World w) {
        return new Location(w, x + 0.5D, y + 0.5D, z + 0.5D);
    }

    public Location topCenter(World w) {
        return new Location(w, x + 0.5D, y + 1.2D, z + 0.5D);
    }

    public boolean codeMatches(List<Material> other) {
        if (other == null || code.isEmpty() || other.size() != code.size()) {
            return false;
        }
        List<Material> a = new ArrayList<>(code);
        List<Material> b = new ArrayList<>(other);
        a.sort(Comparator.comparingInt(Enum::ordinal));
        b.sort(Comparator.comparingInt(Enum::ordinal));
        for (int i = 0; i < a.size(); i++) {
            if (a.get(i) != b.get(i)) {
                return false;
            }
        }
        return true;
    }

    public List<String> codeNames() {
        List<String> list = new ArrayList<>();
        for (Material m : code) {
            list.add(m.name());
        }
        return list;
    }

    public void setCodeNames(List<String> names) {
        code.clear();
        if (names == null) {
            return;
        }
        for (String s : names) {
            Material m = Material.matchMaterial(s);
            if (m != null) {
                code.add(m);
            }
        }
    }
}
