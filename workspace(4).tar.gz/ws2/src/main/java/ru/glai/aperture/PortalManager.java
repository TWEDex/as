package ru.glai.aperture;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public final class PortalManager {

    public static final class Portal {
        public World world;
        public int bx;
        public int by;
        public int bz;
        public BlockFace face = BlockFace.NORTH;
        public boolean orange;
    }

    private static final double REACH = 200.0D;
    private static final int COOLDOWN = 20;

    private final JavaPlugin plugin;
    private final CubeManager cubes;
    private Portal orange;
    private Portal blue;
    private final Map<UUID, Long> cooldown = new HashMap<>();
    private long tick;

    public PortalManager(JavaPlugin plugin, CubeManager cubes) {
        this.plugin = plugin;
        this.cubes = cubes;
    }

    public boolean placeOrange(Player player) {
        return place(player, true);
    }

    public boolean placeBlue(Player player) {
        return place(player, false);
    }

    private boolean place(Player player, boolean isOrange) {
        RayTraceResult result = player.rayTraceBlocks(REACH);
        if (result == null || result.getHitBlock() == null) {
            player.sendMessage("наведи на блок");
            return false;
        }
        Block block = result.getHitBlock();
        if (block.getType() != Material.BONE_BLOCK) {
            player.sendMessage("портал можно ставить только на костный блок");
            return false;
        }
        BlockFace face = result.getHitBlockFace();
        if (face == null) {
            face = BlockFace.NORTH;
        }
        Portal portal = new Portal();
        portal.world = block.getWorld();
        portal.bx = block.getX();
        portal.by = block.getY();
        portal.bz = block.getZ();
        portal.face = face;
        portal.orange = isOrange;
        if (isOrange) {
            orange = portal;
        } else {
            blue = portal;
        }
        player.playSound(player.getLocation(), Sound.BLOCK_PORTAL_TRIGGER, SoundCategory.BLOCKS, 0.7F, isOrange ? 1.2F : 0.9F);
        return true;
    }

    public void clear() {
        orange = null;
        blue = null;
    }

    public String status() {
        return "orange: " + (orange == null ? "none" : pos(orange)) + ", blue: " + (blue == null ? "none" : pos(blue));
    }

    private String pos(Portal p) {
        return p.world.getName() + " " + p.bx + " " + p.by + " " + p.bz + " " + p.face.name();
    }

    public void tick() {
        tick++;
        if (orange != null) {
            render(orange, Color.fromRGB(0xFF7F00));
        }
        if (blue != null) {
            render(blue, Color.fromRGB(0x3366FF));
        }
        if (orange != null && blue != null) {
            teleportNear(orange, blue);
            teleportNear(blue, orange);
            teleportCubes();
        }
    }

    private void render(Portal portal, Color color) {
        World world = portal.world;
        BlockFace f = portal.face;
        double cx = portal.bx + 0.5D + f.getModX() * 0.55D;
        double cy = portal.by + 0.5D + f.getModY() * 0.55D;
        double cz = portal.bz + 0.5D + f.getModZ() * 0.55D;
        Particle.DustOptions dust = new Particle.DustOptions(color, 1.3F);
        double half = 0.5D;
        int per = 7;
        double[] u = axisU(f);
        double[] v = axisV(f);
        for (int i = 0; i <= per; i++) {
            double t = -half + (2.0D * half) * i / per;
            spawn(world, cx, cy, cz, u, v, t, -half, dust);
            spawn(world, cx, cy, cz, u, v, t, half, dust);
            spawn(world, cx, cy, cz, u, v, -half, t, dust);
            spawn(world, cx, cy, cz, u, v, half, t, dust);
        }
    }

    private void spawn(World world, double cx, double cy, double cz, double[] u, double[] v, double a, double b, Particle.DustOptions dust) {
        double x = cx + u[0] * a + v[0] * b;
        double y = cy + u[1] * a + v[1] * b;
        double z = cz + u[2] * a + v[2] * b;
        world.spawnParticle(Particle.DUST, x, y, z, 0, 0.0D, 0.0D, 0.0D, 0.0D, dust);
    }

    private static double[] axisU(BlockFace f) {
        switch (f) {
            case NORTH:
            case SOUTH:
                return new double[]{1.0D, 0.0D, 0.0D};
            case EAST:
            case WEST:
                return new double[]{0.0D, 0.0D, 1.0D};
            default:
                return new double[]{1.0D, 0.0D, 0.0D};
        }
    }

    private static double[] axisV(BlockFace f) {
        switch (f) {
            case UP:
            case DOWN:
                return new double[]{0.0D, 0.0D, 1.0D};
            default:
                return new double[]{0.0D, 1.0D, 0.0D};
        }
    }

    private void teleportNear(Portal from, Portal to) {
        World world = from.world;
        int tx = from.bx + from.face.getModX();
        int ty = from.by + from.face.getModY();
        int tz = from.bz + from.face.getModZ();
        BoundingBox box = new BoundingBox(tx, ty, tz, tx + 1.0D, ty + 1.0D, tz + 1.0D);
        Location center = new Location(world, tx + 0.5D, ty + 0.5D, tz + 0.5D);
        for (Entity entity : world.getNearbyEntities(center, 2.0D, 2.0D, 2.0D)) {
            if (entity instanceof org.bukkit.entity.Item) {
                continue;
            }
            if (isCooling(entity.getUniqueId())) {
                continue;
            }
            if (!entity.getBoundingBox().overlaps(box)) {
                continue;
            }
            doTeleport(entity, to);
        }
    }

    private void doTeleport(Entity entity, Portal to) {
        World world = to.world;
        int tx = to.bx + to.face.getModX();
        int ty = to.by + to.face.getModY();
        int tz = to.bz + to.face.getModZ();
        double ox = tx + 0.5D + to.face.getModX() * 0.6D;
        double oy = ty + 0.4D + to.face.getModY() * 0.6D;
        double oz = tz + 0.5D + to.face.getModZ() * 0.6D;
        float yaw = faceYaw(to.face, entity.getLocation().getYaw());
        float pitch = entity.getLocation().getPitch();
        Location exit = new Location(world, ox, oy, oz, yaw, pitch);
        Vector velocity = entity.getVelocity();
        setCooldown(entity.getUniqueId());
        if (entity instanceof Player) {
            ((Player) entity).teleport(exit, org.bukkit.event.player.PlayerTeleportEvent.TeleportCause.PLUGIN);
        } else {
            entity.teleport(exit);
        }
        entity.setVelocity(velocity);
        world.playSound(exit, Sound.ENTITY_ENDERMAN_TELEPORT, SoundCategory.BLOCKS, 0.6F, 1.0F);
    }

    private void teleportCubes() {
        for (CubeManager.Cube cube : cubes.cubes()) {
            if (cube.carried) {
                continue;
            }
            if (isCooling(cube.id)) {
                continue;
            }
            if (matches(cube, orange)) {
                sendCube(cube, blue);
            } else if (matches(cube, blue)) {
                sendCube(cube, orange);
            }
        }
    }

    private boolean matches(CubeManager.Cube cube, Portal portal) {
        if (portal == null || cube.world == null) {
            return false;
        }
        int tx = portal.bx + portal.face.getModX();
        int ty = portal.by + portal.face.getModY();
        int tz = portal.bz + portal.face.getModZ();
        return cube.world.equals(portal.world) && cube.bx == tx && cube.by == ty && cube.bz == tz;
    }

    private void sendCube(CubeManager.Cube cube, Portal to) {
        if (to == null) {
            return;
        }
        int tx = to.bx + to.face.getModX();
        int ty = to.by + to.face.getModY();
        int tz = to.bz + to.face.getModZ();
        Location exit = new Location(to.world, tx, ty, tz);
        setCooldown(cube.id);
        cubes.teleportCube(cube, exit, cube.vy);
        to.world.playSound(exit, Sound.ENTITY_ENDERMAN_TELEPORT, SoundCategory.BLOCKS, 0.6F, 1.0F);
    }

    private static float faceYaw(BlockFace face, float fallback) {
        switch (face) {
            case NORTH:
                return 180.0F;
            case SOUTH:
                return 0.0F;
            case EAST:
                return 270.0F;
            case WEST:
                return 90.0F;
            default:
                return fallback;
        }
    }

    private boolean isCooling(UUID id) {
        Long until = cooldown.get(id);
        return until != null && tick < until;
    }

    private void setCooldown(UUID id) {
        cooldown.put(id, tick + COOLDOWN);
    }
}
