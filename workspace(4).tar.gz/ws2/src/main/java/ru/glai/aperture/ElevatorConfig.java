package ru.glai.aperture;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public final class ElevatorConfig {

    public final String id;
    public final String worldName;
    public final Location button;
    public final Location statusLamp;
    public final List<Location> blinkLamps = new ArrayList<>();
    public final List<Location> shoreDoors = new ArrayList<>();
    public final List<Location> farShoreDoors = new ArrayList<>();
    public final List<Location> cabinDoorsWest = new ArrayList<>();
    public final List<Location> cabinDoorsEast = new ArrayList<>();
    public final Location cabinHomeA;
    public final Location cabinHomeB;
    public final Location cabinFarA;
    public final Location cabinFarB;
    public final int blinkDuration;
    public final int blinkPeriod;
    public final int boardDelay;
    public final int exitDelay;
    public final int departDelay;
    public final int checkPeriod;
    public final int movePeriod;
    public final String ambienceSound;
    public final String ambienceCategory;
    public final Location ambienceLocation;
    public final float ambienceVolume;
    public final float ambiencePitch;
    public final int ambiencePeriod;
    public final boolean moveSoundEnabled;
    public final String moveSound;
    public final float moveSoundVolume;
    public final float moveSoundPitch;
    public final int moveSoundPeriod;
    public final boolean blinkSoundEnabled;
    public final String blinkSound;
    public final float blinkSoundVolume;
    public final float blinkSoundPitch;
    public final boolean arrivalSoundEnabled;
    public final String arrivalSound;
    public final float arrivalSoundVolume;
    public final float arrivalSoundPitch;
    public final boolean smokeEnabled;
    public final String smokeParticle;
    public final int smokeCount;
    public final int smokePeriod;
    public final double smokeSpread;
    public final double smokeSpeed;

    public ElevatorConfig(String id, FileConfiguration config, String path) {
        this.id = id;
        this.worldName = config.getString(path + ".world", "world");
        World world = Worlds.resolve(this.worldName);
        if (world == null) {
            throw new IllegalArgumentException("No world loaded");
        }
        this.button = readLocation(config, path + ".button", world);
        this.statusLamp = readLocation(config, path + ".status-lamp", world);
        readLocations(config, path + ".blink-lamps", world, this.blinkLamps);
        readLocations(config, path + ".shore-doors", world, this.shoreDoors);
        readLocations(config, path + ".far-shore-doors", world, this.farShoreDoors);
        readLocations(config, path + ".cabin-doors-west", world, this.cabinDoorsWest);
        readLocations(config, path + ".cabin-doors-east", world, this.cabinDoorsEast);
        this.cabinHomeA = readLocation(config, path + ".cabin-home-a", world);
        this.cabinHomeB = readLocation(config, path + ".cabin-home-b", world);
        this.cabinFarA = readLocation(config, path + ".cabin-far-a", world);
        this.cabinFarB = readLocation(config, path + ".cabin-far-b", world);
        this.blinkDuration = config.getInt(path + ".blink-duration", 40);
        this.blinkPeriod = Math.max(1, config.getInt(path + ".blink-period", 10));
        this.boardDelay = config.getInt(path + ".board-delay", 60);
        this.exitDelay = config.getInt(path + ".exit-delay", 20);
        this.departDelay = config.getInt(path + ".depart-delay", 20);
        this.checkPeriod = Math.max(1, config.getInt(path + ".check-period", 5));
        this.movePeriod = Math.max(1, config.getInt(path + ".move-period", 1));
        this.ambienceSound = config.getString(path + ".ambience.sound", "tropicalberry:ambience.limbo");
        this.ambienceCategory = config.getString(path + ".ambience.category", "master");
        this.ambienceLocation = readLocation(config, path + ".ambience.location", world);
        this.ambienceVolume = (float) Math.min(config.getDouble(path + ".ambience.volume", 10.0D), 3.0D);
        this.ambiencePitch = (float) config.getDouble(path + ".ambience.pitch", 2.0D);
        this.ambiencePeriod = Math.max(20, config.getInt(path + ".ambience.period", 200));
        this.moveSoundEnabled = config.getBoolean(path + ".move-sound.enabled", true);
        this.moveSound = config.getString(path + ".move-sound.sound", "entity.minecart.riding");
        this.moveSoundVolume = (float) config.getDouble(path + ".move-sound.volume", 0.55D);
        this.moveSoundPitch = (float) config.getDouble(path + ".move-sound.pitch", 0.7D);
        this.moveSoundPeriod = Math.max(1, config.getInt(path + ".move-sound.period", 4));
        this.blinkSoundEnabled = config.getBoolean(path + ".blink-sound.enabled", true);
        this.blinkSound = config.getString(path + ".blink-sound.sound", "block.copper_bulb.turn_on");
        this.blinkSoundVolume = (float) config.getDouble(path + ".blink-sound.volume", 1.0D);
        this.blinkSoundPitch = (float) config.getDouble(path + ".blink-sound.pitch", 1.0D);
        this.arrivalSoundEnabled = config.getBoolean(path + ".arrival-sound.enabled", true);
        this.arrivalSound = config.getString(path + ".arrival-sound.sound", "block.note_block.bit");
        this.arrivalSoundVolume = (float) config.getDouble(path + ".arrival-sound.volume", 1.0D);
        this.arrivalSoundPitch = (float) config.getDouble(path + ".arrival-sound.pitch", 1.0D);
        this.smokeEnabled = config.getBoolean(path + ".smoke.enabled", true);
        this.smokeParticle = config.getString(path + ".smoke.particle", "SMOKE");
        this.smokeCount = Math.max(1, config.getInt(path + ".smoke.count", 3));
        this.smokePeriod = Math.max(1, config.getInt(path + ".smoke.period", 1));
        this.smokeSpread = config.getDouble(path + ".smoke.spread", 0.6D);
        this.smokeSpeed = config.getDouble(path + ".smoke.speed", 0.01D);
    }

    public World world() {
        return Worlds.resolve(worldName);
    }

    private static void readLocations(FileConfiguration config, String path, World world, List<Location> target) {
        ConfigurationSection section = config.getConfigurationSection(path);
        if (section != null) {
            for (String key : section.getKeys(false)) {
                target.add(parseLocation(section.getString(key), world));
            }
            return;
        }
        for (String line : config.getStringList(path)) {
            if (line != null && !line.trim().isEmpty()) {
                target.add(parseLocation(line, world));
            }
        }
    }

    private static Location readLocation(FileConfiguration config, String path, World world) {
        String raw = config.getString(path);
        if (raw == null || raw.trim().isEmpty()) {
            throw new IllegalArgumentException("Missing position: " + path);
        }
        return parseLocation(raw, world);
    }

    private static Location parseLocation(String raw, World world) {
        String[] parts = raw.trim().split("\\s+");
        if (parts.length < 3) {
            throw new IllegalArgumentException("Bad position: " + raw);
        }
        return new Location(world, Double.parseDouble(parts[0]), Double.parseDouble(parts[1]), Double.parseDouble(parts[2]));
    }
}
