package ru.glai.aperture;

import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public final class Items {

    public static final String KIND_BUTTON = "button";
    public static final String KIND_WRENCH = "wrench";
    public static final String KIND_DETECTOR = "detector";
    public static final String KIND_PORTAL_GUN = "portal_gun";
    public static final String KIND_PUMP = "pump";
    public static final String KIND_ACID = "acid";

    private final Plugin plugin;
    private final NamespacedKey kindKey;

    public Items(Plugin plugin) {
        this.plugin = plugin;
        this.kindKey = new NamespacedKey(plugin, "aperture_item");
    }

    public NamespacedKey kindKey() {
        return kindKey;
    }

    public String kindOf(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return null;
        }
        return meta.getPersistentDataContainer().get(kindKey, PersistentDataType.STRING);
    }

    public boolean is(ItemStack item, String kind) {
        String value = kindOf(item);
        return value != null && value.equals(kind);
    }

    public ItemStack create(String kind) {
        switch (kind) {
            case KIND_BUTTON:
                return tag(build(Material.CRIMSON_BUTTON,
                        Component.text("Портальная кнопка", NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false),
                        List.of(Component.text("Поставь блок, затем настрой ключом", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false))),
                        KIND_BUTTON);
            case KIND_WRENCH:
                return tag(build(Material.GOLDEN_AXE,
                        Component.text("Ключ настройки", NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false),
                        List.of(Component.text("ПКМ по кнопке, детектору или насосу", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false))),
                        KIND_WRENCH);
            case KIND_DETECTOR:
                return tag(build(Material.DAYLIGHT_DETECTOR,
                        Component.text("Детектор", NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false),
                        List.of(Component.text("Выдается только командой", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false))),
                        KIND_DETECTOR);
            case KIND_PORTAL_GUN:
                return tag(buildCrossbow(), KIND_PORTAL_GUN);
            case KIND_PUMP:
                return tag(build(Material.DISPENSER,
                        Component.text("Насос нейротоксина", NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false),
                        List.of(Component.text("Сам распыляет нейротоксин, настрой ключом", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false))),
                        KIND_PUMP);
            case KIND_ACID:
                return tag(build(Material.WATER_BUCKET,
                        Component.text("Кислота", NamedTextColor.DARK_GREEN).decoration(TextDecoration.ITALIC, false),
                        List.of(Component.text("Не растекается, смертельно опасна", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false))),
                        KIND_ACID);
            default:
                return null;
        }
    }

    private ItemStack buildCrossbow() {
        ItemStack item = new ItemStack(Material.CROSSBOW);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            Component name = Component.text("портальная ", NamedTextColor.GOLD)
                    .decoration(TextDecoration.ITALIC, false)
                    .append(Component.text("пушка", NamedTextColor.BLUE).decoration(TextDecoration.ITALIC, false));
            meta.displayName(name);
            meta.lore(new ArrayList<>(List.of(
                    Component.text("ЛКМ - оранжевый портал, ПКМ - синий", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                    Component.text("Шифт+ПКМ по кубу - взять, Шифт+ПКМ - отпустить", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false))));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack build(Material material, Component name, List<Component> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(name);
            meta.lore(new ArrayList<>(lore));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack tag(ItemStack item, String kind) {
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(kindKey, PersistentDataType.STRING, kind);
            item.setItemMeta(meta);
        }
        return item;
    }

    public List<String> kinds() {
        List<String> list = new ArrayList<>();
        list.add(KIND_BUTTON);
        list.add(KIND_WRENCH);
        list.add(KIND_DETECTOR);
        list.add(KIND_PORTAL_GUN);
        list.add(KIND_PUMP);
        list.add(KIND_ACID);
        return list;
    }
}
