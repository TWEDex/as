package ru.glai.aperture;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class FluidSystem {

    public static final class Pump {
        public int number;
        public String world;
        public int x;
        public int y;
        public int z;
        public BlockFace facing = BlockFace.NORTH;
        public boolean enabled = true;
        public final List<Material> code = new ArrayList<>();
        public String group = "";
        public int concentration = 2;
        public int poisonSpeed = 10;
        public String extraEffect = "";
    }

    public static final class NeuroCloud {
        public String world;
        public double x;
        public double y;
        public double z;
        public int secondsLeft;
        public int concentration;
    }

    private static final double NEURO_RADIUS = 6.0D;
    private static final double ACID_RADIUS = 2.2D;
    private static final int ACID_DEATH_SECONDS = 5;

    private final JavaPlugin plugin;
    private final Items items;

    private final Map<Integer, Pump> pumps = new LinkedHashMap<>();
    private final Map<String, Pump> pumpByLoc = new HashMap<>();
    private final Set<String> acidKeys = new HashSet<>();
    private final Map<String, Boolean> groupsRunning = new LinkedHashMap<>();
    private final List<NeuroCloud> clouds = new ArrayList<>();

    private final Map<UUID, Integer> neuroSeconds = new HashMap<>();
    private final Map<UUID, Integer> acidSeconds = new HashMap<>();

    private long clock;

    public FluidSystem(JavaPlugin plugin, Items items) {
        this.plugin = plugin;
        this.items = items;
    }

    public Items items() {
        return items;
    }

    public JavaPlugin plugin() {
        return plugin;
    }

    private static String key(String world, int x, int y, int z) {
        return world + " " + x + " " + y + " " + z;
    }

    public static String blockKey(Location loc) {
        World w = loc.getWorld();
        return key(w == null ? "world" : w.getName(), loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
    }

    public int lowestFreePump() {
        Set<Integer> set = new TreeSet<>(pumps.keySet());
        int n = 1;
        while (set.contains(n)) {
            n++;
        }
        return n;
    }

    public Pump pump(int number) {
        return pumps.get(number);
    }

    public Map<Integer, Pump> pumps() {
        return pumps;
    }

    public Pump pumpAt(Location loc) {
        return pumpByLoc.get(blockKey(loc));
    }

    public Pump placePump(Player player, Block target) {
        target.setType(Material.DISPENSER);
        BlockData data = target.getBlockData();
        BlockFace face = yawToFace(player.getLocation().getYaw());
        if (data instanceof Directional) {
            Directional dir = (Directional) data;
            if (dir.getFaces().contains(face)) {
                dir.setFacing(face);
            }
            target.setBlockData(dir, false);
        }
        Pump pump = new Pump();
        pump.number = lowestFreePump();
        pump.world = target.getWorld().getName();
        pump.x = target.getX();
        pump.y = target.getY();
        pump.z = target.getZ();
        pump.facing = face;
        pumps.put(pump.number, pump);
        pumpByLoc.put(key(pump.world, pump.x, pump.y, pump.z), pump);
        save();
        return pump;
    }

    public boolean deletePump(int number) {
        Pump pump = pumps.remove(number);
        if (pump == null) {
            return false;
        }
        pumpByLoc.remove(key(pump.world, pump.x, pump.y, pump.z));
        World world = Worlds.resolve(pump.world);
        if (world != null) {
            Block b = world.getBlockAt(pump.x, pump.y, pump.z);
            if (b.getType() == Material.DISPENSER) {
                b.setType(Material.AIR, false);
            }
        }
        save();
        return true;
    }

    public void placeAcid(Block target) {
        target.setType(Material.WATER, false);
        acidKeys.add(key(target.getWorld().getName(), target.getX(), target.getY(), target.getZ()));
        save();
    }

    public boolean isAcid(String key) {
        return acidKeys.contains(key);
    }

    public boolean isAcid(Location loc) {
        return acidKeys.contains(blockKey(loc));
    }

    public void removeAcid(String key) {
        if (acidKeys.remove(key)) {
            save();
        }
    }

    public void spawnNeuroCloud(World world, double x, double y, double z, int seconds, int concentration) {
        NeuroCloud cloud = new NeuroCloud();
        cloud.world = world.getName();
        cloud.x = x;
        cloud.y = y;
        cloud.z = z;
        cloud.secondsLeft = Math.max(1, seconds);
        cloud.concentration = Math.max(1, Math.min(5, concentration));
        clouds.add(cloud);
    }

    public void groupSetRunning(String name, boolean running) {
        groupsRunning.put(name.toLowerCase(Locale.ROOT), running);
        save();
    }

    public boolean groupRunning(String name) {
        Boolean b = groupsRunning.get(name.toLowerCase(Locale.ROOT));
        return b != null && b;
    }

    public boolean hasGroup(String name) {
        return groupsRunning.containsKey(name.toLowerCase(Locale.ROOT));
    }

    public Set<String> groupNames() {
        return groupsRunning.keySet();
    }

    public List<Pump> groupMembers(String name) {
        List<Pump> list = new ArrayList<>();
        String lower = name.toLowerCase(Locale.ROOT);
        for (Pump pump : pumps.values()) {
            if (pump.group != null && pump.group.toLowerCase(Locale.ROOT).equals(lower)) {
                list.add(pump);
            }
        }
        return list;
    }

    private static BlockFace yawToFace(float yaw) {
        float y = (yaw % 360.0F + 360.0F) % 360.0F;
        if (y >= 315.0F || y < 45.0F) {
            return BlockFace.SOUTH;
        }
        if (y < 135.0F) {
            return BlockFace.WEST;
        }
        if (y < 225.0F) {
            return BlockFace.NORTH;
        }
        return BlockFace.EAST;
    }

    public void tick() {
        clock++;
        for (NeuroCloud cloud : new ArrayList<>(clouds)) {
            cloud.secondsLeft--;
            if (cloud.secondsLeft <= 0) {
                clouds.remove(cloud);
            }
        }
        if (clock % 20L != 0L) {
            return;
        }
        Set<UUID> neuroTouched = new HashSet<>();
        Set<UUID> acidTouched = new HashSet<>();

        for (Pump pump : pumps.values()) {
            if (!pump.enabled) {
                continue;
            }
            if (!pump.group.isEmpty() && !groupRunning(pump.group)) {
                continue;
            }
            sprayPump(pump, neuroTouched);
        }
        for (NeuroCloud cloud : clouds) {
            sprayCloud(cloud, neuroTouched);
        }

        List<String> deadAcid = new ArrayList<>();
        for (String k : acidKeys) {
            String[] parts = k.split(" ");
            World world = Worlds.resolve(parts[0]);
            if (world == null) {
                continue;
            }
            int x = Integer.parseInt(parts[1]);
            int y = Integer.parseInt(parts[2]);
            int z = Integer.parseInt(parts[3]);
            Block b = world.getBlockAt(x, y, z);
            if (b.getType() != Material.WATER) {
                deadAcid.add(k);
                continue;
            }
            applyAcid(world, x, y, z, acidTouched);
        }
        acidKeys.removeAll(deadAcid);

        neuroSeconds.keySet().retainAll(neuroTouched);
        acidSeconds.keySet().retainAll(acidTouched);
    }

    private void sprayPump(Pump pump, Set<UUID> touched) {
        World world = Worlds.resolve(pump.world);
        if (world == null) {
            return;
        }
        BlockFace f = pump.facing;
        Location face = new Location(world, pump.x + 0.5D + f.getModX() * 0.9D, pump.y + 0.5D, pump.z + 0.5D + f.getModZ() * 0.9D);
        Particle.DustOptions dust = new Particle.DustOptions(Color.fromRGB(0x4CBB17), 1.6F);
        world.spawnParticle(Particle.DUST, face, 16, f.getModX() * 0.7D, 0.35D, f.getModZ() * 0.7D, dust);
        PotionEffectType extra = parseEffect(pump.extraEffect);
        for (Player player : world.getPlayers()) {
            if (player.getGameMode() == org.bukkit.GameMode.CREATIVE || player.getGameMode() == org.bukkit.GameMode.SPECTATOR) {
                continue;
            }
            if (player.getLocation().distance(face) > NEURO_RADIUS) {
                continue;
            }
            touched.add(player.getUniqueId());
            int amp = Math.max(0, pump.concentration - 1);
            applyNeuro(player, amp, extra);
            if (clock % 60L == 0L) {
                player.playSound(player.getLocation(), Sound.ENTITY_ELDER_GUARDIAN_CURSE, SoundCategory.MASTER, 1.0F, 1.0F);
            }
            int sec = neuroSeconds.getOrDefault(player.getUniqueId(), 0) + 1;
            neuroSeconds.put(player.getUniqueId(), sec);
            if (sec >= pump.poisonSpeed) {
                neuroSeconds.remove(player.getUniqueId());
                kill(player);
            }
        }
    }

    private void sprayCloud(NeuroCloud cloud, Set<UUID> touched) {
        World world = Worlds.resolve(cloud.world);
        if (world == null) {
            return;
        }
        Location center = new Location(world, cloud.x, cloud.y, cloud.z);
        Particle.DustOptions dust = new Particle.DustOptions(Color.fromRGB(0x4CBB17), 2.0F);
        world.spawnParticle(Particle.DUST, center, 40, 1.6D, 1.2D, 1.6D, 0.0D, dust);
        int amp = Math.max(0, cloud.concentration - 1);
        for (Player player : world.getPlayers()) {
            if (player.getGameMode() == org.bukkit.GameMode.CREATIVE || player.getGameMode() == org.bukkit.GameMode.SPECTATOR) {
                continue;
            }
            if (player.getLocation().distance(center) > NEURO_RADIUS) {
                continue;
            }
            touched.add(player.getUniqueId());
            applyNeuro(player, amp, null);
            int sec = neuroSeconds.getOrDefault(player.getUniqueId(), 0) + 1;
            neuroSeconds.put(player.getUniqueId(), sec);
            if (sec >= 10) {
                neuroSeconds.remove(player.getUniqueId());
                kill(player);
            }
        }
    }

    private void applyNeuro(Player player, int amp, PotionEffectType extra) {
        addEffect(player, PotionEffectType.NAUSEA, 60, amp);
        addEffect(player, PotionEffectType.POISON, 60, amp);
        addEffect(player, PotionEffectType.WITHER, 60, Math.max(0, amp - 1));
        addEffect(player, PotionEffectType.DARKNESS, 80, 0);
        if (extra != null) {
            addEffect(player, extra, 60, 0);
        }
    }

    private void applyAcid(World world, int x, int y, int z, Set<UUID> touched) {
        Location center = new Location(world, x + 0.5D, y + 0.5D, z + 0.5D);
        for (Entity entity : world.getNearbyEntities(center, ACID_RADIUS, ACID_RADIUS, ACID_RADIUS)) {
            if (entity instanceof Item) {
                entity.remove();
                continue;
            }
            if (!(entity instanceof Player)) {
                continue;
            }
            Player player = (Player) entity;
            if (player.getGameMode() == org.bukkit.GameMode.CREATIVE || player.getGameMode() == org.bukkit.GameMode.SPECTATOR) {
                continue;
            }
            if (player.getLocation().distance(center) > ACID_RADIUS + 0.6D) {
                continue;
            }
            touched.add(player.getUniqueId());
            addEffect(player, PotionEffectType.NAUSEA, 60, 1);
            addEffect(player, PotionEffectType.POISON, 60, 2);
            double max = player.getMaxHealth();
            double dmg = max / ACID_DEATH_SECONDS;
            player.setHealth(Math.max(0.0D, player.getHealth() - dmg));
            int sec = acidSeconds.getOrDefault(player.getUniqueId(), 0) + 1;
            acidSeconds.put(player.getUniqueId(), sec);
            if (sec >= ACID_DEATH_SECONDS) {
                acidSeconds.remove(player.getUniqueId());
                kill(player);
            }
        }
    }

    private void kill(Player player) {
        player.setHealth(0.0D);
    }

    private void addEffect(Player player, PotionEffectType type, int duration, int amplifier) {
        if (type == null) {
            return;
        }
        player.addPotionEffect(new PotionEffect(type, duration, amplifier, false, false, false));
    }

    private static PotionEffectType parseEffect(String name) {
        if (name == null || name.isEmpty()) {
            return null;
        }
        return PotionEffectType.getByName(name.toUpperCase(Locale.ROOT));
    }

    public void load() {
        pumps.clear();
        pumpByLoc.clear();
        acidKeys.clear();
        groupsRunning.clear();
        clouds.clear();
        File file = new File(plugin.getDataFolder(), "fluids.yml");
        if (!file.exists()) {
            return;
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection ps = cfg.getConfigurationSection("pumps");
        if (ps != null) {
            for (String k : ps.getKeys(false)) {
                Pump p = new Pump();
                try {
                    p.number = Integer.parseInt(k);
                } catch (NumberFormatException ex) {
                    continue;
                }
                p.world = ps.getString(k + ".world", "world");
                p.x = ps.getInt(k + ".x");
                p.y = ps.getInt(k + ".y");
                p.z = ps.getInt(k + ".z");
                p.facing = parseFace(ps.getString(k + ".facing", "NORTH"));
                p.enabled = ps.getBoolean(k + ".enabled", true);
                p.group = ps.getString(k + ".group", "");
                p.concentration = ps.getInt(k + ".concentration", 2);
                p.poisonSpeed = ps.getInt(k + ".poisonSpeed", 10);
                p.extraEffect = ps.getString(k + ".extraEffect", "");
                for (String cn : ps.getStringList(k + ".code")) {
                    Material m = Material.matchMaterial(cn);
                    if (m != null) {
                        p.code.add(m);
                    }
                }
                pumps.put(p.number, p);
                pumpByLoc.put(key(p.world, p.x, p.y, p.z), p);
            }
        }
        for (String a : cfg.getStringList("acid")) {
            acidKeys.add(a);
        }
        ConfigurationSection gs = cfg.getConfigurationSection("groups");
        if (gs != null) {
            for (String name : gs.getKeys(false)) {
                groupsRunning.put(name.toLowerCase(Locale.ROOT), gs.getBoolean(name, false));
            }
        }
    }

    private static BlockFace parseFace(String s) {
        try {
            return BlockFace.valueOf(s.toUpperCase(Locale.ROOT));
        } catch (RuntimeException ex) {
            return BlockFace.NORTH;
        }
    }

    public void save() {
        File file = new File(plugin.getDataFolder(), "fluids.yml");
        YamlConfiguration cfg = new YamlConfiguration();
        for (Pump p : pumps.values()) {
            String b = "pumps." + p.number + ".";
            cfg.set(b + "world", p.world);
            cfg.set(b + "x", p.x);
            cfg.set(b + "y", p.y);
            cfg.set(b + "z", p.z);
            cfg.set(b + "facing", p.facing.name());
            cfg.set(b + "enabled", p.enabled);
            cfg.set(b + "group", p.group);
            cfg.set(b + "concentration", p.concentration);
            cfg.set(b + "poisonSpeed", p.poisonSpeed);
            cfg.set(b + "extraEffect", p.extraEffect);
            List<String> code = new ArrayList<>();
            for (Material m : p.code) {
                code.add(m.name());
            }
            cfg.set(b + "code", code);
        }
        cfg.set("acid", new ArrayList<>(acidKeys));
        for (Map.Entry<String, Boolean> e : groupsRunning.entrySet()) {
            cfg.set("groups." + e.getKey(), e.getValue());
        }
        try {
            cfg.save(file);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
