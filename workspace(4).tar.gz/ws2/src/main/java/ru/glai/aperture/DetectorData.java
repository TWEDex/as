package ru.glai.aperture;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

public final class DetectorData {

    public String world;
    public int x;
    public int y;
    public int z;
    public final List<Material> code = new ArrayList<>();
    public boolean active;

    public DetectorData(Location loc) {
        World w = loc.getWorld();
        this.world = w == null ? "world" : w.getName();
        this.x = loc.getBlockX();
        this.y = loc.getBlockY();
        this.z = loc.getBlockZ();
    }

    public List<String> codeNames() {
        List<String> list = new ArrayList<>();
        for (Material m : code) {
            list.add(m.name());
        }
        return list;
    }

    public void setCodeNames(List<String> names) {
        code.clear();
        if (names == null) {
            return;
        }
        for (String s : names) {
            Material m = Material.matchMaterial(s);
            if (m != null) {
                code.add(m);
            }
        }
    }
}
