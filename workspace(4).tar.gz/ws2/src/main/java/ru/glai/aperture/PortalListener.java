package ru.glai.aperture;

import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class PortalListener implements Listener {

    private final PortalManager portals;
    private final CubeManager cubes;
    private final Items items;

    public PortalListener(PortalManager portals, CubeManager cubes, Items items) {
        this.portals = portals;
        this.cubes = cubes;
        this.items = items;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Player player = event.getPlayer();
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (!items.is(hand, Items.KIND_PORTAL_GUN)) {
            return;
        }
        Action action = event.getAction();
        event.setCancelled(true);

        if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK) {
            portals.placeOrange(player);
            return;
        }
        if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
            if (player.isSneaking()) {
                if (cubes.carriedBy(player) != null) {
                    cubes.release(player);
                    return;
                }
                Block clicked = event.getClickedBlock();
                if (clicked != null && cubes.cubeAt(clicked.getLocation()) != null) {
                    cubes.pickUp(player, clicked);
                }
                return;
            }
            portals.placeBlue(player);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (!cubes.isCubeBlock(block.getLocation())) {
            return;
        }
        event.setCancelled(true);
        Player player = event.getPlayer();
        if (player.hasPermission("aperturescience.admin")) {
            CubeManager.Cube cube = cubes.cubeAt(block.getLocation());
            if (cube != null) {
                cubes.removeCube(cube);
                player.sendMessage("куб удален");
            }
        } else {
            player.sendMessage("куб нельзя сломать");
        }
    }
}
