package ru.glai.aperture;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public final class ButtonListener implements Listener {

    private final ButtonManager manager;
    private final Items items;

    public ButtonListener(ApertureScience plugin, ButtonManager manager, Items items) {
        this.manager = manager;
        this.items = items;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null) {
            return;
        }
        Player player = event.getPlayer();
        ItemStack hand = player.getInventory().getItemInMainHand();
        String kind = items.kindOf(hand);

        if (Items.KIND_BUTTON.equals(kind)) {
            Block target = block.getRelative(event.getBlockFace());
            if (!target.getType().isAir() || !target.getRelative(0, 1, 0).getType().isAir()) {
                player.sendMessage("нужно два свободных блока");
                event.setCancelled(true);
                return;
            }
            event.setCancelled(true);
            WirelessButton button = manager.placeButton(player, target);
            consume(hand, player);
            if (button != null) {
                player.sendMessage("кнопка " + button.number + " создана");
            }
            return;
        }
        if (Items.KIND_DETECTOR.equals(kind)) {
            Block target = block.getRelative(event.getBlockFace());
            if (!target.getType().isAir()) {
                player.sendMessage("место занято");
                event.setCancelled(true);
                return;
            }
            event.setCancelled(true);
            manager.placeDetector(target);
            consume(hand, player);
            player.sendMessage("детектор установлен, настрой ключом");
            return;
        }

        WirelessButton placed = manager.buttonByBlock(block.getLocation());
        if (placed != null) {
            event.setCancelled(true);
            if (Items.KIND_WRENCH.equals(kind)) {
                openMenu(player, placed, null);
            } else {
                manager.press(player, placed);
            }
            return;
        }

        if (Items.KIND_WRENCH.equals(kind)) {
            DetectorData detector = manager.detectorAt(block.getLocation());
            if (detector != null) {
                event.setCancelled(true);
                openMenu(player, null, detector);
            }
        }
    }

    private void consume(ItemStack hand, Player player) {
        if (hand.getAmount() <= 1) {
            player.getInventory().setItemInMainHand(null);
        } else {
            hand.setAmount(hand.getAmount() - 1);
        }
    }

    private void openMenu(Player player, WirelessButton button, DetectorData detector) {
        WrenchMenu menu = new WrenchMenu(manager, button, detector);
        player.openInventory(menu.getInventory());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        Material type = block.getType();
        if (type == Material.DIORITE_WALL || type == Material.CRIMSON_BUTTON) {
            WirelessButton button = manager.buttonByBlock(block.getLocation());
            if (button != null) {
                event.setCancelled(true);
                if (event.getPlayer().hasPermission("aperturescience.admin")) {
                    manager.deleteButton(button.number);
                    event.getPlayer().sendMessage("кнопка " + button.number + " удалена");
                }
                return;
            }
        }
        if (type == Material.DAYLIGHT_DETECTOR || type == Material.REDSTONE_BLOCK) {
            DetectorData detector = manager.detectorAt(block.getLocation());
            if (detector != null) {
                event.setCancelled(true);
                if (event.getPlayer().hasPermission("aperturescience.admin")) {
                    manager.removeDetector(detector);
                    block.setType(Material.AIR, false);
                    event.getPlayer().sendMessage("детектор удален");
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof WrenchMenu)) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        ((WrenchMenu) holder).handleClick(event, (Player) event.getWhoClicked());
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof WrenchMenu)) {
            return;
        }
        if (!(event.getPlayer() instanceof Player)) {
            return;
        }
        ((WrenchMenu) holder).handleClose((Player) event.getPlayer());
    }
}
