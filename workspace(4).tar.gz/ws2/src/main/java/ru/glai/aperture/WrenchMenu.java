package ru.glai.aperture;

import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class WrenchMenu implements InventoryHolder {

    private final ButtonManager manager;
    private final NamespacedKey virtualKey;
    private final WirelessButton button;
    private final DetectorData detector;
    private final Inventory inventory;
    private final int[] codeSlots;
    private final int modeSlot;
    private final int holdSlot;
    private final int leverSlot;
    private final int doneSlot;

    public WrenchMenu(ButtonManager manager, WirelessButton button, DetectorData detector) {
        this.manager = manager;
        this.virtualKey = new NamespacedKey(manager.plugin(), "aperture_virtual");
        this.button = button;
        this.detector = detector;
        boolean isButton = button != null;
        if (isButton) {
            this.inventory = Bukkit.createInventory(this, 45, plain("Настройка кнопки " + button.number));
            this.codeSlots = new int[]{9, 10, 11, 12, 13, 14};
            this.modeSlot = 20;
            this.holdSlot = 22;
            this.leverSlot = 24;
            this.doneSlot = 40;
        } else {
            this.inventory = Bukkit.createInventory(this, 27, plain("Настройка детектора"));
            this.codeSlots = new int[]{10, 11, 12, 13, 14, 15};
            this.modeSlot = -1;
            this.holdSlot = -1;
            this.leverSlot = -1;
            this.doneSlot = 22;
        }
        fill();
    }

    private static Component plain(String text) {
        return Component.text(text).decoration(TextDecoration.ITALIC, false);
    }

    private void fill() {
        ItemStack filler = pane(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, filler);
        }
        List<Material> code = button != null ? button.code : (detector != null ? detector.code : new ArrayList<>());
        for (int i = 0; i < codeSlots.length; i++) {
            Material m = i < code.size() ? code.get(i) : null;
            if (m != null && m.isBlock()) {
                inventory.setItem(codeSlots[i], virtualItem(m));
            } else {
                inventory.setItem(codeSlots[i], null);
            }
        }
        if (button != null) {
            inventory.setItem(modeSlot, modeItem());
            inventory.setItem(holdSlot, holdItem());
            inventory.setItem(leverSlot, leverItem());
        }
        inventory.setItem(doneSlot, doneItem());
    }

    private ItemStack virtualItem(Material material) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(virtualKey, PersistentDataType.BYTE, (byte) 1);
            item.setItemMeta(meta);
        }
        return item;
    }

    private boolean isVirtual(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        return meta != null && meta.getPersistentDataContainer().has(virtualKey, PersistentDataType.BYTE);
    }

    private ItemStack pane(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Component.text(name, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack modeItem() {
        Material m = button.modeLever ? Material.LEVER : Material.STONE_BUTTON;
        String state = button.modeLever ? "рычаг" : "кнопка";
        return named(m, "Режим: " + state, "ЛКМ чтобы сменить");
    }

    private ItemStack holdItem() {
        return named(Material.CLOCK, "Удержание: " + button.holdSeconds + " сек",
                "ЛКМ +1, ПКМ -1 (1-15)");
    }

    private ItemStack leverItem() {
        Material m = button.leverOffNoWrench ? Material.LIME_DYE : Material.RED_DYE;
        String state = button.leverOffNoWrench ? "да" : "нет";
        return named(m, "Выкл. рычаг без ключа: " + state, "ЛКМ чтобы сменить");
    }

    private ItemStack doneItem() {
        return named(Material.LIME_STAINED_GLASS_PANE, "Готово", "Сохранить и закрыть");
    }

    private ItemStack named(Material material, String name, String lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Component.text(name, NamedTextColor.WHITE).decoration(TextDecoration.ITALIC, false));
            List<Component> lines = new ArrayList<>();
            lines.add(Component.text(lore, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
            meta.lore(lines);
            item.setItemMeta(meta);
        }
        return item;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    private boolean isCodeSlot(int raw) {
        for (int slot : codeSlots) {
            if (slot == raw) {
                return true;
            }
        }
        return false;
    }

    public void handleClick(InventoryClickEvent event, Player player) {
        int raw = event.getRawSlot();
        if (raw < 0) {
            return;
        }
        if (raw >= inventory.getSize()) {
            if (event.isShiftClick()) {
                event.setCancelled(true);
            }
            return;
        }
        if (isCodeSlot(raw)) {
            return;
        }
        event.setCancelled(true);
        if (raw == doneSlot) {
            saveCode();
            player.closeInventory();
            return;
        }
        if (button == null) {
            return;
        }
        if (raw == modeSlot) {
            button.modeLever = !button.modeLever;
            inventory.setItem(modeSlot, modeItem());
            manager.save();
            return;
        }
        if (raw == holdSlot) {
            int delta = event.isRightClick() ? -1 : 1;
            button.holdSeconds = Math.max(1, Math.min(15, button.holdSeconds + delta));
            inventory.setItem(holdSlot, holdItem());
            manager.save();
            return;
        }
        if (raw == leverSlot) {
            button.leverOffNoWrench = !button.leverOffNoWrench;
            inventory.setItem(leverSlot, leverItem());
            manager.save();
        }
    }

    public void handleClose(Player player) {
        saveCode();
        List<ItemStack> giveBack = new ArrayList<>();
        for (int slot : codeSlots) {
            ItemStack item = inventory.getItem(slot);
            if (item != null && item.getType() != Material.AIR && !isVirtual(item)) {
                giveBack.add(item.clone());
            }
        }
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, null);
        }
        for (ItemStack item : giveBack) {
            if (player.getInventory().firstEmpty() >= 0) {
                player.getInventory().addItem(item);
            } else {
                player.getWorld().dropItemNaturally(player.getLocation(), item);
            }
        }
        manager.save();
    }

    private void saveCode() {
        List<Material> code = new ArrayList<>();
        for (int slot : codeSlots) {
            ItemStack item = inventory.getItem(slot);
            if (item != null && item.getType() != Material.AIR && item.getType().isBlock()) {
                code.add(item.getType());
            }
        }
        if (button != null) {
            button.code.clear();
            button.code.addAll(code);
        } else if (detector != null) {
            detector.code.clear();
            detector.code.addAll(code);
        }
    }
}
