package ru.glai.aperture;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Powerable;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

public final class CubeManager {

    public static final class Cube {
        public final UUID id = UUID.randomUUID();
        public World world;
        public int bx;
        public int by;
        public int bz;
        public boolean carried;
        public UUID carrier;
        public BlockDisplay display;
        public double vy;
        public boolean onPlate;
    }

    private final JavaPlugin plugin;
    private final Map<UUID, Cube> cubes = new java.util.LinkedHashMap<>();
    private final Map<UUID, UUID> carrying = new HashMap<>();

    public CubeManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public Collection<Cube> cubes() {
        return cubes.values();
    }

    public Cube spawnCube(Location loc) {
        World world = loc.getWorld();
        if (world == null) {
            return null;
        }
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();
        Cube cube = new Cube();
        cube.world = world;
        cube.bx = x;
        cube.by = y;
        cube.bz = z;
        world.getBlockAt(x, y, z).setType(Material.IRON_BLOCK, false);
        cubes.put(cube.id, cube);
        save();
        return cube;
    }

    public Cube cubeAt(Location loc) {
        World w = loc.getWorld();
        if (w == null) {
            return null;
        }
        for (Cube cube : cubes.values()) {
            if (!cube.carried && cube.world.equals(w)
                && cube.bx == loc.getBlockX() && cube.by == loc.getBlockY() && cube.bz == loc.getBlockZ()) {
                return cube;
            }
        }
        return null;
    }

    public Cube cubeAtCell(World world, int x, int y, int z) {
        for (Cube cube : cubes.values()) {
            if (!cube.carried && cube.world.equals(world) && cube.bx == x && cube.by == y && cube.bz == z) {
                return cube;
            }
        }
        return null;
    }

    public boolean isCubeBlock(Location loc) {
        return cubeAt(loc) != null;
    }

    public Cube carriedBy(Player player) {
        UUID id = carrying.get(player.getUniqueId());
        return id == null ? null : cubes.get(id);
    }

    public boolean pickUp(Player player, Block clicked) {
        Cube existing = carriedBy(player);
        if (existing != null) {
            return false;
        }
        Cube cube = cubeAt(clicked.getLocation());
        if (cube == null) {
            return false;
        }
        cube.world.getBlockAt(cube.bx, cube.by, cube.bz).setType(Material.AIR, false);
        unpowerPlateBelow(cube);
        cube.carried = true;
        cube.carrier = player.getUniqueId();
        cube.vy = 0;
        Location eye = player.getEyeLocation();
        BlockDisplay display = cube.world.spawn(eye.clone().add(eye.getDirection().multiply(2.2)), BlockDisplay.class);
        display.setBlock(Material.IRON_BLOCK.createBlockData());
        display.setGravity(false);
        display.setPersistent(false);
        display.setInvulnerable(true);
        display.setTransformation(new Transformation(
            new Vector3f(-0.5F, -0.5F, -0.5F),
            new AxisAngle4f(0.0F, 0.0F, 1.0F, 0.0F),
            new Vector3f(1.0F, 1.0F, 1.0F),
            new AxisAngle4f(0.0F, 0.0F, 1.0F, 0.0F)));
        cube.display = display;
        carrying.put(player.getUniqueId(), cube.id);
        player.playSound(player.getLocation(), Sound.BLOCK_PISTON_CONTRACT, SoundCategory.BLOCKS, 0.6F, 1.2F);
        return true;
    }

    public boolean release(Player player) {
        Cube cube = carriedBy(player);
        if (cube == null) {
            return false;
        }
        if (cube.display != null) {
            cube.display.remove();
            cube.display = null;
        }
        carrying.remove(player.getUniqueId());
        cube.carried = false;
        cube.carrier = null;
        Location target = findReleaseSpot(player);
        cube.world = target.getWorld();
        cube.bx = target.getBlockX();
        cube.by = target.getBlockY();
        cube.bz = target.getBlockZ();
        cube.vy = 0;
        cube.world.getBlockAt(cube.bx, cube.by, cube.bz).setType(Material.IRON_BLOCK, false);
        player.playSound(player.getLocation(), Sound.BLOCK_PISTON_EXTEND, SoundCategory.BLOCKS, 0.6F, 1.0F);
        save();
        return true;
    }

    private Location findReleaseSpot(Player player) {
        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection();
        for (double d = 2.0D; d <= 5.0D; d += 0.5D) {
            Location spot = eye.clone().add(dir.clone().multiply(d));
            Block b = spot.getBlock();
            if (b.getType().isAir() || b.isLiquid() || !b.getType().isSolid()) {
                return new Location(player.getWorld(), b.getX(), b.getY(), b.getZ());
            }
        }
        Location spot = eye.clone().add(dir.clone().multiply(3.0D));
        Block b = spot.getBlock();
        return new Location(player.getWorld(), b.getX(), b.getY(), b.getZ());
    }

    public void removeCube(Cube cube) {
        if (cube.display != null) {
            cube.display.remove();
        }
        if (!cube.carried) {
            Block b = cube.world.getBlockAt(cube.bx, cube.by, cube.bz);
            if (b.getType() == Material.IRON_BLOCK) {
                b.setType(Material.AIR, false);
            }
            unpowerPlateBelow(cube);
        }
        if (cube.carrier != null) {
            carrying.remove(cube.carrier);
        }
        cubes.remove(cube.id);
        save();
    }

    public void teleportCube(Cube cube, Location to, double newVy) {
        if (cube.carried) {
            return;
        }
        cube.world.getBlockAt(cube.bx, cube.by, cube.bz).setType(Material.AIR, false);
        unpowerPlateBelow(cube);
        cube.world = to.getWorld();
        cube.bx = to.getBlockX();
        cube.by = to.getBlockY();
        cube.bz = to.getBlockZ();
        cube.vy = newVy;
        cube.world.getBlockAt(cube.bx, cube.by, cube.bz).setType(Material.IRON_BLOCK, false);
    }

    public void tick() {
        for (Cube cube : new ArrayList<>(cubes.values())) {
            if (cube.carried) {
                tickCarried(cube);
            } else {
                tickGravity(cube);
            }
        }
    }

    private void tickCarried(Cube cube) {
        Player player = cube.carrier == null ? null : plugin.getServer().getPlayer(cube.carrier);
        if (player == null || !player.isOnline()) {
            if (cube.display != null) {
                cube.display.remove();
                cube.display = null;
            }
            cube.carried = false;
            cube.carrier = null;
            if (cube.carrier != null) {
                carrying.remove(cube.carrier);
            }
            cube.world.getBlockAt(cube.bx, cube.by, cube.bz).setType(Material.IRON_BLOCK, false);
            return;
        }
        if (cube.display == null || cube.display.isDead()) {
            cube.display = null;
            return;
        }
        Location eye = player.getEyeLocation();
        Location spot = eye.clone().add(eye.getDirection().multiply(2.2));
        cube.display.teleport(spot);
    }

    private void tickGravity(Cube cube) {
        World world = cube.world;
        Block here = world.getBlockAt(cube.bx, cube.by, cube.bz);
        if (here.getType() != Material.IRON_BLOCK) {
            here.setType(Material.IRON_BLOCK, false);
        }
        Block below = world.getBlockAt(cube.bx, cube.by - 1, cube.bz);
        if (canFallThrough(below)) {
            here.setType(Material.AIR, false);
            cube.by--;
            cube.vy = Math.max(cube.vy - 0.12D, -1.6D);
            world.getBlockAt(cube.bx, cube.by, cube.bz).setType(Material.IRON_BLOCK, false);
            cube.onPlate = false;
            return;
        }
        cube.vy = 0;
        BlockData data = below.getBlockData();
        boolean plate = data instanceof Powerable && below.getType().name().endsWith("PRESSURE_PLATE");
        if (plate) {
            Powerable p = (Powerable) data;
            if (!p.isPowered()) {
                p.setPowered(true);
                below.setBlockData(p, true);
                if (!cube.onPlate) {
                    world.playSound(below.getLocation(), Sound.BLOCK_WOODEN_PRESSURE_PLATE_CLICK_ON, SoundCategory.BLOCKS, 0.5F, 1.0F);
                }
            } else {
                below.setBlockData(p, false);
            }
            cube.onPlate = true;
        } else {
            cube.onPlate = false;
        }
    }

    private void unpowerPlateBelow(Cube cube) {
        Block below = cube.world.getBlockAt(cube.bx, cube.by - 1, cube.bz);
        BlockData data = below.getBlockData();
        if (data instanceof Powerable) {
            Powerable p = (Powerable) data;
            if (p.isPowered()) {
                p.setPowered(false);
                below.setBlockData(p, true);
            }
        }
        cube.onPlate = false;
    }

    private static boolean canFallThrough(Block below) {
        BlockData data = below.getBlockData();
        if (data instanceof Powerable) {
            return false;
        }
        Material m = below.getType();
        return m.isAir() || m == Material.WATER || m == Material.LAVA || !m.isSolid();
    }

    public void load() {
        cubes.clear();
        carrying.clear();
        File file = new File(plugin.getDataFolder(), "cubes.yml");
        if (!file.exists()) {
            return;
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        for (Map<?, ?> e : cfg.getMapList("cubes")) {
            World world = Worlds.resolve(String.valueOf(e.get("world")));
            if (world == null) {
                continue;
            }
            int x = toInt(e.get("x"));
            int y = toInt(e.get("y"));
            int z = toInt(e.get("z"));
            Cube cube = new Cube();
            cube.world = world;
            cube.bx = x;
            cube.by = y;
            cube.bz = z;
            world.getBlockAt(x, y, z).setType(Material.IRON_BLOCK, false);
            cubes.put(cube.id, cube);
        }
    }

    private static int toInt(Object o) {
        if (o instanceof Number) {
            return ((Number) o).intValue();
        }
        try {
            return Integer.parseInt(String.valueOf(o));
        } catch (NumberFormatException ex) {
            return 0;
        }
    }

    public void save() {
        File file = new File(plugin.getDataFolder(), "cubes.yml");
        YamlConfiguration cfg = new YamlConfiguration();
        List<Map<String, Object>> list = new ArrayList<>();
        for (Cube cube : cubes.values()) {
            if (cube.carried) {
                continue;
            }
            Map<String, Object> m = new HashMap<>();
            m.put("world", cube.world.getName());
            m.put("x", cube.bx);
            m.put("y", cube.by);
            m.put("z", cube.bz);
            list.add(m);
        }
        cfg.set("cubes", list);
        try {
            cfg.save(file);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void shutdown() {
        for (Cube cube : cubes.values()) {
            if (cube.display != null) {
                cube.display.remove();
            }
        }
        save();
    }
}
