package ru.glai.aperture;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.HashSet;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Lightable;
import org.bukkit.block.data.Openable;
import org.bukkit.block.data.Powerable;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

public final class Elevator {

    public enum State {
        IDLE,
        BLINK,
        WAIT_BOARD,
        HOLD_BOARD,
        MOVE_FAR,
        HOLD_FAR_OPEN,
        WAIT_EXIT,
        HOLD_FAR_CLOSE,
        MOVE_HOME,
        RESET
    }

    private final ApertureScience plugin;
    private final ElevatorConfig config;

    private final int[] homeBox = new int[6];
    private final int[] stepVec = new int[3];
    private int totalSteps;

    private boolean enabled;
    private State state = State.IDLE;
    private boolean waitHome = true;
    private boolean waitFar = true;
    private int timer;
    private boolean lampsOn;
    private int progress;
    private int moveTicks;
    private BukkitTask ambienceTask;
    private final Set<UUID> soundTargets = new HashSet<>();

    public Elevator(ApertureScience plugin, ElevatorConfig config, boolean enabled) {
        this.plugin = plugin;
        this.config = config;
        this.enabled = enabled;
        computeGeometry();
    }

    private void computeGeometry() {
        normalize(config.cabinHomeA, config.cabinHomeB, homeBox);
        int dx = config.cabinFarA.getBlockX() - config.cabinHomeA.getBlockX();
        int dy = config.cabinFarA.getBlockY() - config.cabinHomeA.getBlockY();
        int dz = config.cabinFarA.getBlockZ() - config.cabinHomeA.getBlockZ();
        stepVec[0] = Integer.signum(dx);
        stepVec[1] = Integer.signum(dy);
        stepVec[2] = Integer.signum(dz);
        totalSteps = Math.max(Math.abs(dx), Math.max(Math.abs(dy), Math.abs(dz)));
    }

    private static void normalize(Location a, Location b, int[] out) {
        out[0] = Math.min(a.getBlockX(), b.getBlockX());
        out[1] = Math.min(a.getBlockY(), b.getBlockY());
        out[2] = Math.min(a.getBlockZ(), b.getBlockZ());
        out[3] = Math.max(a.getBlockX(), b.getBlockX());
        out[4] = Math.max(a.getBlockY(), b.getBlockY());
        out[5] = Math.max(a.getBlockZ(), b.getBlockZ());
    }

    public String id() {
        return config.id;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean value) {
        enabled = value;
        if (state == State.IDLE) {
            applyIdleLamps();
        }
    }

    private void applyIdleLamps() {
        applyLamps(false);
        if (!enabled) {
            for (Location location : config.blinkLamps) {
                setLamp(location, true);
            }
        }
    }

    public boolean isRunning() {
        return state != State.IDLE;
    }

    public boolean isButton(Location location) {
        if (location == null || location.getWorld() == null || config.button.getWorld() == null) {
            return false;
        }
        return location.getWorld().getUID().equals(config.button.getWorld().getUID())
                && location.getBlockX() == config.button.getBlockX()
                && location.getBlockY() == config.button.getBlockY()
                && location.getBlockZ() == config.button.getBlockZ();
    }

    public void pressButton() {
        if (!enabled || state != State.IDLE) {
            return;
        }
        waitHome = true;
        waitFar = true;
        begin();
    }

    public void remoteStart() {
        remoteStart(true, true);
    }

    public void remoteStart(boolean waitAtHome, boolean waitAtFar) {
        if (state != State.IDLE) {
            return;
        }
        waitHome = waitAtHome;
        waitFar = waitAtFar;
        begin();
    }

    public void tick() {
        if (config.world() == null) {
            return;
        }
        switch (state) {
            case BLINK:
                timer--;
                if (timer % config.blinkPeriod == 0) {
                    lampsOn = !lampsOn;
                    applyLamps(lampsOn);
                    if (lampsOn) {
                        playBlinkSound();
                    }
                }
                if (timer <= 0) {
                    lampsOn = true;
                    applyLamps(true);
                    setDoors(config.shoreDoors, true, zero());
                    setDoors(config.cabinDoorsWest, true, zero());
                    if (waitHome) {
                        state = State.WAIT_BOARD;
                        timer = 0;
                    } else {
                        state = State.HOLD_BOARD;
                        timer = config.boardDelay;
                    }
                }
                break;
            case WAIT_BOARD:
                timer++;
                if (timer % config.checkPeriod == 0 && playerInCabin()) {
                    state = State.HOLD_BOARD;
                    timer = config.boardDelay;
                }
                break;
            case HOLD_BOARD:
                timer--;
                if (timer <= 0) {
                    setDoors(config.shoreDoors, false, zero());
                    setDoors(config.cabinDoorsWest, false, zero());
                    state = State.MOVE_FAR;
                    moveTicks = 0;
                }
                break;
            case MOVE_FAR:
                moveTicks++;
                if (moveTicks >= config.movePeriod) {
                    moveTicks = 0;
                    if (progress >= totalSteps) {
                        stopAmbience();
                        playArrivalSound();
                        setDoors(config.cabinDoorsEast, true, currentOffset());
                        setDoors(config.farShoreDoors, true, zero());
                        state = State.HOLD_FAR_OPEN;
                        timer = config.exitDelay;
                    } else {
                        doStep(1);
                    }
                }
                break;
            case HOLD_FAR_OPEN:
                timer--;
                if (timer <= 0) {
                    if (waitFar) {
                        state = State.WAIT_EXIT;
                        timer = 0;
                    } else {
                        setDoors(config.cabinDoorsEast, false, currentOffset());
                        setDoors(config.farShoreDoors, false, zero());
                        state = State.HOLD_FAR_CLOSE;
                        timer = config.departDelay;
                    }
                }
                break;
            case WAIT_EXIT:
                timer++;
                if (timer % config.checkPeriod == 0 && !playerInCabin()) {
                    setDoors(config.cabinDoorsEast, false, currentOffset());
                    setDoors(config.farShoreDoors, false, zero());
                    state = State.HOLD_FAR_CLOSE;
                    timer = config.departDelay;
                }
                break;
            case HOLD_FAR_CLOSE:
                timer--;
                if (timer <= 0) {
                    state = State.MOVE_HOME;
                    moveTicks = 0;
                }
                break;
            case MOVE_HOME:
                moveTicks++;
                if (moveTicks >= config.movePeriod) {
                    moveTicks = 0;
                    if (progress <= 0) {
                        state = State.RESET;
                        timer = 10;
                    } else {
                        doStep(-1);
                    }
                }
                break;
            case RESET:
                timer--;
                if (timer <= 0) {
                    shutdown();
                }
                break;
            case IDLE:
            default:
                break;
        }
    }

    private void begin() {
        if (config.world() == null) {
            return;
        }
        progress = 0;
        moveTicks = 0;
        lampsOn = true;
        applyLamps(true);
        playBlinkSound();
        startAmbience();
        state = State.BLINK;
        timer = config.blinkDuration;
    }

    private void doStep(int sign) {
        World world = config.world();
        if (world == null) {
            return;
        }
        int[] box = currentBox();
        Vector delta = new Vector(stepVec[0] * sign, stepVec[1] * sign, stepVec[2] * sign);

        int wx = box[3] - box[0] + 1;
        int wy = box[4] - box[1] + 1;
        int wz = box[5] - box[2] + 1;
        BlockData[][][] snapshot = new BlockData[wx][wy][wz];
        for (int x = 0; x < wx; x++) {
            for (int y = 0; y < wy; y++) {
                for (int z = 0; z < wz; z++) {
                    snapshot[x][y][z] = world.getBlockAt(box[0] + x, box[1] + y, box[2] + z).getBlockData();
                }
            }
        }

        List<Entity> riders = collectEntities(box);

        for (int x = 0; x < wx; x++) {
            for (int y = 0; y < wy; y++) {
                for (int z = 0; z < wz; z++) {
                    Block b = world.getBlockAt(box[0] + x, box[1] + y, box[2] + z);
                    if (b.getType() != Material.AIR) {
                        b.setType(Material.AIR, false);
                    }
                }
            }
        }

        progress += sign;

        int[] newBox = currentBox();
        for (int x = 0; x < wx; x++) {
            for (int y = 0; y < wy; y++) {
                for (int z = 0; z < wz; z++) {
                    BlockData data = snapshot[x][y][z];
                    if (data != null && data.getMaterial() != Material.AIR) {
                        world.getBlockAt(newBox[0] + x, newBox[1] + y, newBox[2] + z).setBlockData(data, false);
                    }
                }
            }
        }

        teleportEntities(riders, delta);

        if (config.moveSoundEnabled && Math.abs(progress) % config.moveSoundPeriod == 0) {
            Location center = cabinCenter();
            world.playSound(center, config.moveSound, SoundCategory.BLOCKS, config.moveSoundVolume, config.moveSoundPitch);
        }

        if (config.smokeEnabled && Math.abs(progress) % config.smokePeriod == 0) {
            spawnSmoke();
        }
    }

    private List<Entity> collectEntities(int[] box) {
        World world = config.world();
        List<Entity> result = new ArrayList<>();
        if (world == null) {
            return result;
        }
        BoundingBox bb = new BoundingBox(box[0], box[1], box[2], box[3] + 1, box[4] + 1, box[5] + 1);
        for (Entity entity : world.getNearbyEntities(bb)) {
            if (entity.isInsideVehicle()) {
                continue;
            }
            if (entity.getBoundingBox().overlaps(bb)) {
                result.add(entity);
            }
        }
        return result;
    }

    private void teleportEntities(List<Entity> entities, Vector delta) {
        for (Entity entity : entities) {
            if (!entity.isValid() || entity.isDead()) {
                continue;
            }
            Location loc = entity.getLocation().add(delta);
            if (entity instanceof Player) {
                entity.teleport(loc, PlayerTeleportEvent.TeleportCause.PLUGIN);
            } else {
                entity.teleport(loc);
            }
        }
    }

    private boolean playerInCabin() {
        World world = config.world();
        if (world == null) {
            return false;
        }
        int[] box = currentBox();
        BoundingBox bb = new BoundingBox(box[0], box[1], box[2], box[3] + 1, box[4] + 1, box[5] + 1);
        for (Entity entity : world.getNearbyEntities(bb)) {
            if (entity instanceof Player && entity.getBoundingBox().overlaps(bb)) {
                return true;
            }
        }
        return false;
    }

    private int[] currentBox() {
        Vector off = currentOffset();
        return new int[]{
                homeBox[0] + off.getBlockX(), homeBox[1] + off.getBlockY(), homeBox[2] + off.getBlockZ(),
                homeBox[3] + off.getBlockX(), homeBox[4] + off.getBlockY(), homeBox[5] + off.getBlockZ()
        };
    }

    private Vector currentOffset() {
        return new Vector(stepVec[0] * progress, stepVec[1] * progress, stepVec[2] * progress);
    }

    private static Vector zero() {
        return new Vector(0, 0, 0);
    }

    private Location cabinCenter() {
        World world = config.world();
        int[] box = currentBox();
        return new Location(world, (box[0] + box[3] + 1) / 2.0D, (box[1] + box[4] + 1) / 2.0D, (box[2] + box[5] + 1) / 2.0D);
    }

    private Location cabinTop() {
        World world = config.world();
        int[] box = currentBox();
        return new Location(world, (box[0] + box[3] + 1) / 2.0D, box[4] + 1.0D, (box[2] + box[5] + 1) / 2.0D);
    }

    private void playBlinkSound() {
        if (!config.blinkSoundEnabled) {
            return;
        }
        World world = config.world();
        if (world == null) {
            return;
        }
        Location at = config.statusLamp != null ? config.statusLamp : config.button;
        world.playSound(at, config.blinkSound, SoundCategory.BLOCKS, config.blinkSoundVolume, config.blinkSoundPitch);
    }

    private void playArrivalSound() {
        if (!config.arrivalSoundEnabled) {
            return;
        }
        World world = config.world();
        if (world == null) {
            return;
        }
        world.playSound(cabinCenter(), config.arrivalSound, SoundCategory.BLOCKS, config.arrivalSoundVolume, config.arrivalSoundPitch);
    }

    private void spawnSmoke() {
        World world = config.world();
        if (world == null) {
            return;
        }
        Particle particle;
        try {
            particle = Particle.valueOf(config.smokeParticle.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            particle = Particle.SMOKE;
        }
        Location top = cabinTop();
        double s = config.smokeSpread;
        world.spawnParticle(particle, top, config.smokeCount, s, 0.15D, s, config.smokeSpeed);
    }

    public void shutdown() {
        state = State.IDLE;
        timer = 0;
        moveTicks = 0;
        progress = 0;
        lampsOn = false;
        applyIdleLamps();
        setDoors(config.shoreDoors, false, zero());
        setDoors(config.cabinDoorsWest, false, zero());
        setDoors(config.cabinDoorsEast, false, currentOffset());
        setDoors(config.farShoreDoors, false, zero());
        stopAmbience();
    }

    public void restore() {
        if (config.world() == null) {
            return;
        }
        progress = 0;
        applyIdleLamps();
        setDoors(config.shoreDoors, false, zero());
        setDoors(config.cabinDoorsWest, false, zero());
        setDoors(config.cabinDoorsEast, false, zero());
        setDoors(config.farShoreDoors, false, zero());
    }

    public void stop() {
        stopAmbience();
        state = State.IDLE;
    }

    public void playerJoined(Player player) {
        if (ambienceTask != null) {
            playAmbience();
        }
    }

    public String statusLine() {
        String head = enabled ? "lift " + config.id + ": enabled" : "lift " + config.id + ": disabled";
        return head + ", " + stateText();
    }

    private String stateText() {
        switch (state) {
            case BLINK:
                return "state starting, lamps blinking";
            case WAIT_BOARD:
                return "state waiting for passenger";
            case HOLD_BOARD:
                return "state doors closing";
            case MOVE_FAR:
                return "state moving to far point";
            case HOLD_FAR_OPEN:
                return "state far doors opening";
            case WAIT_EXIT:
                return "state waiting for exit";
            case HOLD_FAR_CLOSE:
                return "state far doors closing";
            case MOVE_HOME:
                return "state returning";
            case RESET:
                return "state finishing";
            case IDLE:
            default:
                return "state idle";
        }
    }

    private void applyLamps(boolean on) {
        setLamp(config.statusLamp, on);
        for (Location location : config.blinkLamps) {
            setLamp(location, on);
        }
    }

    private void setLamp(Location location, boolean on) {
        World world = config.world();
        if (world == null || location == null) {
            return;
        }
        Block block = world.getBlockAt(location.getBlockX(), location.getBlockY(), location.getBlockZ());
        BlockData data = block.getBlockData();
        boolean changed = false;
        if (data instanceof Lightable) {
            Lightable lightable = (Lightable) data;
            if (lightable.isLit() != on) {
                lightable.setLit(on);
                changed = true;
            }
        }
        if (data instanceof Powerable) {
            Powerable powerable = (Powerable) data;
            if (powerable.isPowered() != on) {
                powerable.setPowered(on);
                changed = true;
            }
        }
        if (changed) {
            block.setBlockData(data, false);
        }
    }

    private void setDoors(List<Location> doors, boolean open, Vector offset) {
        World world = config.world();
        if (world == null) {
            return;
        }
        for (Location location : doors) {
            int bx = location.getBlockX() + offset.getBlockX();
            int by = location.getBlockY() + offset.getBlockY();
            int bz = location.getBlockZ() + offset.getBlockZ();
            Block bottom = world.getBlockAt(bx, by, bz);
            BlockData data = bottom.getBlockData();
            if (data instanceof Openable) {
                Openable openable = (Openable) data;
                if (openable.isOpen() != open) {
                    openable.setOpen(open);
                    bottom.setBlockData(openable, false);
                    world.playSound(bottom.getLocation(), open ? Sound.BLOCK_IRON_DOOR_OPEN : Sound.BLOCK_IRON_DOOR_CLOSE, SoundCategory.BLOCKS, 1.0F, 1.0F);
                }
                Block top = world.getBlockAt(bx, by + 1, bz);
                BlockData topData = top.getBlockData();
                if (topData instanceof Openable) {
                    Openable topOpenable = (Openable) topData;
                    if (topOpenable.isOpen() != open) {
                        topOpenable.setOpen(open);
                        top.setBlockData(topOpenable, false);
                    }
                }
            }
        }
    }

    private void startAmbience() {
        if (ambienceTask != null) {
            return;
        }
        soundTargets.clear();
        playAmbience();
        ambienceTask = Bukkit.getScheduler().runTaskTimer(plugin, this::playAmbience, config.ambiencePeriod, config.ambiencePeriod);
    }

    private void playAmbience() {
        World world = config.world();
        if (world == null || config.ambienceLocation == null) {
            return;
        }
        world.playSound(config.ambienceLocation, config.ambienceSound, category(config.ambienceCategory), config.ambienceVolume, config.ambiencePitch);
    }

    private void stopAmbience() {
        if (ambienceTask != null) {
            ambienceTask.cancel();
            ambienceTask = null;
        }
        SoundCategory cat = category(config.ambienceCategory);
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.stopSound(config.ambienceSound, cat);
        }
        soundTargets.clear();
    }

    private static SoundCategory category(String raw) {
        if (raw == null) {
            return SoundCategory.MASTER;
        }
        try {
            return SoundCategory.valueOf(raw.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return SoundCategory.MASTER;
        }
    }
}
