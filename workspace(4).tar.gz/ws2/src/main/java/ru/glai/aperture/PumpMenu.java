package ru.glai.aperture;

import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffectType;

public final class PumpMenu implements InventoryHolder {

    private static final String[] EFFECTS = {"", "BLINDNESS", "SLOWNESS", "WEAKNESS", "HUNGER", "MINING_FATIGUE"};

    private final FluidSystem fluids;
    private final FluidSystem.Pump pump;
    private final Inventory inventory;

    public PumpMenu(FluidSystem fluids, FluidSystem.Pump pump) {
        this.fluids = fluids;
        this.pump = pump;
        this.inventory = Bukkit.createInventory(this, 36, "Pump " + pump.number);
        rebuild();
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    private void rebuild() {
        inventory.clear();
        inventory.setItem(10, info("Enabled", pump.enabled ? Material.LIME_DYE : Material.RED_DYE, List.of(
            "Status: " + (pump.enabled ? "on" : "off"),
            "Click to toggle"
        )));
        inventory.setItem(12, info("Concentration", Material.SLIME_BALL, List.of(
            "Level: " + pump.concentration + " / 5",
            "Click +1, shift-click -1",
            "Higher level = stronger poison"
        )));
        inventory.setItem(14, info("Death timer", Material.CLOCK, List.of(
            "Seconds to death: " + pump.poisonSpeed,
            "Click +1, shift-click -1, min 3"
        )));
        inventory.setItem(16, info("Extra effect", Material.POTION, List.of(
            "Effect: " + (pump.extraEffect.isEmpty() ? "none" : pump.extraEffect),
            "Click to cycle"
        )));
        inventory.setItem(22, info("Group", Material.NAME_TAG, List.of(
            "Group: " + (pump.group.isEmpty() ? "none" : pump.group),
            "Pump sprays when its group is started",
            "Set with /asm pump " + pump.number + " group <name>"
        )));
        for (int i = 0; i < 8; i++) {
            int slot = 27 + i;
            if (i < pump.code.size()) {
                inventory.setItem(slot, new ItemStack(pump.code.get(i)));
            } else {
                inventory.setItem(slot, info("Empty slot", Material.LIGHT_GRAY_STAINED_GLASS_PANE,
                    List.of("Click with item in hand to add", "Click with empty hand to clear")));
            }
        }
    }

    public void handleClick(Player player, int slot, boolean shift) {
        if (slot == 10) {
            pump.enabled = !pump.enabled;
        } else if (slot == 12) {
            pump.concentration += shift ? -1 : 1;
            pump.concentration = Math.max(1, Math.min(5, pump.concentration));
        } else if (slot == 14) {
            pump.poisonSpeed += shift ? -1 : 1;
            pump.poisonSpeed = Math.max(3, Math.min(60, pump.poisonSpeed));
        } else if (slot == 16) {
            int idx = 0;
            for (int i = 0; i < EFFECTS.length; i++) {
                if (EFFECTS[i].equalsIgnoreCase(pump.extraEffect)) {
                    idx = i;
                }
            }
            idx = (idx + (shift ? EFFECTS.length - 1 : 1)) % EFFECTS.length;
            pump.extraEffect = EFFECTS[idx];
        } else if (slot >= 27 && slot <= 34) {
            int index = slot - 27;
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (hand.getType() == Material.AIR) {
                if (index < pump.code.size()) {
                    pump.code.remove(index);
                }
            } else {
                if (index < pump.code.size()) {
                    pump.code.set(index, hand.getType());
                } else {
                    while (pump.code.size() < index) {
                        pump.code.add(Material.STONE);
                    }
                    pump.code.add(hand.getType());
                }
            }
        } else {
            return;
        }
        fluids.save();
        rebuild();
    }

    public static PotionEffectType effectByName(String name) {
        if (name == null || name.isEmpty()) {
            return null;
        }
        return PotionEffectType.getByName(name.toUpperCase());
    }

    private static ItemStack info(String title, Material material, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.RESET + title);
            meta.setLore(lore.stream().map(s -> ChatColor.GRAY + s).toList());
            item.setItemMeta(meta);
        }
        return item;
    }
}
