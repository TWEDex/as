package ru.glai.aperture;

import java.io.File;
import java.io.IOException;
import java.util.Base64;
import java.util.UUID;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public final class ItemStorage {

    private final File folder;

    public ItemStorage(Plugin plugin) {
        this.folder = new File(plugin.getDataFolder(), "storage");
        if (!this.folder.exists()) {
            this.folder.mkdirs();
        }
    }

    private File file(UUID id) {
        return new File(folder, id.toString() + ".yml");
    }

    public boolean has(UUID id) {
        return file(id).exists();
    }

    public void save(UUID id, String name, ItemStack[] contents) {
        FileConfiguration cfg = new YamlConfiguration();
        cfg.set("name", name);
        cfg.set("items", Base64.getEncoder().encodeToString(ItemStack.serializeItemsAsBytes(contents)));
        try {
            cfg.save(file(id));
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public ItemStack[] load(UUID id) {
        File f = file(id);
        if (!f.exists()) {
            return null;
        }
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        String encoded = cfg.getString("items");
        if (encoded == null) {
            return null;
        }
        try {
            return ItemStack.deserializeItemsFromBytes(Base64.getDecoder().decode(encoded));
        } catch (RuntimeException ex) {
            return null;
        }
    }

    public String storedName(UUID id) {
        File f = file(id);
        if (!f.exists()) {
            return null;
        }
        return YamlConfiguration.loadConfiguration(f).getString("name");
    }

    public void remove(UUID id) {
        File f = file(id);
        if (f.exists()) {
            f.delete();
        }
    }
}
