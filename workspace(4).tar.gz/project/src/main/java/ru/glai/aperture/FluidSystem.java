package ru.glai.aperture;

import java.io.File;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import ru.glai.aperture.Items;
import ru.glai.aperture.Worlds;

public final class FluidSystem {
    private static final double ACID_RADIUS = 2.2;
    private static final int ACID_DEATH_SECONDS = 5;
    private static final BlockFace[] FACES = new BlockFace[]{BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST, BlockFace.UP, BlockFace.DOWN};
    private final JavaPlugin plugin;
    private final Items items;
    private final Random random = new Random();
    private final Map<Integer, Pump> pumps = new LinkedHashMap<Integer, Pump>();
    private final Map<String, Pump> pumpByLoc = new HashMap<String, Pump>();
    private final Set<String> acidKeys = new HashSet<String>();
    private final Map<String, Boolean> groupsRunning = new LinkedHashMap<String, Boolean>();
    private final Map<Integer, GasCloud> pumpClouds = new HashMap<Integer, GasCloud>();
    private final List<GasCloud> tempClouds = new ArrayList<GasCloud>();
    private final Map<UUID, Integer> neuroSeconds = new HashMap<UUID, Integer>();
    private final Map<UUID, Integer> acidSeconds = new HashMap<UUID, Integer>();
    private int fillSecondsDefault = 15;
    private int maxCells = 1500;
    private int deathSecondsDefault = 10;
    private int particleCap = 40;
    private long clock;

    public FluidSystem(JavaPlugin javaPlugin, Items items) {
        this.plugin = javaPlugin;
        this.items = items;
        this.fillSecondsDefault = Math.max(1, javaPlugin.getConfig().getInt("neurotoxin.fill-seconds", 15));
        this.maxCells = Math.max(50, javaPlugin.getConfig().getInt("neurotoxin.max-cells", 1500));
        this.deathSecondsDefault = Math.max(1, javaPlugin.getConfig().getInt("neurotoxin.death-seconds", 10));
        this.particleCap = Math.max(1, javaPlugin.getConfig().getInt("neurotoxin.particles-per-tick", 40));
    }

    public Items items() {
        return this.items;
    }

    public JavaPlugin plugin() {
        return this.plugin;
    }

    public int fillSecondsDefault() {
        return this.fillSecondsDefault;
    }

    private static String key(String string, int n, int n2, int n3) {
        return string + " " + n + " " + n2 + " " + n3;
    }

    private static String cellKey(int n, int n2, int n3) {
        return n + " " + n2 + " " + n3;
    }

    private static String key(Location location) {
        World world = location.getWorld();
        return FluidSystem.key(world == null ? "world" : world.getName(), location.getBlockX(), location.getBlockY(), location.getBlockZ());
    }

    public int lowestFreePump() {
        TreeSet<Integer> treeSet = new TreeSet<Integer>(this.pumps.keySet());
        int n = 1;
        while (treeSet.contains(n)) {
            ++n;
        }
        return n;
    }

    public Pump pump(int n) {
        return this.pumps.get(n);
    }

    public Map<Integer, Pump> pumps() {
        return this.pumps;
    }

    public Pump pumpAt(Location location) {
        return this.pumpByLoc.get(FluidSystem.key(location));
    }

    public Pump placePump(Player player, Block block) {
        block.setType(Material.DISPENSER);
        BlockFace blockFace = FluidSystem.lookFace(player);
        BlockData blockData = block.getBlockData();
        if (blockData instanceof Directional) {
            Directional directional = (Directional)blockData;
            if (directional.getFaces().contains(blockFace)) {
                directional.setFacing(blockFace);
            }
            block.setBlockData(directional, false);
        }
        Pump pump = new Pump();
        pump.number = this.lowestFreePump();
        pump.world = block.getWorld().getName();
        pump.x = block.getX();
        pump.y = block.getY();
        pump.z = block.getZ();
        pump.facing = blockFace;
        this.pumps.put(pump.number, pump);
        this.pumpByLoc.put(FluidSystem.key(pump.world, pump.x, pump.y, pump.z), pump);
        this.save();
        return pump;
    }

    private static BlockFace lookFace(Player player) {
        Vector vector = player.getLocation().getDirection();
        double d = Math.abs(vector.getX());
        double d2 = Math.abs(vector.getY());
        double d3 = Math.abs(vector.getZ());
        if (d2 > d && d2 > d3) {
            return vector.getY() > 0.0 ? BlockFace.UP : BlockFace.DOWN;
        }
        if (d > d3) {
            return vector.getX() > 0.0 ? BlockFace.EAST : BlockFace.WEST;
        }
        return vector.getZ() > 0.0 ? BlockFace.SOUTH : BlockFace.NORTH;
    }

    public boolean deletePump(int n) {
        Block block;
        Pump pump = this.pumps.remove(n);
        if (pump == null) {
            return false;
        }
        this.pumpByLoc.remove(FluidSystem.key(pump.world, pump.x, pump.y, pump.z));
        this.pumpClouds.remove(n);
        World world = Worlds.resolve(pump.world);
        if (world != null && (block = world.getBlockAt(pump.x, pump.y, pump.z)).getType() == Material.DISPENSER) {
            block.setType(Material.AIR, false);
        }
        this.save();
        return true;
    }

    public void placeAcid(Block block) {
        block.setType(Material.WATER, false);
        this.acidKeys.add(FluidSystem.key(block.getLocation()));
        this.save();
    }

    public boolean isAcid(String string) {
        return this.acidKeys.contains(string);
    }

    public void removeAcid(String string) {
        if (this.acidKeys.remove(string)) {
            this.save();
        }
    }

    public Set<String> acidKeys() {
        return this.acidKeys;
    }

    public void groupSetRunning(String string, boolean bl) {
        this.groupsRunning.put(string.toLowerCase(Locale.ROOT), bl);
        this.save();
    }

    public boolean groupRunning(String string) {
        if (string == null) {
            return false;
        }
        Boolean bl = this.groupsRunning.get(string.toLowerCase(Locale.ROOT));
        return bl != null && bl != false;
    }

    public Set<String> groupNames() {
        return this.groupsRunning.keySet();
    }

    public List<Pump> groupMembers(String string) {
        ArrayList<Pump> arrayList = new ArrayList<Pump>();
        String string2 = string.toLowerCase(Locale.ROOT);
        for (Pump pump : this.pumps.values()) {
            if (pump.group == null || !pump.group.toLowerCase(Locale.ROOT).equals(string2)) continue;
            arrayList.add(pump);
        }
        return arrayList;
    }

    public void addEmitter(World world, double d, double d2, double d3, int n, int n2) {
        GasCloud gasCloud = new GasCloud();
        gasCloud.world = world;
        gasCloud.cells = this.computeRoom(world, (int)Math.floor(d), (int)Math.floor(d2), (int)Math.floor(d3));
        gasCloud.fillTotalTicks = Math.max(20, this.fillSecondsDefault * 20);
        gasCloud.deathSeconds = this.deathSecondsDefault;
        gasCloud.concentration = Math.max(1, Math.min(5, n2));
        gasCloud.lifeTicks = Math.max(20, n * 20);
        this.tempClouds.add(gasCloud);
    }

    private List<int[]> computeRoom(World world, int n, int n2, int n3) {
        int n4;
        int n5;
        ArrayList<int[]> arrayList = new ArrayList<int[]>();
        if (world == null) {
            return arrayList;
        }
        HashSet<String> hashSet = new HashSet<String>();
        ArrayDeque<int[]> arrayDeque = new ArrayDeque<int[]>();
        for (BlockFace blockFace : FACES) {
            int n6 = n + blockFace.getModX();
            if (!FluidSystem.isGas(world, n6, n5 = n2 + blockFace.getModY(), n4 = n3 + blockFace.getModZ()) || !hashSet.add(FluidSystem.cellKey(n6, n5, n4))) continue;
            arrayDeque.add(new int[]{n6, n5, n4});
        }
        while (!arrayDeque.isEmpty() && arrayList.size() < this.maxCells) {
            int[] nArray = (int[])arrayDeque.poll();
            arrayList.add(nArray);
            for (BlockFace blockFace : FACES) {
                n5 = nArray[0] + blockFace.getModX();
                n4 = nArray[1] + blockFace.getModY();
                int n7 = nArray[2] + blockFace.getModZ();
                if (n4 < world.getMinHeight() || n4 > world.getMaxHeight() || !FluidSystem.isGas(world, n5, n4, n7) || !hashSet.add(FluidSystem.cellKey(n5, n4, n7))) continue;
                arrayDeque.add(new int[]{n5, n4, n7});
            }
        }
        return arrayList;
    }

    private static boolean isGas(World world, int n, int n2, int n3) {
        Material material = world.getBlockAt(n, n2, n3).getType();
        return material.isAir();
    }

    public void tick() {
        ++this.clock;
        this.updateGas();
        if (this.clock % 20L != 0L) {
            return;
        }
        this.updateEffects();
        this.updateAcid();
    }

    private boolean pumpActive(Pump pump) {
        return pump.enabled && (pump.group.isEmpty() || this.groupRunning(pump.group));
    }

    private void updateGas() {
        for (Pump object : this.pumps.values()) {
            GasCloud gasCloud = this.pumpClouds.get(object.number);
            if (this.pumpActive(object)) {
                if (gasCloud == null || gasCloud.world == null) {
                    World world = Worlds.resolve(object.world);
                    gasCloud = new GasCloud();
                    gasCloud.world = world;
                    gasCloud.cells = this.computeRoom(world, object.x, object.y, object.z);
                    int n = object.fillSeconds > 0 ? object.fillSeconds : this.fillSecondsDefault;
                    gasCloud.fillTotalTicks = Math.max(20, n * 20);
                    gasCloud.deathSeconds = this.deathSecondsDefault;
                    gasCloud.concentration = 2;
                    gasCloud.lifeTicks = -1;
                    this.pumpClouds.put(object.number, gasCloud);
                }
                this.advance(gasCloud, 1);
                this.spawnParticles(gasCloud);
                continue;
            }
            if (gasCloud == null) continue;
            this.advance(gasCloud, -6);
            this.spawnParticles(gasCloud);
            if (gasCloud.fillIndex > 0) continue;
            this.pumpClouds.remove(object.number);
        }
        ArrayList arrayList = new ArrayList();
        for (GasCloud gasCloud : this.tempClouds) {
            if (gasCloud.lifeTicks > 0) {
                --gasCloud.lifeTicks;
                this.advance(gasCloud, 3);
            } else {
                this.advance(gasCloud, -8);
            }
            this.spawnParticles(gasCloud);
            if (gasCloud.fillIndex > 0 || gasCloud.lifeTicks > 0) continue;
            arrayList.add(gasCloud);
        }
        this.tempClouds.removeAll(arrayList);
    }

    private void advance(GasCloud gasCloud, int n) {
        int[] nArray;
        if (gasCloud.cells.isEmpty() || gasCloud.fillTotalTicks <= 0) {
            return;
        }
        gasCloud.fillTicks = Math.max(0, Math.min(gasCloud.fillTotalTicks, gasCloud.fillTicks + n));
        int n2 = (int)((long)gasCloud.cells.size() * (long)gasCloud.fillTicks / (long)gasCloud.fillTotalTicks);
        while (gasCloud.fillIndex < n2 && gasCloud.fillIndex < gasCloud.cells.size()) {
            nArray = gasCloud.cells.get(gasCloud.fillIndex);
            gasCloud.filled.add(FluidSystem.cellKey(nArray[0], nArray[1], nArray[2]));
            ++gasCloud.fillIndex;
        }
        while (gasCloud.fillIndex > n2) {
            --gasCloud.fillIndex;
            nArray = gasCloud.cells.get(gasCloud.fillIndex);
            gasCloud.filled.remove(FluidSystem.cellKey(nArray[0], nArray[1], nArray[2]));
        }
    }

    private void spawnParticles(GasCloud gasCloud) {
        if (gasCloud.world == null || gasCloud.fillIndex <= 0) {
            return;
        }
        int n = Math.min(this.particleCap, 6 + gasCloud.fillIndex / 6);
        Particle.DustOptions dustOptions = new Particle.DustOptions(Color.fromRGB((int)5028631), 1.6f);
        for (int i = 0; i < n; ++i) {
            int[] nArray = gasCloud.cells.get(this.random.nextInt(gasCloud.fillIndex));
            Location location = new Location(gasCloud.world, (double)nArray[0] + 0.2 + this.random.nextDouble() * 0.6, (double)nArray[1] + 0.2 + this.random.nextDouble() * 0.6, (double)nArray[2] + 0.2 + this.random.nextDouble() * 0.6);
            gasCloud.world.spawnParticle(Particle.DUST, location, 1, 0.02, 0.02, 0.02, (Object)dustOptions);
        }
    }

    private void updateEffects() {
        HashSet<UUID> hashSet = new HashSet<UUID>();
        HashMap<UUID, Integer> hashMap = new HashMap<UUID, Integer>();
        ArrayList<GasCloud> arrayList = new ArrayList<GasCloud>(this.pumpClouds.values());
        arrayList.addAll(this.tempClouds);
        for (GasCloud object : arrayList) {
            if (object.world == null || object.fillIndex <= 0) continue;
            for (Player player : object.world.getPlayers()) {
                Location location;
                GameMode gameMode = player.getGameMode();
                if (gameMode == GameMode.CREATIVE || gameMode == GameMode.SPECTATOR || !object.filled.contains(FluidSystem.cellKey((location = player.getLocation()).getBlockX(), location.getBlockY(), location.getBlockZ())) && !object.filled.contains(FluidSystem.cellKey(location.getBlockX(), location.getBlockY() + 1, location.getBlockZ()))) continue;
                hashSet.add(player.getUniqueId());
                hashMap.merge(player.getUniqueId(), object.concentration, Math::max);
            }
        }
        for (UUID uUID : hashSet) {
            Player player = Bukkit.getPlayer((UUID)uUID);
            if (player == null) continue;
            int n = Math.max(0, hashMap.getOrDefault(uUID, 2) - 1);
            this.addEffect(player, PotionEffectType.NAUSEA, 60, n);
            this.addEffect(player, PotionEffectType.POISON, 60, n);
            this.addEffect(player, PotionEffectType.WITHER, 60, Math.max(0, n - 1));
            this.addEffect(player, PotionEffectType.DARKNESS, 80, 0);
            if (this.clock % 60L == 0L) {
                player.playSound(player.getLocation(), Sound.ENTITY_ELDER_GUARDIAN_CURSE, SoundCategory.MASTER, 0.8f, 1.0f);
            }
            int n2 = this.neuroSeconds.getOrDefault(uUID, 0) + 1;
            this.neuroSeconds.put(uUID, n2);
            if (n2 < this.deathSecondsDefault) continue;
            this.neuroSeconds.remove(uUID);
            player.setHealth(0.0);
        }
        for (UUID uUID : new ArrayList<UUID>(this.neuroSeconds.keySet())) {
            if (hashSet.contains(uUID)) continue;
            this.neuroSeconds.remove(uUID);
        }
    }

    private void updateAcid() {
        HashSet<UUID> hashSet = new HashSet<UUID>();
        ArrayList<String> arrayList = new ArrayList<String>();
        for (String object : this.acidKeys) {
            int n;
            int n2;
            String[] stringArray = object.split(" ");
            World world = Worlds.resolve(stringArray[0]);
            if (world == null) continue;
            int n3 = Integer.parseInt(stringArray[1]);
            Block block = world.getBlockAt(n3, n2 = Integer.parseInt(stringArray[2]), n = Integer.parseInt(stringArray[3]));
            if (block.getType() != Material.WATER) {
                arrayList.add(object);
                continue;
            }
            this.applyAcid(world, n3, n2, n, hashSet);
        }
        this.acidKeys.removeAll(arrayList);
        for (UUID uUID : new ArrayList<UUID>(this.acidSeconds.keySet())) {
            if (hashSet.contains(uUID)) continue;
            this.acidSeconds.remove(uUID);
        }
    }

    private void applyAcid(World world, int n, int n2, int n3, Set<UUID> set) {
        Location location = new Location(world, (double)n + 0.5, (double)n2 + 0.5, (double)n3 + 0.5);
        for (Entity entity : world.getNearbyEntities(location, 2.2, 2.2, 2.2)) {
            Player player;
            GameMode gameMode;
            if (entity instanceof Item) {
                entity.remove();
                continue;
            }
            if (!(entity instanceof Player) || (gameMode = (player = (Player)entity).getGameMode()) == GameMode.CREATIVE || gameMode == GameMode.SPECTATOR || player.getLocation().distance(location) > 2.7) continue;
            set.add(player.getUniqueId());
            this.addEffect(player, PotionEffectType.NAUSEA, 60, 1);
            this.addEffect(player, PotionEffectType.POISON, 60, 2);
            int n4 = this.acidSeconds.getOrDefault(player.getUniqueId(), 0) + 1;
            this.acidSeconds.put(player.getUniqueId(), n4);
            if (n4 < 5) continue;
            this.acidSeconds.remove(player.getUniqueId());
            player.setHealth(0.0);
        }
    }

    private void addEffect(Player player, PotionEffectType potionEffectType, int n, int n2) {
        if (potionEffectType == null) {
            return;
        }
        player.addPotionEffect(new PotionEffect(potionEffectType, n, n2, false, false, false));
    }

    public void load() {
        this.pumps.clear();
        this.pumpByLoc.clear();
        this.acidKeys.clear();
        this.groupsRunning.clear();
        File file = new File(this.plugin.getDataFolder(), "fluids.yml");
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration((File)file);
        ConfigurationSection configurationSection = yamlConfiguration.getConfigurationSection("pumps");
        if (configurationSection != null) {
            for (Object object : configurationSection.getKeys(false)) {
                Object object2 = new Pump();
                try {
                    ((Pump)object2).number = Integer.parseInt((String)object);
                }
                catch (NumberFormatException numberFormatException) {
                    continue;
                }
                ((Pump)object2).world = configurationSection.getString((String)object + ".world", "world");
                ((Pump)object2).x = configurationSection.getInt((String)object + ".x");
                ((Pump)object2).y = configurationSection.getInt((String)object + ".y");
                ((Pump)object2).z = configurationSection.getInt((String)object + ".z");
                ((Pump)object2).facing = FluidSystem.parseFace(configurationSection.getString((String)object + ".facing", "NORTH"));
                ((Pump)object2).enabled = configurationSection.getBoolean((String)object + ".enabled", true);
                ((Pump)object2).group = configurationSection.getString((String)object + ".group", "");
                ((Pump)object2).fillSeconds = configurationSection.getInt((String)object + ".fill-seconds", 0);
                this.pumps.put(((Pump)object2).number, (Pump)object2);
                this.pumpByLoc.put(FluidSystem.key(((Pump)object2).world, ((Pump)object2).x, ((Pump)object2).y, ((Pump)object2).z), (Pump)object2);
            }
        }
        for (Object object : yamlConfiguration.getStringList("acid")) {
            this.acidKeys.add((String)object);
        }
        ConfigurationSection configurationSection2 = yamlConfiguration.getConfigurationSection("groups");
        if (configurationSection2 != null) {
            for (Object object2 : configurationSection2.getKeys(false)) {
                this.groupsRunning.put(((String)object2).toLowerCase(Locale.ROOT), configurationSection2.getBoolean((String)object2, false));
            }
        }
    }

    private static BlockFace parseFace(String string) {
        try {
            return BlockFace.valueOf((String)string.toUpperCase(Locale.ROOT));
        }
        catch (RuntimeException runtimeException) {
            return BlockFace.NORTH;
        }
    }

    public void save() {
        File file = new File(this.plugin.getDataFolder(), "fluids.yml");
        YamlConfiguration yamlConfiguration = new YamlConfiguration();
        for (Pump object : this.pumps.values()) {
            String string = "pumps." + object.number + ".";
            yamlConfiguration.set(string + "world", (Object)object.world);
            yamlConfiguration.set(string + "x", (Object)object.x);
            yamlConfiguration.set(string + "y", (Object)object.y);
            yamlConfiguration.set(string + "z", (Object)object.z);
            yamlConfiguration.set(string + "facing", (Object)object.facing.name());
            yamlConfiguration.set(string + "enabled", (Object)object.enabled);
            yamlConfiguration.set(string + "group", (Object)object.group);
            yamlConfiguration.set(string + "fill-seconds", (Object)object.fillSeconds);
        }
        yamlConfiguration.set("acid", new ArrayList<String>(this.acidKeys));
        for (Map.Entry entry : this.groupsRunning.entrySet()) {
            yamlConfiguration.set("groups." + (String)entry.getKey(), entry.getValue());
        }
        try {
            yamlConfiguration.save(file);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    public static final class Pump {
        public int number;
        public String world;
        public int x;
        public int y;
        public int z;
        public BlockFace facing = BlockFace.NORTH;
        public boolean enabled = true;
        public String group = "";
        public int fillSeconds = 0;
    }

    public static final class GasCloud {
        public World world;
        public List<int[]> cells = new ArrayList<int[]>();
        public final Set<String> filled = new HashSet<String>();
        public int fillIndex;
        public int fillTicks;
        public int fillTotalTicks = 300;
        public int lifeTicks = -1;
        public int deathSeconds = 10;
        public int concentration = 2;
    }
}

