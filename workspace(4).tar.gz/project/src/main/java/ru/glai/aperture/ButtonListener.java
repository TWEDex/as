package ru.glai.aperture;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import ru.glai.aperture.ApertureScience;
import ru.glai.aperture.ButtonManager;
import ru.glai.aperture.CodeDevice;
import ru.glai.aperture.DetectorData;
import ru.glai.aperture.Items;
import ru.glai.aperture.WirelessButton;
import ru.glai.aperture.WrenchMenu;

public final class ButtonListener
implements Listener {
    private final ButtonManager manager;
    private final Items items;

    public ButtonListener(ApertureScience apertureScience, ButtonManager buttonManager, Items items) {
        this.manager = buttonManager;
        this.items = items;
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onInteract(PlayerInteractEvent playerInteractEvent) {
        if (playerInteractEvent.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (playerInteractEvent.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Block block = playerInteractEvent.getClickedBlock();
        if (block == null) {
            return;
        }
        Player player = playerInteractEvent.getPlayer();
        ItemStack itemStack = player.getInventory().getItemInMainHand();
        String string = this.items.kindOf(itemStack);
        if ("button".equals(string)) {
            Block block2 = block.getRelative(playerInteractEvent.getBlockFace());
            if (!block2.getType().isAir() || !block2.getRelative(0, 1, 0).getType().isAir()) {
                player.sendMessage("\u043d\u0443\u0436\u043d\u043e \u0434\u0432\u0430 \u0441\u0432\u043e\u0431\u043e\u0434\u043d\u044b\u0445 \u0431\u043b\u043e\u043a\u0430");
                playerInteractEvent.setCancelled(true);
                return;
            }
            playerInteractEvent.setCancelled(true);
            WirelessButton wirelessButton = this.manager.placeButton(player, block2);
            this.consume(itemStack, player);
            if (wirelessButton != null) {
                player.sendMessage("\u043a\u043d\u043e\u043f\u043a\u0430 " + wirelessButton.number + " \u0441\u043e\u0437\u0434\u0430\u043d\u0430");
            }
            return;
        }
        if ("detector".equals(string)) {
            Block block3 = block.getRelative(playerInteractEvent.getBlockFace());
            if (!block3.getType().isAir()) {
                player.sendMessage("\u043c\u0435\u0441\u0442\u043e \u0437\u0430\u043d\u044f\u0442\u043e");
                playerInteractEvent.setCancelled(true);
                return;
            }
            playerInteractEvent.setCancelled(true);
            this.manager.placeDetector(block3);
            this.consume(itemStack, player);
            player.sendMessage("\u0434\u0435\u0442\u0435\u043a\u0442\u043e\u0440 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d, \u043d\u0430\u0441\u0442\u0440\u043e\u0439 \u043a\u043b\u044e\u0447\u043e\u043c");
            return;
        }
        WirelessButton wirelessButton = this.manager.buttonByBlock(block.getLocation());
        if (wirelessButton != null) {
            playerInteractEvent.setCancelled(true);
            if ("wrench".equals(string)) {
                this.openMenu(player, wirelessButton, null);
            } else {
                this.manager.press(player, wirelessButton);
            }
            return;
        }
        if ("wrench".equals(string)) {
            DetectorData detectorData = this.manager.detectorAt(block.getLocation());
            if (detectorData != null) {
                playerInteractEvent.setCancelled(true);
                this.openMenu(player, null, detectorData);
                return;
            }
            if (ButtonManager.isDeviceBlock(block.getType())) {
                playerInteractEvent.setCancelled(true);
                CodeDevice codeDevice = this.manager.registerDevice(block);
                player.openInventory(new WrenchMenu(this.manager, codeDevice).getInventory());
            }
        }
    }

    private void consume(ItemStack itemStack, Player player) {
        if (itemStack.getAmount() <= 1) {
            player.getInventory().setItemInMainHand(null);
        } else {
            itemStack.setAmount(itemStack.getAmount() - 1);
        }
    }

    private void openMenu(Player player, WirelessButton wirelessButton, DetectorData detectorData) {
        WrenchMenu wrenchMenu = new WrenchMenu(this.manager, wirelessButton, detectorData);
        player.openInventory(wrenchMenu.getInventory());
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onBreak(BlockBreakEvent blockBreakEvent) {
        Object object;
        Block block = blockBreakEvent.getBlock();
        Material material = block.getType();
        if ((material == Material.DIORITE_WALL || material == Material.CRIMSON_BUTTON) && (object = this.manager.buttonByBlock(block.getLocation())) != null) {
            blockBreakEvent.setCancelled(true);
            if (blockBreakEvent.getPlayer().hasPermission("aperturescience.admin")) {
                this.manager.deleteButton(((WirelessButton)object).number);
                blockBreakEvent.getPlayer().sendMessage("\u043a\u043d\u043e\u043f\u043a\u0430 " + ((WirelessButton)object).number + " \u0443\u0434\u0430\u043b\u0435\u043d\u0430");
            }
            return;
        }
        if ((material == Material.DAYLIGHT_DETECTOR || material == Material.REDSTONE_BLOCK) && (object = this.manager.detectorAt(block.getLocation())) != null) {
            blockBreakEvent.setCancelled(true);
            if (blockBreakEvent.getPlayer().hasPermission("aperturescience.admin")) {
                this.manager.removeDetector((DetectorData)object);
                block.setType(Material.AIR, false);
                blockBreakEvent.getPlayer().sendMessage("\u0434\u0435\u0442\u0435\u043a\u0442\u043e\u0440 \u0443\u0434\u0430\u043b\u0435\u043d");
            }
        }
        this.manager.removeDeviceAt(block.getLocation());
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent inventoryClickEvent) {
        InventoryHolder inventoryHolder = inventoryClickEvent.getInventory().getHolder();
        if (!(inventoryHolder instanceof WrenchMenu)) {
            return;
        }
        if (!(inventoryClickEvent.getWhoClicked() instanceof Player)) {
            return;
        }
        ((WrenchMenu)inventoryHolder).handleClick(inventoryClickEvent, (Player)inventoryClickEvent.getWhoClicked());
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent inventoryCloseEvent) {
        InventoryHolder inventoryHolder = inventoryCloseEvent.getInventory().getHolder();
        if (!(inventoryHolder instanceof WrenchMenu)) {
            return;
        }
        if (!(inventoryCloseEvent.getPlayer() instanceof Player)) {
            return;
        }
        ((WrenchMenu)inventoryHolder).handleClose((Player)inventoryCloseEvent.getPlayer());
    }
}

