package ru.glai.aperture;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.BlockIterator;
import org.bukkit.util.Vector;

/**
 * Система порталов, адаптированная из плагина PortalGun v3.1.2 (rogermiranda1000):
 * - у каждого игрока своя пара порталов: ЛКМ — оранжевый, ПКМ — синий;
 * - порталы ставятся на стены (1x2), пол и потолок (1x2 / 2x2) на расстоянии до 80 блоков;
 * - телепорт с сохранением импульса (перенос скорости из системы входа в систему выхода);
 * - порталы исчезают, если сломать блок-опору или загородить клетку.
 * Без цветовых вариантов пушек и без лимитов — одна пушка, как в оригинале.
 */
public final class PortalSystem {

    public enum Side { LEFT, RIGHT }

    public enum Kind { WALL, FLOOR, CEILING }

    public static final Color ORANGE = Color.fromRGB(0xFF8C14);
    public static final Color BLUE = Color.fromRGB(0x3C8CFF);

    private static final int PARTICLE_POINTS = 20;

    private final JavaPlugin plugin;
    private final Map<UUID, Portal[]> byOwner = new HashMap<>();
    private final Map<UUID, Vector> prevPos = new HashMap<>();
    private final Map<Entity, Location> teleported = new HashMap<>();
    private CubeSystem cubes;
    private int range = 80;
    private boolean castBeam = true;
    private List<Material> whitelist = new ArrayList<>();
    private long clock;

    public PortalSystem(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadConfig() {
        this.range = Math.max(8, plugin.getConfig().getInt("portal.placement-length", 80));
        this.castBeam = plugin.getConfig().getBoolean("portal.cast-beam", true);
        this.whitelist = new ArrayList<>();
        for (String s : plugin.getConfig().getStringList("portal.whitelist")) {
            Material m = Material.matchMaterial(s.toUpperCase());
            if (m != null) whitelist.add(m);
        }
    }

    public void setCubeSystem(CubeSystem cubes) {
        this.cubes = cubes;
    }

    // ============================== портал ==============================

    public static final class Portal {
        final UUID owner;
        final String worldName;
        final int x;
        final int y;
        final int z;
        final BlockFace dir; // горизонтальное направление: для стены — наружу из стены
        final Kind kind;
        final Side side;
        Portal linked;
        int spark;

        Portal(UUID owner, String worldName, int x, int y, int z, BlockFace dir, Kind kind, Side side) {
            this.owner = owner;
            this.worldName = worldName;
            this.x = x;
            this.y = y;
            this.z = z;
            this.dir = dir;
            this.kind = kind;
            this.side = side;
        }

        public World world() {
            return Worlds.resolve(worldName);
        }

        public Side side() {
            return side;
        }

        public Kind kind() {
            return kind;
        }

        Vector dirVec() {
            return new Vector(dir.getModX(), dir.getModY(), dir.getModZ());
        }

        /** вектор «в поверхность» (как approachVector в PortalGun) */
        Vector approach() {
            switch (kind) {
                case FLOOR:
                    return new Vector(0, -1, 0);
                case CEILING:
                    return new Vector(0, 1, 0);
                default:
                    return dirVec().multiply(-1);
            }
        }

        Vector outward() {
            return approach().multiply(-1);
        }

        private static Location at(World w, int x, int y, int z) {
            return new Location(w, x, y, z);
        }

        /** блоки-опоры (должны быть твёрдыми) */
        public Location[] supports() {
            World w = world();
            if (w == null) return new Location[0];
            if (kind == Kind.WALL) {
                return new Location[]{at(w, x, y, z), at(w, x, y + 1, z)};
            }
            BlockFace opp = dir.getOppositeFace();
            return new Location[]{at(w, x, y, z),
                    at(w, x + opp.getModX(), y + opp.getModY(), z + opp.getModZ())};
        }

        /** воздушные клетки портала (в них происходит телепорт) */
        public Location[] cells() {
            World w = world();
            if (w == null) return new Location[0];
            BlockFace opp = dir.getOppositeFace();
            switch (kind) {
                case WALL: {
                    Location l = at(w, x + dir.getModX(), y + dir.getModY(), z + dir.getModZ());
                    return new Location[]{l, l.clone().add(0, 1, 0)};
                }
                case FLOOR: {
                    Location l = at(w, x, y + 1, z);
                    return new Location[]{l, at(w, l.getBlockX() + opp.getModX(), l.getBlockY(), l.getBlockZ() + opp.getModZ())};
                }
                default: { // CEILING
                    Location l = at(w, x, y - 1, z);
                    Location l2 = at(w, x, y - 2, z);
                    return new Location[]{l,
                            at(w, l.getBlockX() + opp.getModX(), l.getBlockY(), l.getBlockZ() + opp.getModZ()),
                            l2,
                            at(w, l2.getBlockX() + opp.getModX(), l2.getBlockY(), l2.getBlockZ() + opp.getModZ())};
                }
            }
        }

        boolean isValid(PortalSystem sys) {
            for (Location l : supports()) {
                Block b = l.getBlock();
                if (b.isPassable()) return false;
                if (!sys.whitelist.isEmpty() && !sys.whitelist.contains(b.getType())) return false;
            }
            for (Location l : cells()) {
                if (!l.getBlock().isPassable()) return false;
            }
            return true;
        }

        Location center() {
            Location[] c = cells();
            if (c.length == 0) return null;
            double sx = 0, sy = 0, sz = 0;
            for (Location l : c) {
                sx += l.getX() + 0.5;
                sy += l.getY() + 0.5;
                sz += l.getZ() + 0.5;
            }
            return new Location(c[0].getWorld(), sx / c.length, sy / c.length, sz / c.length);
        }
    }

    // ============================== стрельба ==============================

    public boolean shoot(Player player, boolean isLeft) {
        World world = player.getWorld();
        Block hit = lookingBlock(player, range);
        if (hit == null) {
            player.sendMessage("§cслишком далеко — портал не достанет (дальность " + range + ")");
            return false;
        }
        Location eye = player.getEyeLocation();
        if (castBeam) {
            trail(world, eye, hit.getLocation().add(0.5, 0.5, 0.5).toVector(), isLeft ? ORANGE : BLUE);
        }
        Vector v = player.getLocation().getBlock().getLocation().subtract(hit.getLocation()).toVector();
        List<BlockFace> faces = candidateFaces(v, player);
        Portal created = null;
        // сначала стены, затем пол (смотрим вниз), затем потолок (смотрим вверх) — как в PortalGun
        for (BlockFace f : faces) {
            Portal p = new Portal(player.getUniqueId(), world.getName(), hit.getX(), hit.getY(), hit.getZ(), f, Kind.WALL, isLeft ? Side.LEFT : Side.RIGHT);
            if (p.isValid(this) && !collides(p, false)) {
                created = p;
                break;
            }
        }
        if (created == null && v.getY() >= -1.0) {
            for (BlockFace f : faces) {
                Portal p = new Portal(player.getUniqueId(), world.getName(), hit.getX(), hit.getY(), hit.getZ(), f, Kind.FLOOR, isLeft ? Side.LEFT : Side.RIGHT);
                if (p.isValid(this) && !collides(p, false)) {
                    created = p;
                    break;
                }
            }
        }
        if (created == null && v.getY() <= -1.0) {
            for (BlockFace f : faces) {
                Portal p = new Portal(player.getUniqueId(), world.getName(), hit.getX(), hit.getY(), hit.getZ(), f, Kind.CEILING, isLeft ? Side.LEFT : Side.RIGHT);
                if (p.isValid(this) && !collides(p, false)) {
                    created = p;
                    break;
                }
            }
        }
        if (created == null) {
            boolean blocked = firstInvalidReason(player, hit, faces);
            if (!blocked) {
                player.sendMessage("§cздесь уже есть портал");
            }
            world.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, SoundCategory.PLAYERS, 0.7f, 0.7f);
            return false;
        }
        setPortal(player.getUniqueId(), created);
        Location c = created.center();
        if (c != null) {
            world.playSound(c, Sound.BLOCK_END_PORTAL_FRAME_FILL, SoundCategory.BLOCKS, 0.9f, isLeft ? 1.2f : 0.85f);
        }
        return true;
    }

    private boolean firstInvalidReason(Player player, Block hit, List<BlockFace> faces) {
        // возвращает true, если поверхность не подходит (не белый список / не твёрдая),
        // false — если мешают существующие порталы
        for (BlockFace f : faces) {
            for (Kind k : Kind.values()) {
                Portal p = new Portal(player.getUniqueId(), hit.getWorld().getName(), hit.getX(), hit.getY(), hit.getZ(), f, k, Side.LEFT);
                if (p.isValid(this)) return false;
            }
        }
        player.sendMessage("§cнужна твёрдая поверхность" + (whitelist.isEmpty() ? "" : " из: " + whitelistNames()));
        return true;
    }

    private String whitelistNames() {
        StringBuilder sb = new StringBuilder();
        for (Material m : whitelist) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(m.name().toLowerCase());
        }
        return sb.toString();
    }

    /** первый непроходимый блок на луче (проходимые пропускаем) — как getLookingBlock в PortalGun */
    public static Block lookingBlock(Player player, int max) {
        try {
            BlockIterator iter = new BlockIterator(player, max);
            Block last = null;
            while (iter.hasNext()) {
                last = iter.next();
                if (!last.isPassable()) return last;
            }
            return null;
        } catch (IllegalStateException e) {
            return null;
        }
    }

    /** кандидаты-направления (наружу из поверхности) по вектору игрок→... как getDirections в PortalGun */
    private static List<BlockFace> candidateFaces(Vector v, Player player) {
        List<BlockFace> r = new ArrayList<>(2);
        double x = v.getX();
        double z = v.getZ();
        if (x > 0) {
            if (z == 0) r.add(BlockFace.EAST);
            else if (z > 0) {
                if (x >= z) {
                    r.add(BlockFace.EAST);
                    r.add(BlockFace.SOUTH);
                } else {
                    r.add(BlockFace.SOUTH);
                    r.add(BlockFace.EAST);
                }
            } else {
                if (x >= -z) {
                    r.add(BlockFace.EAST);
                    r.add(BlockFace.NORTH);
                } else {
                    r.add(BlockFace.NORTH);
                    r.add(BlockFace.EAST);
                }
            }
        } else if (x < 0) {
            if (z == 0) r.add(BlockFace.WEST);
            else if (z > 0) {
                if (-x >= z) {
                    r.add(BlockFace.WEST);
                    r.add(BlockFace.SOUTH);
                } else {
                    r.add(BlockFace.SOUTH);
                    r.add(BlockFace.WEST);
                }
            } else {
                if (-x >= -z) {
                    r.add(BlockFace.WEST);
                    r.add(BlockFace.NORTH);
                } else {
                    r.add(BlockFace.NORTH);
                    r.add(BlockFace.WEST);
                }
            }
        } else {
            if (z > 0) r.add(BlockFace.SOUTH);
            else if (z < 0) r.add(BlockFace.NORTH);
            else {
                BlockFace f = yawToFace(player.getLocation().getYaw());
                r.add(f);
                r.add(rotate90(f));
                r.add(f.getOppositeFace());
                r.add(rotate90(f.getOppositeFace()));
            }
        }
        return r;
    }

    private static BlockFace yawToFace(float yaw) {
        double y = ((yaw % 360) + 360) % 360;
        if (y < 45 || y >= 315) return BlockFace.SOUTH;
        if (y < 135) return BlockFace.WEST;
        if (y < 225) return BlockFace.NORTH;
        return BlockFace.EAST;
    }

    private static BlockFace rotate90(BlockFace f) {
        switch (f) {
            case SOUTH:
                return BlockFace.WEST;
            case WEST:
                return BlockFace.NORTH;
            case NORTH:
                return BlockFace.EAST;
            default:
                return BlockFace.SOUTH;
        }
    }

    private boolean collides(Portal candidate, boolean ignoreSame) {
        for (Portal[] arr : byOwner.values()) {
            for (Portal p : arr) {
                if (p == null) continue;
                if (ignoreSame && p.owner.equals(candidate.owner) && p.side == candidate.side) continue;
                if (!p.worldName.equals(candidate.worldName)) continue;
                for (Location a : p.cells()) {
                    for (Location b : candidate.cells()) {
                        if (a.getBlockX() == b.getBlockX() && a.getBlockY() == b.getBlockY() && a.getBlockZ() == b.getBlockZ()) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    // ============================== реестр ==============================

    private synchronized void setPortal(UUID owner, Portal p) {
        Portal[] arr = byOwner.computeIfAbsent(owner, k -> new Portal[2]);
        int pos = p.side == Side.LEFT ? 0 : 1;
        int other = pos == 0 ? 1 : 0;
        removePortal(arr[pos]);
        arr[pos] = p;
        if (arr[other] != null) {
            p.linked = arr[other];
            arr[other].linked = p;
        }
    }

    private synchronized void removePortal(Portal p) {
        if (p == null) return;
        if (p.linked != null) p.linked.linked = null;
        Portal[] arr = byOwner.get(p.owner);
        if (arr != null) {
            if (arr[0] == p) arr[0] = null;
            if (arr[1] == p) arr[1] = null;
        }
    }

    public synchronized boolean clearFor(UUID owner) {
        Portal[] arr = byOwner.remove(owner);
        if (arr == null) return false;
        if (arr[0] != null && arr[0].linked != null) arr[0].linked.linked = null;
        if (arr[1] != null && arr[1].linked != null) arr[1].linked.linked = null;
        return true;
    }

    public synchronized int clearAll() {
        int n = 0;
        for (Portal[] arr : byOwner.values()) {
            if (arr[0] != null) n++;
            if (arr[1] != null) n++;
        }
        byOwner.clear();
        return n;
    }

    public synchronized List<String> status() {
        List<String> out = new ArrayList<>();
        int n = 0;
        for (Map.Entry<UUID, Portal[]> e : byOwner.entrySet()) {
            String name = Bukkit.getOfflinePlayer(e.getKey()).getName();
            for (Portal p : e.getValue()) {
                if (p == null) continue;
                n++;
                out.add((p.side == Side.LEFT ? "§6оранжевый" : "§9синий") + " §7" + (name == null ? "?" : name)
                        + ": " + p.kind.name().toLowerCase() + " " + p.worldName + " " + p.x + " " + p.y + " " + p.z
                        + (p.linked != null ? " (связан)" : " (без пары)"));
            }
        }
        out.add(0, "порталов: " + n);
        return out;
    }

    /** портал, чья клетка занимает данный блок (для кубов) */
    public synchronized Portal cellPortalAt(Block block) {
        for (Portal[] arr : byOwner.values()) {
            for (Portal p : arr) {
                if (p == null) continue;
                for (Location l : p.cells()) {
                    if (l.getBlockX() == block.getX() && l.getBlockY() == block.getY() && l.getBlockZ() == block.getZ()
                            && l.getWorld() != null && block.getWorld() != null
                            && l.getWorld().getUID().equals(block.getWorld().getUID())) {
                        return p;
                    }
                }
            }
        }
        return null;
    }

    /** удалить порталы, опирающиеся на блок или занимающие его клетку (при поломке) */
    public synchronized void removeAt(Block block) {
        List<Portal> victims = new ArrayList<>();
        for (Portal[] arr : byOwner.values()) {
            for (Portal p : arr) {
                if (p == null) continue;
                if (!p.worldName.equals(block.getWorld().getName())) continue;
                boolean hit = false;
                for (Location l : p.supports()) {
                    if (l.getBlockX() == block.getX() && l.getBlockY() == block.getY() && l.getBlockZ() == block.getZ()) hit = true;
                }
                if (!hit) {
                    for (Location l : p.cells()) {
                        if (l.getBlockX() == block.getX() && l.getBlockY() == block.getY() && l.getBlockZ() == block.getZ()) hit = true;
                    }
                }
                if (hit) victims.add(p);
            }
        }
        for (Portal p : victims) {
            removePortal(p);
            Portal[] arr = byOwner.get(p.owner);
            if (arr != null && arr[0] == null && arr[1] == null) byOwner.remove(p.owner);
        }
    }

    private synchronized List<Portal> allPortals() {
        List<Portal> r = new ArrayList<>();
        for (Portal[] arr : byOwner.values()) {
            if (arr[0] != null) r.add(arr[0]);
            if (arr[1] != null) r.add(arr[1]);
        }
        return r;
    }

    // ============================== тик ==============================

    public void tick() {
        ++clock;
        if (clock % 2 == 0) {
            for (Portal p : allPortals()) render(p);
        }
        if (clock % 10 == 0) {
            validate();
        }
        checkEntities();
        cleanupTeleported();
        if (prevPos.size() > 2000) prevPos.clear();
    }

    private void validate() {
        for (Portal p : allPortals()) {
            if (!p.isValid(this) || collides(p, true)) {
                World w = p.world();
                removePortal(p);
                if (w != null) {
                    Location c = p.center();
                    if (c != null) w.playSound(c, Sound.BLOCK_GLASS_BREAK, SoundCategory.BLOCKS, 0.6f, 1.3f);
                }
            }
        }
    }

    // ============================== частицы ==============================

    private void render(Portal p) {
        World w = p.world();
        if (w == null) return;
        Location base = new Location(w, p.x, p.y, p.z);
        if (!base.getChunk().isLoaded()) return;
        Color color = p.side == Side.LEFT ? ORANGE : BLUE;
        Particle.DustOptions dust = new Particle.DustOptions(color, 1.3f);
        Particle.DustOptions sparkDust = new Particle.DustOptions(color, 2.2f);
        Vector dirV = p.dirVec();
        if (p.kind == Kind.WALL) {
            Vector outward = dirV.clone();
            Vector perp = outward.clone().crossProduct(new Vector(0, 1, 0)).normalize();
            Location center = base.clone().add(0.5, 1.0, 0.5).add(outward.clone().multiply(0.12));
            for (int i = 0; i < PARTICLE_POINTS; i++) {
                double a = Math.PI * 2 * i / PARTICLE_POINTS;
                Location l = center.clone()
                        .add(perp.clone().multiply(0.45 * Math.cos(a)))
                        .add(0, 0.9 * Math.sin(a), 0);
                w.spawnParticle(Particle.DUST, l, 1, 0, 0, 0, 0, dust);
            }
            // бегущие искры — как в PortalGun (шаг 10, затем 1)
            p.spark = (p.spark + 10) % PARTICLE_POINTS;
            spawnSpark(w, center, perp, p.spark, sparkDust);
            p.spark = (p.spark + 1) % PARTICLE_POINTS;
            spawnSpark(w, center, perp, p.spark, sparkDust);
        } else {
            BlockFace opp = p.dir.getOppositeFace();
            Vector oppV = new Vector(opp.getModX(), opp.getModY(), opp.getModZ());
            Vector perp = oppV.clone().crossProduct(new Vector(0, 1, 0));
            if (perp.lengthSquared() < 0.001) perp = new Vector(1, 0, 0);
            perp.normalize();
            double y = p.kind == Kind.FLOOR ? p.y + 1.04 : p.y - 1.04;
            Location center = new Location(w, p.x + 0.5, y, p.z + 0.5).add(oppV.clone().multiply(0.5));
            for (int i = 0; i < PARTICLE_POINTS; i++) {
                double a = Math.PI * 2 * i / PARTICLE_POINTS;
                Location l = center.clone()
                        .add(oppV.clone().multiply(0.9 * Math.cos(a)))
                        .add(perp.clone().multiply(0.45 * Math.sin(a)));
                w.spawnParticle(Particle.DUST, l, 1, 0, 0, 0, 0, dust);
            }
            p.spark = (p.spark + 10) % PARTICLE_POINTS;
            spawnSparkFlat(w, center, oppV, perp, p.spark, sparkDust);
            p.spark = (p.spark + 1) % PARTICLE_POINTS;
            spawnSparkFlat(w, center, oppV, perp, p.spark, sparkDust);
        }
    }

    private static void spawnSpark(World w, Location center, Vector perp, int i, Particle.DustOptions dust) {
        double a = Math.PI * 2 * i / PARTICLE_POINTS;
        Location l = center.clone().add(perp.clone().multiply(0.45 * Math.cos(a))).add(0, 0.9 * Math.sin(a), 0);
        w.spawnParticle(Particle.DUST, l, 1, 0, 0, 0, 0, dust);
    }

    private static void spawnSparkFlat(World w, Location center, Vector axis, Vector perp, int i, Particle.DustOptions dust) {
        double a = Math.PI * 2 * i / PARTICLE_POINTS;
        Location l = center.clone().add(axis.clone().multiply(0.9 * Math.cos(a))).add(perp.clone().multiply(0.45 * Math.sin(a)));
        w.spawnParticle(Particle.DUST, l, 1, 0, 0, 0, 0, dust);
    }

    private void trail(World world, Location from, Vector to, Color color) {
        Particle.DustOptions dust = new Particle.DustOptions(color, 1.0f);
        Vector start = from.toVector();
        Vector delta = to.clone().subtract(start);
        double len = delta.length();
        int n = (int) Math.min(120, Math.max(1, len * 3));
        for (int i = 1; i <= n; i++) {
            Vector at = start.clone().add(delta.clone().multiply((double) i / n));
            world.spawnParticle(Particle.DUST, at.toLocation(world), 1, 0, 0, 0, 0, dust);
        }
    }

    // ============================== телепорт ==============================

    private boolean teleportable(Entity e) {
        if (e == null || !e.isValid() || e.isDead()) return false;
        if (e instanceof Display) return false; // визуал куба летает вместе с телом
        if (cubes != null && cubes.isCarriedEntity(e)) return false;
        return true;
    }

    private void checkEntities() {
        for (Portal p : allPortals()) {
            if (p.linked == null) continue;
            World w = p.world();
            if (w == null) continue;
            Location[] cells = p.cells();
            for (int ci = 0; ci < cells.length; ci++) {
                Location cell = cells[ci];
                if (!cell.getChunk().isLoaded()) continue;
                BoundingBox box = BoundingBox.of(cell, cell.clone().add(1, 1, 1));
                for (Entity e : w.getNearbyEntities(box)) {
                    if (!teleportable(e)) continue;
                    if (teleported.containsKey(e)) continue;
                    Location el = e.getLocation();
                    if (el.getBlockX() != cell.getBlockX() || el.getBlockY() != cell.getBlockY() || el.getBlockZ() != cell.getBlockZ()) {
                        continue;
                    }
                    Vector delta = deltaOf(e, el);
                    if (delta == null) continue;
                    if (!entering(p, delta)) continue;
                    teleport(p, e, delta, ci);
                }
            }
        }
    }

    private Vector deltaOf(Entity e, Location el) {
        Vector now = el.toVector();
        Vector prev = prevPos.put(e.getUniqueId(), now.clone());
        if (prev == null) {
            if (e instanceof Player) return null; // первый тик — только запоминаем
            return e.getVelocity();
        }
        return now.clone().subtract(prev);
    }

    private boolean entering(Portal p, Vector delta) {
        if (p.kind == Kind.WALL) {
            double dn = delta.dot(p.approach());
            if (dn <= 0) return false;
            // движение должно быть преимущественно «в портал» (защита от касательных)
            return 2.0 * dn * dn >= delta.dot(delta);
        }
        return true; // пол/потолок — как в PortalGun, достаточно попасть в клетку
    }

    private void teleport(Portal in, Entity e, Vector velocity, int cellIndex) {
        Portal out = in.linked;
        if (out == null) return;
        Location[] outCells = out.cells();
        if (outCells.length == 0) return;
        Location dest = outCells[cellIndex % outCells.length].clone().add(0.5, 0, 0.5);
        float yaw = e.getLocation().getYaw();
        float pitch = e.getLocation().getPitch();
        dest.setYaw(exitYaw(yaw, velocity, in, out));
        dest.setPitch(pitch);
        if (e instanceof Player) {
            ((Player) e).teleport(dest, PlayerTeleportEvent.TeleportCause.PLUGIN);
        } else {
            e.teleport(dest);
        }
        Vector vOut = remapVelocity(velocity, in, out);
        e.setVelocity(vOut);
        final Entity ent = e;
        Bukkit.getScheduler().runTaskLater((Plugin) plugin, () -> {
            if (ent.isValid()) ent.setVelocity(vOut);
        }, 1L);
        e.setFallDistance(0);
        teleported.put(e, dest.toVector().toLocation(dest.getWorld()).getBlock().getLocation());
        World w = dest.getWorld();
        if (w != null) {
            w.playSound(dest, Sound.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 0.6f, 1.0f);
        }
    }

    private void cleanupTeleported() {
        Iterator<Map.Entry<Entity, Location>> it = teleported.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Entity, Location> en = it.next();
            Entity e = en.getKey();
            if (!e.isValid()) {
                it.remove();
                continue;
            }
            Location cur = e.getLocation().getBlock().getLocation();
            if (!cur.equals(en.getValue())) {
                it.remove();
            }
        }
    }

    /** перенос скорости из системы входа в систему выхода: нормаль → нормаль, касательные → касательные */
    static Vector remapVelocity(Vector v, Portal in, Portal out) {
        Vector inA = in.approach();
        Vector outA = out.approach();
        double vn = v.dot(inA); // > 0 — влетаем
        Vector vT = v.clone().subtract(inA.clone().multiply(vn));
        Vector[] tin = tangentBasis(in);
        Vector[] tout = tangentBasis(out);
        double vnEff = Math.max(vn, 0.30);
        Vector vOut = outA.clone().multiply(-vnEff)
                .add(tout[0].clone().multiply(vT.dot(tin[0])))
                .add(tout[1].clone().multiply(vT.dot(tin[1])));
        double len = vOut.length();
        if (len > 4.0) vOut.multiply(4.0 / len);
        return vOut;
    }

    private static Vector[] tangentBasis(Portal p) {
        Vector a = p.approach();
        Vector t1;
        if (p.kind == Kind.WALL) {
            t1 = new Vector(0, 1, 0);
        } else {
            t1 = p.dirVec();
        }
        Vector t2 = a.clone().crossProduct(t1);
        if (t2.lengthSquared() < 1.0E-6) {
            t2 = new Vector(1, 0, 0);
            if (Math.abs(t2.dot(a)) > 0.9) t2 = new Vector(0, 0, 1);
        }
        t2.normalize();
        // ортогонализируем t1 относительно a и t2
        t1 = t2.clone().crossProduct(a);
        if (t1.lengthSquared() < 1.0E-6) t1 = new Vector(0, 1, 0);
        t1.normalize();
        return new Vector[]{t1, t2};
    }

    /** newYaw = yaw выхода наружу + (старый yaw относительно направления входа) */
    private static float exitYaw(float yaw, Vector delta, Portal in, Portal out) {
        if (out.kind != Kind.WALL) {
            return yaw; // выход через пол/потолок — курс сохраняем
        }
        Vector outDir = out.outward(); // куда вылетаем
        double outYaw = Math.toDegrees(Math.atan2(-outDir.getX(), outDir.getZ()));
        double inRef;
        if (in.kind == Kind.WALL) {
            Vector a = in.approach();
            inRef = Math.toDegrees(Math.atan2(-a.getX(), a.getZ()));
        } else {
            // вход через пол/потолок — берём горизонтальную составляющую движения
            Vector h = delta.clone().setY(0);
            if (h.lengthSquared() < 1.0E-4) {
                inRef = yaw;
            } else {
                inRef = Math.toDegrees(Math.atan2(-h.getX(), h.getZ()));
            }
        }
        float r = (float) (yaw - inRef);
        return (float) (outYaw + r);
    }

    private static double yawOf(Vector v) {
        return Math.toDegrees(Math.atan2(-v.getX(), v.getZ()));
    }
}
