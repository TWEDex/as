package ru.glai.aperture;

import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.glai.aperture.FluidSystem;

public final class PumpMenu
implements InventoryHolder {
    private final FluidSystem fluids;
    private final FluidSystem.Pump pump;
    private final Inventory inventory;

    public PumpMenu(FluidSystem fluidSystem, FluidSystem.Pump pump) {
        this.fluids = fluidSystem;
        this.pump = pump;
        this.inventory = Bukkit.createInventory((InventoryHolder)this, (int)27, (String)("\u041d\u0430\u0441\u043e\u0441 " + pump.number));
        this.rebuild();
    }

    public Inventory getInventory() {
        return this.inventory;
    }

    private int effectiveSeconds() {
        return this.pump.fillSeconds > 0 ? this.pump.fillSeconds : this.fluids.fillSecondsDefault();
    }

    private void rebuild() {
        this.inventory.clear();
        this.inventory.setItem(11, PumpMenu.info("\u0412\u043a\u043b\u044e\u0447\u0435\u043d", this.pump.enabled ? Material.LIME_DYE : Material.RED_DYE, List.of("\u0421\u0442\u0430\u0442\u0443\u0441: " + (this.pump.enabled ? "\u0432\u043a\u043b\u044e\u0447\u0435\u043d" : "\u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d"), "\u041a\u043b\u0438\u043a - \u043f\u0435\u0440\u0435\u043a\u043b\u044e\u0447\u0438\u0442\u044c")));
        this.inventory.setItem(13, PumpMenu.info("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u043f\u043e\u0434\u0430\u0447\u0438", Material.CLOCK, List.of("\u0417\u0430\u043f\u043e\u043b\u043d\u0435\u043d\u0438\u0435 \u043a\u043e\u043c\u043d\u0430\u0442\u044b: " + this.effectiveSeconds() + " \u0441\u0435\u043a", "\u041b\u041a\u041c +1 \u0441\u0435\u043a, \u041f\u041a\u041c -1 \u0441\u0435\u043a", "\u041c\u0435\u043d\u044c\u0448\u0435 - \u0431\u044b\u0441\u0442\u0440\u0435\u0435 \u043f\u043e\u0434\u0430\u0447\u0430 \u043d\u0435\u0439\u0440\u043e\u0442\u043e\u043a\u0441\u0438\u043d\u0430")));
        this.inventory.setItem(15, PumpMenu.info("\u0413\u0440\u0443\u043f\u043f\u0430", Material.NAME_TAG, List.of("\u0413\u0440\u0443\u043f\u043f\u0430: " + (this.pump.group.isEmpty() ? "\u043d\u0435\u0442" : this.pump.group), "\u0411\u0435\u0437 \u0433\u0440\u0443\u043f\u043f\u044b \u043d\u0430\u0441\u043e\u0441 \u0440\u0430\u0431\u043e\u0442\u0430\u0435\u0442 \u0432\u0441\u0435\u0433\u0434\u0430 \u043a\u043e\u0433\u0434\u0430 \u0432\u043a\u043b\u044e\u0447\u0435\u043d", "\u0412 \u0433\u0440\u0443\u043f\u043f\u0435 - \u0442\u043e\u043b\u044c\u043a\u043e \u043a\u043e\u0433\u0434\u0430 \u0433\u0440\u0443\u043f\u043f\u0430 \u0437\u0430\u043f\u0443\u0449\u0435\u043d\u0430", "\u0417\u0430\u0434\u0430\u0442\u044c: /asm pump " + this.pump.number + " group add <\u0438\u043c\u044f>")));
    }

    public void handleClick(Player player, int n, boolean bl) {
        if (n == 11) {
            this.pump.enabled = !this.pump.enabled;
        } else if (n == 13) {
            int n2 = this.effectiveSeconds();
            this.pump.fillSeconds = Math.max(1, Math.min(120, n2 += bl ? -1 : 1));
        } else {
            return;
        }
        this.fluids.save();
        this.rebuild();
    }

    private static ItemStack info(String string2, Material material, List<String> list) {
        ItemStack itemStack = new ItemStack(material);
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta != null) {
            itemMeta.setDisplayName(String.valueOf(ChatColor.RESET) + string2);
            itemMeta.setLore(list.stream().map(string -> String.valueOf(ChatColor.GRAY) + string).toList());
            itemStack.setItemMeta(itemMeta);
        }
        return itemStack;
    }
}

