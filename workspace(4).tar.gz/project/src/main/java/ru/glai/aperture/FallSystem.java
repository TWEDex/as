package ru.glai.aperture;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.FallingBlock;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.util.function.Predicate;

/**
 * /asm fall <x1 y1 z1> <x2 y2 z2> [falling|boom]
 * falling — блоки области реалистично падают (превращаются в падающие блоки и приземляются);
 * boom — взрыв: блоки разлетаются в стороны от центра и падают.
 */
public final class FallSystem {

    private static final Set<Material> SKIP = EnumSet.of(
            Material.BEDROCK, Material.BARRIER, Material.END_PORTAL, Material.END_PORTAL_FRAME,
            Material.NETHER_PORTAL, Material.END_GATEWAY, Material.COMMAND_BLOCK, Material.CHAIN_COMMAND_BLOCK,
            Material.REPEATING_COMMAND_BLOCK, Material.STRUCTURE_BLOCK, Material.JIGSAW, Material.SPAWNER,
            Material.BUDDING_AMETHYST, Material.PETRIFIED_OAK_SLAB, Material.LIGHT);

    private final JavaPlugin plugin;
    private final Predicate<Location> protectedLoc;
    private final Random random = new Random();
    private final List<Pending> queue = new ArrayList<>();
    private int maxBlocks = 10000;
    private int perTick = 400;
    private boolean explosionDamage = false;

    public FallSystem(JavaPlugin plugin, Predicate<Location> protectedLoc) {
        this.plugin = plugin;
        this.protectedLoc = protectedLoc;
    }

    public void loadConfig() {
        this.maxBlocks = Math.max(1, plugin.getConfig().getInt("fall.max-blocks", 10000));
        this.perTick = Math.max(1, plugin.getConfig().getInt("fall.per-tick", 400));
        this.explosionDamage = plugin.getConfig().getBoolean("fall.damage", false);
    }

    private static final class Pending {
        World world;
        Location location;
        BlockData data;
        Vector velocity;
    }

    /** выполняет обрушение; возвращает сообщение для отправителя */
    public String execute(World world, int x1, int y1, int z1, int x2, int y2, int z2, boolean boom) {
        int minX = Math.min(x1, x2), maxX = Math.max(x1, x2);
        int minY = Math.min(y1, y2), maxY = Math.max(y1, y2);
        int minZ = Math.min(z1, z2), maxZ = Math.max(z1, z2);
        long volume = (long) (maxX - minX + 1) * (maxY - minY + 1) * (maxZ - minZ + 1);
        if (volume > maxBlocks) {
            return "§cобласть слишком большая: " + volume + " блоков (максимум " + maxBlocks + ")";
        }
        Location center = new Location(world, (minX + maxX + 1) / 2.0, (minY + maxY + 1) / 2.0, (minZ + maxZ + 1) / 2.0);
        int converted = 0;
        // идём сверху вниз — сначала верхние слои, реалистичное обрушение
        for (int y = maxY; y >= minY; y--) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int x = minX; x <= maxX; x++) {
                    Block block = world.getBlockAt(x, y, z);
                    if (!canFall(block)) continue;
                    BlockData data = block.getBlockData();
                    block.setType(Material.AIR, false);
                    Pending pending = new Pending();
                    pending.world = world;
                    pending.location = new Location(world, x + 0.5, y, z + 0.5);
                    pending.data = data;
                    if (boom) {
                        Vector away = new Location(world, x + 0.5, y + 0.5, z + 0.5).toVector().subtract(center.toVector());
                        double dist = Math.max(0.5, away.length());
                        away.normalize();
                        double power = Math.max(0.5, 2.2 - dist * 0.12);
                        pending.velocity = away.multiply(power)
                                .add(new Vector(0, 0.55 + random.nextDouble() * 0.9, 0))
                                .add(new Vector((random.nextDouble() - 0.5) * 0.35, 0, (random.nextDouble() - 0.5) * 0.35));
                        double len = pending.velocity.length();
                        if (len > 3.2) pending.velocity.multiply(3.2 / len);
                    } else {
                        pending.velocity = new Vector(0, 0, 0);
                    }
                    queue.add(pending);
                    converted++;
                }
            }
        }
        if (converted == 0) {
            return "§eв этой области нет блоков, которые можно обрушить";
        }
        if (boom) {
            if (explosionDamage) {
                world.createExplosion(center, 2.0f, false, false);
            } else {
                world.playSound(center, Sound.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 1.6f, 1.0f);
                world.spawnParticle(Particle.EXPLOSION_EMITTER, center, 2, 0.5, 0.5, 0.5, 0);
            }
        }
        return "§a" + (boom ? "взрыв" : "обрушение") + ": " + converted + " блоков в "
                + world.getName() + " " + minX + " " + minY + " " + minZ + " → " + maxX + " " + maxY + " " + maxZ;
    }

    private boolean canFall(Block block) {
        Material material = block.getType();
        if (material.isAir()) return false;
        if (SKIP.contains(material)) return false;
        if (material == Material.WATER || material == Material.LAVA) return false;
        if (protectedLoc != null && protectedLoc.test(block.getLocation())) return false; // наши устройства (насосы, кнопки, детекторы)
        return true;
    }

    /** вызывается каждый тик — порционный спавн падающих блоков */
    public void tick() {
        if (queue.isEmpty()) return;
        int n = Math.min(perTick, queue.size());
        for (int i = 0; i < n; i++) {
            Pending pending = queue.remove(0);
            if (pending.world == null) continue;
            try {
                FallingBlock falling = pending.world.spawn(pending.location, FallingBlock.class, fb -> {
                    fb.setBlockData(pending.data);
                    fb.setDropItem(true);
                    fb.setHurtEntities(false);
                });
                falling.setVelocity(pending.velocity);
            } catch (IllegalArgumentException ignored) {
                // блок в невыгруженном чанке и т.п.
            }
        }
    }

    public void shutdown() {
        queue.clear();
    }
}
