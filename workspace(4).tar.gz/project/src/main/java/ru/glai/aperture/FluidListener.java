package ru.glai.aperture;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import ru.glai.aperture.FluidSystem;
import ru.glai.aperture.Items;
import ru.glai.aperture.PumpMenu;

public final class FluidListener
implements Listener {
    private final FluidSystem fluids;
    private final Items items;

    public FluidListener(FluidSystem fluidSystem, Items items) {
        this.fluids = fluidSystem;
        this.items = items;
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onInteract(PlayerInteractEvent playerInteractEvent) {
        if (playerInteractEvent.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (playerInteractEvent.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Block block = playerInteractEvent.getClickedBlock();
        if (block == null) {
            return;
        }
        Player player = playerInteractEvent.getPlayer();
        ItemStack itemStack = player.getInventory().getItemInMainHand();
        String string = this.items.kindOf(itemStack);
        if ("pump".equals(string)) {
            Block block2 = block.getRelative(playerInteractEvent.getBlockFace());
            if (!block2.getType().isAir() && !FluidListener.isReplaceable(block2.getType())) {
                player.sendMessage("\u043c\u0435\u0441\u0442\u043e \u0437\u0430\u043d\u044f\u0442\u043e");
                playerInteractEvent.setCancelled(true);
                return;
            }
            playerInteractEvent.setCancelled(true);
            FluidSystem.Pump pump = this.fluids.placePump(player, block2);
            this.consume(itemStack, player);
            player.sendMessage("\u043d\u0430\u0441\u043e\u0441 " + pump.number + " \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d");
            return;
        }
        if ("acid".equals(string)) {
            Block block3 = block.getRelative(playerInteractEvent.getBlockFace());
            if (!block3.getType().isAir() && !FluidListener.isReplaceable(block3.getType())) {
                player.sendMessage("\u043c\u0435\u0441\u0442\u043e \u0437\u0430\u043d\u044f\u0442\u043e");
                playerInteractEvent.setCancelled(true);
                return;
            }
            playerInteractEvent.setCancelled(true);
            this.fluids.placeAcid(block3);
            this.consume(itemStack, player);
            player.sendMessage("\u043a\u0438\u0441\u043b\u043e\u0442\u0430 \u0432\u044b\u043b\u0438\u0442\u0430");
            return;
        }
        FluidSystem.Pump pump = this.fluids.pumpAt(block.getLocation());
        if (pump != null) {
            playerInteractEvent.setCancelled(true);
            if ("wrench".equals(string)) {
                player.openInventory(new PumpMenu(this.fluids, pump).getInventory());
            }
        }
    }

    private static boolean isReplaceable(Material material) {
        return material == Material.WATER || material == Material.LAVA || material == Material.TALL_GRASS || material == Material.SHORT_GRASS || material == Material.SNOW;
    }

    private void consume(ItemStack itemStack, Player player) {
        if (itemStack.getAmount() <= 1) {
            player.getInventory().setItemInMainHand(null);
        } else {
            itemStack.setAmount(itemStack.getAmount() - 1);
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onBreak(BlockBreakEvent blockBreakEvent) {
        Object object;
        Block block = blockBreakEvent.getBlock();
        Material material = block.getType();
        Player player = blockBreakEvent.getPlayer();
        boolean bl = player.hasPermission("aperturescience.admin");
        if (material == Material.DISPENSER && (object = this.fluids.pumpAt(block.getLocation())) != null) {
            blockBreakEvent.setCancelled(true);
            if (bl) {
                this.fluids.deletePump(((FluidSystem.Pump)object).number);
                player.sendMessage("\u043d\u0430\u0441\u043e\u0441 " + ((FluidSystem.Pump)object).number + " \u0443\u0434\u0430\u043b\u0435\u043d");
            }
            return;
        }
        if (material == Material.WATER && this.fluids.isAcid((String)(object = block.getWorld().getName() + " " + block.getX() + " " + block.getY() + " " + block.getZ()))) {
            this.fluids.removeAcid((String)object);
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onFlow(BlockFromToEvent blockFromToEvent) {
        Block block = blockFromToEvent.getBlock();
        String string = block.getWorld().getName() + " " + block.getX() + " " + block.getY() + " " + block.getZ();
        if (this.fluids.isAcid(string)) {
            blockFromToEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent inventoryClickEvent) {
        InventoryHolder inventoryHolder = inventoryClickEvent.getInventory().getHolder();
        if (!(inventoryHolder instanceof PumpMenu)) {
            return;
        }
        if (!(inventoryClickEvent.getWhoClicked() instanceof Player)) {
            return;
        }
        inventoryClickEvent.setCancelled(true);
        ((PumpMenu)inventoryHolder).handleClick((Player)inventoryClickEvent.getWhoClicked(), inventoryClickEvent.getRawSlot(), inventoryClickEvent.isRightClick());
    }
}

