package ru.glai.aperture;

import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EnderDragon;
import org.bukkit.entity.Hoglin;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Shulker;
import org.bukkit.entity.Slime;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityTeleportEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

/**
 * Правила территории Апертуры:
 * - жемчуг края не работает (бросок и телепорт отменяются);
 * - плод хоруса не телепортирует;
 * - криперы мгновенно уничтожаются (вдобавок к периодической зачистке в ZoneManager);
 * - агрессивные мобы не спавнятся;
 * - взрывы на территории отменяются.
 */
public final class ZoneRulesListener implements Listener {

    private final ZoneManager zone;

    public ZoneRulesListener(ZoneManager zone) {
        this.zone = zone;
    }

    private static boolean isHostile(Entity e) {
        return e instanceof Monster || e instanceof Slime || e instanceof Hoglin
                || e instanceof Shulker || e instanceof EnderDragon;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onProjectileLaunch(ProjectileLaunchEvent event) {
        Projectile projectile = event.getEntity();
        if (!(projectile instanceof EnderPearl)) {
            return;
        }
        if (projectile.getShooter() instanceof org.bukkit.entity.Player) {
            org.bukkit.entity.Player player = (org.bukkit.entity.Player) projectile.getShooter();
            if (zone.isInZone(player)) {
                event.setCancelled(true);
                player.sendMessage("§cна территории Апертуры жемчуг края не работает");
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        PlayerTeleportEvent.TeleportCause cause = event.getCause();
        if (cause == PlayerTeleportEvent.TeleportCause.ENDER_PEARL) {
            if (zone.contains(event.getFrom()) || zone.contains(event.getTo())) {
                event.setCancelled(true);
                event.getPlayer().sendMessage("§cна территории Апертуры жемчуг края не работает");
            }
            return;
        }
        if (cause == PlayerTeleportEvent.TeleportCause.CHORUS_FRUIT) {
            if (zone.contains(event.getFrom()) || zone.contains(event.getTo())) {
                event.setCancelled(true);
                event.getPlayer().sendMessage("§cна территории Апертуры плод хоруса не работает");
            }
        }
    }

    /** эндермены и прочие телепорты не должны попадать на территорию */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityTeleport(EntityTeleportEvent event) {
        if (event.getTo() != null && zone.contains(event.getTo()) && isHostile(event.getEntity())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCreatureSpawn(CreatureSpawnEvent event) {
        if (!zone.contains(event.getLocation())) {
            return;
        }
        if (isHostile(event.getEntity())) {
            event.setCancelled(true);
        }
    }

    /** страховка: крипер не может взорваться на территории */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent event) {
        if (event.getLocation() != null && zone.contains(event.getLocation())) {
            event.setCancelled(true);
            event.blockList().clear();
        }
    }

    /** плод хоруса не срабатывает вообще (съеден — эффекта нет) */
    @EventHandler(priority = EventPriority.HIGH)
    public void onEatChorus(PlayerInteractEvent event) {
        ItemStack item = event.getItem();
        if (item == null || item.getType() != Material.CHORUS_FRUIT) {
            return;
        }
        if (zone.isInZone(event.getPlayer())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage("§cна территории Апертуры плод хоруса не работает");
        }
    }
}
