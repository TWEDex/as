package ru.glai.aperture;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Openable;
import org.bukkit.block.data.type.Switch;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import ru.glai.aperture.ButtonListener;
import ru.glai.aperture.ButtonManager;
import ru.glai.aperture.CubeSystem;
import ru.glai.aperture.Elevator;
import ru.glai.aperture.ElevatorConfig;
import ru.glai.aperture.FluidListener;
import ru.glai.aperture.FluidSystem;
import ru.glai.aperture.GunListener;
import ru.glai.aperture.ItemStorage;
import ru.glai.aperture.Items;
import ru.glai.aperture.PortalSystem;
import ru.glai.aperture.PumpMenu;
import ru.glai.aperture.VerticalLift;
import ru.glai.aperture.WirelessButton;
import ru.glai.aperture.Worlds;
import ru.glai.aperture.WrenchMenu;
import ru.glai.aperture.ZoneManager;

public final class ApertureScience
extends JavaPlugin
implements Listener,
TabExecutor {
    private static final String PERMISSION = "aperturescience.admin";
    private final Map<String, Elevator> elevators = new LinkedHashMap<String, Elevator>();
    private final Map<String, VerticalLift> verticalLifts = new LinkedHashMap<String, VerticalLift>();
    private final Map<String, Location> doors = new LinkedHashMap<String, Location>();
    private ItemStorage storage;
    private Items items;
    private ButtonManager buttonManager;
    private FluidSystem fluids;
    private CubeSystem cubes;
    private PortalSystem portals;
    private ZoneManager zone;
    private String owner = "MrBaGued";
    private boolean active;
    private int tickerId = -1;
    private int regionClock;
    private FallSystem fall;
    private GunListener gunListener;

    public void onEnable() {
        this.saveDefaultConfig();
        this.storage = new ItemStorage((Plugin)this);
        this.items = new Items((Plugin)this);
        this.buttonManager = new ButtonManager(this, this.items);
        this.buttonManager.load();
        this.fluids = new FluidSystem(this, this.items);
        this.fluids.load();
        this.cubes = new CubeSystem(this);
        this.portals = new PortalSystem(this);
        this.portals.loadConfig();
        this.portals.setCubeSystem(this.cubes);
        this.cubes.setPortals(this.portals);
        this.owner = this.getConfig().getString("owner", "MrBaGued");
        this.loadElevators();
        this.loadVerticalLifts();
        this.loadDoors();
        this.zone = new ZoneManager(this, this.owner);
        this.zone.loadConfig();
        this.zone.load();
        this.fall = new FallSystem(this, loc -> this.isProtectedDevice(loc));
        PluginCommand pluginCommand = this.getCommand("aps");
        if (pluginCommand != null) {
            pluginCommand.setExecutor((CommandExecutor)this);
            pluginCommand.setTabCompleter((TabCompleter)this);
        }
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)this);
        Bukkit.getPluginManager().registerEvents((Listener)new ButtonListener(this, this.buttonManager, this.items), (Plugin)this);
        Bukkit.getPluginManager().registerEvents((Listener)new FluidListener(this.fluids, this.items), (Plugin)this);
        this.gunListener = new GunListener(this.items, this.cubes, this.portals, this.zone);
        Bukkit.getPluginManager().registerEvents((Listener)this.gunListener, (Plugin)this);
        Bukkit.getPluginManager().registerEvents((Listener)new ZoneRulesListener(this.zone), (Plugin)this);
        this.active = true;
        this.tickerId = Bukkit.getScheduler().runTaskTimer((Plugin)this, this::tickAll, 1L, 1L).getTaskId();
        Bukkit.getScheduler().runTaskLater((Plugin)this, this::restoreAll, 5L);
    }

    public void onDisable() {
        if (this.tickerId != -1) {
            Bukkit.getScheduler().cancelTask(this.tickerId);
            this.tickerId = -1;
        }
        Bukkit.getScheduler().cancelTasks((Plugin)this);
        for (Elevator object : this.elevators.values()) {
            object.stop();
        }
        for (VerticalLift verticalLift : this.verticalLifts.values()) {
            verticalLift.stop();
        }
        if (this.buttonManager != null) {
            this.buttonManager.shutdown();
        }
        if (this.cubes != null) {
            this.cubes.save();
            this.cubes.shutdown();
        }
        if (this.fluids != null) {
            this.fluids.save();
        }
        if (this.zone != null) {
            this.zone.save();
        }
        if (this.fall != null) {
            this.fall.shutdown();
        }
        this.active = false;
    }

    private void loadElevators() {
        this.elevators.clear();
        ConfigurationSection configurationSection = this.getConfig().getConfigurationSection("elevators");
        if (configurationSection == null) {
            return;
        }
        for (String string : configurationSection.getKeys(false)) {
            try {
                ElevatorConfig elevatorConfig = new ElevatorConfig(string, this.getConfig(), "elevators." + string);
                this.elevators.put(string.toLowerCase(Locale.ROOT), new Elevator(this, elevatorConfig, configurationSection.getBoolean(string + ".enabled", true)));
            }
            catch (RuntimeException runtimeException) {
                this.getLogger().warning("Lift " + string + " not loaded: " + runtimeException.getMessage());
            }
        }
    }

    private void loadVerticalLifts() {
        this.verticalLifts.clear();
        ConfigurationSection configurationSection = this.getConfig().getConfigurationSection("vertical-lifts");
        if (configurationSection == null) {
            return;
        }
        for (String string : configurationSection.getKeys(false)) {
            try {
                this.verticalLifts.put(string.toLowerCase(Locale.ROOT), new VerticalLift(this, this.storage, string, this.getConfig(), "vertical-lifts." + string, this.owner));
            }
            catch (RuntimeException runtimeException) {
                this.getLogger().warning("Vertical lift " + string + " not loaded: " + runtimeException.getMessage());
            }
        }
    }

    private void loadDoors() {
        this.doors.clear();
        ConfigurationSection configurationSection = this.getConfig().getConfigurationSection("doors");
        if (configurationSection == null) {
            return;
        }
        for (String string : configurationSection.getKeys(false)) {
            String string2 = configurationSection.getString(string + ".world", "world");
            String string3 = configurationSection.getString(string + ".location");
            World world = Worlds.resolve(string2);
            if (world == null || string3 == null) continue;
            try {
                this.doors.put(string.toLowerCase(Locale.ROOT), ApertureScience.parseLocation(string3, world));
            }
            catch (RuntimeException runtimeException) {
                this.getLogger().warning("Door " + string + " not loaded: " + runtimeException.getMessage());
            }
        }
    }

    private void tickAll() {
        for (Elevator object : this.elevators.values()) {
            object.tick();
        }
        for (VerticalLift verticalLift : this.verticalLifts.values()) {
            verticalLift.tick();
        }
        if (this.buttonManager != null) {
            this.buttonManager.tick();
        }
        if (this.fluids != null) {
            this.fluids.tick();
        }
        if (this.cubes != null) {
            this.cubes.tick();
        }
        if (this.portals != null) {
            this.portals.tick();
        }
        if (this.fall != null) {
            this.fall.tick();
        }
        if (this.gunListener != null) {
            this.gunListener.tick();
        }
        ++this.regionClock;
        if (this.regionClock >= 10) {
            this.regionClock = 0;
            if (this.zone != null) {
                this.zone.tick();
            }
        }
    }

    private void restoreAll() {
        if (this.zone != null) {
            this.zone.loadConfig();
        }
        if (this.cubes != null) {
            this.cubes.load();
        }
        for (Elevator object : this.elevators.values()) {
            object.restore();
        }
        for (VerticalLift verticalLift : this.verticalLifts.values()) {
            verticalLift.restore();
        }
    }

    public boolean onCommand(CommandSender commandSender, Command command, String string, String[] stringArray) {
        if (!commandSender.hasPermission(PERMISSION)) {
            return true;
        }
        if (stringArray.length == 0) {
            commandSender.sendMessage("usage /" + string + " on off status itemsback item button create pump block spawn operator portal fall <lift> <door>");
            return true;
        }
        String string2 = stringArray[0].toLowerCase(Locale.ROOT);
        if (string2.equals("on")) {
            this.active = true;
            if (this.tickerId == -1) {
                this.tickerId = Bukkit.getScheduler().runTaskTimer((Plugin)this, this::tickAll, 1L, 1L).getTaskId();
            }
            commandSender.sendMessage("plugin on");
            return true;
        }
        if (string2.equals("off")) {
            this.active = false;
            commandSender.sendMessage("plugin off, running actions will finish");
            return true;
        }
        if (string2.equals("status")) {
            commandSender.sendMessage("plugin: " + (this.active ? "on" : "off"));
            for (Elevator object : this.elevators.values()) {
                commandSender.sendMessage(object.statusLine());
            }
            for (VerticalLift verticalLift : this.verticalLifts.values()) {
                commandSender.sendMessage(verticalLift.statusLine());
            }
            return true;
        }
        if (string2.equals("itemsback")) {
            this.handleItemsBack(commandSender, stringArray);
            return true;
        }
        if (string2.equals("item")) {
            this.handleItem(commandSender, string, stringArray);
            return true;
        }
        if (string2.equals("button")) {
            this.handleButtonCommand(commandSender, string, stringArray);
            return true;
        }
        if (string2.equals("create")) {
            this.handleCreate(commandSender, string, stringArray);
            return true;
        }
        if (string2.equals("pump")) {
            this.handlePumpCommand(commandSender, string, stringArray);
            return true;
        }
        if (string2.equals("block")) {
            this.handleBlockCommand(commandSender, string, stringArray);
            return true;
        }
        if (string2.equals("spawn")) {
            this.handleSpawnCommand(commandSender, string, stringArray);
            return true;
        }
        if (string2.equals("operator")) {
            this.handleOperator(commandSender, string, stringArray);
            return true;
        }
        if (string2.equals("portal")) {
            this.handlePortalCommand(commandSender, string, stringArray);
            return true;
        }
        if (string2.equals("fall")) {
            this.handleFall(commandSender, string, stringArray);
            return true;
        }
        Elevator elevator = this.elevators.get(string2);
        if (elevator != null) {
            this.handleElevator(commandSender, string, elevator, stringArray);
            return true;
        }
        VerticalLift verticalLift = this.verticalLifts.get(string2);
        if (verticalLift != null) {
            this.handleVertical(commandSender, verticalLift, stringArray);
            return true;
        }
        Location location = this.doors.get(string2);
        if (location != null) {
            this.handleDoor(commandSender, location, stringArray);
            return true;
        }
        commandSender.sendMessage("device " + string2 + " not found");
        return true;
    }

    private void handleElevator(CommandSender commandSender, String string, Elevator elevator, String[] stringArray) {
        String string2;
        String string3 = string2 = stringArray.length > 1 ? stringArray[1].toLowerCase(Locale.ROOT) : "";
        if (string2.equals("on")) {
            elevator.setEnabled(true);
            commandSender.sendMessage("lift " + elevator.id() + " on");
            return;
        }
        if (string2.equals("off")) {
            elevator.setEnabled(false);
            commandSender.sendMessage("lift " + elevator.id() + " off");
            return;
        }
        if (string2.equals("end")) {
            elevator.emergencyStop();
            commandSender.sendMessage("lift " + elevator.id() + " emergency stopped, waiting for command");
            return;
        }
        if (string2.equals("start")) {
            if (!this.active) {
                commandSender.sendMessage("plugin is off");
                return;
            }
            if (elevator.isRunning()) {
                commandSender.sendMessage("lift " + elevator.id() + " is busy");
                return;
            }
            boolean bl = true;
            boolean bl2 = true;
            int n = 1;
            int n2 = 0;
            for (int i = 2; i < stringArray.length; ++i) {
                String string4 = stringArray[i].toLowerCase(Locale.ROOT);
                if (string4.equals("fast")) {
                    bl = false;
                    bl2 = false;
                    continue;
                }
                if (string4.equals("nohome")) {
                    bl = false;
                    continue;
                }
                if (string4.equals("nofar")) {
                    bl2 = false;
                    continue;
                }
                if (string4.startsWith("human:")) {
                    try {
                        n = Integer.parseInt(string4.substring(6));
                    }
                    catch (NumberFormatException numberFormatException) {}
                    continue;
                }
                if (!string4.matches("\\d+")) continue;
                n2 = Integer.parseInt(string4);
            }
            elevator.remoteStart(bl, bl2, Math.max(1, n), Math.max(0, n2));
            commandSender.sendMessage("lift " + elevator.id() + " started");
            return;
        }
        commandSender.sendMessage("usage /" + string + " " + elevator.id() + " <on off start end> [fast nohome nofar human:N seconds]");
    }

    private void handleVertical(CommandSender commandSender, VerticalLift verticalLift, String[] stringArray) {
        String string;
        String string2 = string = stringArray.length > 1 ? stringArray[1].toLowerCase(Locale.ROOT) : "";
        if (!this.active) {
            commandSender.sendMessage("plugin is off");
            return;
        }
        if (string.equals("end")) {
            verticalLift.emergencyStop();
            commandSender.sendMessage("lift " + verticalLift.id() + " emergency stopped, waiting for command");
            return;
        }
        int[] nArray = this.parseMods(stringArray, 2);
        boolean bl = nArray[0] == 1;
        int n = nArray[1];
        int n2 = nArray[2];
        if (string.equals("down")) {
            if (verticalLift.isBusy()) {
                commandSender.sendMessage("lift " + verticalLift.id() + " is busy");
                return;
            }
            if (verticalLift.isAtBottom()) {
                commandSender.sendMessage("lift " + verticalLift.id() + " is already at bottom");
                return;
            }
            if (verticalLift.isAtTop()) {
                verticalLift.commandDown(bl, n, n2);
            } else {
                verticalLift.resumeDown();
            }
            commandSender.sendMessage("lift " + verticalLift.id() + " going down");
            return;
        }
        if (string.equals("up")) {
            if (verticalLift.isBusy()) {
                commandSender.sendMessage("lift " + verticalLift.id() + " is busy");
                return;
            }
            if (verticalLift.isAtTop()) {
                commandSender.sendMessage("lift " + verticalLift.id() + " is already at top");
                return;
            }
            if (verticalLift.isAtBottom()) {
                verticalLift.commandUp(bl, n, n2);
            } else {
                verticalLift.resumeUp();
            }
            commandSender.sendMessage("lift " + verticalLift.id() + " going up");
            return;
        }
        commandSender.sendMessage("usage /asm " + verticalLift.id() + " <up down end> [fast] [human:N] [seconds]");
    }

    private int[] parseMods(String[] stringArray, int n) {
        int n2 = 0;
        int n3 = 1;
        int n4 = 0;
        for (int i = n; i < stringArray.length; ++i) {
            String string = stringArray[i].toLowerCase(Locale.ROOT);
            if (string.equals("fast")) {
                n2 = 1;
                continue;
            }
            if (string.startsWith("human:")) {
                try {
                    n3 = Integer.parseInt(string.substring(6));
                }
                catch (NumberFormatException numberFormatException) {}
                continue;
            }
            if (!string.matches("\\d+")) continue;
            n4 = Integer.parseInt(string);
        }
        return new int[]{n2, Math.max(1, n3), Math.max(0, n4)};
    }

    private void handleDoor(CommandSender commandSender, Location location, String[] stringArray) {
        String string;
        String string2 = string = stringArray.length > 1 ? stringArray[1].toLowerCase(Locale.ROOT) : "";
        if (string.equals("open")) {
            this.setDoor(location, true);
            commandSender.sendMessage("door open");
            return;
        }
        if (string.equals("close")) {
            this.setDoor(location, false);
            commandSender.sendMessage("door close");
            return;
        }
        commandSender.sendMessage("usage /asm <door> <open close>");
    }

    private void handleItemsBack(CommandSender commandSender, String[] stringArray) {
        Player player;
        if (stringArray.length > 1) {
            player = Bukkit.getPlayerExact((String)stringArray[1]);
            if (player == null) {
                commandSender.sendMessage("player offline");
                return;
            }
        } else if (commandSender instanceof Player) {
            player = (Player)commandSender;
        } else {
            commandSender.sendMessage("specify a player");
            return;
        }
        if (!this.storage.has(player.getUniqueId())) {
            commandSender.sendMessage("\u0443 \u0438\u0433\u0440\u043e\u043a\u0430 \u043d\u0435 \u0437\u0430\u0431\u0438\u0440\u0430\u043b\u0438 \u0432\u0435\u0449\u0438");
            return;
        }
        ItemStack[] itemStackArray = this.storage.load(player.getUniqueId());
        if (itemStackArray == null) {
            commandSender.sendMessage("\u0443 \u0438\u0433\u0440\u043e\u043a\u0430 \u043d\u0435 \u0437\u0430\u0431\u0438\u0440\u0430\u043b\u0438 \u0432\u0435\u0449\u0438");
            return;
        }
        this.giveItems(player, itemStackArray);
        this.storage.remove(player.getUniqueId());
        commandSender.sendMessage("items returned to " + player.getName());
    }

    private static final Set<String> OLD_COLORS = new HashSet<String>(Arrays.asList(
            "green", "black", "red", "blue", "yellow", "orange", "purple", "cyan", "white", "magenta"));

    private void handlePortalGun(CommandSender commandSender, String label, String[] args) {
        Player player;
        String arg = args.length > 2 ? args[2] : null;
        if (arg != null && OLD_COLORS.contains(arg.toLowerCase(Locale.ROOT))) {
            commandSender.sendMessage("\u0446\u0432\u0435\u0442\u0430 \u0431\u043e\u043b\u044c\u0448\u0435 \u043d\u0435 \u043d\u0443\u0436\u043d\u044b: \u043f\u0443\u0448\u043a\u0430 \u043e\u0434\u043d\u0430, \u041b\u041a\u041c \u2014 \u043e\u0440\u0430\u043d\u0436\u0435\u0432\u044b\u0439, \u041f\u041a\u041c \u2014 \u0441\u0438\u043d\u0438\u0439 \u043f\u043e\u0440\u0442\u0430\u043b");
            arg = args.length > 3 ? args[3] : null;
        }
        if (arg != null) {
            player = Bukkit.getPlayerExact(arg);
            if (player == null) {
                commandSender.sendMessage("\u0438\u0433\u0440\u043e\u043a \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d");
                return;
            }
        } else if (commandSender instanceof Player) {
            player = (Player)commandSender;
        } else {
            commandSender.sendMessage("\u0443\u043a\u0430\u0436\u0438\u0442\u0435 \u0438\u0433\u0440\u043e\u043a\u0430");
            return;
        }
        ItemStack gun = this.items.createPortalGun();
        for (ItemStack left : player.getInventory().addItem(gun).values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), left);
        }
        commandSender.sendMessage("\u043f\u043e\u0440\u0442\u0430\u043b\u044c\u043d\u0430\u044f \u043f\u0443\u0448\u043a\u0430 \u0432\u044b\u0434\u0430\u043d\u0430 " + player.getName());
    }

    private void handlePortalCommand(CommandSender commandSender, String label, String[] args) {
        String sub = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "status";
        if (sub.equals("status")) {
            for (String line : this.portals.status()) {
                commandSender.sendMessage(line);
            }
            return;
        }
        if (sub.equals("clear")) {
            int n = this.portals.clearAll();
            commandSender.sendMessage("\u0443\u0434\u0430\u043b\u0435\u043d\u043e \u043f\u043e\u0440\u0442\u0430\u043b\u043e\u0432: " + n);
            return;
        }
        if (sub.equals("delete")) {
            Player target;
            if (args.length > 2) {
                target = Bukkit.getPlayerExact(args[2]);
                if (target == null) {
                    commandSender.sendMessage("\u0438\u0433\u0440\u043e\u043a \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d");
                    return;
                }
            } else if (commandSender instanceof Player) {
                target = (Player)commandSender;
            } else {
                commandSender.sendMessage("usage /" + label + " portal delete [player]");
                return;
            }
            if (this.portals.clearFor(target.getUniqueId())) {
                commandSender.sendMessage("\u043f\u043e\u0440\u0442\u0430\u043b\u044b " + target.getName() + " \u0443\u0434\u0430\u043b\u0435\u043d\u044b");
            } else {
                commandSender.sendMessage("\u0443 " + target.getName() + " \u043d\u0435\u0442 \u043f\u043e\u0440\u0442\u0430\u043b\u043e\u0432");
            }
            return;
        }
        commandSender.sendMessage("usage /" + label + " portal <status delete clear> [player]");
    }

    /** /asm fall <x1 y1 z1> <x2 y2 z2> [falling|boom] */
    private void handleFall(CommandSender commandSender, String label, String[] args) {
        if (args.length < 7) {
            commandSender.sendMessage("usage /" + label + " fall <x1 y1 z1> <x2 y2 z2> [falling boom] (\u0440\u0430\u0431\u043e\u0442\u0430\u0435\u0442 ~)");
            return;
        }
        boolean boom;
        if (args.length >= 8) {
            String type = args[7].toLowerCase(Locale.ROOT);
            if (type.equals("falling") || type.equals("fall")) {
                boom = false;
            } else if (type.equals("boom") || type.equals("explode")) {
                boom = true;
            } else {
                commandSender.sendMessage("\u0442\u0438\u043f: falling \u0438\u043b\u0438 boom");
                return;
            }
        } else {
            boom = false;
        }
        World world;
        if (commandSender instanceof Player) {
            world = ((Player)commandSender).getWorld();
        } else {
            world = Bukkit.getWorlds().isEmpty() ? null : Bukkit.getWorlds().get(0);
        }
        if (world == null) {
            commandSender.sendMessage("\u043c\u0438\u0440 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d");
            return;
        }
        double[] a;
        double[] b;
        try {
            a = this.parseXYZ(commandSender, args, 1);
            b = this.parseXYZ(commandSender, args, 4);
        }
        catch (NumberFormatException | ArrayIndexOutOfBoundsException ex) {
            commandSender.sendMessage("\u043d\u0435\u0432\u0435\u0440\u043d\u044b\u0435 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b (\u043c\u043e\u0436\u043d\u043e ~)");
            return;
        }
        if (this.fall == null) {
            commandSender.sendMessage("fall system not ready");
            return;
        }
        commandSender.sendMessage(this.fall.execute(world,
                (int)Math.floor(a[0]), (int)Math.floor(a[1]), (int)Math.floor(a[2]),
                (int)Math.floor(b[0]), (int)Math.floor(b[1]), (int)Math.floor(b[2]), boom));
    }

    /** устройства плагина, которые нельзя обрушать */
    private boolean isProtectedDevice(Location location) {
        if (this.fluids != null && this.fluids.pumpAt(location) != null) {
            return true;
        }
        if (this.buttonManager == null) {
            return false;
        }
        return this.buttonManager.buttonByBlock(location) != null
                || this.buttonManager.detectorAt(location) != null
                || this.buttonManager.deviceAt(location) != null;
    }

    /** координаты с поддержкой ~ (относительно позиции игрока) */
    private static double parseCoord(String token, double base) {
        if (token.equals("~")) {
            return base;
        }
        if (token.startsWith("~")) {
            String rest = token.substring(1);
            return base + (rest.isEmpty() ? 0.0 : Double.parseDouble(rest));
        }
        return Double.parseDouble(token);
    }

    private double[] parseXYZ(CommandSender sender, String[] args, int idx) {
        double bx = 0.0;
        double by = 0.0;
        double bz = 0.0;
        if (sender instanceof Player) {
            Location l = ((Player)sender).getLocation();
            bx = l.getX();
            by = l.getY();
            bz = l.getZ();
        }
        return new double[]{
                ApertureScience.parseCoord(args[idx], bx),
                ApertureScience.parseCoord(args[idx + 1], by),
                ApertureScience.parseCoord(args[idx + 2], bz)};
    }

    private void handleItem(CommandSender commandSender, String string, String[] stringArray) {
        ItemStack itemStack;
        Player player;
        if (stringArray.length >= 3 && stringArray[1].equalsIgnoreCase("block") && stringArray[2].equalsIgnoreCase("spawn")) {
            this.handleBlockCommand(commandSender, string, stringArray);
            return;
        }
        if (stringArray.length >= 2 && stringArray[1].equalsIgnoreCase("portal_gun")) {
            this.handlePortalGun(commandSender, string, stringArray);
            return;
        }
        if (stringArray.length < 2) {
            commandSender.sendMessage("usage /" + string + " item <button wrench detector portal_gun pump acid> [player]");
            return;
        }
        String string2 = stringArray[1].toLowerCase(Locale.ROOT);
        if (!this.items.kinds().contains(string2)) {
            commandSender.sendMessage("unknown item " + string2);
            return;
        }
        if (stringArray.length > 2) {
            player = Bukkit.getPlayerExact((String)stringArray[2]);
            if (player == null) {
                commandSender.sendMessage("player offline");
                return;
            }
        } else if (commandSender instanceof Player) {
            player = (Player)commandSender;
        } else {
            commandSender.sendMessage("specify a player");
            return;
        }
        if ((itemStack = this.items.create(string2)) == null) {
            commandSender.sendMessage("cannot create item");
            return;
        }
        for (ItemStack itemStack2 : player.getInventory().addItem(new ItemStack[]{itemStack}).values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), itemStack2);
        }
        commandSender.sendMessage("item " + string2 + " given to " + player.getName());
    }

    private void handleButtonCommand(CommandSender commandSender, String string, String[] stringArray) {
        int n;
        if (stringArray.length < 3) {
            commandSender.sendMessage("usage /" + string + " button <number> <delete rename enable disable options>");
            return;
        }
        try {
            n = Integer.parseInt(stringArray[1]);
        }
        catch (NumberFormatException numberFormatException) {
            commandSender.sendMessage("number required");
            return;
        }
        WirelessButton wirelessButton = this.buttonManager.button(n);
        if (wirelessButton == null) {
            commandSender.sendMessage("button " + n + " not found");
            return;
        }
        String string2 = stringArray[2].toLowerCase(Locale.ROOT);
        if (string2.equals("delete")) {
            this.buttonManager.deleteButton(n);
            commandSender.sendMessage("button " + n + " deleted");
            return;
        }
        if (string2.equals("rename")) {
            if (stringArray.length < 4) {
                commandSender.sendMessage("usage /" + string + " button " + n + " rename <name>");
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 3; i < stringArray.length; ++i) {
                if (i > 3) {
                    stringBuilder.append(' ');
                }
                stringBuilder.append(stringArray[i]);
            }
            wirelessButton.name = stringBuilder.toString();
            this.buttonManager.save();
            commandSender.sendMessage("button " + n + " renamed");
            return;
        }
        if (string2.equals("enable")) {
            wirelessButton.enabled = true;
            this.buttonManager.save();
            commandSender.sendMessage("button " + n + " enabled");
            return;
        }
        if (string2.equals("disable")) {
            wirelessButton.enabled = false;
            this.buttonManager.setActive(wirelessButton, false, -1L);
            this.buttonManager.save();
            commandSender.sendMessage("button " + n + " disabled");
            return;
        }
        if (string2.equals("options")) {
            if (!(commandSender instanceof Player)) {
                commandSender.sendMessage("player only");
                return;
            }
            WrenchMenu wrenchMenu = new WrenchMenu(this.buttonManager, wirelessButton, null);
            ((Player)commandSender).openInventory(wrenchMenu.getInventory());
            return;
        }
        commandSender.sendMessage("usage /" + string + " button <number> <delete rename enable disable options>");
    }

    private void handleCreate(CommandSender commandSender, String string, String[] stringArray) {
        World world;
        float f;
        int n;
        int n2;
        int n3;
        int n4;
        if (stringArray.length < 7 || !stringArray[1].equalsIgnoreCase("button")) {
            commandSender.sendMessage("usage /" + string + " create button <number> <x y z> <+x -x +z -z>");
            return;
        }
        try {
            n4 = Integer.parseInt(stringArray[2]);
            double[] pos = this.parseXYZ(commandSender, stringArray, 3);
            n3 = (int)Math.floor(pos[0]);
            n2 = (int)Math.floor(pos[1]);
            n = (int)Math.floor(pos[2]);
        }
        catch (NumberFormatException numberFormatException) {
            commandSender.sendMessage("bad number or coordinates");
            return;
        }
        if (this.buttonManager.button(n4) != null) {
            commandSender.sendMessage("number " + n4 + " already used");
            return;
        }
        String string2 = stringArray[6].toLowerCase(Locale.ROOT);
        if (string2.equals("+x")) {
            f = 270.0f;
        } else if (string2.equals("-x")) {
            f = 90.0f;
        } else if (string2.equals("-z")) {
            f = 180.0f;
        } else if (string2.equals("+z")) {
            f = 0.0f;
        } else {
            commandSender.sendMessage("facing must be +x -x +z -z");
            return;
        }
        if (commandSender instanceof Player) {
            world = ((Player)commandSender).getWorld();
        } else {
            World world2 = world = Bukkit.getWorlds().isEmpty() ? null : (World)Bukkit.getWorlds().get(0);
        }
        if (world == null) {
            commandSender.sendMessage("world not found");
            return;
        }
        WirelessButton wirelessButton = this.buttonManager.createButton(n4, "button " + n4, world, n3, n2, n, f);
        if (wirelessButton == null) {
            commandSender.sendMessage("cannot create button");
            return;
        }
        commandSender.sendMessage("button " + n4 + " created at " + n3 + " " + n2 + " " + n);
    }

    private void handlePumpCommand(CommandSender commandSender, String string, String[] stringArray) {
        int n;
        if (stringArray.length < 2) {
            commandSender.sendMessage("usage /" + string + " pump <number> <options enable disable group> | group <name> <on off start stop>");
            return;
        }
        if (stringArray[1].equalsIgnoreCase("group")) {
            this.handlePumpGroup(commandSender, string, stringArray);
            return;
        }
        try {
            n = Integer.parseInt(stringArray[1]);
        }
        catch (NumberFormatException numberFormatException) {
            commandSender.sendMessage("number required");
            return;
        }
        FluidSystem.Pump pump = this.fluids.pump(n);
        if (pump == null) {
            commandSender.sendMessage("pump " + n + " not found");
            return;
        }
        if (stringArray.length < 3) {
            commandSender.sendMessage("pump " + n + ": " + (pump.enabled ? "enabled" : "disabled") + ", group " + (pump.group.isEmpty() ? "none" : pump.group));
            return;
        }
        String string2 = stringArray[2].toLowerCase(Locale.ROOT);
        if (string2.equals("options")) {
            if (!(commandSender instanceof Player)) {
                commandSender.sendMessage("player only");
                return;
            }
            ((Player)commandSender).openInventory(new PumpMenu(this.fluids, pump).getInventory());
            return;
        }
        if (string2.equals("enable")) {
            pump.enabled = true;
            this.fluids.save();
            commandSender.sendMessage("pump " + n + " enabled");
            return;
        }
        if (string2.equals("disable")) {
            pump.enabled = false;
            this.fluids.save();
            commandSender.sendMessage("pump " + n + " disabled");
            return;
        }
        if (string2.equals("group")) {
            String string3;
            if (stringArray.length < 4) {
                commandSender.sendMessage("pump " + n + " group: " + (pump.group.isEmpty() ? "none" : pump.group));
                return;
            }
            String string4 = stringArray[3].toLowerCase(Locale.ROOT);
            if (string4.equals("delete") || string4.equals("remove") || string4.equals("none") || string4.equals("clear")) {
                pump.group = "";
                this.fluids.save();
                commandSender.sendMessage("pump " + n + " removed from group");
                return;
            }
            if (string4.equals("add") || string4.equals("set")) {
                if (stringArray.length < 5) {
                    commandSender.sendMessage("usage /" + string + " pump " + n + " group add <name>");
                    return;
                }
                string3 = stringArray[4];
            } else {
                string3 = stringArray[3];
            }
            pump.group = string3;
            if (!this.fluids.groupNames().contains(string3.toLowerCase(Locale.ROOT))) {
                this.fluids.groupSetRunning(string3, false);
            }
            this.fluids.save();
            commandSender.sendMessage("pump " + n + " group " + string3);
            return;
        }
        commandSender.sendMessage("usage /" + string + " pump " + n + " <options enable disable group>");
    }

    private void handlePumpGroup(CommandSender commandSender, String string, String[] stringArray) {
        if (stringArray.length < 4) {
            commandSender.sendMessage("usage /" + string + " pump group <name> <on off start [seconds] stop list>");
            return;
        }
        String string2 = stringArray[2];
        String string3 = string2.toLowerCase(Locale.ROOT);
        String string4 = stringArray[3].toLowerCase(Locale.ROOT);
        if (string4.equals("list")) {
            List<FluidSystem.Pump> list = this.fluids.groupMembers(string2);
            if (list.isEmpty()) {
                commandSender.sendMessage("group " + string2 + " has no pumps");
            } else {
                StringBuilder stringBuilder = new StringBuilder("group " + string2 + " (" + (this.fluids.groupRunning(string2) ? "running" : "stopped") + "):");
                for (FluidSystem.Pump pump : list) {
                    stringBuilder.append(' ').append(pump.number);
                }
                commandSender.sendMessage(stringBuilder.toString());
            }
            return;
        }
        if (!this.fluids.groupNames().contains(string3)) {
            this.fluids.groupSetRunning(string2, false);
        }
        if (string4.equals("on") || string4.equals("start")) {
            this.fluids.groupSetRunning(string2, true);
            commandSender.sendMessage("group " + string2 + " started");
            if (string4.equals("start") && stringArray.length >= 5) {
                int n;
                try {
                    n = Integer.parseInt(stringArray[4]);
                }
                catch (NumberFormatException numberFormatException) {
                    commandSender.sendMessage("seconds must be a number");
                    return;
                }
                if (n > 0) {
                    String string5 = string2;
                    Bukkit.getScheduler().runTaskLater((Plugin)this, () -> {
                        this.fluids.groupSetRunning(string5, false);
                        Bukkit.getConsoleSender().sendMessage("group " + string5 + " stopped");
                    }, (long)n * 20L);
                }
            }
            return;
        }
        if (string4.equals("off") || string4.equals("stop")) {
            this.fluids.groupSetRunning(string2, false);
            commandSender.sendMessage("group " + string2 + " stopped");
            return;
        }
        commandSender.sendMessage("usage /" + string + " pump group " + string2 + " <on off start [seconds] stop list>");
    }

    private void handleBlockCommand(CommandSender commandSender, String string, String[] stringArray) {
        World world;
        double d;
        double d2;
        double d3;
        if (stringArray.length < 5 || !stringArray[1].equalsIgnoreCase("spawn")) {
            commandSender.sendMessage("usage /" + string + " block spawn <x> <y> <z> (~ \u0440\u0430\u0431\u043e\u0442\u0430\u0435\u0442)");
            return;
        }
        try {
            double[] pos = this.parseXYZ(commandSender, stringArray, 2);
            d3 = pos[0];
            d2 = pos[1];
            d = pos[2];
        }
        catch (NumberFormatException | ArrayIndexOutOfBoundsException numberFormatException) {
            commandSender.sendMessage("bad coordinates");
            return;
        }
        if (commandSender instanceof Player) {
            world = ((Player)commandSender).getWorld();
        } else {
            World world2 = world = Bukkit.getWorlds().isEmpty() ? null : (World)Bukkit.getWorlds().get(0);
        }
        if (world == null) {
            commandSender.sendMessage("world not found");
            return;
        }
        if (this.cubes == null) {
            commandSender.sendMessage("cube system not ready");
            return;
        }
        this.cubes.spawnCube(world, d3, d2, d);
        commandSender.sendMessage("cube spawned at " + (int)d3 + " " + (int)d2 + " " + (int)d);
    }

    private void handleSpawnCommand(CommandSender commandSender, String string, String[] stringArray) {
        World world;
        int n;
        double d;
        double d2;
        double d3;
        if (stringArray.length < 5 || !stringArray[1].equalsIgnoreCase("neir")) {
            commandSender.sendMessage("usage /" + string + " spawn neir <x> <y> <z> <seconds> [concentration]");
            return;
        }
        int n2 = 2;
        try {
            double[] pos = this.parseXYZ(commandSender, stringArray, 2);
            d3 = pos[0];
            d2 = pos[1];
            d = pos[2];
            n = Integer.parseInt(stringArray[5]);
            if (stringArray.length >= 7) {
                n2 = Integer.parseInt(stringArray[6]);
            }
        }
        catch (ArrayIndexOutOfBoundsException | NumberFormatException runtimeException) {
            commandSender.sendMessage("usage /" + string + " spawn neir <x> <y> <z> <seconds> [concentration] (~ \u0440\u0430\u0431\u043e\u0442\u0430\u0435\u0442)");
            return;
        }
        if (commandSender instanceof Player) {
            world = ((Player)commandSender).getWorld();
        } else {
            World world2 = world = Bukkit.getWorlds().isEmpty() ? null : (World)Bukkit.getWorlds().get(0);
        }
        if (world == null) {
            commandSender.sendMessage("world not found");
            return;
        }
        this.fluids.addEmitter(world, d3, d2, d, n, n2);
        commandSender.sendMessage("neurotoxin spawned at " + (int)d3 + " " + (int)d2 + " " + (int)d + " for " + n + "s");
    }

    private void handleOperator(CommandSender commandSender, String string, String[] stringArray) {
        if (stringArray.length < 2) {
            commandSender.sendMessage("usage /" + string + " operator <add delete block unblock status region expand shrink> [player|\u0431\u043b\u043e\u043a\u0438]");
            return;
        }
        String string2 = stringArray[1].toLowerCase(Locale.ROOT);
        if (string2.equals("region")) {
            commandSender.sendMessage("\u0442\u0435\u0440\u0440\u0438\u0442\u043e\u0440\u0438\u044f: " + this.zone.regionInfo());
            return;
        }
        if (string2.equals("expand") || string2.equals("shrink")) {
            if (stringArray.length < 3) {
                commandSender.sendMessage("usage /" + string + " operator " + string2 + " <\u0431\u043b\u043e\u043a\u043e\u0432>");
                return;
            }
            int amount;
            try {
                amount = Integer.parseInt(stringArray[2]);
            }
            catch (NumberFormatException numberFormatException) {
                commandSender.sendMessage("\u043d\u0443\u0436\u043d\u043e \u0447\u0438\u0441\u043b\u043e \u0431\u043b\u043e\u043a\u043e\u0432");
                return;
            }
            if (amount <= 0) {
                commandSender.sendMessage("\u0447\u0438\u0441\u043b\u043e \u0434\u043e\u043b\u0436\u043d\u043e \u0431\u044b\u0442\u044c \u0431\u043e\u043b\u044c\u0448\u0435 \u043d\u0443\u043b\u044f");
                return;
            }
            String result = string2.equals("expand") ? this.zone.expand(amount) : this.zone.shrink(amount);
            if (result == null) {
                commandSender.sendMessage("\u0442\u0435\u0440\u0440\u0438\u0442\u043e\u0440\u0438\u044f \u043d\u0435 \u0437\u0430\u0434\u0430\u043d\u0430 \u0432 \u043a\u043e\u043d\u0444\u0438\u0433\u0435");
            } else {
                commandSender.sendMessage((string2.equals("expand") ? "\u0442\u0435\u0440\u0440\u0438\u0442\u043e\u0440\u0438\u044f \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043d\u0430 \u043d\u0430 " : "\u0442\u0435\u0440\u0440\u0438\u0442\u043e\u0440\u0438\u044f \u0441\u0443\u0436\u0435\u043d\u0430 \u043d\u0430 ") + amount + ": " + result);
            }
            return;
        }
        if (string2.equals("status")) {
            commandSender.sendMessage("operators: " + (this.zone.operatorNames().isEmpty() ? "none" : String.join((CharSequence)", ", this.zone.operatorNames())));
            commandSender.sendMessage("blocked: " + (this.zone.blockedNames().isEmpty() ? "none" : String.join((CharSequence)", ", this.zone.blockedNames())));
            List<String> list = this.zone.playersInZone();
            commandSender.sendMessage("in zone now: " + (list.isEmpty() ? "none" : String.join((CharSequence)", ", list)));
            return;
        }
        if (stringArray.length < 3) {
            commandSender.sendMessage("usage /" + string + " operator " + string2 + " <player>");
            return;
        }
        String string3 = stringArray[2];
        if (string2.equals("add")) {
            if (this.zone.addOperator(string3)) {
                commandSender.sendMessage(string3 + " added to operators");
            } else {
                commandSender.sendMessage("player " + string3 + " not found");
            }
            return;
        }
        if (string2.equals("delete") || string2.equals("remove")) {
            if (this.zone.removeOperator(string3)) {
                commandSender.sendMessage(string3 + " removed from operators");
            } else {
                commandSender.sendMessage("player " + string3 + " not found");
            }
            return;
        }
        if (string2.equals("block")) {
            if (this.zone.addBlocked(string3)) {
                commandSender.sendMessage(string3 + " blocked from zone");
            } else {
                commandSender.sendMessage("player " + string3 + " not found");
            }
            return;
        }
        if (string2.equals("unblock")) {
            if (this.zone.removeBlocked(string3)) {
                commandSender.sendMessage(string3 + " unblocked");
            } else {
                commandSender.sendMessage("player " + string3 + " not found");
            }
            return;
        }
        commandSender.sendMessage("usage /" + string + " operator <add delete block unblock status region expand shrink> [player|\u0431\u043b\u043e\u043a\u0438]");
    }

    private void giveItems(Player player, ItemStack[] itemStackArray) {
        PlayerInventory playerInventory = player.getInventory();
        ItemStack[] itemStackArray2 = playerInventory.getContents();
        boolean bl = true;
        for (ItemStack itemStack : itemStackArray2) {
            if (itemStack == null || itemStack.getType() == Material.AIR) continue;
            bl = false;
            break;
        }
        if (bl && itemStackArray.length == itemStackArray2.length) {
            playerInventory.setContents(itemStackArray);
            return;
        }
        for (ItemStack itemStack : itemStackArray) {
            if (itemStack == null || itemStack.getType() == Material.AIR) continue;
            HashMap<Integer, ItemStack> hashMap = playerInventory.addItem(new ItemStack[]{itemStack});
            for (ItemStack itemStack2 : hashMap.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), itemStack2);
            }
        }
    }

    private void setDoor(Location location, boolean bl) {
        World world = location.getWorld();
        if (world == null) {
            return;
        }
        Block block = world.getBlockAt(location.getBlockX(), location.getBlockY(), location.getBlockZ());
        BlockData blockData = block.getBlockData();
        if (blockData instanceof Openable) {
            Openable openable;
            Block block2;
            BlockData blockData2;
            Openable openable2 = (Openable)blockData;
            if (openable2.isOpen() != bl) {
                openable2.setOpen(bl);
                block.setBlockData((BlockData)openable2, false);
                world.playSound(block.getLocation(), bl ? Sound.BLOCK_IRON_DOOR_OPEN : Sound.BLOCK_IRON_DOOR_CLOSE, SoundCategory.BLOCKS, 1.0f, 1.0f);
            }
            if ((blockData2 = (block2 = world.getBlockAt(location.getBlockX(), location.getBlockY() + 1, location.getBlockZ())).getBlockData()) instanceof Openable && (openable = (Openable)blockData2).isOpen() != bl) {
                openable.setOpen(bl);
                block2.setBlockData((BlockData)openable, false);
            }
        }
    }

    public List<String> onTabComplete(CommandSender commandSender, Command command, String string, String[] stringArray) {
        String string2;
        if (!commandSender.hasPermission(PERMISSION)) {
            return new ArrayList<String>();
        }
        if (stringArray.length == 1) {
            ArrayList<String> arrayList = new ArrayList<String>(Arrays.asList("on", "off", "status", "itemsback", "item", "button", "create", "pump", "block", "spawn", "operator", "portal", "fall"));
            arrayList.addAll(this.elevators.keySet());
            arrayList.addAll(this.verticalLifts.keySet());
            arrayList.addAll(this.doors.keySet());
            return this.filter(arrayList, stringArray[0]);
        }
        if (stringArray.length == 2) {
            string2 = stringArray[0].toLowerCase(Locale.ROOT);
            if (string2.equals("item")) {
                return this.filter(this.items.kinds(), stringArray[1]);
            }
            if (string2.equals("create")) {
                return this.filter(Arrays.asList("button"), stringArray[1]);
            }
            if (string2.equals("button")) {
                ArrayList<String> arrayList = new ArrayList<String>();
                for (Integer n : this.buttonManager.buttons().keySet()) {
                    arrayList.add(String.valueOf(n));
                }
                return this.filter(arrayList, stringArray[1]);
            }
            if (string2.equals("pump")) {
                ArrayList<String> arrayList = new ArrayList<String>();
                arrayList.add("group");
                for (Integer n : this.fluids.pumps().keySet()) {
                    arrayList.add(String.valueOf(n));
                }
                return this.filter(arrayList, stringArray[1]);
            }
            if (string2.equals("block")) {
                return this.filter(Arrays.asList("spawn"), stringArray[1]);
            }
            if (string2.equals("spawn")) {
                return this.filter(Arrays.asList("neir"), stringArray[1]);
            }
            if (string2.equals("operator")) {
                return this.filter(Arrays.asList("add", "delete", "block", "unblock", "status", "region", "expand", "shrink"), stringArray[1]);
            }
            if (string2.equals("portal")) {
                return this.filter(Arrays.asList("status", "delete", "clear"), stringArray[1]);
            }
            if (string2.equals("fall")) {
                return this.filter(Arrays.asList("~", "~1"), stringArray[1]);
            }
            if (this.elevators.containsKey(string2)) {
                return this.filter(Arrays.asList("on", "off", "start", "end"), stringArray[1]);
            }
            if (this.verticalLifts.containsKey(string2)) {
                return this.filter(Arrays.asList("up", "down", "end"), stringArray[1]);
            }
            if (this.doors.containsKey(string2)) {
                return this.filter(Arrays.asList("open", "close"), stringArray[1]);
            }
        }
        if (stringArray.length == 3) {
            string2 = stringArray[0].toLowerCase(Locale.ROOT);
            String string3 = stringArray[1].toLowerCase(Locale.ROOT);
            if (string2.equals("button")) {
                return this.filter(Arrays.asList("delete", "rename", "enable", "disable", "options"), stringArray[2]);
            }
            if (string2.equals("pump")) {
                if (string3.equals("group")) {
                    return this.filter(new ArrayList<String>(this.fluids.groupNames()), stringArray[2]);
                }
                return this.filter(Arrays.asList("options", "enable", "disable", "group"), stringArray[2]);
            }
            if (this.elevators.containsKey(string2) && string3.equals("start")) {
                return this.filter(Arrays.asList("fast", "nohome", "nofar"), stringArray[2]);
            }
            if (this.verticalLifts.containsKey(string2) && (string3.equals("up") || string3.equals("down"))) {
                return this.filter(Arrays.asList("fast"), stringArray[2]);
            }
        }
        if (stringArray.length == 7 && stringArray[1].equalsIgnoreCase("button")) {
            return this.filter(Arrays.asList("+x", "-x", "+z", "-z"), stringArray[6]);
        }
        if (stringArray.length == 8 && stringArray[0].equalsIgnoreCase("fall")) {
            return this.filter(Arrays.asList("falling", "boom"), stringArray[7]);
        }
        if (stringArray.length == 3 && stringArray[0].equalsIgnoreCase("portal") && stringArray[1].equalsIgnoreCase("delete")) {
            ArrayList<String> names = new ArrayList<String>();
            for (Player online : Bukkit.getOnlinePlayers()) {
                names.add(online.getName());
            }
            return this.filter(names, stringArray[2]);
        }
        return new ArrayList<String>();
    }

    private List<String> filter(List<String> list, String string) {
        String string2 = string.toLowerCase(Locale.ROOT);
        ArrayList<String> arrayList = new ArrayList<String>();
        for (String string3 : list) {
            if (!string3.toLowerCase(Locale.ROOT).startsWith(string2)) continue;
            arrayList.add(string3);
        }
        return arrayList;
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onInteract(PlayerInteractEvent playerInteractEvent) {
        Action action = playerInteractEvent.getAction();
        if (action != Action.RIGHT_CLICK_BLOCK && action != Action.LEFT_CLICK_BLOCK) {
            return;
        }
        Block block = playerInteractEvent.getClickedBlock();
        if (block == null || !(block.getBlockData() instanceof Switch)) {
            return;
        }
        for (Elevator elevator : this.elevators.values()) {
            if (!elevator.isButton(block.getLocation())) continue;
            playerInteractEvent.setCancelled(true);
            if (action == Action.RIGHT_CLICK_BLOCK) {
                this.playClick(block);
                if (this.active) {
                    elevator.pressButton();
                }
            }
            return;
        }
    }

    private void playClick(Block block) {
        Material material = block.getType();
        Sound sound = material == Material.STONE_BUTTON || material == Material.POLISHED_BLACKSTONE_BUTTON ? Sound.BLOCK_STONE_BUTTON_CLICK_ON : Sound.BLOCK_WOODEN_BUTTON_CLICK_ON;
        block.getWorld().playSound(block.getLocation(), sound, SoundCategory.BLOCKS, 0.6f, 1.0f);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent playerJoinEvent) {
        Player player = playerJoinEvent.getPlayer();
        for (Elevator elevator : this.elevators.values()) {
            elevator.playerJoined(player);
        }
    }

    private static Location parseLocation(String string, World world) {
        String[] stringArray = string.trim().split("\\s+");
        if (stringArray.length < 3) {
            throw new IllegalArgumentException("Bad position: " + string);
        }
        return new Location(world, Double.parseDouble(stringArray[0]), Double.parseDouble(stringArray[1]), Double.parseDouble(stringArray[2]));
    }
}

