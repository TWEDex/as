package ru.glai.aperture;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Lightable;
import org.bukkit.block.data.Openable;
import org.bukkit.block.data.Powerable;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;
import ru.glai.aperture.ApertureScience;
import ru.glai.aperture.ElevatorConfig;

public final class Elevator {
    private final ApertureScience plugin;
    private final ElevatorConfig config;
    private final int[] homeBox = new int[6];
    private final int[] stepVec = new int[3];
    private int totalSteps;
    private boolean enabled;
    private State state = State.IDLE;
    private boolean waitHome = true;
    private boolean waitFar = true;
    private int requiredHumans = 1;
    private int waitTicks = 0;
    private int timer;
    private boolean lampsOn;
    private int progress;
    private int moveTicks;
    private BukkitTask ambienceTask;
    private final Set<UUID> soundTargets = new HashSet<UUID>();

    public Elevator(ApertureScience apertureScience, ElevatorConfig elevatorConfig, boolean bl) {
        this.plugin = apertureScience;
        this.config = elevatorConfig;
        this.enabled = bl;
        this.computeGeometry();
    }

    private void computeGeometry() {
        Elevator.normalize(this.config.cabinHomeA, this.config.cabinHomeB, this.homeBox);
        int n = this.config.cabinFarA.getBlockX() - this.config.cabinHomeA.getBlockX();
        int n2 = this.config.cabinFarA.getBlockY() - this.config.cabinHomeA.getBlockY();
        int n3 = this.config.cabinFarA.getBlockZ() - this.config.cabinHomeA.getBlockZ();
        this.stepVec[0] = Integer.signum(n);
        this.stepVec[1] = Integer.signum(n2);
        this.stepVec[2] = Integer.signum(n3);
        this.totalSteps = Math.max(Math.abs(n), Math.max(Math.abs(n2), Math.abs(n3)));
    }

    private static void normalize(Location location, Location location2, int[] nArray) {
        nArray[0] = Math.min(location.getBlockX(), location2.getBlockX());
        nArray[1] = Math.min(location.getBlockY(), location2.getBlockY());
        nArray[2] = Math.min(location.getBlockZ(), location2.getBlockZ());
        nArray[3] = Math.max(location.getBlockX(), location2.getBlockX());
        nArray[4] = Math.max(location.getBlockY(), location2.getBlockY());
        nArray[5] = Math.max(location.getBlockZ(), location2.getBlockZ());
    }

    public String id() {
        return this.config.id;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean bl) {
        this.enabled = bl;
        if (this.state == State.IDLE) {
            this.applyIdleLamps();
        }
    }

    private void applyIdleLamps() {
        this.applyLamps(false);
        if (!this.enabled) {
            for (Location location : this.config.blinkLamps) {
                this.setLamp(location, true);
            }
        }
    }

    public boolean isRunning() {
        return this.state != State.IDLE;
    }

    public boolean isButton(Location location) {
        if (location == null || location.getWorld() == null || this.config.button.getWorld() == null) {
            return false;
        }
        return location.getWorld().getUID().equals(this.config.button.getWorld().getUID()) && location.getBlockX() == this.config.button.getBlockX() && location.getBlockY() == this.config.button.getBlockY() && location.getBlockZ() == this.config.button.getBlockZ();
    }

    public void pressButton() {
        if (!this.enabled || this.state != State.IDLE) {
            return;
        }
        this.waitHome = true;
        this.waitFar = true;
        this.begin();
    }

    public void remoteStart() {
        this.remoteStart(true, true);
    }

    public void remoteStart(boolean bl, boolean bl2) {
        this.remoteStart(bl, bl2, 1, 0);
    }

    public void remoteStart(boolean bl, boolean bl2, int n, int n2) {
        if (this.state != State.IDLE) {
            return;
        }
        this.waitHome = bl;
        this.waitFar = bl2;
        this.requiredHumans = Math.max(1, n);
        this.waitTicks = n2 > 0 ? n2 * 20 : 0;
        this.begin();
    }

    public void emergencyStop() {
        this.stopAmbience();
        this.state = State.IDLE;
        this.timer = 0;
        this.moveTicks = 0;
    }

    public void tick() {
        if (this.config.world() == null) {
            return;
        }
        switch (this.state.ordinal()) {
            case 1: {
                --this.timer;
                if (this.timer % this.config.blinkPeriod == 0) {
                    this.lampsOn = !this.lampsOn;
                    this.applyLamps(this.lampsOn);
                    if (this.lampsOn) {
                        this.playBlinkSound();
                    }
                }
                if (this.timer > 0) break;
                this.lampsOn = true;
                this.applyLamps(true);
                this.setDoors(this.config.shoreDoors, true, Elevator.zero());
                this.setDoors(this.config.cabinDoorsWest, true, Elevator.zero());
                if (this.waitHome) {
                    this.state = State.WAIT_BOARD;
                    this.timer = 0;
                    break;
                }
                this.state = State.HOLD_BOARD;
                this.timer = this.config.boardDelay;
                break;
            }
            case 2: {
                ++this.timer;
                if (this.countPlayersInCabin() < this.requiredHumans && (this.waitTicks <= 0 || this.timer < this.waitTicks)) break;
                this.state = State.HOLD_BOARD;
                this.timer = this.config.boardDelay;
                break;
            }
            case 3: {
                --this.timer;
                if (this.timer > 0) break;
                this.setDoors(this.config.shoreDoors, false, Elevator.zero());
                this.setDoors(this.config.cabinDoorsWest, false, Elevator.zero());
                this.state = State.MOVE_FAR;
                this.moveTicks = 0;
                break;
            }
            case 4: {
                ++this.moveTicks;
                if (this.moveTicks < this.config.movePeriod) break;
                this.moveTicks = 0;
                if (this.progress >= this.totalSteps) {
                    this.stopAmbience();
                    this.playArrivalSound();
                    this.setDoors(this.config.cabinDoorsEast, true, this.currentOffset());
                    this.setDoors(this.config.farShoreDoors, true, Elevator.zero());
                    this.state = State.HOLD_FAR_OPEN;
                    this.timer = this.config.exitDelay;
                    break;
                }
                this.doStep(1);
                break;
            }
            case 5: {
                --this.timer;
                if (this.timer > 0) break;
                if (this.waitFar) {
                    this.state = State.WAIT_EXIT;
                    this.timer = 0;
                    break;
                }
                this.setDoors(this.config.cabinDoorsEast, false, this.currentOffset());
                this.setDoors(this.config.farShoreDoors, false, Elevator.zero());
                this.state = State.HOLD_FAR_CLOSE;
                this.timer = this.config.departDelay;
                break;
            }
            case 6: {
                ++this.timer;
                if (this.timer % this.config.checkPeriod != 0 || this.playerInCabin()) break;
                this.setDoors(this.config.cabinDoorsEast, false, this.currentOffset());
                this.setDoors(this.config.farShoreDoors, false, Elevator.zero());
                this.state = State.HOLD_FAR_CLOSE;
                this.timer = this.config.departDelay;
                break;
            }
            case 7: {
                --this.timer;
                if (this.timer > 0) break;
                this.state = State.MOVE_HOME;
                this.moveTicks = 0;
                break;
            }
            case 8: {
                ++this.moveTicks;
                if (this.moveTicks < this.config.movePeriod) break;
                this.moveTicks = 0;
                if (this.progress <= 0) {
                    this.state = State.RESET;
                    this.timer = 10;
                    break;
                }
                this.doStep(-1);
                break;
            }
            case 9: {
                --this.timer;
                if (this.timer > 0) break;
                this.shutdown();
                break;
            }
        }
    }

    private void begin() {
        if (this.config.world() == null) {
            return;
        }
        this.moveTicks = 0;
        this.lampsOn = true;
        this.applyLamps(true);
        this.playBlinkSound();
        this.startAmbience();
        this.state = State.BLINK;
        this.timer = this.config.blinkDuration;
    }

    private void doStep(int n) {
        int n2;
        int n3;
        int n4;
        World world = this.config.world();
        if (world == null) {
            return;
        }
        int[] nArray = this.currentBox();
        Vector vector = new Vector(this.stepVec[0] * n, this.stepVec[1] * n, this.stepVec[2] * n);
        int n5 = nArray[3] - nArray[0] + 1;
        int n6 = nArray[4] - nArray[1] + 1;
        int n7 = nArray[5] - nArray[2] + 1;
        BlockData[][][] blockDataArray = new BlockData[n5][n6][n7];
        for (int i = 0; i < n5; ++i) {
            for (n4 = 0; n4 < n6; ++n4) {
                for (n3 = 0; n3 < n7; ++n3) {
                    blockDataArray[i][n4][n3] = world.getBlockAt(nArray[0] + i, nArray[1] + n4, nArray[2] + n3).getBlockData();
                }
            }
        }
        List<Entity> list = this.collectEntities(nArray);
        for (n4 = 0; n4 < n5; ++n4) {
            for (n3 = 0; n3 < n6; ++n3) {
                for (n2 = 0; n2 < n7; ++n2) {
                    Block block = world.getBlockAt(nArray[0] + n4, nArray[1] + n3, nArray[2] + n2);
                    if (block.getType() == Material.AIR) continue;
                    block.setType(Material.AIR, false);
                }
            }
        }
        this.progress += n;
        int[] nArray2 = this.currentBox();
        for (n3 = 0; n3 < n5; ++n3) {
            for (n2 = 0; n2 < n6; ++n2) {
                for (int i = 0; i < n7; ++i) {
                    BlockData blockData = blockDataArray[n3][n2][i];
                    if (blockData == null || blockData.getMaterial() == Material.AIR) continue;
                    world.getBlockAt(nArray2[0] + n3, nArray2[1] + n2, nArray2[2] + i).setBlockData(blockData, false);
                }
            }
        }
        this.teleportEntities(list, vector);
        if (this.config.moveSoundEnabled && Math.abs(this.progress) % this.config.moveSoundPeriod == 0) {
            Location location = this.cabinCenter();
            world.playSound(location, this.config.moveSound, SoundCategory.BLOCKS, this.config.moveSoundVolume, this.config.moveSoundPitch);
        }
        if (this.config.smokeEnabled && Math.abs(this.progress) % this.config.smokePeriod == 0) {
            this.spawnSmoke();
        }
    }

    private List<Entity> collectEntities(int[] nArray) {
        World world = this.config.world();
        ArrayList<Entity> arrayList = new ArrayList<Entity>();
        if (world == null) {
            return arrayList;
        }
        BoundingBox boundingBox = new BoundingBox((double)nArray[0], (double)nArray[1], (double)nArray[2], (double)(nArray[3] + 1), (double)(nArray[4] + 1), (double)(nArray[5] + 1));
        for (Entity entity : world.getNearbyEntities(boundingBox)) {
            if (entity.isInsideVehicle() || !entity.getBoundingBox().overlaps(boundingBox)) continue;
            arrayList.add(entity);
        }
        return arrayList;
    }

    private void teleportEntities(List<Entity> list, Vector vector) {
        for (Entity entity : list) {
            if (!entity.isValid() || entity.isDead()) continue;
            Location location = entity.getLocation().add(vector);
            if (entity instanceof Player) {
                entity.teleport(location, PlayerTeleportEvent.TeleportCause.PLUGIN);
                continue;
            }
            entity.teleport(location);
        }
    }

    private boolean playerInCabin() {
        return this.countPlayersInCabin() > 0;
    }

    private int countPlayersInCabin() {
        World world = this.config.world();
        if (world == null) {
            return 0;
        }
        int[] nArray = this.currentBox();
        BoundingBox boundingBox = new BoundingBox((double)nArray[0], (double)nArray[1], (double)nArray[2], (double)(nArray[3] + 1), (double)(nArray[4] + 1), (double)(nArray[5] + 1));
        int n = 0;
        for (Entity entity : world.getNearbyEntities(boundingBox)) {
            if (!(entity instanceof Player) || !entity.getBoundingBox().overlaps(boundingBox)) continue;
            ++n;
        }
        return n;
    }

    private int[] currentBox() {
        Vector vector = this.currentOffset();
        return new int[]{this.homeBox[0] + vector.getBlockX(), this.homeBox[1] + vector.getBlockY(), this.homeBox[2] + vector.getBlockZ(), this.homeBox[3] + vector.getBlockX(), this.homeBox[4] + vector.getBlockY(), this.homeBox[5] + vector.getBlockZ()};
    }

    private Vector currentOffset() {
        return new Vector(this.stepVec[0] * this.progress, this.stepVec[1] * this.progress, this.stepVec[2] * this.progress);
    }

    private static Vector zero() {
        return new Vector(0, 0, 0);
    }

    private Location cabinCenter() {
        World world = this.config.world();
        int[] nArray = this.currentBox();
        return new Location(world, (double)(nArray[0] + nArray[3] + 1) / 2.0, (double)(nArray[1] + nArray[4] + 1) / 2.0, (double)(nArray[2] + nArray[5] + 1) / 2.0);
    }

    private Location cabinTop() {
        World world = this.config.world();
        int[] nArray = this.currentBox();
        return new Location(world, (double)(nArray[0] + nArray[3] + 1) / 2.0, (double)nArray[4] + 1.0, (double)(nArray[2] + nArray[5] + 1) / 2.0);
    }

    private void playBlinkSound() {
        if (!this.config.blinkSoundEnabled) {
            return;
        }
        World world = this.config.world();
        if (world == null) {
            return;
        }
        Location location = this.config.statusLamp != null ? this.config.statusLamp : this.config.button;
        world.playSound(location, this.config.blinkSound, SoundCategory.BLOCKS, this.config.blinkSoundVolume, this.config.blinkSoundPitch);
    }

    private void playArrivalSound() {
        if (!this.config.arrivalSoundEnabled) {
            return;
        }
        World world = this.config.world();
        if (world == null) {
            return;
        }
        world.playSound(this.cabinCenter(), this.config.arrivalSound, SoundCategory.BLOCKS, this.config.arrivalSoundVolume, this.config.arrivalSoundPitch);
    }

    private void spawnSmoke() {
        Particle particle;
        World world = this.config.world();
        if (world == null) {
            return;
        }
        try {
            particle = Particle.valueOf((String)this.config.smokeParticle.trim().toUpperCase(Locale.ROOT));
        }
        catch (IllegalArgumentException illegalArgumentException) {
            particle = Particle.SMOKE;
        }
        Location location = this.cabinTop();
        double d = this.config.smokeSpread;
        world.spawnParticle(particle, location, this.config.smokeCount, d, 0.15, d, this.config.smokeSpeed);
    }

    public void shutdown() {
        this.state = State.IDLE;
        this.timer = 0;
        this.moveTicks = 0;
        this.progress = 0;
        this.lampsOn = false;
        this.applyIdleLamps();
        this.setDoors(this.config.shoreDoors, false, Elevator.zero());
        this.setDoors(this.config.cabinDoorsWest, false, Elevator.zero());
        this.setDoors(this.config.cabinDoorsEast, false, this.currentOffset());
        this.setDoors(this.config.farShoreDoors, false, Elevator.zero());
        this.stopAmbience();
    }

    public void restore() {
        if (this.config.world() == null) {
            return;
        }
        this.progress = 0;
        this.applyIdleLamps();
        this.setDoors(this.config.shoreDoors, false, Elevator.zero());
        this.setDoors(this.config.cabinDoorsWest, false, Elevator.zero());
        this.setDoors(this.config.cabinDoorsEast, false, Elevator.zero());
        this.setDoors(this.config.farShoreDoors, false, Elevator.zero());
    }

    public void stop() {
        this.stopAmbience();
        this.state = State.IDLE;
    }

    public void playerJoined(Player player) {
        if (this.ambienceTask != null) {
            this.playAmbience();
        }
    }

    public String statusLine() {
        String string = this.enabled ? "lift " + this.config.id + ": enabled" : "lift " + this.config.id + ": disabled";
        return string + ", " + this.stateText();
    }

    private String stateText() {
        switch (this.state.ordinal()) {
            case 1: {
                return "state starting, lamps blinking";
            }
            case 2: {
                return "state waiting for passenger";
            }
            case 3: {
                return "state doors closing";
            }
            case 4: {
                return "state moving to far point";
            }
            case 5: {
                return "state far doors opening";
            }
            case 6: {
                return "state waiting for exit";
            }
            case 7: {
                return "state far doors closing";
            }
            case 8: {
                return "state returning";
            }
            case 9: {
                return "state finishing";
            }
        }
        return "state idle";
    }

    private void applyLamps(boolean bl) {
        this.setLamp(this.config.statusLamp, bl);
        for (Location location : this.config.blinkLamps) {
            this.setLamp(location, bl);
        }
    }

    private void setLamp(Location location, boolean bl) {
        World world = this.config.world();
        if (world == null || location == null) {
            return;
        }
        Block block = world.getBlockAt(location.getBlockX(), location.getBlockY(), location.getBlockZ());
        BlockData blockData = block.getBlockData();
        boolean bl2 = false;
        if (blockData instanceof Lightable) {
            Lightable lightable = (Lightable) blockData;
            if (lightable.isLit() != bl) {
                lightable.setLit(bl);
                bl2 = true;
            }
        }
        if (blockData instanceof Powerable) {
            Powerable powerable = (Powerable) blockData;
            if (powerable.isPowered() != bl) {
                powerable.setPowered(bl);
                bl2 = true;
            }
        }
        if (bl2) {
            block.setBlockData(blockData, false);
        }
    }

    private void setDoors(List<Location> list, boolean bl, Vector vector) {
        World world = this.config.world();
        if (world == null) {
            return;
        }
        for (Location location : list) {
            Openable openable;
            Block block;
            BlockData blockData;
            int n;
            int n2;
            int n3 = location.getBlockX() + vector.getBlockX();
            Block block2 = world.getBlockAt(n3, n2 = location.getBlockY() + vector.getBlockY(), n = location.getBlockZ() + vector.getBlockZ());
            BlockData blockData2 = block2.getBlockData();
            if (!(blockData2 instanceof Openable)) continue;
            Openable openable2 = (Openable)blockData2;
            if (openable2.isOpen() != bl) {
                openable2.setOpen(bl);
                block2.setBlockData((BlockData)openable2, false);
                world.playSound(block2.getLocation(), bl ? Sound.BLOCK_IRON_DOOR_OPEN : Sound.BLOCK_IRON_DOOR_CLOSE, SoundCategory.BLOCKS, 1.0f, 1.0f);
            }
            if (!((blockData = (block = world.getBlockAt(n3, n2 + 1, n)).getBlockData()) instanceof Openable) || (openable = (Openable)blockData).isOpen() == bl) continue;
            openable.setOpen(bl);
            block.setBlockData((BlockData)openable, false);
        }
    }

    private void startAmbience() {
        if (this.ambienceTask != null) {
            return;
        }
        this.soundTargets.clear();
        this.playAmbience();
        this.ambienceTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::playAmbience, (long)this.config.ambiencePeriod, (long)this.config.ambiencePeriod);
    }

    private void playAmbience() {
        World world = this.config.world();
        if (world == null || this.config.ambienceLocation == null) {
            return;
        }
        world.playSound(this.config.ambienceLocation, this.config.ambienceSound, Elevator.category(this.config.ambienceCategory), this.config.ambienceVolume, this.config.ambiencePitch);
    }

    private void stopAmbience() {
        if (this.ambienceTask != null) {
            this.ambienceTask.cancel();
            this.ambienceTask = null;
        }
        SoundCategory soundCategory = Elevator.category(this.config.ambienceCategory);
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.stopSound(this.config.ambienceSound, soundCategory);
        }
        this.soundTargets.clear();
    }

    private static SoundCategory category(String string) {
        if (string == null) {
            return SoundCategory.MASTER;
        }
        try {
            return SoundCategory.valueOf((String)string.trim().toUpperCase(Locale.ROOT));
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return SoundCategory.MASTER;
        }
    }

    public static enum State {
        IDLE,
        BLINK,
        WAIT_BOARD,
        HOLD_BOARD,
        MOVE_FAR,
        HOLD_FAR_OPEN,
        WAIT_EXIT,
        HOLD_FAR_CLOSE,
        MOVE_HOME,
        RESET;

    }
}

