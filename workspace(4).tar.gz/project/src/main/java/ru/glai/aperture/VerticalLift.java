package ru.glai.aperture;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.MultipleFacing;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;
import ru.glai.aperture.ApertureScience;
import ru.glai.aperture.ItemStorage;
import ru.glai.aperture.Worlds;

public final class VerticalLift {
    private final ApertureScience plugin;
    private final ItemStorage storage;
    private final String id;
    private final String owner;
    private final String worldName;
    private final int[] topBox = new int[6];
    private final int[] stepVec = new int[3];
    private int totalSteps;
    private final int[] gateBox = new int[6];
    private final List<int[]> gateCellsClose = new ArrayList<int[]>();
    private final List<int[]> gateCellsOpen = new ArrayList<int[]>();
    private final int movePeriod;
    private final int boardCheck;
    private final int boardHold;
    private final int storeTime;
    private final int exitCheck;
    private final int gateCloseDelay;
    private final int upWait;
    private final String storeSound;
    private final float storeVolume;
    private final float storePitch;
    private final String windSound;
    private final SoundCategory windCategory;
    private final float windVolume;
    private final float windPitch;
    private final int windPeriod;
    private final boolean moveSoundEnabled;
    private final String moveSound;
    private final float moveVolume;
    private final float movePitch;
    private final int moveSoundPeriod;
    private final String gateOpenSound;
    private final String gateCloseSound;
    private final float gateVolume;
    private final float gatePitch;
    private final boolean smokeEnabled;
    private final String smokeParticle;
    private final int smokeCount;
    private final int smokeStorePeriod;
    private final int smokeMovePeriod;
    private final double smokeSpread;
    private State state = State.IDLE;
    private int progress;
    private int timer;
    private int moveTicks;
    private int windClock;
    private int smokeClock;
    private boolean gateOpen;
    private boolean skipBoard;
    private int requiredHumans = 1;
    private int waitTicks = 0;
    private boolean gateAnimating;
    private boolean gateAnimOpening;
    private int gateIndex;
    private List<int[]> gateOrder = new ArrayList<int[]>();

    public VerticalLift(ApertureScience apertureScience, ItemStorage itemStorage, String string, FileConfiguration fileConfiguration, String string2, String string3) {
        this.plugin = apertureScience;
        this.storage = itemStorage;
        this.id = string;
        this.owner = string3;
        this.worldName = fileConfiguration.getString(string2 + ".world", "world");
        World world = this.world();
        if (world == null) {
            throw new IllegalArgumentException("World not found: " + this.worldName);
        }
        Location location = VerticalLift.parse(fileConfiguration.getString(string2 + ".cabin-top-a"), world);
        Location location2 = VerticalLift.parse(fileConfiguration.getString(string2 + ".cabin-top-b"), world);
        Location location3 = VerticalLift.parse(fileConfiguration.getString(string2 + ".cabin-bottom-a"), world);
        VerticalLift.normalize(location, location2, this.topBox);
        int n = location3.getBlockY() - location.getBlockY();
        int n2 = location3.getBlockX() - location.getBlockX();
        int n3 = location3.getBlockZ() - location.getBlockZ();
        this.stepVec[0] = Integer.signum(n2);
        this.stepVec[1] = Integer.signum(n);
        this.stepVec[2] = Integer.signum(n3);
        this.totalSteps = Math.max(Math.abs(n2), Math.max(Math.abs(n), Math.abs(n3)));
        Location location4 = VerticalLift.parse(fileConfiguration.getString(string2 + ".gate-a"), world);
        Location location5 = VerticalLift.parse(fileConfiguration.getString(string2 + ".gate-b"), world);
        VerticalLift.normalize(location4, location5, this.gateBox);
        this.buildGateCells();
        this.movePeriod = Math.max(1, fileConfiguration.getInt(string2 + ".move-period", 6));
        this.boardCheck = Math.max(1, fileConfiguration.getInt(string2 + ".board-check", 5));
        this.boardHold = fileConfiguration.getInt(string2 + ".board-hold", 40);
        this.storeTime = fileConfiguration.getInt(string2 + ".store-time", 60);
        this.exitCheck = Math.max(1, fileConfiguration.getInt(string2 + ".exit-check", 5));
        this.gateCloseDelay = fileConfiguration.getInt(string2 + ".gate-close-delay", 10);
        this.upWait = fileConfiguration.getInt(string2 + ".up-wait", 60);
        this.storeSound = fileConfiguration.getString(string2 + ".store-sound.sound", "block.respawn_anchor.charge");
        this.storeVolume = (float)fileConfiguration.getDouble(string2 + ".store-sound.volume", 1.0);
        this.storePitch = (float)fileConfiguration.getDouble(string2 + ".store-sound.pitch", 1.0);
        this.windSound = fileConfiguration.getString(string2 + ".wind-sound.sound", "tropicalberry:ambience.wind");
        this.windCategory = VerticalLift.category(fileConfiguration.getString(string2 + ".wind-sound.category", "master"));
        this.windVolume = (float)Math.min(fileConfiguration.getDouble(string2 + ".wind-sound.volume", 10.0), 3.0);
        this.windPitch = (float)fileConfiguration.getDouble(string2 + ".wind-sound.pitch", 0.1);
        this.windPeriod = Math.max(20, fileConfiguration.getInt(string2 + ".wind-sound.period", 140));
        this.moveSoundEnabled = fileConfiguration.getBoolean(string2 + ".move-sound.enabled", true);
        this.moveSound = fileConfiguration.getString(string2 + ".move-sound.sound", "entity.minecart.riding");
        this.moveVolume = (float)fileConfiguration.getDouble(string2 + ".move-sound.volume", 0.5);
        this.movePitch = (float)fileConfiguration.getDouble(string2 + ".move-sound.pitch", 0.7);
        this.moveSoundPeriod = Math.max(1, fileConfiguration.getInt(string2 + ".move-sound.period", 4));
        this.gateOpenSound = fileConfiguration.getString(string2 + ".gate-sound.open", "block.iron_door.open");
        this.gateCloseSound = fileConfiguration.getString(string2 + ".gate-sound.close", "block.iron_door.close");
        this.gateVolume = (float)fileConfiguration.getDouble(string2 + ".gate-sound.volume", 1.0);
        this.gatePitch = (float)fileConfiguration.getDouble(string2 + ".gate-sound.pitch", 0.8);
        this.smokeEnabled = fileConfiguration.getBoolean(string2 + ".smoke.enabled", true);
        this.smokeParticle = fileConfiguration.getString(string2 + ".smoke.particle", "SMOKE");
        this.smokeCount = Math.max(1, fileConfiguration.getInt(string2 + ".smoke.count", 4));
        this.smokeStorePeriod = Math.max(1, fileConfiguration.getInt(string2 + ".smoke.store-period", 2));
        this.smokeMovePeriod = Math.max(1, fileConfiguration.getInt(string2 + ".smoke.move-period", 2));
        this.smokeSpread = fileConfiguration.getDouble(string2 + ".smoke.spread", 0.5);
        this.gateOpen = false;
        this.loadPosition();
    }

    private void buildGateCells() {
        int n;
        int n2;
        ArrayList<int[]> arrayList;
        ArrayList arrayList2 = new ArrayList();
        for (int i = this.gateBox[0]; i <= this.gateBox[3]; ++i) {
            arrayList = new ArrayList<int[]>();
            for (n2 = this.gateBox[1]; n2 <= this.gateBox[4]; ++n2) {
                n = this.gateBox[2];
                while (n <= this.gateBox[5]) {
                    arrayList.add(new int[]{i, n2, n++});
                }
            }
            arrayList2.add(arrayList);
        }
        ArrayList arrayList3 = new ArrayList();
        arrayList = new ArrayList();
        n2 = arrayList2.size() - 1;
        for (n = 0; n < arrayList2.size(); ++n) {
            if (n == 0 || n == n2) {
                arrayList3.addAll((Collection)arrayList2.get(n));
                continue;
            }
            arrayList.addAll((Collection)arrayList2.get(n));
        }
        this.gateCellsClose.clear();
        this.gateCellsClose.addAll(arrayList3);
        this.gateCellsClose.addAll(arrayList);
        this.gateCellsOpen.clear();
        this.gateCellsOpen.addAll(arrayList);
        this.gateCellsOpen.addAll(arrayList3);
    }

    public String id() {
        return this.id;
    }

    public boolean isBusy() {
        return this.state != State.IDLE;
    }

    public boolean isAtTop() {
        return this.progress <= 0;
    }

    public boolean isAtBottom() {
        return this.progress >= this.totalSteps;
    }

    public World world() {
        return Worlds.resolve(this.worldName);
    }

    public void commandDown() {
        this.commandDown(false);
    }

    public void commandDown(boolean bl) {
        this.commandDown(bl, 1, 0);
    }

    public void commandDown(boolean bl, int n, int n2) {
        if (this.state != State.IDLE || !this.isAtTop()) {
            return;
        }
        this.skipBoard = bl;
        this.requiredHumans = Math.max(1, n);
        this.waitTicks = n2 > 0 ? n2 * 20 : 0;
        this.state = State.WAIT_TOP;
        this.timer = 0;
    }

    public void commandUp() {
        this.commandUp(false);
    }

    public void commandUp(boolean bl) {
        this.commandUp(bl, 1, 0);
    }

    public void commandUp(boolean bl, int n, int n2) {
        if (this.state != State.IDLE || !this.isAtBottom()) {
            return;
        }
        this.skipBoard = bl;
        this.requiredHumans = Math.max(1, n);
        this.waitTicks = n2 > 0 ? n2 * 20 : 0;
        this.openGate();
        this.state = State.WAIT_BOTTOM;
        this.timer = 0;
    }

    public void emergencyStop() {
        this.stopWind();
        this.gateAnimating = false;
        this.state = State.IDLE;
        this.timer = 0;
        this.moveTicks = 0;
        this.savePosition();
    }

    public void resumeUp() {
        if (this.state != State.IDLE || this.progress <= 0) {
            return;
        }
        this.skipBoard = false;
        this.state = State.MOVE_UP;
        this.moveTicks = 0;
        this.windClock = 0;
        this.smokeClock = 0;
        this.playWind();
    }

    public void resumeDown() {
        if (this.state != State.IDLE || this.progress >= this.totalSteps) {
            return;
        }
        this.skipBoard = false;
        this.state = State.MOVE_DOWN;
        this.moveTicks = 0;
        this.windClock = 0;
        this.smokeClock = 0;
        this.playWind();
    }

    public void tick() {
        World world = this.world();
        if (world == null) {
            return;
        }
        this.gateTick();
        switch (this.state.ordinal()) {
            case 1: {
                ++this.timer;
                if (this.skipBoard) {
                    this.state = State.HOLD_TOP;
                    this.timer = this.boardHold;
                    break;
                }
                if (this.playersOnPlatform().size() < this.requiredHumans && (this.waitTicks <= 0 || this.timer < this.waitTicks)) break;
                this.state = State.HOLD_TOP;
                this.timer = this.boardHold;
                break;
            }
            case 2: {
                --this.timer;
                if (this.timer > 0) break;
                this.storeItems();
                this.state = State.STORE;
                this.timer = this.storeTime;
                this.smokeClock = 0;
                break;
            }
            case 3: {
                --this.timer;
                ++this.smokeClock;
                if (this.smokeEnabled && this.smokeClock % this.smokeStorePeriod == 0) {
                    this.spawnSmoke(this.cabinCenter());
                }
                if (this.timer > 0) break;
                this.state = State.MOVE_DOWN;
                this.moveTicks = 0;
                this.windClock = 0;
                this.playWind();
                break;
            }
            case 4: {
                ++this.windClock;
                if (this.windClock % this.windPeriod == 0) {
                    this.playWind();
                }
                ++this.smokeClock;
                if (this.smokeEnabled && this.smokeClock % this.smokeMovePeriod == 0) {
                    this.spawnSmoke(this.cabinTop());
                }
                ++this.moveTicks;
                if (this.moveTicks < this.movePeriod) break;
                this.moveTicks = 0;
                if (this.progress < this.totalSteps) {
                    this.doStep(1);
                }
                if (this.progress < this.totalSteps) break;
                this.stopWind();
                this.arriveBottom();
                break;
            }
            case 5: {
                ++this.timer;
                if (this.timer % this.exitCheck != 0 || !this.playersOnPlatform().isEmpty() || !this.gateZoneClear()) break;
                this.state = State.GATE_CLOSE;
                this.timer = this.gateCloseDelay;
                break;
            }
            case 6: {
                --this.timer;
                if (this.timer > 0) break;
                if (this.gateZoneClear()) {
                    this.closeGate();
                    this.state = State.IDLE;
                    this.savePosition();
                    break;
                }
                this.state = State.WAIT_EXIT;
                this.timer = 0;
                break;
            }
            case 7: {
                ++this.timer;
                if (!this.skipBoard && this.playersOnPlatform().size() < this.requiredHumans && (this.waitTicks <= 0 || this.timer < this.waitTicks) || !this.gateZoneClear()) break;
                this.closeGate();
                this.state = State.GATE_SHUT;
                break;
            }
            case 8: {
                if (!this.gateShut()) break;
                this.state = State.MOVE_UP;
                this.moveTicks = 0;
                this.windClock = 0;
                this.smokeClock = 0;
                this.playWind();
                break;
            }
            case 9: {
                ++this.windClock;
                if (this.windClock % this.windPeriod == 0) {
                    this.playWind();
                }
                ++this.smokeClock;
                if (this.smokeEnabled && this.smokeClock % this.smokeMovePeriod == 0) {
                    this.spawnSmoke(this.cabinTop());
                }
                ++this.moveTicks;
                if (this.moveTicks < this.movePeriod) break;
                this.moveTicks = 0;
                if (this.progress > 0) {
                    this.doStep(-1);
                }
                if (this.progress > 0) break;
                this.stopWind();
                this.state = State.IDLE;
                this.savePosition();
                break;
            }
        }
    }

    private void arriveBottom() {
        this.openGate();
        this.state = State.WAIT_EXIT;
        this.timer = 0;
    }

    private void doStep(int n) {
        int n2;
        int n3;
        int n4;
        World world = this.world();
        if (world == null) {
            return;
        }
        int[] nArray = this.currentBox();
        Vector vector = new Vector(this.stepVec[0] * n, this.stepVec[1] * n, this.stepVec[2] * n);
        int n5 = nArray[3] - nArray[0] + 1;
        int n6 = nArray[4] - nArray[1] + 1;
        int n7 = nArray[5] - nArray[2] + 1;
        BlockData[][][] blockDataArray = new BlockData[n5][n6][n7];
        for (int i = 0; i < n5; ++i) {
            for (n4 = 0; n4 < n6; ++n4) {
                for (n3 = 0; n3 < n7; ++n3) {
                    blockDataArray[i][n4][n3] = world.getBlockAt(nArray[0] + i, nArray[1] + n4, nArray[2] + n3).getBlockData();
                }
            }
        }
        List<Entity> list = this.collectEntities(nArray);
        for (n4 = 0; n4 < n5; ++n4) {
            for (n3 = 0; n3 < n6; ++n3) {
                for (n2 = 0; n2 < n7; ++n2) {
                    Block block = world.getBlockAt(nArray[0] + n4, nArray[1] + n3, nArray[2] + n2);
                    if (block.getType() == Material.AIR) continue;
                    block.setType(Material.AIR, false);
                }
            }
        }
        this.progress += n;
        int[] nArray2 = this.currentBox();
        for (n3 = 0; n3 < n5; ++n3) {
            for (n2 = 0; n2 < n6; ++n2) {
                for (int i = 0; i < n7; ++i) {
                    BlockData blockData = blockDataArray[n3][n2][i];
                    if (blockData == null || blockData.getMaterial() == Material.AIR) continue;
                    world.getBlockAt(nArray2[0] + n3, nArray2[1] + n2, nArray2[2] + i).setBlockData(blockData, false);
                }
            }
        }
        this.teleportEntities(list, vector);
        if (this.moveSoundEnabled && Math.abs(this.progress) % this.moveSoundPeriod == 0) {
            world.playSound(this.cabinCenter(), this.moveSound, SoundCategory.BLOCKS, this.moveVolume, this.movePitch);
        }
    }

    private void storeItems() {
        World world = this.world();
        if (world == null) {
            return;
        }
        for (Player player : this.playersOnPlatform()) {
            if (player.getName().equalsIgnoreCase(this.owner)) continue;
            try {
                PlayerInventory playerInventory = player.getInventory();
                ItemStack[] itemStackArray = (ItemStack[])playerInventory.getContents().clone();
                this.storage.save(player.getUniqueId(), player.getName(), itemStackArray);
                if (!this.storage.has(player.getUniqueId())) continue;
                playerInventory.setStorageContents(new ItemStack[36]);
                playerInventory.setArmorContents(new ItemStack[4]);
                playerInventory.setExtraContents(new ItemStack[1]);
            }
            catch (RuntimeException runtimeException) {
                runtimeException.printStackTrace();
            }
        }
        world.playSound(this.cabinCenter(), this.storeSound, SoundCategory.MASTER, this.storeVolume, this.storePitch);
    }

    private List<Player> playersOnPlatform() {
        ArrayList<Player> arrayList = new ArrayList<Player>();
        World world = this.world();
        if (world == null) {
            return arrayList;
        }
        int[] nArray = this.currentBox();
        for (Entity entity : world.getNearbyEntities(this.riderBox(nArray))) {
            if (!(entity instanceof Player) || !this.inRiderArea(entity, nArray)) continue;
            arrayList.add((Player)entity);
        }
        return arrayList;
    }

    private boolean gateZoneClear() {
        World world = this.world();
        if (world == null) {
            return true;
        }
        BoundingBox boundingBox = this.gateZone();
        for (Entity entity : world.getNearbyEntities(boundingBox)) {
            if (!(entity instanceof Player) || !entity.getBoundingBox().overlaps(boundingBox)) continue;
            return false;
        }
        return true;
    }

    private BoundingBox gateZone() {
        return new BoundingBox((double)this.gateBox[0] - 0.5, (double)this.gateBox[1] - 0.5, (double)this.gateBox[2] - 1.0, (double)this.gateBox[3] + 1.5, (double)this.gateBox[4] + 1.5, (double)this.gateBox[5] + 0.5);
    }

    private void gateTick() {
        if (!this.gateAnimating) {
            return;
        }
        World world = this.world();
        if (world == null) {
            this.gateAnimating = false;
            return;
        }
        if (!this.gateAnimOpening && !this.gateZoneClear()) {
            this.gateOrder = this.gateCellsOpen;
            this.gateIndex = 0;
            this.gateAnimOpening = true;
            if (this.state == State.IDLE || this.state == State.GATE_CLOSE) {
                this.state = State.WAIT_EXIT;
                this.timer = 0;
            }
            world.playSound(this.gateCenter(), this.gateOpenSound, SoundCategory.BLOCKS, this.gateVolume, this.gatePitch);
            return;
        }
        if (this.gateIndex >= this.gateOrder.size()) {
            this.gateAnimating = false;
            this.gateOpen = this.gateAnimOpening;
            return;
        }
        int[] nArray = this.gateOrder.get(this.gateIndex);
        Block block = world.getBlockAt(nArray[0], nArray[1], nArray[2]);
        if (this.gateAnimOpening) {
            if (block.getType() != Material.AIR) {
                block.setType(Material.AIR, false);
            }
        } else {
            this.placeBars(world, nArray[0], nArray[1], nArray[2]);
        }
        ++this.gateIndex;
    }

    private void placeBars(World world, int n, int n2, int n3) {
        Block block = world.getBlockAt(n, n2, n3);
        if (block.getType() != Material.IRON_BARS) {
            block.setType(Material.IRON_BARS, false);
        }
        this.refreshBars(world, n, n2, n3);
        this.refreshBars(world, n + 1, n2, n3);
        this.refreshBars(world, n - 1, n2, n3);
        this.refreshBars(world, n, n2, n3 + 1);
        this.refreshBars(world, n, n2, n3 - 1);
    }

    private void refreshBars(World world, int n, int n2, int n3) {
        Block block = world.getBlockAt(n, n2, n3);
        if (block.getType() != Material.IRON_BARS) {
            return;
        }
        BlockData blockData = block.getBlockData();
        if (!(blockData instanceof MultipleFacing)) {
            return;
        }
        MultipleFacing multipleFacing = (MultipleFacing)blockData;
        for (BlockFace blockFace : multipleFacing.getAllowedFaces()) {
            Block block2 = block.getRelative(blockFace);
            Material material = block2.getType();
            boolean bl = material == Material.IRON_BARS || material.isSolid();
            multipleFacing.setFace(blockFace, bl);
        }
        block.setBlockData((BlockData)multipleFacing, false);
    }

    private void openGate() {
        World world = this.world();
        if (world == null) {
            return;
        }
        this.gateOrder = this.gateCellsOpen;
        this.gateIndex = 0;
        this.gateAnimating = true;
        this.gateAnimOpening = true;
        world.playSound(this.gateCenter(), this.gateOpenSound, SoundCategory.BLOCKS, this.gateVolume, this.gatePitch);
    }

    private void closeGate() {
        World world = this.world();
        if (world == null) {
            return;
        }
        this.gateOrder = this.gateCellsClose;
        this.gateIndex = 0;
        this.gateAnimating = true;
        this.gateAnimOpening = false;
        world.playSound(this.gateCenter(), this.gateCloseSound, SoundCategory.BLOCKS, this.gateVolume, this.gatePitch);
    }

    private boolean gateShut() {
        return !this.gateAnimating && !this.gateOpen;
    }

    private List<Entity> collectEntities(int[] nArray) {
        ArrayList<Entity> arrayList = new ArrayList<Entity>();
        World world = this.world();
        if (world == null) {
            return arrayList;
        }
        for (Entity entity : world.getNearbyEntities(this.riderBox(nArray))) {
            if (entity.isInsideVehicle() || !this.inRiderArea(entity, nArray)) continue;
            arrayList.add(entity);
        }
        return arrayList;
    }

    private void teleportEntities(List<Entity> list, Vector vector) {
        for (Entity entity : list) {
            if (!entity.isValid() || entity.isDead()) continue;
            entity.teleport(entity.getLocation().add(vector));
            entity.setFallDistance(0.0f);
        }
    }

    private boolean inRiderArea(Entity entity, int[] nArray) {
        Location location = entity.getLocation();
        double d = location.getX();
        double d2 = location.getY();
        double d3 = location.getZ();
        return d >= (double)nArray[0] && d <= (double)(nArray[3] + 1) && d3 >= (double)nArray[2] && d3 <= (double)(nArray[5] + 1) && d2 >= (double)nArray[4] + 0.4 && d2 <= (double)nArray[4] + 3.0;
    }

    private void playWind() {
        World world = this.world();
        if (world == null) {
            return;
        }
        world.playSound(this.cabinCenter(), this.windSound, this.windCategory, this.windVolume, this.windPitch);
    }

    private void stopWind() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.stopSound(this.windSound, this.windCategory);
        }
    }

    private void spawnSmoke(Location location) {
        Particle particle;
        World world = this.world();
        if (world == null) {
            return;
        }
        try {
            particle = Particle.valueOf((String)this.smokeParticle.trim().toUpperCase(Locale.ROOT));
        }
        catch (IllegalArgumentException illegalArgumentException) {
            particle = Particle.SMOKE;
        }
        double d = this.smokeSpread;
        world.spawnParticle(particle, location, this.smokeCount, d, d, d, 0.01);
    }

    private int[] currentBox() {
        return new int[]{this.topBox[0] + this.stepVec[0] * this.progress, this.topBox[1] + this.stepVec[1] * this.progress, this.topBox[2] + this.stepVec[2] * this.progress, this.topBox[3] + this.stepVec[0] * this.progress, this.topBox[4] + this.stepVec[1] * this.progress, this.topBox[5] + this.stepVec[2] * this.progress};
    }

    private BoundingBox riderBox(int[] nArray) {
        return new BoundingBox((double)nArray[0], (double)nArray[1], (double)nArray[2], (double)(nArray[3] + 1), (double)(nArray[4] + 3), (double)(nArray[5] + 1));
    }

    private Location cabinCenter() {
        int[] nArray = this.currentBox();
        return new Location(this.world(), (double)(nArray[0] + nArray[3] + 1) / 2.0, (double)nArray[4] + 1.0, (double)(nArray[2] + nArray[5] + 1) / 2.0);
    }

    private Location cabinTop() {
        int[] nArray = this.currentBox();
        return new Location(this.world(), (double)(nArray[0] + nArray[3] + 1) / 2.0, (double)nArray[4] + 1.0, (double)(nArray[2] + nArray[5] + 1) / 2.0);
    }

    private Location gateCenter() {
        return new Location(this.world(), (double)(this.gateBox[0] + this.gateBox[3] + 1) / 2.0, (double)(this.gateBox[1] + this.gateBox[4] + 1) / 2.0, (double)(this.gateBox[2] + this.gateBox[5] + 1) / 2.0);
    }

    public void restore() {
        World world = this.world();
        if (world == null) {
            return;
        }
        this.state = State.IDLE;
        this.gateAnimating = false;
        for (int[] nArray : this.gateCellsClose) {
            this.placeBars(world, nArray[0], nArray[1], nArray[2]);
        }
        this.gateOpen = false;
    }

    public void stop() {
        this.stopWind();
        this.state = State.IDLE;
        this.savePosition();
    }

    private void loadPosition() {
        File file = new File(this.plugin.getDataFolder(), "liftstate.yml");
        if (file.exists()) {
            YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration((File)file);
            this.progress = yamlConfiguration.getInt("lifts." + this.id + ".progress", 0);
        }
        if (this.progress < 0) {
            this.progress = 0;
        }
        if (this.progress > this.totalSteps) {
            this.progress = this.totalSteps;
        }
    }

    private void savePosition() {
        File file = new File(this.plugin.getDataFolder(), "liftstate.yml");
        YamlConfiguration yamlConfiguration = file.exists() ? YamlConfiguration.loadConfiguration((File)file) : new YamlConfiguration();
        yamlConfiguration.set("lifts." + this.id + ".progress", (Object)this.progress);
        try {
            yamlConfiguration.save(file);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    public String statusLine() {
        String string = this.isAtTop() ? "top" : (this.isAtBottom() ? "bottom" : "moving");
        return "lift " + this.id + ": " + string + ", " + this.state.name().toLowerCase(Locale.ROOT);
    }

    private static void normalize(Location location, Location location2, int[] nArray) {
        nArray[0] = Math.min(location.getBlockX(), location2.getBlockX());
        nArray[1] = Math.min(location.getBlockY(), location2.getBlockY());
        nArray[2] = Math.min(location.getBlockZ(), location2.getBlockZ());
        nArray[3] = Math.max(location.getBlockX(), location2.getBlockX());
        nArray[4] = Math.max(location.getBlockY(), location2.getBlockY());
        nArray[5] = Math.max(location.getBlockZ(), location2.getBlockZ());
    }

    private static Location parse(String string, World world) {
        if (string == null || string.trim().isEmpty()) {
            throw new IllegalArgumentException("Missing position");
        }
        String[] stringArray = string.trim().split("\\s+");
        if (stringArray.length < 3) {
            throw new IllegalArgumentException("Bad position: " + string);
        }
        return new Location(world, Double.parseDouble(stringArray[0]), Double.parseDouble(stringArray[1]), Double.parseDouble(stringArray[2]));
    }

    private static SoundCategory category(String string) {
        if (string == null) {
            return SoundCategory.MASTER;
        }
        try {
            return SoundCategory.valueOf((String)string.trim().toUpperCase(Locale.ROOT));
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return SoundCategory.MASTER;
        }
    }

    public static enum State {
        IDLE,
        WAIT_TOP,
        HOLD_TOP,
        STORE,
        MOVE_DOWN,
        WAIT_EXIT,
        GATE_CLOSE,
        WAIT_BOTTOM,
        GATE_SHUT,
        MOVE_UP;

    }
}

