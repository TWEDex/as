package ru.glai.aperture;

import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import ru.glai.aperture.ButtonManager;
import ru.glai.aperture.CodeDevice;
import ru.glai.aperture.DetectorData;
import ru.glai.aperture.WirelessButton;

public final class WrenchMenu
implements InventoryHolder {
    private final ButtonManager manager;
    private final NamespacedKey virtualKey;
    private final WirelessButton button;
    private final DetectorData detector;
    private final CodeDevice device;
    private final Inventory inventory;
    private final int[] codeSlots;
    private final int modeSlot;
    private final int holdSlot;
    private final int leverSlot;
    private final int doneSlot;

    public WrenchMenu(ButtonManager buttonManager, CodeDevice codeDevice) {
        this.manager = buttonManager;
        this.virtualKey = new NamespacedKey((Plugin)buttonManager.plugin(), "aperture_virtual");
        this.button = null;
        this.detector = null;
        this.device = codeDevice;
        this.inventory = Bukkit.createInventory((InventoryHolder)this, (int)27, (Component)WrenchMenu.plain("\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u0430"));
        this.codeSlots = new int[]{10, 11, 12, 13, 14, 15};
        this.modeSlot = -1;
        this.holdSlot = -1;
        this.leverSlot = -1;
        this.doneSlot = 22;
        this.fill();
    }

    public WrenchMenu(ButtonManager buttonManager, WirelessButton wirelessButton, DetectorData detectorData) {
        boolean bl;
        this.manager = buttonManager;
        this.virtualKey = new NamespacedKey((Plugin)buttonManager.plugin(), "aperture_virtual");
        this.button = wirelessButton;
        this.detector = detectorData;
        this.device = null;
        boolean bl2 = bl = wirelessButton != null;
        if (bl) {
            this.inventory = Bukkit.createInventory((InventoryHolder)this, (int)45, (Component)WrenchMenu.plain("\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u043a\u043d\u043e\u043f\u043a\u0438 " + wirelessButton.number));
            this.codeSlots = new int[]{9, 10, 11, 12, 13, 14};
            this.modeSlot = 20;
            this.holdSlot = 22;
            this.leverSlot = 24;
            this.doneSlot = 40;
        } else {
            this.inventory = Bukkit.createInventory((InventoryHolder)this, (int)27, (Component)WrenchMenu.plain("\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u0434\u0435\u0442\u0435\u043a\u0442\u043e\u0440\u0430"));
            this.codeSlots = new int[]{10, 11, 12, 13, 14, 15};
            this.modeSlot = -1;
            this.holdSlot = -1;
            this.leverSlot = -1;
            this.doneSlot = 22;
        }
        this.fill();
    }

    private static Component plain(String string) {
        return Component.text((String)string).decoration(TextDecoration.ITALIC, false);
    }

    private void fill() {
        ItemStack itemStack = this.pane(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < this.inventory.getSize(); ++i) {
            this.inventory.setItem(i, itemStack);
        }
        List<Material> codeList = this.button != null ? this.button.code : (this.detector != null ? this.detector.code : (this.device != null ? this.device.code : new ArrayList<Material>()));
        for (int i = 0; i < this.codeSlots.length; ++i) {
            Material material;
            Material material2 = material = i < codeList.size() ? codeList.get(i) : null;
            if (material != null && material.isBlock()) {
                this.inventory.setItem(this.codeSlots[i], this.virtualItem(material));
                continue;
            }
            this.inventory.setItem(this.codeSlots[i], null);
        }
        if (this.button != null) {
            this.inventory.setItem(this.modeSlot, this.modeItem());
            this.inventory.setItem(this.holdSlot, this.holdItem());
            this.inventory.setItem(this.leverSlot, this.leverItem());
        }
        this.inventory.setItem(this.doneSlot, this.doneItem());
    }

    private ItemStack virtualItem(Material material) {
        ItemStack itemStack = new ItemStack(material);
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta != null) {
            itemMeta.getPersistentDataContainer().set(this.virtualKey, PersistentDataType.BYTE, (byte)1);
            itemStack.setItemMeta(itemMeta);
        }
        return itemStack;
    }

    private boolean isVirtual(ItemStack itemStack) {
        if (itemStack == null || !itemStack.hasItemMeta()) {
            return false;
        }
        ItemMeta itemMeta = itemStack.getItemMeta();
        return itemMeta != null && itemMeta.getPersistentDataContainer().has(this.virtualKey, PersistentDataType.BYTE);
    }

    private ItemStack pane(Material material, String string) {
        ItemStack itemStack = new ItemStack(material);
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta != null) {
            itemMeta.displayName(Component.text((String)string, (TextColor)NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
            itemStack.setItemMeta(itemMeta);
        }
        return itemStack;
    }

    private ItemStack modeItem() {
        Material material = this.button.modeLever ? Material.LEVER : Material.STONE_BUTTON;
        String string = this.button.modeLever ? "\u0440\u044b\u0447\u0430\u0433" : "\u043a\u043d\u043e\u043f\u043a\u0430";
        return this.named(material, "\u0420\u0435\u0436\u0438\u043c: " + string, "\u041b\u041a\u041c \u0447\u0442\u043e\u0431\u044b \u0441\u043c\u0435\u043d\u0438\u0442\u044c");
    }

    private ItemStack holdItem() {
        return this.named(Material.CLOCK, "\u0423\u0434\u0435\u0440\u0436\u0430\u043d\u0438\u0435: " + this.button.holdSeconds + " \u0441\u0435\u043a", "\u041b\u041a\u041c +1, \u041f\u041a\u041c -1 (1-15)");
    }

    private ItemStack leverItem() {
        Material material = this.button.leverOffNoWrench ? Material.LIME_DYE : Material.RED_DYE;
        String string = this.button.leverOffNoWrench ? "\u0434\u0430" : "\u043d\u0435\u0442";
        return this.named(material, "\u0412\u044b\u043a\u043b. \u0440\u044b\u0447\u0430\u0433 \u0431\u0435\u0437 \u043a\u043b\u044e\u0447\u0430: " + string, "\u041b\u041a\u041c \u0447\u0442\u043e\u0431\u044b \u0441\u043c\u0435\u043d\u0438\u0442\u044c");
    }

    private ItemStack doneItem() {
        return this.named(Material.LIME_STAINED_GLASS_PANE, "\u0413\u043e\u0442\u043e\u0432\u043e", "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u0438 \u0437\u0430\u043a\u0440\u044b\u0442\u044c");
    }

    private ItemStack named(Material material, String string, String string2) {
        ItemStack itemStack = new ItemStack(material);
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta != null) {
            itemMeta.displayName(Component.text((String)string, (TextColor)NamedTextColor.WHITE).decoration(TextDecoration.ITALIC, false));
            ArrayList<Component> arrayList = new ArrayList<Component>();
            arrayList.add(Component.text((String)string2, (TextColor)NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
            itemMeta.lore(arrayList);
            itemStack.setItemMeta(itemMeta);
        }
        return itemStack;
    }

    public Inventory getInventory() {
        return this.inventory;
    }

    private boolean isCodeSlot(int n) {
        for (int n2 : this.codeSlots) {
            if (n2 != n) continue;
            return true;
        }
        return false;
    }

    public void handleClick(InventoryClickEvent inventoryClickEvent, Player player) {
        int n = inventoryClickEvent.getRawSlot();
        if (n < 0) {
            return;
        }
        if (n >= this.inventory.getSize()) {
            if (inventoryClickEvent.isShiftClick()) {
                inventoryClickEvent.setCancelled(true);
            }
            return;
        }
        if (this.isCodeSlot(n)) {
            return;
        }
        inventoryClickEvent.setCancelled(true);
        if (n == this.doneSlot) {
            this.saveCode();
            player.closeInventory();
            return;
        }
        if (this.button == null) {
            return;
        }
        if (n == this.modeSlot) {
            this.button.modeLever = !this.button.modeLever;
            this.inventory.setItem(this.modeSlot, this.modeItem());
            this.manager.save();
            return;
        }
        if (n == this.holdSlot) {
            int n2 = inventoryClickEvent.isRightClick() ? -1 : 1;
            this.button.holdSeconds = Math.max(1, Math.min(15, this.button.holdSeconds + n2));
            this.inventory.setItem(this.holdSlot, this.holdItem());
            this.manager.save();
            return;
        }
        if (n == this.leverSlot) {
            this.button.leverOffNoWrench = !this.button.leverOffNoWrench;
            this.inventory.setItem(this.leverSlot, this.leverItem());
            this.manager.save();
        }
    }

    public void handleClose(Player player) {
        this.saveCode();
        ArrayList<ItemStack> arrayList = new ArrayList<ItemStack>();
        for (int n : this.codeSlots) {
            ItemStack itemStack = this.inventory.getItem(n);
            if (itemStack == null || itemStack.getType() == Material.AIR || this.isVirtual(itemStack)) continue;
            arrayList.add(itemStack.clone());
        }
        for (int i = 0; i < this.inventory.getSize(); ++i) {
            this.inventory.setItem(i, null);
        }
        for (ItemStack itemStack : arrayList) {
            if (player.getInventory().firstEmpty() >= 0) {
                player.getInventory().addItem(new ItemStack[]{itemStack});
                continue;
            }
            player.getWorld().dropItemNaturally(player.getLocation(), itemStack);
        }
        this.manager.save();
    }

    private void saveCode() {
        ArrayList<Material> arrayList = new ArrayList<Material>();
        for (int n : this.codeSlots) {
            ItemStack itemStack = this.inventory.getItem(n);
            if (itemStack == null || itemStack.getType() == Material.AIR || !itemStack.getType().isBlock()) continue;
            arrayList.add(itemStack.getType());
        }
        if (this.button != null) {
            this.button.code.clear();
            this.button.code.addAll(arrayList);
        } else if (this.detector != null) {
            this.detector.code.clear();
            this.detector.code.addAll(arrayList);
        } else if (this.device != null) {
            this.device.code.clear();
            this.device.code.addAll(arrayList);
        }
    }
}

