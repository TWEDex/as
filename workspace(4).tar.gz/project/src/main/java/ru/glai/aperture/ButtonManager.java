package ru.glai.aperture;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.Dispenser;
import org.bukkit.block.Dropper;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.Lightable;
import org.bukkit.block.data.Powerable;
import org.bukkit.block.data.type.NoteBlock;
import org.bukkit.block.data.type.Piston;
import org.bukkit.block.data.type.Switch;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import ru.glai.aperture.CodeDevice;
import ru.glai.aperture.DetectorData;
import ru.glai.aperture.Items;
import ru.glai.aperture.WirelessButton;
import ru.glai.aperture.Worlds;

public final class ButtonManager {
    private final JavaPlugin plugin;
    private final Items items;
    private final Map<Integer, WirelessButton> buttons = new LinkedHashMap<Integer, WirelessButton>();
    private final List<DetectorData> detectors = new ArrayList<DetectorData>();
    private final List<CodeDevice> devices = new ArrayList<CodeDevice>();
    private static final Set<Material> DEVICE_MATERIALS = EnumSet.of(Material.REDSTONE_LAMP, new Material[]{Material.REDSTONE_TORCH, Material.REDSTONE_WALL_TORCH, Material.COPPER_BULB, Material.EXPOSED_COPPER_BULB, Material.WEATHERED_COPPER_BULB, Material.OXIDIZED_COPPER_BULB, Material.WAXED_COPPER_BULB, Material.WAXED_EXPOSED_COPPER_BULB, Material.WAXED_WEATHERED_COPPER_BULB, Material.WAXED_OXIDIZED_COPPER_BULB, Material.PISTON, Material.STICKY_PISTON, Material.DISPENSER, Material.DROPPER, Material.NOTE_BLOCK});
    private String pressSound = "block.wooden_button.click_on";
    private String tickSound = "block.note_block.hat";
    private float soundVolume = 0.8f;
    private float soundPitch = 1.0f;
    private long clock;

    public static boolean isDeviceBlock(Material material) {
        return DEVICE_MATERIALS.contains(material);
    }

    public ButtonManager(JavaPlugin javaPlugin, Items items) {
        this.plugin = javaPlugin;
        this.items = items;
        this.readSettings();
    }

    private void readSettings() {
        this.pressSound = this.plugin.getConfig().getString("wireless.press-sound", this.pressSound);
        this.tickSound = this.plugin.getConfig().getString("wireless.tick-sound", this.tickSound);
        this.soundVolume = (float)this.plugin.getConfig().getDouble("wireless.sound-volume", (double)this.soundVolume);
        this.soundPitch = (float)this.plugin.getConfig().getDouble("wireless.sound-pitch", (double)this.soundPitch);
    }

    public void load() {
        String string;
        this.buttons.clear();
        this.detectors.clear();
        this.devices.clear();
        File file = new File(this.plugin.getDataFolder(), "buttons.yml");
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration((File)file);
        ConfigurationSection configurationSection = yamlConfiguration.getConfigurationSection("buttons");
        if (configurationSection != null) {
            for (Object object : configurationSection.getKeys(false)) {
                int n;
                try {
                    n = Integer.parseInt((String)object);
                }
                catch (NumberFormatException numberFormatException) {
                    continue;
                }
                string = configurationSection.getString((String)object + ".world", "world");
                int n2 = configurationSection.getInt((String)object + ".x");
                int n3 = configurationSection.getInt((String)object + ".y");
                int n4 = configurationSection.getInt((String)object + ".z");
                float f = (float)configurationSection.getDouble((String)object + ".yaw", 0.0);
                Object object2 = new WirelessButton(n, configurationSection.getString((String)object + ".name", "button " + n), new Location(Worlds.resolve(string), (double)n2, (double)n3, (double)n4), f);
                ((WirelessButton)object2).world = string;
                ((WirelessButton)object2).setCodeNames(configurationSection.getStringList((String)object + ".code"));
                ((WirelessButton)object2).modeLever = configurationSection.getBoolean((String)object + ".mode-lever", false);
                ((WirelessButton)object2).leverOffNoWrench = configurationSection.getBoolean((String)object + ".lever-off-no-wrench", false);
                ((WirelessButton)object2).holdSeconds = configurationSection.getInt((String)object + ".hold-seconds", 1);
                ((WirelessButton)object2).enabled = configurationSection.getBoolean((String)object + ".enabled", true);
                this.buttons.put(n, (WirelessButton)object2);
            }
        }
        for (Map<?, ?> object : yamlConfiguration.getMapList("detectors")) {
            Object v = object.get("world");
            if (v == null) continue;
            Location detectorLoc = new Location(Worlds.resolve(v.toString()), (double)ButtonManager.toInt(object.get("x")), (double)ButtonManager.toInt(object.get("y")), (double)ButtonManager.toInt(object.get("z")));
            DetectorData detectorData = new DetectorData(detectorLoc);
            detectorData.world = v.toString();
            ArrayList<String> arrayList = new ArrayList<String>();
            Object v2 = object.get("code");
            if (v2 instanceof List) {
                for (Object object2 : (List)v2) {
                    arrayList.add(String.valueOf(object2));
                }
            }
            detectorData.setCodeNames(arrayList);
            this.detectors.add(detectorData);
        }
        for (Map<?, ?> object : yamlConfiguration.getMapList("devices")) {
            Object v = object.get("world");
            if (v == null) continue;
            Location deviceLoc = new Location(Worlds.resolve(v.toString()), (double)ButtonManager.toInt(object.get("x")), (double)ButtonManager.toInt(object.get("y")), (double)ButtonManager.toInt(object.get("z")));
            Material material = Material.matchMaterial(String.valueOf(object.get("type")));
            CodeDevice codeDevice = new CodeDevice(deviceLoc, material == null ? Material.REDSTONE_LAMP : material);
            codeDevice.world = v.toString();
            ArrayList<String> arrayList = new ArrayList<String>();
            Object v3 = object.get("code");
            if (v3 instanceof List) {
                for (Object e : (List)v3) {
                    arrayList.add(String.valueOf(e));
                }
            }
            codeDevice.setCodeNames(arrayList);
            this.devices.add(codeDevice);
        }
        this.resetDetectorBlocks();
    }

    private void resetDetectorBlocks() {
        for (DetectorData detectorData : this.detectors) {
            Block block;
            World world = Worlds.resolve(detectorData.world);
            if (world == null || (block = world.getBlockAt(detectorData.x, detectorData.y, detectorData.z)).getType() != Material.REDSTONE_BLOCK) continue;
            block.setType(Material.DAYLIGHT_DETECTOR, false);
        }
    }

    private static int toInt(Object object) {
        if (object instanceof Number) {
            return ((Number)object).intValue();
        }
        try {
            return Integer.parseInt(String.valueOf(object));
        }
        catch (NumberFormatException numberFormatException) {
            return 0;
        }
    }

    public void save() {
        File file = new File(this.plugin.getDataFolder(), "buttons.yml");
        YamlConfiguration yamlConfiguration = new YamlConfiguration();
        for (WirelessButton arrayList2 : this.buttons.values()) {
            String string = "buttons." + arrayList2.number + ".";
            yamlConfiguration.set(string + "name", (Object)arrayList2.name);
            yamlConfiguration.set(string + "world", (Object)arrayList2.world);
            yamlConfiguration.set(string + "x", (Object)arrayList2.x);
            yamlConfiguration.set(string + "y", (Object)arrayList2.y);
            yamlConfiguration.set(string + "z", (Object)arrayList2.z);
            yamlConfiguration.set(string + "yaw", (Object)Float.valueOf(arrayList2.yaw));
            yamlConfiguration.set(string + "code", arrayList2.codeNames());
            yamlConfiguration.set(string + "mode-lever", (Object)arrayList2.modeLever);
            yamlConfiguration.set(string + "lever-off-no-wrench", (Object)arrayList2.leverOffNoWrench);
            yamlConfiguration.set(string + "hold-seconds", (Object)arrayList2.holdSeconds);
            yamlConfiguration.set(string + "enabled", (Object)arrayList2.enabled);
        }
        ArrayList arrayList3 = new ArrayList();
        for (DetectorData detectorData : this.detectors) {
            HashMap<String, Object> hashMap = new HashMap<String, Object>();
            hashMap.put("world", detectorData.world);
            hashMap.put("x", detectorData.x);
            hashMap.put("y", detectorData.y);
            hashMap.put("z", detectorData.z);
            hashMap.put("code", detectorData.codeNames());
            arrayList3.add(hashMap);
        }
        yamlConfiguration.set("detectors", (Object)arrayList3);
        ArrayList arrayList = new ArrayList();
        for (CodeDevice codeDevice : this.devices) {
            HashMap<String, Object> hashMap = new HashMap<String, Object>();
            hashMap.put("world", codeDevice.world);
            hashMap.put("x", codeDevice.x);
            hashMap.put("y", codeDevice.y);
            hashMap.put("z", codeDevice.z);
            hashMap.put("type", codeDevice.type == null ? "REDSTONE_LAMP" : codeDevice.type.name());
            hashMap.put("code", codeDevice.codeNames());
            arrayList.add(hashMap);
        }
        yamlConfiguration.set("devices", arrayList);
        try {
            yamlConfiguration.save(file);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    public void shutdown() {
        for (DetectorData detectorData : this.detectors) {
            this.setPower(detectorData, false);
        }
        this.save();
    }

    public int lowestFreeNumber() {
        TreeSet<Integer> treeSet = new TreeSet<Integer>(this.buttons.keySet());
        int n = 1;
        while (treeSet.contains(n)) {
            ++n;
        }
        return n;
    }

    public WirelessButton button(int n) {
        return this.buttons.get(n);
    }

    public Map<Integer, WirelessButton> buttons() {
        return this.buttons;
    }

    public WirelessButton placeButton(Player player, Block block) {
        World world = block.getWorld();
        return this.createButton(this.lowestFreeNumber(), "button " + this.lowestFreeNumber(), world, block.getX(), block.getY(), block.getZ(), player.getLocation().getYaw());
    }

    public WirelessButton createButton(int n, String string, World world, int n2, int n3, int n4, float f) {
        if (this.buttons.containsKey(n) || world == null) {
            return null;
        }
        world.getBlockAt(n2, n3, n4).setType(Material.DIORITE_WALL);
        world.getBlockAt(n2, n3 + 1, n4).setBlockData(this.crimsonData(f, false), false);
        WirelessButton wirelessButton = new WirelessButton(n, string, new Location(world, (double)n2, (double)n3, (double)n4), f);
        this.buttons.put(n, wirelessButton);
        this.save();
        return wirelessButton;
    }

    public boolean deleteButton(int n) {
        WirelessButton wirelessButton = this.buttons.remove(n);
        if (wirelessButton == null) {
            return false;
        }
        World world = Worlds.resolve(wirelessButton.world);
        if (world != null) {
            Block block;
            Block block2 = world.getBlockAt(wirelessButton.x, wirelessButton.y + 1, wirelessButton.z);
            if (block2.getType() == Material.CRIMSON_BUTTON) {
                block2.setType(Material.AIR, false);
            }
            if ((block = world.getBlockAt(wirelessButton.x, wirelessButton.y, wirelessButton.z)).getType() == Material.DIORITE_WALL) {
                block.setType(Material.AIR, false);
            }
        }
        this.save();
        return true;
    }

    private BlockData crimsonData(float f, boolean bl) {
        BlockData blockData = Material.CRIMSON_BUTTON.createBlockData();
        if (blockData instanceof Switch) {
            ((Switch)blockData).setFace(Switch.Face.FLOOR);
        }
        if (blockData instanceof Directional) {
            Directional directional = (Directional)blockData;
            BlockFace blockFace = ButtonManager.yawToFace(f);
            if (directional.getFaces().contains(blockFace)) {
                directional.setFacing(blockFace);
            }
        }
        if (blockData instanceof Powerable) {
            ((Powerable)blockData).setPowered(bl);
        }
        return blockData;
    }

    private static BlockFace yawToFace(float f) {
        float f2 = (f % 360.0f + 360.0f) % 360.0f;
        if (f2 >= 315.0f || f2 < 45.0f) {
            return BlockFace.SOUTH;
        }
        if (f2 < 135.0f) {
            return BlockFace.WEST;
        }
        if (f2 < 225.0f) {
            return BlockFace.NORTH;
        }
        return BlockFace.EAST;
    }

    private void setCrimsonPowered(WirelessButton wirelessButton, boolean bl) {
        Powerable powerable;
        World world = Worlds.resolve(wirelessButton.world);
        if (world == null) {
            return;
        }
        Block block = world.getBlockAt(wirelessButton.x, wirelessButton.y + 1, wirelessButton.z);
        if (block.getType() != Material.CRIMSON_BUTTON) {
            return;
        }
        BlockData blockData = block.getBlockData();
        if (blockData instanceof Powerable && (powerable = (Powerable)blockData).isPowered() != bl) {
            powerable.setPowered(bl);
            block.setBlockData(blockData, false);
        }
    }

    public WirelessButton buttonByBlock(Location location) {
        if (location == null || location.getWorld() == null) {
            return null;
        }
        String string = location.getWorld().getName();
        int n = location.getBlockX();
        int n2 = location.getBlockY();
        int n3 = location.getBlockZ();
        for (WirelessButton wirelessButton : this.buttons.values()) {
            if (!wirelessButton.world.equals(string) || wirelessButton.x != n || wirelessButton.z != n3 || wirelessButton.y != n2 && wirelessButton.y + 1 != n2) continue;
            return wirelessButton;
        }
        return null;
    }

    public DetectorData detectorAt(Location location) {
        if (location == null || location.getWorld() == null) {
            return null;
        }
        String string = location.getWorld().getName();
        for (DetectorData detectorData : this.detectors) {
            if (!detectorData.world.equals(string) || detectorData.x != location.getBlockX() || detectorData.y != location.getBlockY() || detectorData.z != location.getBlockZ()) continue;
            return detectorData;
        }
        return null;
    }

    public DetectorData placeDetector(Block block) {
        block.setType(Material.DAYLIGHT_DETECTOR);
        DetectorData detectorData = new DetectorData(block.getLocation());
        this.detectors.add(detectorData);
        this.save();
        return detectorData;
    }

    public boolean removeDetector(DetectorData detectorData) {
        if (this.detectors.remove(detectorData)) {
            this.setPower(detectorData, false);
            this.save();
            return true;
        }
        return false;
    }

    public CodeDevice deviceAt(Location location) {
        if (location == null || location.getWorld() == null) {
            return null;
        }
        String string = location.getWorld().getName();
        for (CodeDevice codeDevice : this.devices) {
            if (!codeDevice.world.equals(string) || codeDevice.x != location.getBlockX() || codeDevice.y != location.getBlockY() || codeDevice.z != location.getBlockZ()) continue;
            return codeDevice;
        }
        return null;
    }

    public CodeDevice registerDevice(Block block) {
        CodeDevice codeDevice = this.deviceAt(block.getLocation());
        if (codeDevice != null) {
            codeDevice.type = block.getType();
            return codeDevice;
        }
        CodeDevice codeDevice2 = new CodeDevice(block.getLocation(), block.getType());
        this.devices.add(codeDevice2);
        this.save();
        return codeDevice2;
    }

    public boolean removeDeviceAt(Location location) {
        CodeDevice codeDevice = this.deviceAt(location);
        if (codeDevice == null) {
            return false;
        }
        this.devices.remove(codeDevice);
        this.save();
        return true;
    }

    public void press(Player player, WirelessButton wirelessButton) {
        if (!wirelessButton.enabled) {
            return;
        }
        if (wirelessButton.modeLever) {
            if (!wirelessButton.active) {
                this.setActive(wirelessButton, true, -1L);
                this.click(wirelessButton);
            } else if (wirelessButton.leverOffNoWrench) {
                this.setActive(wirelessButton, false, -1L);
                this.click(wirelessButton);
            }
            return;
        }
        int n = Math.max(1, Math.min(15, wirelessButton.holdSeconds));
        this.setActive(wirelessButton, true, this.clock + (long)n * 20L);
        this.click(wirelessButton);
    }

    private void click(WirelessButton wirelessButton) {
        World world = Worlds.resolve(wirelessButton.world);
        if (world != null) {
            world.playSound(wirelessButton.center(world), this.pressSound, SoundCategory.BLOCKS, this.soundVolume, this.soundPitch);
        }
    }

    public void setActive(WirelessButton wirelessButton, boolean bl, long l) {
        wirelessButton.active = bl;
        wirelessButton.activeUntil = bl ? l : -1L;
        this.setCrimsonPowered(wirelessButton, bl);
    }

    public void tick() {
        ++this.clock;
        for (WirelessButton wirelessButton : this.buttons.values()) {
            if (!wirelessButton.active) continue;
            if (wirelessButton.activeUntil > 0L && this.clock >= wirelessButton.activeUntil) {
                this.setActive(wirelessButton, false, -1L);
                continue;
            }
            World world = Worlds.resolve(wirelessButton.world);
            if (world == null) continue;
            Location location = wirelessButton.topCenter(world);
            Particle.DustOptions dustOptions = new Particle.DustOptions(Color.RED, 1.2f);
            world.spawnParticle(Particle.DUST, location, 4, 0.25, 0.2, 0.25, (Object)dustOptions);
            if (wirelessButton.holdSeconds <= 1 || wirelessButton.activeUntil <= 0L || this.clock % 20L != 0L) continue;
            world.playSound(location, this.tickSound, SoundCategory.BLOCKS, this.soundVolume, this.soundPitch);
        }
        this.updateDetectors();
        this.updateDevices();
    }

    private void updateDevices() {
        for (CodeDevice codeDevice : this.devices) {
            boolean bl = false;
            if (!codeDevice.code.isEmpty()) {
                for (WirelessButton wirelessButton : this.buttons.values()) {
                    if (!wirelessButton.enabled || !wirelessButton.active || !wirelessButton.codeMatches(codeDevice.code)) continue;
                    bl = true;
                    break;
                }
            }
            if (bl == codeDevice.active) continue;
            codeDevice.active = bl;
            this.applyDevice(codeDevice, bl);
        }
    }

    private void applyDevice(CodeDevice codeDevice, boolean bl) {
        World world = Worlds.resolve(codeDevice.world);
        if (world == null) {
            return;
        }
        Block block = world.getBlockAt(codeDevice.x, codeDevice.y, codeDevice.z);
        Material material = block.getType();
        BlockData blockData = block.getBlockData();
        if (material == Material.REDSTONE_LAMP || ButtonManager.isBulb(material)) {
            if (blockData instanceof Lightable) {
                Lightable lightable = (Lightable)blockData;
                lightable.setLit(bl);
                block.setBlockData((BlockData)lightable, false);
            }
        } else if (material == Material.REDSTONE_TORCH || material == Material.REDSTONE_WALL_TORCH) {
            if (blockData instanceof Lightable) {
                Lightable lightable = (Lightable)blockData;
                lightable.setLit(!bl);
                block.setBlockData((BlockData)lightable, false);
            }
        } else if (material == Material.PISTON || material == Material.STICKY_PISTON) {
            if (blockData instanceof Piston) {
                Piston piston = (Piston)blockData;
                piston.setExtended(bl);
                block.setBlockData((BlockData)piston, false);
            }
        } else if (material == Material.DISPENSER) {
            BlockState blockState;
            if (bl && (blockState = block.getState()) instanceof Dispenser) {
                ((Dispenser)blockState).dispense();
            }
        } else if (material == Material.DROPPER) {
            BlockState blockState;
            if (bl && (blockState = block.getState()) instanceof Dropper) {
                ((Dropper)blockState).drop();
            }
        } else if (material == Material.NOTE_BLOCK && bl && blockData instanceof NoteBlock) {
            NoteBlock noteBlock = (NoteBlock)blockData;
            world.playNote(block.getLocation(), noteBlock.getInstrument(), noteBlock.getNote());
        }
    }

    private static boolean isBulb(Material material) {
        return material == Material.COPPER_BULB || material == Material.EXPOSED_COPPER_BULB || material == Material.WEATHERED_COPPER_BULB || material == Material.OXIDIZED_COPPER_BULB || material == Material.WAXED_COPPER_BULB || material == Material.WAXED_EXPOSED_COPPER_BULB || material == Material.WAXED_WEATHERED_COPPER_BULB || material == Material.WAXED_OXIDIZED_COPPER_BULB;
    }

    private void updateDetectors() {
        for (DetectorData detectorData : this.detectors) {
            boolean bl = false;
            for (WirelessButton wirelessButton : this.buttons.values()) {
                if (!wirelessButton.enabled || !wirelessButton.active || !wirelessButton.codeMatches(detectorData.code)) continue;
                bl = true;
                break;
            }
            if (bl != detectorData.active) {
                detectorData.active = bl;
                this.setPower(detectorData, bl);
            }
            World world;
            if (!detectorData.active || (world = Worlds.resolve(detectorData.world)) == null) continue;
            Location particleLoc = new Location(world, (double)detectorData.x + 0.5, (double)detectorData.y + 1.0, (double)detectorData.z + 0.5);
            Particle.DustOptions dustOptions = new Particle.DustOptions(Color.RED, 1.0f);
            world.spawnParticle(Particle.DUST, particleLoc, 3, 0.25, 0.2, 0.25, dustOptions);
        }
    }

    private void setPower(DetectorData detectorData, boolean bl) {
        Material material;
        World world = Worlds.resolve(detectorData.world);
        if (world == null) {
            return;
        }
        Block block = world.getBlockAt(detectorData.x, detectorData.y, detectorData.z);
        Material material2 = material = bl ? Material.REDSTONE_BLOCK : Material.DAYLIGHT_DETECTOR;
        if (block.getType() != material) {
            block.setType(material, true);
        }
    }

    public Items items() {
        return this.items;
    }

    public JavaPlugin plugin() {
        return this.plugin;
    }
}

