package ru.glai.aperture;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Boat;
import org.bukkit.entity.Display;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.EnderDragon;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ExperienceOrb;
import org.bukkit.entity.Item;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Minecart;
import org.bukkit.entity.Painting;
import org.bukkit.entity.Player;
import org.bukkit.entity.Warden;
import org.bukkit.entity.Wither;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

/**
 * Обработка портальной пушки (адаптация PortalGun v3.1.2):
 * - ЛКМ — оранжевый портал, ПКМ — синий портал;
 * - ПКМ по существу/кубу — взять (удерживать перед собой), ЛКМ — бросить, ПКМ — отпустить;
 * - порталы исчезают при поломке опоры или установке блока в клетку портала.
 */
public final class GunListener implements Listener {

    private static final double PICK_RANGE = 4.0;
    private static final double HOLD_DISTANCE = 2.5;

    private final Items items;
    private final CubeSystem cubes;
    private final PortalSystem portals;
    private final ZoneManager zone;
    private final Map<UUID, Entity> picked = new HashMap<>();

    public GunListener(Items items, CubeSystem cubes, PortalSystem portals, ZoneManager zone) {
        this.items = items;
        this.cubes = cubes;
        this.portals = portals;
        this.zone = zone;
    }

    private boolean holdingGun(Player player) {
        ItemStack main = player.getInventory().getItemInMainHand();
        ItemStack off = player.getInventory().getItemInOffHand();
        return Items.KIND_PORTAL_GUN.equals(items.kindOf(main)) || Items.KIND_PORTAL_GUN.equals(items.kindOf(off));
    }

    /** вызывается каждый тик из главного класса — удержание подобранной сущности */
    public void tick() {
        if (picked.isEmpty()) return;
        picked.entrySet().removeIf(en -> {
            Entity e = en.getValue();
            if (e == null || !e.isValid() || e.isDead()) return true;
            Player p = org.bukkit.Bukkit.getPlayer(en.getKey());
            if (p == null || !p.isOnline() || !holdingGun(p)) {
                releaseEntity(e);
                return true;
            }
            Location eye = p.getEyeLocation();
            Vector dir = eye.getDirection().normalize();
            Location target = eye.clone().add(dir.multiply(HOLD_DISTANCE));
            if (target.getBlock().isPassable()) {
                target.setYaw(p.getLocation().getYaw());
                e.teleport(target);
            }
            e.setVelocity(new Vector(0, 0, 0));
            return false;
        });
    }

    private void releaseEntity(Entity e) {
        if (e instanceof org.bukkit.entity.LivingEntity) {
            ((org.bukkit.entity.LivingEntity) e).setGravity(true);
        } else {
            trySetGravity(e, true);
        }
    }

    private void trySetGravity(Entity e, boolean gravity) {
        try {
            e.setGravity(gravity);
        } catch (Throwable ignored) {
        }
    }

    private boolean pickable(Entity e) {
        if (e == null || !e.isValid() || e.isDead()) return false;
        if (e instanceof Player) return false;
        if (e instanceof Item || e instanceof ItemFrame || e instanceof Painting) return false;
        if (e instanceof EnderCrystal || e instanceof ExperienceOrb) return false;
        if (e instanceof EnderDragon || e instanceof Wither || e instanceof Warden) return false;
        if (e instanceof Display) return false;
        if (e instanceof Minecart || e instanceof Boat) return false;
        if (e.getVehicle() != null) return false;
        return true;
    }

    /** ближайшее существо на луче взгляда (как getLookingEntity в PortalGun) */
    private Entity lookingEntity(Player player, double max) {
        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        Entity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : player.getWorld().getNearbyEntities(eye, max, max, max)) {
            if (e.equals(player) || !pickable(e)) continue;
            if (!cubes.isTagged(e) && e instanceof org.bukkit.entity.ArmorStand) continue;
            org.bukkit.util.RayTraceResult r = e.getBoundingBox().rayTrace(eye.toVector(), dir, max);
            if (r == null) continue;
            double d = r.getHitPosition().distanceSquared(eye.toVector());
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        // блок не должен перекрывать существо
        Block b = PortalSystem.lookingBlock(player, (int) max + 1);
        if (best != null && b != null) {
            double bd = b.getLocation().distanceSquared(player.getLocation());
            if (bd < bestDist) return null;
        }
        return best;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Player player = event.getPlayer();
        if (!Items.KIND_PORTAL_GUN.equals(items.kindOf(player.getInventory().getItemInMainHand()))) {
            return;
        }
        Action action = event.getAction();
        boolean left = action == Action.LEFT_CLICK_BLOCK || action == Action.LEFT_CLICK_AIR;
        boolean right = action == Action.RIGHT_CLICK_BLOCK || action == Action.RIGHT_CLICK_AIR;
        if (!left && !right) return;
        event.setCancelled(true);
        if (zone != null && !zone.gunAllowed(player)) {
            return;
        }
        UUID uid = player.getUniqueId();
        CubeSystem.Cube carriedCube = cubes.cubeByCarrier(player);
        Entity carriedEntity = picked.get(uid);

        if (left) {
            if (carriedCube != null) {
                cubes.throwCube(player, carriedCube);
                player.sendMessage("§eкуб брошен");
                return;
            }
            if (carriedEntity != null) {
                picked.remove(uid);
                releaseEntity(carriedEntity);
                Vector v = carriedEntity.getLocation().toVector().subtract(player.getLocation().toVector());
                if (v.length() > 4) v.normalize().multiply(4);
                carriedEntity.setVelocity(v);
                return;
            }
            portals.shoot(player, true);
            return;
        }

        // правый клик
        if (carriedCube != null) {
            cubes.release(carriedCube);
            player.sendMessage("§eкуб отпущен");
            return;
        }
        if (carriedEntity != null) {
            picked.remove(uid);
            releaseEntity(carriedEntity);
            return;
        }
        // поднять куб или существо
        Entity target = lookingEntity(player, PICK_RANGE);
        if (target != null) {
            CubeSystem.Cube cube = cubes.cubeByBody(target);
            if (cube != null) {
                cubes.grab(player, cube);
                player.sendMessage("§eкуб взят");
            } else {
                picked.put(uid, target);
                trySetGravity(target, false);
                target.setVelocity(new Vector(0, 0, 0));
            }
            return;
        }
        Block clicked = event.getClickedBlock();
        if (clicked != null && clicked.getType() == Material.BARRIER) {
            CubeSystem.Cube cube = cubes.cubeByBarrier(clicked.getLocation());
            if (cube != null) {
                cubes.grab(player, cube);
                player.sendMessage("§eкуб взят");
                return;
            }
        }
        portals.shoot(player, false);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent event) {
        Entity entity = event.getRightClicked();
        Player player = event.getPlayer();
        if (!holdingGun(player)) {
            if (!cubes.isTagged(entity)) return;
            event.setCancelled(true);
            return;
        }
        if (!cubes.isTagged(entity) && !pickable(entity)) return;
        event.setCancelled(true);
        if (zone != null && !zone.gunAllowed(player)) return;
        CubeSystem.Cube carried = cubes.cubeByCarrier(player);
        if (carried != null) {
            cubes.release(carried);
            player.sendMessage("§eкуб отпущен");
            return;
        }
        Entity held = picked.get(player.getUniqueId());
        if (held != null) {
            picked.remove(player.getUniqueId());
            releaseEntity(held);
            return;
        }
        CubeSystem.Cube cube = cubes.cubeByBody(entity);
        if (cube != null) {
            cubes.grab(player, cube);
            player.sendMessage("§eкуб взят");
        } else if (pickable(entity)) {
            picked.put(player.getUniqueId(), entity);
            trySetGravity(entity, false);
            entity.setVelocity(new Vector(0, 0, 0));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onShootBow(EntityShootBowEvent event) {
        if (Items.KIND_PORTAL_GUN.equals(items.kindOf(event.getBow()))) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (cubes.isTagged(event.getEntity())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onManipulate(PlayerArmorStandManipulateEvent event) {
        if (cubes.isTagged(event.getRightClicked())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (block.getType() == Material.BARRIER && cubes.isCubeBarrier(block.getLocation())) {
            event.setCancelled(true);
            return;
        }
        portals.removeAt(block);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        // поставленный блок в клетке портала ломает портал
        portals.removeAt(event.getBlockPlaced());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        Entity item = event.getItemDrop();
        if (picked.containsValue(item)) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Entity e = picked.remove(event.getPlayer().getUniqueId());
        if (e != null) releaseEntity(e);
    }
}
