package ru.glai.aperture;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;
import ru.glai.aperture.Worlds;

public final class CubeSystem {
    private final JavaPlugin plugin;
    private final NamespacedKey tagKey;
    private final Map<UUID, Cube> cubes = new HashMap<UUID, Cube>();
    private PortalSystem portals;

    public CubeSystem(JavaPlugin javaPlugin) {
        this.plugin = javaPlugin;
        this.tagKey = new NamespacedKey((Plugin)javaPlugin, "aperture_cube");
    }

    public void setPortals(PortalSystem portalSystem) {
        this.portals = portalSystem;
    }

    public boolean isCarriedEntity(Entity entity) {
        if (entity == null) {
            return false;
        }
        for (Cube cube : this.cubes.values()) {
            if (cube.carried && cube.body != null && cube.body.getUniqueId().equals(entity.getUniqueId())) {
                return true;
            }
        }
        return false;
    }

    public void throwCube(Player player, Cube cube) {
        this.release(cube);
        Vector dir = player.getEyeLocation().getDirection().normalize();
        cube.body.setVelocity(dir.multiply(2.0).add(new Vector(0, 0.15, 0)));
    }

    /** убирает опору куба (барьер), чтобы он провалился, например, в портал в полу */
    public void unsupport(Cube cube) {
        this.removeBarrier(cube);
        cube.body.setGravity(true);
    }

    public NamespacedKey tagKey() {
        return this.tagKey;
    }

    public boolean isTagged(Entity entity) {
        return entity != null && entity.getPersistentDataContainer().has(this.tagKey, PersistentDataType.BYTE);
    }

    public Cube cubeByBody(Entity entity) {
        if (entity == null) {
            return null;
        }
        return this.cubes.get(entity.getUniqueId());
    }

    public Cube cubeByCarrier(Player player) {
        for (Cube cube : this.cubes.values()) {
            if (!cube.carried || !player.getUniqueId().equals(cube.carrier)) continue;
            return cube;
        }
        return null;
    }

    public void spawnCube(World world, double d, double d2, double d3) {
        int n = (int)Math.floor(d);
        int n2 = (int)Math.floor(d2);
        int n3 = (int)Math.floor(d3);
        Location location = new Location(world, (double)n + 0.5, (double)n2, (double)n3 + 0.5);
        this.spawnAt(location);
        this.save();
    }

    private Cube spawnAt(Location location) {
        World world = location.getWorld();
        ArmorStand armorStand2 = (ArmorStand)world.spawn(location, ArmorStand.class, armorStand -> {
            armorStand.setVisible(false);
            armorStand.setSmall(true);
            armorStand.setBasePlate(false);
            armorStand.setArms(false);
            armorStand.setGravity(true);
            armorStand.setInvulnerable(true);
            armorStand.setPersistent(true);
            armorStand.setSilent(true);
            armorStand.setCanPickupItems(false);
            armorStand.setRemoveWhenFarAway(false);
            armorStand.getPersistentDataContainer().set(this.tagKey, PersistentDataType.BYTE, (byte)1);
        });
        BlockDisplay blockDisplay2 = (BlockDisplay)world.spawn(location, BlockDisplay.class, blockDisplay -> {
            blockDisplay.setBlock(Material.IRON_BLOCK.createBlockData());
            blockDisplay.setTransformation(new Transformation(new Vector3f(-0.5f, 0.0f, -0.5f), new AxisAngle4f(0.0f, 0.0f, 1.0f, 0.0f), new Vector3f(1.0f, 1.0f, 1.0f), new AxisAngle4f(0.0f, 0.0f, 1.0f, 0.0f)));
            blockDisplay.setBrightness(new Display.Brightness(15, 15));
            blockDisplay.setInvulnerable(true);
            blockDisplay.setPersistent(true);
            blockDisplay.getPersistentDataContainer().set(this.tagKey, PersistentDataType.BYTE, (byte)1);
        });
        Cube cube = new Cube();
        cube.body = armorStand2;
        cube.visual = blockDisplay2;
        cube.carried = false;
        this.cubes.put(armorStand2.getUniqueId(), cube);
        if (this.isGrounded((Entity)armorStand2)) {
            this.settle(cube);
        }
        return cube;
    }

    public Cube rayCastCube(Player player) {
        Location location = player.getEyeLocation();
        Vector vector = location.getDirection();
        RayTraceResult rayTraceResult = player.getWorld().rayTraceEntities(location, vector, 5.0, 0.35, entity -> entity instanceof ArmorStand && this.isTagged((Entity)entity));
        if (rayTraceResult == null || rayTraceResult.getHitEntity() == null) {
            return null;
        }
        return this.cubes.get(rayTraceResult.getHitEntity().getUniqueId());
    }

    public Cube cubeByBarrier(Location location) {
        for (Cube cube : this.cubes.values()) {
            if (cube.barrier == null || cube.barrier.getBlockX() != location.getBlockX() || cube.barrier.getBlockY() != location.getBlockY() || cube.barrier.getBlockZ() != location.getBlockZ() || !cube.barrier.getWorld().equals((Object)location.getWorld())) continue;
            return cube;
        }
        return null;
    }

    public void grab(Player player, Cube cube) {
        this.removeBarrier(cube);
        cube.carried = true;
        cube.carrier = player.getUniqueId();
        cube.body.setGravity(false);
        cube.body.setVelocity(new Vector(0, 0, 0));
        this.save();
    }

    public void release(Cube cube) {
        cube.carried = false;
        cube.carrier = null;
        cube.body.setGravity(true);
        cube.body.setVelocity(new Vector(0, 0, 0));
        this.save();
    }

    public void tick() {
        Iterator<Map.Entry<UUID, Cube>> iterator = this.cubes.entrySet().iterator();
        while (iterator.hasNext()) {
            Cube cube = iterator.next().getValue();
            if (cube.body == null || !cube.body.isValid() || cube.visual == null || !cube.visual.isValid()) {
                iterator.remove();
                continue;
            }
            if (cube.carried) {
                Player player;
                Player player2 = player = cube.carrier == null ? null : Bukkit.getPlayer((UUID)cube.carrier);
                if (player == null || !player.isOnline()) {
                    this.release(cube);
                    continue;
                }
                Location location = this.carryLocation(player);
                cube.body.teleport(location);
                cube.body.setVelocity(new Vector(0, 0, 0));
                cube.visual.teleport(cube.body.getLocation());
                continue;
            }
            if (!cube.body.hasGravity()) {
                // куб стоит на опоре: если под ним открылся портал — убираем опору, чтобы провалился
                if (this.portals != null) {
                    Location loc = cube.body.getLocation();
                    Block below = cube.barrier != null
                            ? cube.barrier.getBlock()
                            : loc.getWorld().getBlockAt(loc.getBlockX(), (int) Math.floor(loc.getY() - 0.05), loc.getBlockZ());
                    if (this.portals.cellPortalAt(below) != null) {
                        this.unsupport(cube);
                    }
                }
                continue;
            }
            cube.visual.teleport(cube.body.getLocation());
            if (!this.isGrounded((Entity)cube.body)) continue;
            this.settle(cube);
        }
    }

    private Location carryLocation(Player player) {
        Location location = player.getEyeLocation();
        Vector vector = location.getDirection().normalize();
        Location location2 = location.clone().add(vector.multiply(2.2));
        location2.setY(location2.getY() - 0.7);
        location2.setYaw(player.getLocation().getYaw());
        location2.setPitch(0.0f);
        return location2;
    }

    private void settle(Cube cube) {
        ArmorStand armorStand = cube.body;
        World world = armorStand.getWorld();
        Location location = armorStand.getLocation();
        int n = (int)Math.floor(location.getX());
        int n2 = (int)Math.floor(location.getZ());
        int n3 = (int)Math.floor(location.getY() - 0.05);
        Block block = world.getBlockAt(n, n3, n2);
        armorStand.setGravity(false);
        armorStand.setVelocity(new Vector(0, 0, 0));
        if (CubeSystem.isPlate(block.getType())) {
            cube.barrier = null;
        } else {
            int n4 = n3 + 1;
            armorStand.teleport(new Location(world, (double)n + 0.5, (double)n4, (double)n2 + 0.5, location.getYaw(), location.getPitch()));
            Block block2 = world.getBlockAt(n, n4, n2);
            if (block2.getType() == Material.AIR || block2.getType() == Material.BARRIER) {
                block2.setType(Material.BARRIER, false);
                cube.barrier = block2.getLocation();
            } else {
                cube.barrier = null;
            }
        }
        cube.visual.teleport(armorStand.getLocation());
    }

    private void removeBarrier(Cube cube) {
        if (cube.barrier != null) {
            Block block = cube.barrier.getBlock();
            if (block.getType() == Material.BARRIER) {
                block.setType(Material.AIR, false);
            }
            cube.barrier = null;
        }
    }

    public boolean isCubeBarrier(Location location) {
        for (Cube cube : this.cubes.values()) {
            if (cube.barrier == null || cube.barrier.getBlockX() != location.getBlockX() || cube.barrier.getBlockY() != location.getBlockY() || cube.barrier.getBlockZ() != location.getBlockZ() || !cube.barrier.getWorld().equals((Object)location.getWorld())) continue;
            return true;
        }
        return false;
    }

    private static boolean isPlate(Material material) {
        return material.name().endsWith("PRESSURE_PLATE");
    }

    private boolean isGrounded(Entity entity) {
        Location location = entity.getLocation();
        World world = location.getWorld();
        int n = (int)Math.floor(location.getX());
        int n2 = (int)Math.floor(location.getZ());
        int n3 = (int)Math.floor(location.getY() - 0.05);
        Block block = world.getBlockAt(n, n3, n2);
        Material material = block.getType();
        boolean bl = material.isSolid() || CubeSystem.isPlate(material);
        boolean bl2 = Math.abs(entity.getVelocity().getY()) < 0.15;
        return bl && bl2;
    }

    public void load() {
        this.cubes.clear();
        for (World w : Bukkit.getWorlds()) {
            for (Entity entity : w.getEntities()) {
                if (!this.isTagged(entity)) continue;
                entity.remove();
            }
        }
        File file = new File(this.plugin.getDataFolder(), "cubes.yml");
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration(file);
        for (Map<?, ?> object : yamlConfiguration.getMapList("cubes")) {
            World world3 = Worlds.resolve(String.valueOf(object.get("world")));
            if (world3 == null) continue;
            double d = CubeSystem.toDouble(object.get("x"));
            double d2 = CubeSystem.toDouble(object.get("y"));
            double d3 = CubeSystem.toDouble(object.get("z"));
            Location location = new Location(world3, d, d2, d3);
            Block block = world3.getBlockAt((int)Math.floor(d), (int)Math.floor(d2), (int)Math.floor(d3));
            if (block.getType() == Material.BARRIER) {
                block.setType(Material.AIR, false);
            }
            this.spawnAt(location);
        }
    }

    private static double toDouble(Object object) {
        if (object instanceof Number) {
            return ((Number)object).doubleValue();
        }
        try {
            return Double.parseDouble(String.valueOf(object));
        }
        catch (NumberFormatException numberFormatException) {
            return 0.0;
        }
    }

    public void save() {
        File file = new File(this.plugin.getDataFolder(), "cubes.yml");
        YamlConfiguration yamlConfiguration = new YamlConfiguration();
        ArrayList arrayList = new ArrayList();
        for (Cube cube : this.cubes.values()) {
            if (cube.body == null || !cube.body.isValid()) continue;
            Location location = cube.body.getLocation();
            HashMap<String, Object> hashMap = new HashMap<String, Object>();
            hashMap.put("world", location.getWorld() == null ? "world" : location.getWorld().getName());
            hashMap.put("x", location.getX());
            hashMap.put("y", location.getY());
            hashMap.put("z", location.getZ());
            hashMap.put("carried", cube.carried);
            arrayList.add(hashMap);
        }
        yamlConfiguration.set("cubes", arrayList);
        try {
            yamlConfiguration.save(file);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    public void shutdown() {
        for (Cube cube : this.cubes.values()) {
            this.removeBarrier(cube);
            if (cube.visual != null) {
                cube.visual.remove();
            }
            if (cube.body == null) continue;
            cube.body.remove();
        }
        this.cubes.clear();
    }

    public static final class Cube {
        public ArmorStand body;
        public BlockDisplay visual;
        public boolean carried;
        public UUID carrier;
        public Location barrier;
    }
}

