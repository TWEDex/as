package ru.glai.aperture;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.BoundingBox;
import ru.glai.aperture.Worlds;

public final class ZoneManager {
    private final JavaPlugin plugin;
    private final String owner;
    private String worldName = "world";
    private BoundingBox region;
    private Location blockSpawn;
    private boolean regionOverridden;
    private final Set<UUID> operators = new HashSet<UUID>();
    private final Set<UUID> blocked = new HashSet<UUID>();
    private final Map<UUID, GameMode> inside = new HashMap<UUID, GameMode>();

    public ZoneManager(JavaPlugin javaPlugin, String string) {
        this.plugin = javaPlugin;
        this.owner = string;
    }

    public void loadConfig() {
        this.worldName = this.plugin.getConfig().getString("zone.world", "dragon_island");
        String string = this.plugin.getConfig().getString("zone.region-a", "-460 149 -1670");
        String string2 = this.plugin.getConfig().getString("zone.region-b", "-827 -64 -2033");
        String string3 = this.plugin.getConfig().getString("zone.block-spawn", "-599 62 -1636");
        World world = Worlds.resolve(this.worldName);
        this.region = null;
        this.blockSpawn = null;
        if (world != null) {
            try {
                Location location = ZoneManager.parse(string, world);
                Location location2 = ZoneManager.parse(string2, world);
                double d = Math.min(location.getX(), location2.getX());
                double d2 = Math.min(location.getY(), location2.getY());
                double d3 = Math.min(location.getZ(), location2.getZ());
                double d4 = Math.max(location.getX(), location2.getX()) + 1.0;
                double d5 = Math.max(location.getY(), location2.getY()) + 1.0;
                double d6 = Math.max(location.getZ(), location2.getZ()) + 1.0;
                this.region = new BoundingBox(d, d2, d3, d4, d5, d6);
            }
            catch (RuntimeException runtimeException) {
                this.region = null;
            }
            try {
                this.blockSpawn = ZoneManager.parse(string3, world);
            }
            catch (RuntimeException runtimeException) {
                this.blockSpawn = null;
            }
        }
        this.applyRegionOverride();
    }

    /** переопределение региона из zone.yml (после operator expand/shrink) */
    private void applyRegionOverride() {
        File file = new File(this.plugin.getDataFolder(), "zone.yml");
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration(file);
        String a = yamlConfiguration.getString("region.a");
        String b = yamlConfiguration.getString("region.b");
        String wName = yamlConfiguration.getString("region.world", this.worldName);
        if (a == null || b == null) {
            return;
        }
        World world = Worlds.resolve(wName);
        if (world == null) {
            return;
        }
        try {
            Location la = ZoneManager.parse(a, world);
            Location lb = ZoneManager.parse(b, world);
            this.worldName = wName;
            this.region = new BoundingBox(
                    Math.min(la.getX(), lb.getX()), Math.min(la.getY(), lb.getY()), Math.min(la.getZ(), lb.getZ()),
                    Math.max(la.getX(), lb.getX()) + 1.0, Math.max(la.getY(), lb.getY()) + 1.0, Math.max(la.getZ(), lb.getZ()) + 1.0);
            this.regionOverridden = true;
        }
        catch (RuntimeException runtimeException) {
            // оставляем регион из config.yml
        }
    }

    private void saveRegion() {
        if (this.region == null) {
            return;
        }
        File file = new File(this.plugin.getDataFolder(), "zone.yml");
        YamlConfiguration yamlConfiguration = file.exists() ? YamlConfiguration.loadConfiguration(file) : new YamlConfiguration();
        yamlConfiguration.set("region.world", this.worldName);
        yamlConfiguration.set("region.a", fmt(this.region.getMinX(), this.region.getMinY(), this.region.getMinZ()));
        yamlConfiguration.set("region.b", fmt(this.region.getMaxX() - 1.0, this.region.getMaxY() - 1.0, this.region.getMaxZ() - 1.0));
        try {
            yamlConfiguration.save(file);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        this.regionOverridden = true;
    }

    private static String fmt(double x, double y, double z) {
        return (int)Math.round(x) + " " + (int)Math.round(y) + " " + (int)Math.round(z);
    }

    /** расширить территорию на n блоков во все стороны */
    public String expand(int n) {
        return this.resize(n);
    }

    /** сузить территорию на n блоков со всех сторон */
    public String shrink(int n) {
        return this.resize(-n);
    }

    private String resize(int delta) {
        if (this.region == null) {
            return null;
        }
        BoundingBox box = this.region.clone();
        double sx = box.getWidthX() / 2.0 + delta;
        double sy = box.getHeight() / 2.0 + delta;
        double sz = box.getWidthZ() / 2.0 + delta;
        if (sx < 1.0 || sy < 1.0 || sz < 1.0) {
            return "ошибка: территория станет меньше минимума";
        }
        box.expand(delta, delta, delta);
        this.region = box;
        this.saveRegion();
        return this.regionInfo();
    }

    public String regionInfo() {
        if (this.region == null) {
            return "территория не задана";
        }
        return this.worldName
                + ": A " + fmt(this.region.getMinX(), this.region.getMinY(), this.region.getMinZ())
                + " | B " + fmt(this.region.getMaxX() - 1.0, this.region.getMaxY() - 1.0, this.region.getMaxZ() - 1.0)
                + " (" + (int)this.region.getWidthX() + "x" + (int)this.region.getHeight() + "x" + (int)this.region.getWidthZ() + ")";
    }

    /** точка внутри территории */
    public boolean contains(Location location) {
        if (this.region == null || location == null || location.getWorld() == null) {
            return false;
        }
        World world = Worlds.resolve(this.worldName);
        if (world == null || !location.getWorld().getUID().equals(world.getUID())) {
            return false;
        }
        return this.region.contains(location.getX(), location.getY(), location.getZ());
    }

    public boolean isInZone(Entity entity) {
        if (this.region == null || entity == null) {
            return false;
        }
        World world = Worlds.resolve(this.worldName);
        if (world == null || entity.getWorld() == null || !entity.getWorld().getUID().equals(world.getUID())) {
            return false;
        }
        return entity.getBoundingBox().overlaps(this.region);
    }

    private static Location parse(String string, World world) {
        if (string == null || string.trim().isEmpty()) {
            throw new IllegalArgumentException("empty");
        }
        String[] stringArray = string.trim().split("\\s+");
        if (stringArray.length < 3) {
            throw new IllegalArgumentException("bad: " + string);
        }
        return new Location(world, Double.parseDouble(stringArray[0]), Double.parseDouble(stringArray[1]), Double.parseDouble(stringArray[2]));
    }

    public void load() {
        this.operators.clear();
        this.blocked.clear();
        this.inside.clear();
        File file = new File(this.plugin.getDataFolder(), "zone.yml");
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration((File)file);
        for (String string : yamlConfiguration.getStringList("operators")) {
            ZoneManager.add(this.operators, string);
        }
        for (String string : yamlConfiguration.getStringList("blocked")) {
            ZoneManager.add(this.blocked, string);
        }
        org.bukkit.configuration.ConfigurationSection insideSection = yamlConfiguration.getConfigurationSection("inside");
        List<String> insideKeys = insideSection == null ? new ArrayList<String>() : new ArrayList<String>(insideSection.getKeys(false));
        for (String string : insideKeys) {
            UUID uUID = ZoneManager.parseId(string);
            if (uUID == null) continue;
            String string2 = yamlConfiguration.getString("inside." + string, "SURVIVAL");
            try {
                this.inside.put(uUID, GameMode.valueOf((String)string2.toUpperCase()));
            }
            catch (RuntimeException runtimeException) {
                this.inside.put(uUID, GameMode.SURVIVAL);
            }
        }
    }

    private static void add(Set<UUID> set, String string) {
        UUID uUID = ZoneManager.parseId(string);
        if (uUID != null) {
            set.add(uUID);
        }
    }

    private static UUID parseId(String string) {
        try {
            return UUID.fromString(string);
        }
        catch (RuntimeException runtimeException) {
            return null;
        }
    }

    public void save() {
        File file = new File(this.plugin.getDataFolder(), "zone.yml");
        YamlConfiguration yamlConfiguration = new YamlConfiguration();
        yamlConfiguration.set("operators", new ArrayList<String>(ZoneManager.toStrings(this.operators)));
        yamlConfiguration.set("blocked", new ArrayList<String>(ZoneManager.toStrings(this.blocked)));
        for (Map.Entry<UUID, GameMode> entry : this.inside.entrySet()) {
            yamlConfiguration.set("inside." + String.valueOf(entry.getKey()), (Object)entry.getValue().name());
        }
        try {
            yamlConfiguration.save(file);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    private static List<String> toStrings(Set<UUID> set) {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (UUID uUID : set) {
            arrayList.add(uUID.toString());
        }
        return arrayList;
    }

    public boolean isOperator(UUID uUID) {
        return this.operators.contains(uUID);
    }

    public boolean isBlocked(UUID uUID) {
        return this.blocked.contains(uUID);
    }

    public boolean addOperator(String string) {
        UUID uUID = ZoneManager.idOf(string);
        if (uUID == null) {
            return false;
        }
        boolean bl = this.operators.add(uUID);
        this.save();
        return bl;
    }

    public boolean removeOperator(String string) {
        UUID uUID = ZoneManager.idOf(string);
        if (uUID == null) {
            return false;
        }
        boolean bl = this.operators.remove(uUID);
        this.save();
        return bl;
    }

    public boolean addBlocked(String string) {
        UUID uUID = ZoneManager.idOf(string);
        if (uUID == null) {
            return false;
        }
        boolean bl = this.blocked.add(uUID);
        this.save();
        return bl;
    }

    public boolean removeBlocked(String string) {
        UUID uUID = ZoneManager.idOf(string);
        if (uUID == null) {
            return false;
        }
        boolean bl = this.blocked.remove(uUID);
        this.save();
        return bl;
    }

    private static UUID idOf(String string) {
        Player player = Bukkit.getPlayerExact((String)string);
        if (player != null) {
            return player.getUniqueId();
        }
        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((String)string);
        return offlinePlayer.getUniqueId();
    }

    public List<String> operatorNames() {
        return ZoneManager.names(this.operators);
    }

    public List<String> blockedNames() {
        return ZoneManager.names(this.blocked);
    }

    private static List<String> names(Set<UUID> set) {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (UUID uUID : set) {
            OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)uUID);
            arrayList.add(offlinePlayer.getName() == null ? uUID.toString() : offlinePlayer.getName());
        }
        return arrayList;
    }

    public List<String> playersInZone() {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!this.isInZone(player)) continue;
            arrayList.add(player.getName());
        }
        return arrayList;
    }

    public boolean isInZone(Player player) {
        if (this.region == null) {
            return false;
        }
        World world = Worlds.resolve(this.worldName);
        if (world == null || player.getWorld() == null || !player.getWorld().getUID().equals(world.getUID())) {
            return false;
        }
        return player.getBoundingBox().overlaps(this.region);
    }

    public boolean hasRegion() {
        return this.region != null;
    }

    public boolean gunAllowed(Player player) {
        return this.region == null || this.isInZone(player);
    }

    public void tick() {
        if (this.region == null) {
            return;
        }
        this.killCreepers();
        for (Player player : Bukkit.getOnlinePlayers()) {
            UUID uUID = player.getUniqueId();
            boolean bl = this.isInZone(player);
            if (this.blocked.contains(uUID)) {
                if (this.inside.containsKey(uUID)) {
                    player.setGameMode(this.inside.remove(uUID));
                    this.save();
                }
                if (!bl || this.blockSpawn == null) continue;
                player.teleport(this.blockSpawn);
                continue;
            }
            if (this.operators.contains(uUID) || player.getName().equalsIgnoreCase(this.owner)) {
                if (!this.inside.containsKey(uUID)) continue;
                player.setGameMode(this.inside.remove(uUID));
                this.save();
                continue;
            }
            if (bl) {
                if (this.inside.containsKey(uUID)) continue;
                this.inside.put(uUID, player.getGameMode());
                player.setGameMode(GameMode.ADVENTURE);
                this.save();
                continue;
            }
            if (!this.inside.containsKey(uUID)) continue;
            player.setGameMode(this.inside.remove(uUID));
            this.save();
        }
    }

    /** криперы на территории мгновенно уничтожаются (без взрыва) */
    private void killCreepers() {
        World world = Worlds.resolve(this.worldName);
        if (world == null) {
            return;
        }
        try {
            for (Entity entity : world.getNearbyEntities(this.region, e -> e instanceof Creeper)) {
                entity.remove();
            }
        }
        catch (RuntimeException runtimeException) {
            // мир мог выгрузиться
        }
    }

    public void onQuit(Player player) {
    }
}

