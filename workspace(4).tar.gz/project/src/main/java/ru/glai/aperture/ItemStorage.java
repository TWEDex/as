package ru.glai.aperture;

import java.io.File;
import java.io.IOException;
import java.util.Base64;
import java.util.UUID;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public final class ItemStorage {
    private final File folder;

    public ItemStorage(Plugin plugin) {
        this.folder = new File(plugin.getDataFolder(), "storage");
        if (!this.folder.exists()) {
            this.folder.mkdirs();
        }
    }

    private File file(UUID uUID) {
        return new File(this.folder, uUID.toString() + ".yml");
    }

    public boolean has(UUID uUID) {
        return this.file(uUID).exists();
    }

    public void save(UUID uUID, String string, ItemStack[] itemStackArray) {
        YamlConfiguration yamlConfiguration = new YamlConfiguration();
        yamlConfiguration.set("name", (Object)string);
        yamlConfiguration.set("items", (Object)Base64.getEncoder().encodeToString(ItemStack.serializeItemsAsBytes((ItemStack[])itemStackArray)));
        try {
            yamlConfiguration.save(this.file(uUID));
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    public ItemStack[] load(UUID uUID) {
        File file = this.file(uUID);
        if (!file.exists()) {
            return null;
        }
        YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration((File)file);
        String string = yamlConfiguration.getString("items");
        if (string == null) {
            return null;
        }
        try {
            return ItemStack.deserializeItemsFromBytes((byte[])Base64.getDecoder().decode(string));
        }
        catch (RuntimeException runtimeException) {
            return null;
        }
    }

    public String storedName(UUID uUID) {
        File file = this.file(uUID);
        if (!file.exists()) {
            return null;
        }
        return YamlConfiguration.loadConfiguration((File)file).getString("name");
    }

    public void remove(UUID uUID) {
        File file = this.file(uUID);
        if (file.exists()) {
            file.delete();
        }
    }
}

