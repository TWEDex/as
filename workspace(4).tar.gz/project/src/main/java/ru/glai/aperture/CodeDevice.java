package ru.glai.aperture;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

public final class CodeDevice {
    public String world;
    public int x;
    public int y;
    public int z;
    public Material type;
    public final List<Material> code = new ArrayList<Material>();
    public boolean active;

    public CodeDevice(Location location, Material material) {
        World world = location.getWorld();
        this.world = world == null ? "world" : world.getName();
        this.x = location.getBlockX();
        this.y = location.getBlockY();
        this.z = location.getBlockZ();
        this.type = material;
    }

    public String key() {
        return this.world + " " + this.x + " " + this.y + " " + this.z;
    }

    public List<String> codeNames() {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (Material material : this.code) {
            arrayList.add(material.name());
        }
        return arrayList;
    }

    public void setCodeNames(List<String> list) {
        this.code.clear();
        if (list == null) {
            return;
        }
        for (String string : list) {
            Material material = Material.matchMaterial((String)string);
            if (material == null) continue;
            this.code.add(material);
        }
    }
}

