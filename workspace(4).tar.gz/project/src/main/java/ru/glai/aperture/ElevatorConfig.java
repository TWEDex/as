package ru.glai.aperture;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import ru.glai.aperture.Worlds;

public final class ElevatorConfig {
    public final String id;
    public final String worldName;
    public final Location button;
    public final Location statusLamp;
    public final List<Location> blinkLamps = new ArrayList<Location>();
    public final List<Location> shoreDoors = new ArrayList<Location>();
    public final List<Location> farShoreDoors = new ArrayList<Location>();
    public final List<Location> cabinDoorsWest = new ArrayList<Location>();
    public final List<Location> cabinDoorsEast = new ArrayList<Location>();
    public final Location cabinHomeA;
    public final Location cabinHomeB;
    public final Location cabinFarA;
    public final Location cabinFarB;
    public final int blinkDuration;
    public final int blinkPeriod;
    public final int boardDelay;
    public final int exitDelay;
    public final int departDelay;
    public final int checkPeriod;
    public final int movePeriod;
    public final String ambienceSound;
    public final String ambienceCategory;
    public final Location ambienceLocation;
    public final float ambienceVolume;
    public final float ambiencePitch;
    public final int ambiencePeriod;
    public final boolean moveSoundEnabled;
    public final String moveSound;
    public final float moveSoundVolume;
    public final float moveSoundPitch;
    public final int moveSoundPeriod;
    public final boolean blinkSoundEnabled;
    public final String blinkSound;
    public final float blinkSoundVolume;
    public final float blinkSoundPitch;
    public final boolean arrivalSoundEnabled;
    public final String arrivalSound;
    public final float arrivalSoundVolume;
    public final float arrivalSoundPitch;
    public final boolean smokeEnabled;
    public final String smokeParticle;
    public final int smokeCount;
    public final int smokePeriod;
    public final double smokeSpread;
    public final double smokeSpeed;

    public ElevatorConfig(String string, FileConfiguration fileConfiguration, String string2) {
        this.id = string;
        this.worldName = fileConfiguration.getString(string2 + ".world", "world");
        World world = Worlds.resolve(this.worldName);
        if (world == null) {
            throw new IllegalArgumentException("No world loaded");
        }
        this.button = ElevatorConfig.readLocation(fileConfiguration, string2 + ".button", world);
        this.statusLamp = ElevatorConfig.readLocation(fileConfiguration, string2 + ".status-lamp", world);
        ElevatorConfig.readLocations(fileConfiguration, string2 + ".blink-lamps", world, this.blinkLamps);
        ElevatorConfig.readLocations(fileConfiguration, string2 + ".shore-doors", world, this.shoreDoors);
        ElevatorConfig.readLocations(fileConfiguration, string2 + ".far-shore-doors", world, this.farShoreDoors);
        ElevatorConfig.readLocations(fileConfiguration, string2 + ".cabin-doors-west", world, this.cabinDoorsWest);
        ElevatorConfig.readLocations(fileConfiguration, string2 + ".cabin-doors-east", world, this.cabinDoorsEast);
        this.cabinHomeA = ElevatorConfig.readLocation(fileConfiguration, string2 + ".cabin-home-a", world);
        this.cabinHomeB = ElevatorConfig.readLocation(fileConfiguration, string2 + ".cabin-home-b", world);
        this.cabinFarA = ElevatorConfig.readLocation(fileConfiguration, string2 + ".cabin-far-a", world);
        this.cabinFarB = ElevatorConfig.readLocation(fileConfiguration, string2 + ".cabin-far-b", world);
        this.blinkDuration = fileConfiguration.getInt(string2 + ".blink-duration", 40);
        this.blinkPeriod = Math.max(1, fileConfiguration.getInt(string2 + ".blink-period", 10));
        this.boardDelay = fileConfiguration.getInt(string2 + ".board-delay", 60);
        this.exitDelay = fileConfiguration.getInt(string2 + ".exit-delay", 20);
        this.departDelay = fileConfiguration.getInt(string2 + ".depart-delay", 20);
        this.checkPeriod = Math.max(1, fileConfiguration.getInt(string2 + ".check-period", 5));
        this.movePeriod = Math.max(1, fileConfiguration.getInt(string2 + ".move-period", 1));
        this.ambienceSound = fileConfiguration.getString(string2 + ".ambience.sound", "tropicalberry:ambience.limbo");
        this.ambienceCategory = fileConfiguration.getString(string2 + ".ambience.category", "master");
        this.ambienceLocation = ElevatorConfig.readLocation(fileConfiguration, string2 + ".ambience.location", world);
        this.ambienceVolume = (float)Math.min(fileConfiguration.getDouble(string2 + ".ambience.volume", 10.0), 3.0);
        this.ambiencePitch = (float)fileConfiguration.getDouble(string2 + ".ambience.pitch", 2.0);
        this.ambiencePeriod = Math.max(20, fileConfiguration.getInt(string2 + ".ambience.period", 200));
        this.moveSoundEnabled = fileConfiguration.getBoolean(string2 + ".move-sound.enabled", true);
        this.moveSound = fileConfiguration.getString(string2 + ".move-sound.sound", "entity.minecart.riding");
        this.moveSoundVolume = (float)fileConfiguration.getDouble(string2 + ".move-sound.volume", 0.55);
        this.moveSoundPitch = (float)fileConfiguration.getDouble(string2 + ".move-sound.pitch", 0.7);
        this.moveSoundPeriod = Math.max(1, fileConfiguration.getInt(string2 + ".move-sound.period", 4));
        this.blinkSoundEnabled = fileConfiguration.getBoolean(string2 + ".blink-sound.enabled", true);
        this.blinkSound = fileConfiguration.getString(string2 + ".blink-sound.sound", "block.copper_bulb.turn_on");
        this.blinkSoundVolume = (float)fileConfiguration.getDouble(string2 + ".blink-sound.volume", 1.0);
        this.blinkSoundPitch = (float)fileConfiguration.getDouble(string2 + ".blink-sound.pitch", 1.0);
        this.arrivalSoundEnabled = fileConfiguration.getBoolean(string2 + ".arrival-sound.enabled", true);
        this.arrivalSound = fileConfiguration.getString(string2 + ".arrival-sound.sound", "block.note_block.bit");
        this.arrivalSoundVolume = (float)fileConfiguration.getDouble(string2 + ".arrival-sound.volume", 1.0);
        this.arrivalSoundPitch = (float)fileConfiguration.getDouble(string2 + ".arrival-sound.pitch", 1.0);
        this.smokeEnabled = fileConfiguration.getBoolean(string2 + ".smoke.enabled", true);
        this.smokeParticle = fileConfiguration.getString(string2 + ".smoke.particle", "SMOKE");
        this.smokeCount = Math.max(1, fileConfiguration.getInt(string2 + ".smoke.count", 3));
        this.smokePeriod = Math.max(1, fileConfiguration.getInt(string2 + ".smoke.period", 1));
        this.smokeSpread = fileConfiguration.getDouble(string2 + ".smoke.spread", 0.6);
        this.smokeSpeed = fileConfiguration.getDouble(string2 + ".smoke.speed", 0.01);
    }

    public World world() {
        return Worlds.resolve(this.worldName);
    }

    private static void readLocations(FileConfiguration fileConfiguration, String string, World world, List<Location> list) {
        ConfigurationSection configurationSection = fileConfiguration.getConfigurationSection(string);
        if (configurationSection != null) {
            for (String string2 : configurationSection.getKeys(false)) {
                list.add(ElevatorConfig.parseLocation(configurationSection.getString(string2), world));
            }
            return;
        }
        for (String string3 : fileConfiguration.getStringList(string)) {
            if (string3 == null || string3.trim().isEmpty()) continue;
            list.add(ElevatorConfig.parseLocation(string3, world));
        }
    }

    private static Location readLocation(FileConfiguration fileConfiguration, String string, World world) {
        String string2 = fileConfiguration.getString(string);
        if (string2 == null || string2.trim().isEmpty()) {
            throw new IllegalArgumentException("Missing position: " + string);
        }
        return ElevatorConfig.parseLocation(string2, world);
    }

    private static Location parseLocation(String string, World world) {
        String[] stringArray = string.trim().split("\\s+");
        if (stringArray.length < 3) {
            throw new IllegalArgumentException("Bad position: " + string);
        }
        return new Location(world, Double.parseDouble(stringArray[0]), Double.parseDouble(stringArray[1]), Double.parseDouble(stringArray[2]));
    }
}

