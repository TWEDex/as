package ru.glai.aperture;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

public final class DetectorData {
    public String world;
    public int x;
    public int y;
    public int z;
    public final List<Material> code = new ArrayList<Material>();
    public boolean active;

    public DetectorData(Location location) {
        World world = location.getWorld();
        this.world = world == null ? "world" : world.getName();
        this.x = location.getBlockX();
        this.y = location.getBlockY();
        this.z = location.getBlockZ();
    }

    public List<String> codeNames() {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (Material material : this.code) {
            arrayList.add(material.name());
        }
        return arrayList;
    }

    public void setCodeNames(List<String> list) {
        this.code.clear();
        if (list == null) {
            return;
        }
        for (String string : list) {
            Material material = Material.matchMaterial((String)string);
            if (material == null) continue;
            this.code.add(material);
        }
    }
}

