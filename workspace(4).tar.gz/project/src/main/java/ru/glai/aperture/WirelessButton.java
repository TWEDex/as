package ru.glai.aperture;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

public final class WirelessButton {
    public int number;
    public String name;
    public String world;
    public int x;
    public int y;
    public int z;
    public float yaw;
    public final List<Material> code = new ArrayList<Material>();
    public boolean modeLever;
    public boolean leverOffNoWrench;
    public int holdSeconds = 1;
    public boolean enabled = true;
    public boolean active;
    public long activeUntil = -1L;

    public WirelessButton(int n, String string, Location location, float f) {
        this.number = n;
        this.name = string;
        World world = location.getWorld();
        this.world = world == null ? "world" : world.getName();
        this.x = location.getBlockX();
        this.y = location.getBlockY();
        this.z = location.getBlockZ();
        this.yaw = f;
        this.modeLever = false;
        this.leverOffNoWrench = false;
    }

    public Location location(World world) {
        return new Location(world, (double)this.x, (double)this.y, (double)this.z);
    }

    public Location center(World world) {
        return new Location(world, (double)this.x + 0.5, (double)this.y + 0.5, (double)this.z + 0.5);
    }

    public Location topCenter(World world) {
        return new Location(world, (double)this.x + 0.5, (double)this.y + 1.2, (double)this.z + 0.5);
    }

    public boolean codeMatches(List<Material> list) {
        if (list == null || this.code.isEmpty() || list.size() != this.code.size()) {
            return false;
        }
        ArrayList<Material> arrayList = new ArrayList<Material>(this.code);
        ArrayList<Material> arrayList2 = new ArrayList<Material>(list);
        arrayList.sort(Comparator.comparingInt(Enum::ordinal));
        arrayList2.sort(Comparator.comparingInt(Enum::ordinal));
        for (int i = 0; i < arrayList.size(); ++i) {
            if (arrayList.get(i) == arrayList2.get(i)) continue;
            return false;
        }
        return true;
    }

    public List<String> codeNames() {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (Material material : this.code) {
            arrayList.add(material.name());
        }
        return arrayList;
    }

    public void setCodeNames(List<String> list) {
        this.code.clear();
        if (list == null) {
            return;
        }
        for (String string : list) {
            Material material = Material.matchMaterial((String)string);
            if (material == null) continue;
            this.code.add(material);
        }
    }
}

