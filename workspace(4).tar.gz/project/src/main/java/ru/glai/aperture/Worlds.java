package ru.glai.aperture;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.World;

public final class Worlds {
    private static final Set<String> warned = new HashSet<String>();

    private Worlds() {
    }

    public static World exact(String string) {
        if (string == null) {
            return null;
        }
        return Bukkit.getWorld((String)string);
    }

    public static World resolve(String string) {
        World world;
        World world2 = Worlds.exact(string);
        if (world2 != null) {
            return world2;
        }
        List list = Bukkit.getWorlds();
        World world3 = world = list.isEmpty() ? null : (World)list.get(0);
        if (world != null && warned.add(String.valueOf(string))) {
            Bukkit.getLogger().warning("[ApertureScience] world '" + string + "' not found, using '" + world.getName() + "' instead");
        }
        return world;
    }
}

