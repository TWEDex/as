package ru.glai.aperture;

import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public final class Items {
    public static final String KIND_BUTTON = "button";
    public static final String KIND_WRENCH = "wrench";
    public static final String KIND_DETECTOR = "detector";
    public static final String KIND_PORTAL_GUN = "portal_gun";
    public static final String KIND_PUMP = "pump";
    public static final String KIND_GEN_NEIR = "gen_neir";
    public static final String KIND_SUBMITTER = "submitter";
    public static final String KIND_PIPE = "pipe";
    public static final String KIND_ACID = "acid";
    private final Plugin plugin;
    private final NamespacedKey kindKey;

    public Items(Plugin plugin) {
        this.plugin = plugin;
        this.kindKey = new NamespacedKey(plugin, "aperture_item");
    }

    public ItemStack createPortalGun() {
        ItemStack itemStack = this.buildCrossbow();
        this.tag(itemStack, KIND_PORTAL_GUN);
        return itemStack;
    }

    public NamespacedKey kindKey() {
        return this.kindKey;
    }

    public String kindOf(ItemStack itemStack) {
        if (itemStack == null || !itemStack.hasItemMeta()) {
            return null;
        }
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta == null) {
            return null;
        }
        return (String)itemMeta.getPersistentDataContainer().get(this.kindKey, PersistentDataType.STRING);
    }

    public boolean is(ItemStack itemStack, String string) {
        String string2 = this.kindOf(itemStack);
        return string2 != null && string2.equals(string);
    }

    public ItemStack create(String string) {
        switch (string) {
            case "button": {
                return this.tag(this.build(Material.CRIMSON_BUTTON, Component.text((String)"\u041f\u043e\u0440\u0442\u0430\u043b\u044c\u043d\u0430\u044f \u043a\u043d\u043e\u043f\u043a\u0430", (TextColor)NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false), List.of(Component.text((String)"\u041f\u043e\u0441\u0442\u0430\u0432\u044c \u0431\u043b\u043e\u043a, \u0437\u0430\u0442\u0435\u043c \u043d\u0430\u0441\u0442\u0440\u043e\u0439 \u043a\u043b\u044e\u0447\u043e\u043c", (TextColor)NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false))), KIND_BUTTON);
            }
            case "wrench": {
                return this.tag(this.build(Material.GOLDEN_AXE, Component.text((String)"\u041a\u043b\u044e\u0447 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438", (TextColor)NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false), List.of(Component.text((String)"\u041f\u041a\u041c \u043f\u043e \u043a\u043d\u043e\u043f\u043a\u0435 \u0438\u043b\u0438 \u0434\u0435\u0442\u0435\u043a\u0442\u043e\u0440\u0443", (TextColor)NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false))), KIND_WRENCH);
            }
            case "detector": {
                return this.tag(this.build(Material.DAYLIGHT_DETECTOR, Component.text((String)"\u0414\u0435\u0442\u0435\u043a\u0442\u043e\u0440", (TextColor)NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false), List.of(Component.text((String)"\u0412\u044b\u0434\u0430\u0435\u0442\u0441\u044f \u0442\u043e\u043b\u044c\u043a\u043e \u043a\u043e\u043c\u0430\u043d\u0434\u043e\u0439", (TextColor)NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false))), KIND_DETECTOR);
            }
            case "portal_gun": {
                return this.createPortalGun();
            }
            case "pump": {
                return this.tag(this.build(Material.DISPENSER, Component.text((String)"\u041d\u0430\u0441\u043e\u0441 \u043d\u0435\u0439\u0440\u043e\u0442\u043e\u043a\u0441\u0438\u043d\u0430", (TextColor)NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false), List.of(Component.text((String)"\u0421\u0430\u043c \u0433\u0435\u043d\u0435\u0440\u0438\u0440\u0443\u0435\u0442 \u043d\u0435\u0439\u0440\u043e\u0442\u043e\u043a\u0441\u0438\u043d, \u0440\u0430\u0431\u043e\u0442\u0430\u0435\u0442 \u043e\u0442 \u0433\u0440\u0443\u043f\u043f\u044b", (TextColor)NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false))), KIND_PUMP);
            }
            case "acid": {
                return this.tag(this.build(Material.WATER_BUCKET, Component.text((String)"\u041a\u0438\u0441\u043b\u043e\u0442\u0430", (TextColor)NamedTextColor.DARK_GREEN).decoration(TextDecoration.ITALIC, false), List.of(Component.text((String)"\u0411\u043e\u043b\u043e\u0442\u043d\u0430\u044f \u0432\u043e\u0434\u0430, \u0441\u043c\u0435\u0440\u0442\u0435\u043b\u044c\u043d\u043e \u043e\u043f\u0430\u0441\u043d\u0430", (TextColor)NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false))), KIND_ACID);
            }
        }
        return null;
    }

    private static Component plain(String text, NamedTextColor color) {
        return Component.text(text).color(color).decoration(TextDecoration.ITALIC, false);
    }

    private ItemStack buildCrossbow() {
        ItemStack itemStack = new ItemStack(Material.CROSSBOW);
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta != null) {
            itemMeta.displayName(plain("Портальная пушка", NamedTextColor.GOLD));
            itemMeta.lore(new ArrayList<Component>(List.of(
                    plain("ЛКМ — оранжевый портал", NamedTextColor.GRAY),
                    plain("ПКМ — синий портал", NamedTextColor.GRAY),
                    plain("ПКМ по кубику/существу — взять, ЛКМ — бросить", NamedTextColor.DARK_GRAY))));
            itemMeta.setUnbreakable(true);
            itemStack.setItemMeta(itemMeta);
        }
        return itemStack;
    }

    private ItemStack build(Material material, Component component, List<Component> list) {
        ItemStack itemStack = new ItemStack(material);
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta != null) {
            itemMeta.displayName(component);
            itemMeta.lore(new ArrayList<Component>(list));
            itemStack.setItemMeta(itemMeta);
        }
        return itemStack;
    }

    private ItemStack tag(ItemStack itemStack, String string) {
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta != null) {
            itemMeta.getPersistentDataContainer().set(this.kindKey, PersistentDataType.STRING, string);
            itemStack.setItemMeta(itemMeta);
        }
        return itemStack;
    }

    public List<String> kinds() {
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add(KIND_BUTTON);
        arrayList.add(KIND_WRENCH);
        arrayList.add(KIND_DETECTOR);
        arrayList.add(KIND_PORTAL_GUN);
        arrayList.add(KIND_PUMP);
        arrayList.add(KIND_ACID);
        return arrayList;
    }
}

